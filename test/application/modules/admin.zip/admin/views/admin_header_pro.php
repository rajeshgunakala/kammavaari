<!doctype html>
<html lang="en">

<head>
 
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css"/>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.3/css/select2.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/intl-tel-input/8.4.6/css/intlTelInput.css">
    <link href="http://fonts.googleapis.com/css?family=Poppins:300,400,500,600,700&amp;ubset=devanagari,latin-ext" rel="stylesheet">
    <link href="http://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i,800,800i&amp;subset=cyrillic,cyrillic-ext,greek,greek-ext,latin-ext,vietnamese" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fancybox/3.1.20/jquery.fancybox.min.css">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/flexslider/2.5.0/flexslider.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bxslider/4.2.12/jquery.bxslider.min.css">
    <link href="<?php echo site_url();?>css/font-awesome.css" rel="stylesheet" type="text/css" media="all" />
    <link rel="stylesheet" href="<?php echo site_url(); ?>assets/css/custom101.css?v=<?php echo time();?>"/>
     <link rel="stylesheet" href="<?php echo site_url(); ?>assets/css/admin_new.css?v=<?php echo time();?>"/>
      <link rel="stylesheet" href="<?php echo site_url(); ?>css/style_new.css?v=<?php echo time();?>"/>
      <link rel="stylesheet" href="<?php echo site_url(); ?>assets/css/cust-reset.css?v=<?php echo time();?>" />
    <style>
        a.ct-newsletter-close.ct-sliderPop-close {
            position: absolute;
            right: 0;
            top: 10px;
        }
        a.ct-newsletter-close.ct-sliderPop-close img{
            padding: 5px;
            width: 50% !important;
            background: #333;
            border-radius: 50%;
        }
        .ct-sliderPop .inner{
        margin-top: 0px;
        }

        .ct-sliderPop-container.open.slides {
            border: 6px solid #17a554;
            width: 45%;
            background: #333;
        }
        /* Popup CSS Below */
.flexslider .slides img {
  margin: 0 auto;
  max-width: 20em;
}
.ct-sliderPop {
 
 /* width:650px !important;
  height:650px !important;*/
}
.ct-sliderPop > .inner > .cow-map-img {
  margin-top: 75px;
}
.ct-sectional .col-lg-5.col-lg-offset-1 > img {
  cursor: pointer;
  border-radius: 50%;
}
.ct-sliderPop .inner {
  color: #fff;
  /*margin-top: 110px;*/
}
.map-white-border {
  border-bottom: 1px solid #fff;
  width: 30%;
  margin: 50px auto;
}
.ct-sliderPop-container {
  display: none;
  left: 0px;
  opacity: 0;
  top: 0px;
  z-index: 9998;
}
.ct-sliderPop-container.open {
  animation-duration: 0.35s;
  animation-fill-mode: both;
  animation-name: fadeIn;
  display: block;
}
.ct-sliderPop-container {
  overflow:hidden;
  display: inline-table;
  max-width: 650px !important;
  left: 50%;
  position: fixed !important; /* Required to override style inline style added by Flexslider */
  text-align: center;
  top: 53%;
  transform: translate(-50%, -50%);
  z-index: 9997;
  opacity: 2;
}
.ct-sliderPop-slide1 {
  background: #333 none repeat scroll 0% 0%;
}
.ct-sliderPop-slide2 {
  background: #333 none repeat scroll 0% 0%;
}
.ct-sliderPop-slide3 {
  background: #333 none repeat scroll 0% 0%;
}.sliderPop.flexslider:hover .flex-direction-nav .flex-prev

.ct-sliderPop .inner .ct-sliderPop-close {
  display: inline-block;
  margin: -1% auto 30px;
  transition: opacity 0.25s ease-in-out 0s;
  width: 75px;
}
.ct-sliderPop h1 {
  font-family: "nimbus-sans-condensed", sans-serif;
  font-size: 75px;
  font-weight: 700;
  line-height: 1;
  text-transform: uppercase;
  margin-top: 0;
}
.ct-sliderPop h1 span {
  font-family: 'coquette', fantasy;
  text-transform: capitalize;
  line-height: 0.8;
}
.ct-sliderPop h2,
.ct-sliderPop p {
  font-family: "nimbus-sans-condensed", sans-serif;
  font-size: 30px;
  font-weight: 400;
  line-height: 1;
}
.ct-sliderPop .fa {
    font-size: 84px;
    margin-bottom: 10px;
}
.ct-sliderPop p {
  font-size: 18px;
  padding-bottom: 30px;
  width: 70%;
  line-height: 24px;
  margin: 0 auto;
}
.ct-sliderPop-container .flex-direction-nav a {
  overflow: visible;
}
.flex-direction-nav a,
.flex-direction-nav a.flex-next::before,
.flex-direction-nav a.flex-prev::before {
  color: #fff !important;
}
.flexslider .slides img {
  width: auto !important;
}
.sliderPop-close {
  width: 60px;
}

.flexslider .slides img{
  max-height: 35em!important;
}
.all-images img{
  cursor:pointer;
}

/* =================================
  # Media Queries 
================================= */
/*@media (max-width: 767px){
  .ct-sliderPop {
    height: 500px;
    max-width: 500px !important;
  }
  .ct-sliderPop > .inner > .cow-map-img {
    margin-top: 50px;
  }
  .ct-sliderPop-description span {
    font-size: 50px;
  }
  .ct-sliderPop h2,
  .ct-sliderPop-description {
    font-size: 20px;
  }
  .ct-sliderPop h2 {
    line-height: 0.2;
  }
  .ct-sliderPop-description {
    padding-bottom: 0;
  }
  .ct-sliderPop .inner {
    margin-top: 10px;
  }
  .ct-sliderPop-description .map-fontSize {
    font-size: 80px;
  }
}*/
    </style>
    <title>Welcome to Kammavaari.com</title>
    
    <script type="text/javascript">         

        function showform(){
            if (document.getElementById("thru_outside").checked)           
            {
                document.getElementById("outside").style.display="block";
                document.getElementById("manashaadi").style.display="none";
                
            }
           
         else if (document.getElementById("thru_manashaadi").checked)

            {                
                document.getElementById("outside").style.display="none";
                document.getElementById("manashaadi").style.display="block";
                

            }
        } 
    </script>


</head>

<body>
<nav class="navbar navbar-expand-md navbar-bg">
   <button class="navbar-toggler" data-toggle="collapse" data-target="#collapse_target">
   <span class="navbar-toggler-icon"> </span>
   </button>
   <div class="collapse navbar-collapse" id="collapse_target">
      <ul class="navbar-nav">
         <li class="nav-item">
            <!-- <a href="<?php echo site_url(); ?>admin/admin_home?msg=back" class="nav-link">Dashboard</a>   -->
            <a href="<?php echo site_url(); ?>admin/MyDashboard?msg=back" class="nav-link">Dashboard</a>
         </li>
         <li class="nav-item dropdown">
            <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown" data-target="#dropdown_target"> My Account </a>
            <span class="caret"></span>
            <div class="dropdown-menu" aria-labelledby="dropdown_target">
               <a href="<?php echo site_url(); ?>register" class="dropdown-item">Free Registrations</a>
               <div class="dropdown-divider"></div>
               <a href="<?php echo site_url(); ?>admin/basic_search" class="dropdown-item">Search</a>
               <div class="dropdown-divider"></div>
               <!--<a href="<?php echo site_url(); ?>admin/express_interest" class="dropdown-item">Shared Profiles</a>-->
               <a href="<?php echo site_url(); ?>admin/express_interest?exint=1" class="dropdown-item">Express Interest</a>
               <div class="dropdown-divider"></div>
               <a href="<?php echo site_url(); ?>admin/service_report" class="dropdown-item" >Service Reports </a>
               <div class="dropdown-divider"></div>
               <!-- <a href="<?php echo site_url(); ?>admin/admin_payment" class="dropdown-item">Payment Details</a> -->
               <a href="<?php echo site_url(); ?>admin/enterpayment" class="dropdown-item">Payment Details</a>
            </div>
         </li>
         <li class="nav-item dropdown">
            <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown" data-target="#dropdown_target">Profiles</a>
            <span class="caret"></span>
            <div class="dropdown-menu" aria-labelledby="dropdown_target">
               <a href="<?php echo site_url(); ?>admin/admin_pv" class="dropdown-item">Profile Validation</a>
               <div class="dropdown-divider"></div>
               <a href="<?php echo site_url(); ?>admin/list_inactivate_profiles" class="dropdown-item">Inactive Profiles List</a>
               <div class="dropdown-divider"></div>
               <a href="<?php echo site_url(); ?>admin/inactivate_profile" class="dropdown-item">Inactivate Profile</a>
               <div class="dropdown-divider"></div>
               <a href="<?php echo site_url(); ?>admin/admin_del_profiles" class="dropdown-item">Delete/Settle Profile</a>
            </div>
         </li>
         <li class="nav-item dropdown">
            <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown" data-target="#dropdown_target"> Masters </a>
            <span class="caret"></span>
            <div class="dropdown-menu" aria-labelledby="dropdown_target">
               <a href="#" class="dropdown-item">CMS</a>
               <div class="dropdown-divider"></div>
               <a href="#" class="dropdown-item">Religious Details</a>
               <div class="dropdown-divider"></div>
               <a href="#" class="dropdown-item">Residence Details</a>
               <div class="dropdown-divider"></div>
               <a href="#" class="dropdown-item">Education Details</a>
            </div>
         </li>
         <li class="nav-item dropdown">
            <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown" data-target="#dropdown_target"> Maintainence </a>
            <span class="caret"></span>
            <div class="dropdown-menu" aria-labelledby="dropdown_target">
               <?php if($this->session->userdata('type')=='admin'){?>
               <a href="<?php echo site_url(); ?>admin/profile_assign" class="dropdown-item">Un Assigned Profiless</a>
               <div class="dropdown-divider"></div>
               <a href="<?php echo site_url(); ?>admin/addeditstaff" class="dropdown-item">Add/Edit Staff</a>
               <div class="dropdown-divider"></div>
               <?php } ?>
               <a href="<?php echo site_url(); ?>admin/call_history" class="dropdown-item">Marketing Slide</a>
               <div class="dropdown-divider"></div>
               <a href="<?php echo site_url(); ?>admin/marketing_reminders" class="dropdown-item">Marketing Reminder</a>
               <div class="dropdown-divider"></div>
               <!-- <a href="<?php echo site_url(); ?>admin/admin_photos" class="dropdown-item">Photos</a> -->
               <a href="<?php echo site_url(); ?>admin/photoshp_photos" class="dropdown-item">Photos</a>
               <div class="dropdown-divider"></div>
               <a href="<?php echo site_url();?>admin/emailtemplates" class="dropdown-item">Email Templates</a> 
            </div>
         </li>
         <li class="nav-item dropdown">
            <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown" data-target="#dropdown_target"> Reports </a>
            <span class="caret"></span>
            <div class="dropdown-menu" aria-labelledby="dropdown_target">
               <a href="#" class="dropdown-item">Registrations</a>
            </div>
         </li>
      </ul>
   </div>
   <div>
      <ul class="navbar-nav">
         <li class="nav-item">
            <span class="nav-link"><?php echo ucfirst($this->session->userdata('uname'));?></span>
         </li>
         <li class="nav-item">
            <a href="<?php echo site_url(); ?>admin/logout" class="nav-link">Logout</a>
         </li>
      </ul>
   </div>
</nav>
            
    