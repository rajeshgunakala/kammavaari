<style>
.row {
	margin-bottom: 5px;
	font-size: 1vw;
}
</style>
<div class="row">
  <div class="col-md-12">
    <div class="card" style="border-style: none;background-color: white">
      <div class="card-header" style="border-style: none;background-color: white">
        <button href="#display_form" class="btn" data-toggle="collapse">Inactive/Deleted/Settled Profiles</button>
      </div>
    </div>
  </div>
</div>
<div style="width: 87%;float: left;">
  <h5 style="text-align: center;font-size:22px;text-decoration: underline;"><?php echo $tot_rec; ?> profiles found</h5>
</div>

<div class="limiter">
  <div class="container-table100">
	  <form type="get" name="inactive_search">
	  <div style="width:1200px;float:left; font-size:1vw; margin:0px;">
				<div style="float:left; margin-right:1vw;" class="<?php if($this->session->userdata('type')=='staff') echo 'dn';?>">
					<div class="form-group form-inline">
						<label class="form-group">Employee:</label>
						<select class="form-group form-control" id="emp_drop_down"> </select>
					</div>
				</div>
				<div style="float:left; margin-right:1vw;">
					<div class="form-group form-inline">
						<label class="form-group pr-10">Profile Id: </label>
						<input type="text" name="profile_id" id="profile_id" class="form-group form-control" value="<?php echo $this->input->get("profile_id"); ?>"  style="width:100px;" >
					</div>
				</div>
				<div style="float:left; margin-right:1vw;">
					<div class="form-group form-inline">
						<label class="form-group pr-10">Surname: </label>
						<input type="text" name="surname" id="surname" value="<?php echo $this->input->get("surname"); ?>" class="form-group form-control" >
					</div>
				</div>
				<div style="float:left; margin-right:1vw;">
					<div class="form-group form-inline">
						<label class="form-group pr-10">Name: </label>
						<input type="text" name="firstname" id="firstname" value="<?php echo $this->input->get("firstname"); ?>" class="form-group form-control" >
					</div>
				</div>
				<div style="float:left;">
					<div class="form-group form-inline">
						<button class="form-group form-control btn btn-warning" id="search_prof_emp"> Search </button> &nbsp;<a href="<?php echo base_url()."admin/list_inactivate_profiles" ?>" class="form-group form-control btn btn-info" id="search_prof_emp"> Reset </a>
					</div>
				</div>
			</div>
			</form>
			
    <div class="wrap-table100">
      <div class="table100"> <?php echo $this->pagination->create_links(); ?>
        <table>
          <div class="table100-head">
            <thead style="text-align: left;">
              <tr>
                <th class="cell6" style="width:1%">S No.</th>
                <th class="cell8" style="width:5%">Action</th>
                <th class="cell18" style="width:5%">Profile ID</th>
                <th class="cell10" style="width:5%">Surname</th>
                <th class="cell20" style="width:15%">Name</th>
                <th class="cell5" style="width:5%">Activate Date</th>
                <th class="cell5" style="width:10%">Reason</th>
                <th class="cell17" style="width:10%">Reminder Before</th>
              </tr>
            </thead>
            <tbody style="text-align: left;">
              <?php $slno = $this->uri->segment(3, 0);
                                   foreach ($sub_rec as $value) {	?>
              <tr>
                <td style="width:1%; text-align:center;" class="cell5"><?php echo ++$slno ?></td>
                <td class="cell4" style="width:5%"><a href="javascript:void(0)" onclick="activateProfile(<?php echo $value['id']; ?>)"><button class="btn btn-warning fs12">Activate</button></a></td>
                <td class="cell12" style="width:10%;color:#00818e;"><?php if ($value["payment_status"] == "paid") {  ?>
                  <a style="color:#1bb73f;font-weight: 600;color:#00818e;" target="_blank" href="<?php echo site_url(); ?>admin/admin_search/viewprofile/<?php echo $value['id']; ?>"> <?php echo stripcslashes($value['profile_id']); ?></a>
                  <?php } else { ?>
                  <a style="color:#00818e;" target="_blank" href="<?php echo site_url(); ?>admin/admin_search/viewprofile/<?php echo $value['id']; ?>"> <?php echo stripcslashes($value['profile_id']); ?></a>
                  <?php } ?>
                  
                  <td class="cell10" style="width:5%"><?php echo stripcslashes($value['last_name']); ?></td>
                <td class="cell20" style="width:15%"><span class="<?php echo $vipconfi;?>"></span><?php echo stripcslashes($value['first_name']); ?></td>
                <td class="cell5" style="width:5%"><?php echo ucfirst(stripcslashes($value['activate_date'])); ?></td>
                <td class="cell5" style="width:10%"><?php echo stripcslashes($value['inactive_reason']); ?></td>
                <td class="cell17" style="width:10%"><?php echo stripcslashes($value['before_remind']); ?></td>                
              </tr>
              <?php } ?>
            </tbody>
          </div>
        </table>
      </div>
    </div>
  </div>
</div>
<script type="text/javascript">
function activateProfile(id) {
	var confirmmessage="Would you like to activate profile?";
	var successalert="Profile activated successfully";	
	if (confirm(confirmmessage)) {
		$.ajax({
		  url: "<?php echo base_url();?>admin/Admin_ap/activateProfile",
		  type: "POST",
		  data: {'id':id},
		  success: function(data)
		  {
			alert(successalert);  
			 location.reload(); 
		  }
				
		});
	} 
}
</script>
