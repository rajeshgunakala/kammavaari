
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>




<!-- ======================= JQuery libs =========================== -->
        <!-- <script type="text/javascript" src="<?php echo site_url();?>design/js/jquery-1.8.2.min.js"></script>         -->
        <!-- Bootstrap.js-->
        <script src="<?php echo site_url();?>design/js/bootstrap.js" type="text/javascript"></script>
        <script src="<?php echo site_url();?>design/js/bootstrap-select.min.js" type="text/javascript"></script>
        <script type="text/javascript" src="<?php echo site_url();?>design/js/modernizr.custom.26633.js"></script>
        <!-- Gallery -->
        <script type="text/javascript" src="<?php echo site_url();?>design/js/jquery.gridrotator.js"></script>        
        <!-- Slider -->
        <script type="text/javascript" src="<?php echo site_url();?>design/js/responsiveslides.min.js"></script>        
        <!-- Controls styles -->
        <script type="text/javascript" src="<?php echo site_url();?>design/js/jquery.jstyling.min.js"></script>        
        <!-- Video Responsive-->
        <script src="<?php echo site_url();?>design/js/jquery.fitvids.min.js" type="text/javascript"></script>        
        <!-- Easing plugin ( optional ) -->
        <script src="<?php echo site_url();?>design/js/easing.js" type="text/javascript"></script>        
        <!-- UItoTop plugin -->
        <script src="<?php echo site_url();?>design/js/jquery.ui.totop.min.js" type="text/javascript"></script>        
        <!--  Waypoints --> 
        <script type="text/javascript" src="<?php echo site_url();?>design/js/waypoints.min.js"></script>        
        <!-- Template custom script  -->
        <script type="text/javascript" src="<?php echo site_url();?>design/js/jquery-func.js"></script>

        <script src="https://cdnjs.cloudflare.com/ajax/libs/flexslider/2.5.0/jquery.flexslider-min.js"></script>
	<!-- ======================= End JQuery libs ======================= -->
    
    
        <script type="text/javascript">
        $(document).ready(function() {
			
			$('.btnviewsaform').on('click',function(){
				
				var $this=$(this);
				 $.ajax({
                              url: "<?php echo base_url();?>admin/viewsaform",
                              type: "POST",
                              data: {'uid':$this.attr('rel1')},
                              success: function(data)
                              {
								$('.vsaform').html(data);
							  }
                                    
                            });
							
				});
				
				
			$('.btnviewcontacts').on('click',function(){
				
				var $this=$(this);
				 $.ajax({
                              url: "<?php echo base_url();?>admin/viewcontactsinfo",
                              type: "POST",
                              data: {'uid':$this.attr('rel1')},
                              success: function(data)
                              {
								$('.vcontacts').html(data);
							  }
                                    
                            });
							
				});
				
			$('.btnmarketingticket').on('click',function(){
				
				var $this=$(this);
				 $.ajax({
                              url: "<?php echo base_url();?>admin/marketingticketshistory",
                              type: "POST",
                              data: {'uid':$this.attr('rel1')},
                              success: function(data)
                              {
								$('.mtickethistory').html(data);
							  }
                                    
                            });
							
				});
				
			$('.tickethistory').on('click',function(){
				var $this=$(this);
				 $.ajax({
                              url: "<?php echo base_url();?>admin/getrmticketnotes",
                              type: "POST",
                              data: {'intid':$('.txt_intid').val(),'rmid':$this.attr('id'), 'uid':$this.attr('rel1')},
                              success: function(data)
                              {
								$('.tickethistorynotes').html(data);
							  }
                                    
                            });
				});
				
		$('.tickettextclear').on('click',function(){
			
			$('.txt_desc').val('');
			$('.txt_rmid').val($(this).attr('id'));
			$('.txt_uid').val($(this).attr('rel1'));
			
			});
		$('.submitticketnotes').on('click',function(){
			
			if($.trim($('.txt_desc').val())=='')
			{
				$('.txt_desc').val('');
				$('.txt_desc').focus();
				return false;
			}
			/*console.log($('.txt_desc').val());
			console.log($('.txt_rmid').val());
			console.log($('.txt_uid').val());*/
			
			 $.ajax({
                              url: "<?php echo base_url();?>admin/savermticketnotes",
                              type: "POST",
                              data: {'intid':$('.txt_intid').val(),'notes':$.trim($('.txt_desc').val()), 'rmid':$('.txt_rmid').val(), 'uid':$('.txt_uid').val()},
                              success: function(data)
                              {
								  //$('#IDModal').modal('toggle');
								  $('.submitticketnotesclose').click();
								//  $('.notes_'+$('.txt_uid').val()).find('li.createdate').html(data);
								 // $('.notes_'+$('.txt_uid').val()).find('li.createnotes').html($.trim($('.txt_desc').val()));
								$('.notes_'+$('.txt_uid').val()).append('<li><div class="CPPrifileLeftProfileIntractionLeft">'+data+'</div><div class="CPPrifileLeftProfileIntractionDivider">: </div><div class="CPPrifileLeftProfileIntractionRight">'+$.trim($('.txt_desc').val())+'</div></li>');
								//alert(successalert);  
								// location.reload(); 
							  }
                                    
                            });
			});	
 var confirmmessage="Would you like to process this action?";
 var successalert="Action successfully processed";
$('.sel_bothsideinterest').change(function(){
var $this=$(this);
if(!$this.val())
{
	return false;
}
	if (confirm(confirmmessage)) {
		//$(this).children(":selected").attr("id")
   
   $.ajax({
                              url: "<?php echo base_url();?>admin/bothsideinterest_action",
                              type: "POST",
                              data: {'intid':$this.children(":selected").attr("id"), 'action':$this.val()},
                              success: function(data)
                              {
								alert(successalert);  
								 location.reload(); 
							  }
                                    
                            });
							
							
	
		} 
	});
                $('.all-images img').on('click', function() {
                        $('.sliderPop').show();
                        $('.ct-sliderPop-container').addClass('open');
                        $('.sliderPop').addClass('flexslider');
                        $('.sliderPop .ct-sliderPop-container').addClass('slides');

                        $('.sliderPop').flexslider({
                                selector: '.ct-sliderPop-container > .ct-sliderPop',
                                slideshow: false,
                                controlNav: false,
                                controlsContainer: '.ct-sliderPop-container'
                        });
                });

                $(document).on('click','.ct-sliderPop-close', function(){
                        $('div.sliderPop').hide();
                        $('.ct-sliderPop-container').removeClass('open');
                        $('.sliderPop').removeClass('flexslider');
                        $('.sliderPop .ct-sliderPop-container').removeClass('slides');
                });

                // $('#modalData div a.ct-sliderPop-close').click(function() {
                //         $('div.sliderPop').hide();
                //         $('.ct-sliderPop-container').removeClass('open');
                //         $('.sliderPop').removeClass('flexslider');
                //         $('.sliderPop .ct-sliderPop-container').removeClass('slides');
                // });

                $(".whatsapp_icon").on('click', function() {
                        var id =$(this).attr('id');
                        // alert(id);
                        $('.sliderPop_'+id).show();
                        $('.ct-sliderPop-container').addClass('open');
                        $('.sliderPop_'+id).addClass('flexslider');
                        $('.sliderPop_'+id+' .ct-sliderPop-container').addClass('slides');
                        $('.sliderPop_'+id).flexslider({
                                selector: '.ct-sliderPop-container > .ct-sliderPop',
                                slideshow: false,
                                controlNav: false,
                                controlsContainer: '.ct-sliderPop-container'
                        });
                });
                $('.close_info').on('click', function() {
                        var id = $(this).attr('id');
                        // alert(id);
                        //subpop_close_wicon_984
                        var fid= id.substring(10, id.length);
                        // alert(fid);
                        $('.sliderPop_'+fid).hide();
                        $('.ct-sliderPop-container').removeClass('open');
                        $('.sliderPop_'+fid).removeClass('flexslider');
                        $('.sliderPop_'+fid + ' .ct-sliderPop-container').removeClass('slides');
                });

        });
</script>


<div class="modal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" id="myModal_marketingtickethistory">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title"><b class="fs20">Marketing Ticket History</b></h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
      </div>
      <div class="modal-body mtickethistory">
        <p></p>
      </div>
      <div class="modal-footer"> 
        <!--button type="button" class="btn btn-primary">Save changes</button-->
        <button type="button" class="btn btn-secondary btn-xs" data-dismiss="modal">Close</button>
      </div>
    </div>
  </div>
</div>


</body>

</html>