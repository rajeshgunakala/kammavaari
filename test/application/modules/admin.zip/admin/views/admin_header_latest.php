<!doctype html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">


 <!-- App css -->
        <link href="<?php echo site_url(); ?>assets/kamma/css/bootstrap.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo site_url(); ?>assets/kamma/css/icons.min.css" rel="stylesheet" type="text/css" />
        <link href="<?php echo site_url(); ?>assets/kamma/css/theme.min.css" rel="stylesheet" type="text/css" />
		<link href="<?php echo site_url(); ?>assets/kamma/css_border-radius.scss" rel="stylesheet" type="text/css" />
		<script type="text/javascript" src="<?php echo site_url(); ?>assets/kamma/js/jquery.min.js"></script>
    
    <title>Welcome to Kammavaari.com</title>
    <script type="text/javascript">
        function showform() {


            if (document.getElementById("thru_outside").checked)

            {
                document.getElementById("outside").style.display = "block";
                document.getElementById("manashaadi").style.display = "none";

            } else if (document.getElementById("thru_manashaadi").checked)

            {
                document.getElementById("outside").style.display = "none";
                document.getElementById("manashaadi").style.display = "block";


            }
        }
    </script>
<style>
.row {
	margin-right: 0;
    margin-left: 0;
}
</style>

</head>

<body>
        <!-- Begin page -->
        <div id="layout-wrapper">

            <div class="main-content">

                <header id="page-topbar">
                    <div class="navbar-header">
                        <!-- LOGO -->
                        <div class="navbar-brand-box d-flex align-items-left">
                            <a href="index.html" class="logo">
                                <span>
                                    <img src="<?php echo base_url(); ?>images/logo.png" alt="" height="50">
                                </span>
                                <i>
                                    <img src="<?php echo base_url(); ?>images/logo.png" alt="" height="24">
                                </i>
                            </a>

                            <button type="button" class="btn btn-sm mr-2 font-size-16 d-lg-none header-item waves-effect waves-light" data-toggle="collapse" data-target="#topnav-menu-content">
                                <i class="fa fa-fw fa-bars"></i>
                            </button>
                        </div>
        
                        <div class="d-flex align-items-center">
                            <div class="dropdown d-inline-block">
                                <button type="button" class="btn header-item noti-icon waves-effect waves-light" id="page-header-notifications-dropdown"
                                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <i class="mdi mdi-bell"></i>
									
                                    <span class="badge badge-danger badge-pill"><?php echo $notifications["login_count"]; ?></span>
                                </button>
                                <div class="dropdown-menu dropdown-menu-lg dropdown-menu-right p-0"
                                    aria-labelledby="page-header-notifications-dropdown">
                                    <div class="p-3">
                                        <div class="row align-items-center">
                                            <div class="col">
                                                <h6 class="m-0"><a href="#"> Notifications </a></h6>
                                            </div>
                                            <div class="col-auto">
                                                <a href="<?php echo base_url(); ?>admin/notifications" class="small"> View All</a>
                                            </div>
                                        </div>
                                    </div>
                              <!--      <div data-simplebar style="max-height: 230px;">
                                        <a href="" class="text-reset notification-item">
                                            <div class="media">
                                                <img src="<?php echo base_url(); ?>assets/kamma/images/users/avatar-2.jpg"
                                                    class="mr-3 rounded-circle avatar-xs" alt="user-pic">
                                                <div class="media-body">
                                                    <h6 class="mt-0 mb-1">Samuel Coverdale</h6>
                                                    <p class="font-size-12 mb-1">You have new follower on Instagram</p>
                                                    <p class="font-size-12 mb-0 text-muted"><i class="mdi mdi-clock-outline"></i> 2 min ago</p>
                                                </div>
                                            </div>
                                        </a>
                                        <a href="" class="text-reset notification-item">
                                            <div class="media">
                                                <div class="avatar-xs mr-3">
                                                    <span class="avatar-title bg-success rounded-circle">
                                                        <i class="mdi mdi-cloud-download-outline"></i>
                                                    </span>
                                                </div>
                                                <div class="media-body">
                                                    <h6 class="mt-0 mb-1">Download Available !</h6>
                                                    <p class="font-size-12 mb-1">Latest version of admin is now available. Please download here.</p>
                                                    <p class="font-size-12 mb-0 text-muted"><i class="mdi mdi-clock-outline"></i> 4 hours ago</p>
                                                </div>
                                            </div>
                                        </a>
                                        <a href="" class="text-reset notification-item">
                                            <div class="media">
                                                <img src="<?php echo base_url(); ?>assets/kamma/images/users/avatar-3.jpg"
                                                    class="mr-3 rounded-circle avatar-xs" alt="user-pic">
                                                <div class="media-body">
                                                    <h6 class="mt-0 mb-1">Victoria Mendis</h6>
                                                    <p class="font-size-12 mb-1">Just upgraded to premium account.</p>
                                                    <p class="font-size-12 mb-0 text-muted"><i class="mdi mdi-clock-outline"></i> 1 day ago</p>
                                                </div>
                                            </div>
                                        </a>
                                    </div> 
                                    <div class="p-2 border-top">
                                        <a class="btn btn-sm btn-light btn-block text-center" href="javascript:void(0)">
                                            <i class="mdi mdi-arrow-down-circle mr-1"></i> Load More..
                                        </a>
                                    </div> -->
                                </div>
                            </div>
        
                            <div class="dropdown d-inline-block ml-2">
                                <button type="button" class="btn header-item waves-effect waves-light" id="page-header-user-dropdown"
                                    data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                    <img class="rounded-circle header-profile-user" src="<?php echo base_url(); ?>assets/kamma/images/users/avatar-1.jpg"
                                        alt="Header Avatar">
                                    <span class="d-none d-sm-inline-block ml-1"><?php echo ucfirst($this->session->userdata('uname'));?></span>
                                    <i class="mdi mdi-chevron-down d-none d-sm-inline-block"></i>
                                </button>
                                <div class="dropdown-menu dropdown-menu-right">
                                    <a class="dropdown-item d-flex align-items-center justify-content-between" href="javascript:void(0)">
                                        <span>Inbox</span>
                                        <span>
                                            <span class="badge badge-pill badge-info">3</span>
                                        </span>
                                    </a>
                                    <a class="dropdown-item d-flex align-items-center justify-content-between" href="javascript:void(0)">
                                        <span>Profile</span>
                                        <span>
                                            <span class="badge badge-pill badge-warning">1</span>
                                        </span>
                                    </a>
                                    <a class="dropdown-item d-flex align-items-center justify-content-between" href="javascript:void(0)">
                                        Settings
                                    </a>
                                    <a class="dropdown-item d-flex align-items-center justify-content-between" href="javascript:void(0)">
                                        <span>Lock Account</span>
                                    </a>
                                    <a class="dropdown-item d-flex align-items-center justify-content-between" href="<?php echo site_url(); ?>admin/logout">
                                        <span>Log Out</span>
                                    </a>
                                </div>
                            </div>
                            
                        </div>
                    </div>
                </header>

                <div class="topnav">
                    <div class="container-fluid">
                        <nav class="navbar navbar-light navbar-expand-lg topnav-menu">
                            
                            <div class="collapse navbar-collapse" id="topnav-menu-content">
                                <ul class="navbar-nav">
                                    <li class="nav-item">
                                        <a class="nav-link" href="<?php echo site_url(); ?>admin/MyDashboard?msg=back">
                                            <i class="feather-home mr-2"></i>Dashboard
                                        </a>
                                    </li>
                                
                                    <li class="nav-item dropdown">
                                        <a class="nav-link dropdown-toggle arrow-none" href="#" id="topnav-components" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            <i class="feather-briefcase mr-2"></i>My Account<div class="arrow-down"></div>
                                        </a>
                                        <div class="dropdown-menu" aria-labelledby="topnav-components">
                                            <a href="<?php echo site_url(); ?>register" class="dropdown-item">Free Registrations</a>
                                            <a href="<?php echo site_url(); ?>admin/basic_search" class="dropdown-item">Search</a>
                                            <a href="<?php echo site_url(); ?>admin/express_interest" class="dropdown-item">Shared Profiles</a>
                                            <a href="<?php echo site_url(); ?>admin/express_interest?exint=1" class="dropdown-item">Express Interest</a>
                                            <a href="<?php echo site_url(); ?>admin/service_report" class="dropdown-item">Service Reports</a>
                                     <!--       <a href="<?php echo site_url(); ?>admin/admin_payment" class="dropdown-item">Payment Details</a> -->
                                            <a href="<?php echo site_url(); ?>admin/enterpayment" class="dropdown-item">Payment Details</a>
                                          
                                        </div>
                                    </li>

                                    <li class="nav-item dropdown">
                                        <a class="nav-link dropdown-toggle arrow-none" href="#" id="topnav-pages" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            <i class="feather-copy mr-2"></i>Profiles<div class="arrow-down"></div>
                                        </a>
                                        <div class="dropdown-menu" aria-labelledby="topnav-pages">
                                          
                                                 <a href="<?php echo site_url(); ?>admin/admin_pv" class="dropdown-item">Profile Validation</a>
                                            <a href="<?php echo site_url(); ?>admin/inactivate_profile" class="dropdown-item">Inactive Profiles List</a>
                                            <a href="<?php echo site_url(); ?>admin/inactivate_profile" class="dropdown-item">Inactivate Profile</a>
                                            <a href="<?php echo site_url(); ?>admin/admin_del_profiles" class="dropdown-item">Delete/Settle Profile</a>
                                          </div>
                                        </li>

                                    <li class="nav-item dropdown">
                                        <a class="nav-link dropdown-toggle arrow-none" href="#" id="topnav-charts" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            <i class="feather-bar-chart-2 mr-2"></i> Masters <div class="arrow-down"></div>
                                        </a>
                                        <div class="dropdown-menu" aria-labelledby="topnav-charts">
                                            <a href="#" class="dropdown-item">CMS</a>
                                            <a href="#" class="dropdown-item">Religious Details</a>
                                            <a href="#" class="dropdown-item">Residence Details</a>
                                            <a href="#" class="dropdown-item">Education Details</a>
                                           
                                        </div>
                                    </li>

                                    <li class="nav-item dropdown">
                                        <a class="nav-link dropdown-toggle arrow-none" href="#" id="topnav-forms" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            <i class="feather-disc mr-2"></i>Maintainence <div class="arrow-down"></div>
                                        </a>
                                        <div class="dropdown-menu" aria-labelledby="topnav-forms">
            				   <?php if($this->session->userdata('type')=='admin'){?>
                                            <a href="<?php echo site_url(); ?>admin/profile_assign" class="dropdown-item">Un Assigned Profiles</a>
              
                                            <a href="<?php echo site_url(); ?>admin/addeditstaf" class="dropdown-item">Add/Edit Staff</a>
 						<?php } ?>
                                            <a href="<?php echo site_url(); ?>admin/call_history" class="dropdown-item">Marketing Slide</a>
                                            <a href="<?php echo site_url(); ?>admin/marketing_reminders" class="dropdown-item">Marketing Reminder</a>
                                            <a href="<?php echo site_url(); ?>admin/photoshp_photos" class="dropdown-item">Photos</a>
                                            <a href="<?php echo site_url();?>admin/emailtemplates" class="dropdown-item">Email Templatess</a>
                                        </div>
                                    </li>

                                    <li class="nav-item dropdown">
                                        <a class="nav-link dropdown-toggle arrow-none" href="#" id="topnav-more" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                            <i class="feather-book-open mr-2"></i>Reports
                                        </a>
                                     </div>
                                    </li>

                                </ul>
                            </div>
                        </nav>
                    </div>
                </div>                

              
    <?php session_start(); ?>