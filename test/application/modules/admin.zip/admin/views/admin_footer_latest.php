

<script type="text/javascript" src="<?php echo site_url(); ?>assets/kamma/js/jquery.dataTables.min.js"></script>
<script type="text/javascript" src="<?php echo site_url(); ?>assets/kamma/js/dataTables.bootstrap4.min.js"></script>
    
        <script src="<?php echo site_url(); ?>assets/kamma/js/bootstrap.bundle.min.js"></script>
        <script src="<?php echo site_url(); ?>assets/kamma/js/waves.js"></script>
        <script src="<?php echo site_url(); ?>assets/kamma/js/simplebar.min.js"></script>

        <!-- third party js -->
      
        <script src="<?php echo site_url(); ?>assets/kamma/plugins/datatables/dataTables.responsive.min.js"></script>
        <script src="<?php echo site_url(); ?>assets/kamma/plugins/datatables/responsive.bootstrap4.min.js"></script>
        <script src="<?php echo site_url(); ?>assets/kamma/plugins/datatables/dataTables.buttons.min.js"></script>
        <script src="<?php echo site_url(); ?>assets/kamma/plugins/datatables/buttons.bootstrap4.min.js"></script>
        <script src="<?php echo site_url(); ?>assets/kamma/plugins/datatables/buttons.html5.min.js"></script>
        <script src="<?php echo site_url(); ?>assets/kamma/plugins/datatables/buttons.flash.min.js"></script>
        <script src="<?php echo site_url(); ?>assets/kamma/plugins/datatables/buttons.print.min.js"></script>
        <script src="<?php echo site_url(); ?>assets/kamma/plugins/datatables/dataTables.keyTable.min.js"></script>
        <script src="<?php echo site_url(); ?>assets/kamma/plugins/datatables/dataTables.select.min.js"></script>
        <script src="<?php echo site_url(); ?>assets/kamma/plugins/datatables/pdfmake.min.js"></script>
        <script src="<?php echo site_url(); ?>assets/kamma/plugins/datatables/vfs_fonts.js"></script>
        <!-- third party js ends -->
    
        <!-- Datatables init -->

        <!-- App js -->
        <script src="<?php echo site_url(); ?>assets/kamma/js/theme.js"></script>