<br>

    
    <div class="row">
        <div class="col-md-12">
            <button class="btn submit" style="width: 300px; margin-left: 600px;">Payment Information</button>
        </div> 
    </div>
        <hr/>

            <form>
                <div class=" form-group row">
                    
                        
                        <label class="col-form-label col-md-2 offset-md-2 " >
                            Profile ID
                        </label>
                                              
                       

                        <div class="col-md-2">
                        <button class="btn btn-dark form-control ">Customer Name</button>
                        </div>                   

                </div>

               

               <div class="form-group row">
                    
                        <label class="col-form-label col-md-2 offset-md-2">
                            Agreed amount
                        </label>
                        <div class="col-md-2">
                        <input type="text" name="agreedamount" class="form-control">
                        </div>
                    
                        <label class="col-form-label col-md-2">
                            Paid amount
                        </label>
                        <div class="col-md-2">
                        <input type="text"  name="paidamount" class="form-control">
                        </div>
                    
                </div>                  
                
                <br>

                <div class="form-group row">
                    <label class="col-form-label col-md-2 offset-md-2">
                        No. of Contacts
                    </label>
                    <div class="col-md-2">
                    <input type="text" name="ncontacts" class="form-control"> 
                    </div>                                         
               
                    <label class="col-form-label col-md-2">
                        Expiry Date
                    </label>
                    <div class="col-md-2">
                    <input type="date" name="exodate" class="form-control">
                    </div>

                </div> 
                <br>

                <div class="row col-md-4 offset-md-5" >

                    <pre>       </pre>
                        
                    <input type="submit" class="btn submit" value="Submit">
                        
                    </input>
                    <pre>            </pre>

                    <button style="background-color: white;font-weight: bold;font-size: 21px;border:none;" type="Reset"> Reset  </button>
                </div>   
                
                    
            </form> 

        <hr/>  
