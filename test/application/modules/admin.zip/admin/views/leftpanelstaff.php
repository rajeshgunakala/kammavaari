<div class="col-md-3 col-xs-12">
   <div class="menubox-ms custNew">
      <div class="col-xs-12 no-padding">
         <ul class="nav nav-pills nav-stacked" style="padding:0px !important;">
            <li><a href="<?php echo base_url();?>admin/bothsideinterest"><i class="fa fa-caret-right"></i> <?php echo getlangkeywords('bothsideinterest');?> <span class="count">(<?php echo bothsideinterest_count();?>)</span></a></li>
         </ul>
      </div>
   </div>
   <div class="menubox-ms custNew">
      <div class="col-xs-12 no-padding">
         <ul class="nav nav-pills nav-stacked" style="padding:0px !important;">
            <li><a href="<?php echo base_url();?>admin/notifications"><i class="fa fa-caret-right"></i> Notifications</a></li>
         </ul>
      </div>
   </div>
   <div class="menubox-ms custNew">
      <div class="col-xs-12 no-padding">
         <ul class="nav nav-pills nav-stacked" style="padding:0px !important;">
            <li><a href="<?php echo base_url();?>admin/matchmetingserious"><i class="fa fa-caret-right"></i> Match Meting Serious (MMS) <span class="count">(<?php echo matchmetingserious_count();?>)</span></a></li>
         </ul>
      </div>
   </div>
 <div class="menubox-ms custNew">
      <div class="col-xs-12 no-padding">
         <ul class="nav nav-pills nav-stacked" style="padding:0px !important;">
            <li><a href="<?php echo base_url();?>admin/regularprofiles"><i class="fa fa-caret-right"></i> Regular Profiles <span class="count">(<?php echo $regular_profiles["regcount"];?>)</span></a></li>
         </ul>
      </div>
   </div>
 <div class="menubox-ms custNew">
      <div class="col-xs-12 no-padding">
         <ul class="nav nav-pills nav-stacked" style="padding:0px !important;">
            <li><a href="<?php echo base_url();?>admin/confidentialprofiles"><i class="fa fa-caret-right"></i> Confidential Profiles <span class="count">(<?php echo $confidential_profiles["confcount"];?>)</span></a></li>
         </ul>
      </div>
   </div>
 <div class="menubox-ms custNew">
      <div class="col-xs-12 no-padding">
         <ul class="nav nav-pills nav-stacked" style="padding:0px !important;">
            <li><a href="<?php echo base_url();?>admin/eliteprofiles"><i class="fa fa-caret-right"></i> Elite Profiles <span class="count">(<?php echo $elite_profiles["elitecount"];?>)</span></a></li>
         </ul>
      </div>
   </div>
   <div class="menubox-ms custNew">
      <div class="col-xs-12 no-padding">
         <h3>Opposite side follow ups</h3>
         <ul class="nav nav-pills nav-stacked" style="padding:0px !important;">
            <li><a href="<?php echo base_url();?>admin/opposidesidesinterest"><i class="fa fa-caret-right"></i> <?php echo getlangkeywords('oppositesidesinterest');?> <span class="count">(<?php echo oppositesidesinterest_count();?>)</span></a></li>
            <li><a href="<?php echo base_url();?>admin/opposidependingfourtyeighth"><i class="fa fa-caret-right"></i> Pending > 48 Hrs From Me <span class="count">(<?php echo oppositesidesinterest_count('48hours');?>)</span></a></li>
            <li><a href="<?php echo base_url();?>admin/opposideclosetickets"><i class="fa fa-caret-right"></i> Closed Tickets <span class="count">(<?php echo opposideclosetickets_count();?>)</span></a></li>
         </ul>
      </div>
   </div>
   <div class="menubox-ms custNew">
      <div class="col-xs-12 no-padding">
         <h3>My Side Follow Ups</h3>
         <ul class="nav nav-pills nav-stacked" style="padding:0px !important;">
            <li><a href="<?php echo base_url();?>admin/mysidefollowupsint"><i class="fa fa-caret-right"></i> <?php echo getlangkeywords('mysidesinterest');?> <span class="count">(<?php echo mysidefollowupsint_count();?>)</span></a></li>
            <li><a href="<?php echo base_url();?>admin/mysidefollowupsintfortyeighth"><i class="fa fa-caret-right"></i> Untouched > 48 Hrs <span class="count">(<?php echo mysidefollowupsint_count('48hours');?>)</span></a></li>
            <li class="dn"><a href="javascript:void(0);"><i class="fa fa-caret-right"></i> With Other Emps (3)</a></li>
            <li><a href="<?php echo base_url();?>admin/mysideclosetickets"><i class="fa fa-caret-right"></i> Closed Tickets <span class="count">(<?php echo mysideclosetickets_count();?>)</span></a></li>
            <li><a href="<?php echo base_url();?>admin/freeprofticketexpiry"><i class="fa fa-caret-right"></i> Reminders <span class="count">(<?php echo freeprofticketexpiry_count();?>)</span></a></li>
         </ul>
      </div>
   </div>
</div>