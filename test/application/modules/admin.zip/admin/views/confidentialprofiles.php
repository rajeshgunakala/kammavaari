<div class="page-content">
	<div class="container-fluid">
		 <div class="row">
                            <div class="col-12">
                                <div class="card">
                                    <div class="card-body">
                                        <h4 class="card-title">Confidential Profiles</h4>
                                 
										 <table id="example" class="table dt-responsive nowrap table-striped">
                                    <thead class="thead-dark">
                                        <tr>
                                            <th>Profile ID</th>
                                            <th>Name</th>
                                            <th>Payment Status</th>
                                            <th>Date</th>
                                            <th>Owner</th>
                                           <!-- <th>Ticket ID</th>--> 
                                            <th>Status</th>
                                            
                                        </tr>
 </thead>  
 <tbody>  
					<?php foreach($confprofiles as $profile) {?>
										<tr>
											<td> <a  class="<?Php if($profile['payment_status']=='1'){echo 'badge badge-success'; }else{echo 'badge badge-danger';} ?>" href="<?php echo site_url(); ?>admin/admin_search/viewprofile/<?php echo $profile['ms_id']; ?>"> <?Php echo $profile["profile_id"]; ?></td>
											<td> <?Php echo $profile["first_name"].''.$profile["last_name"]; ?></td>
                                           <td><?php if($profile['payment_status']=='1'){echo "Done"; }else{ echo "unpaid";}?></td>
											<td> <?Php echo $profile["registered_on"]; ?></td>
											<td> <?Php echo $profile["username"]; ?></td>
											<td> <?Php  if($profile["status"]==1) {echo "Active"; } else { echo "InActive"; } ?></td>
										
										</tr>
<?php } ?>
                                   
                                                 
                                    </tbody>
                                </table>
                                    </div> <!-- end card body-->
                                </div> <!-- end card -->
                            </div><!-- end col-->
                        </div>
                        <!-- end row-->
	</div>
</div>
<script>
$(document).ready(function() {
    $('#example').DataTable();
} );
</script>