<?php

if (!defined('BASEPATH')) exit('No direct script access allowed');



class Admin_login_model extends CI_Model {



	public $admindata = "tbl_admin_data";

	

	public function __construct() {

        parent::__construct();
		$this->load->model('../../login/models/Login_model', 'login_model');

 		error_reporting(E_ERROR | E_WARNING | E_PARSE | E_NOTICE);

		error_reporting(0);

		ini_set('display_errors','off'); 

    }

  

	  public function getadmindata() 

	  {

        $result = array();

        $this->db->select("*");

        $this->db->where('username', $this->input->post('username'));

        $this->db->where('password', $this->input->post('password'));

		$query = $this->db->get($this->admindata);

        if ($query->num_rows() > 0):

            $result = $query->row_array();

		else:

			$result = FALSE;

        endif;

		return $result;

     }


     public function getAdminMobileAccount($mobile, $otp = null) {
		$this->db->select('*');
		$this->db->from('tbl_admin_data');
		$this->db->where('phone_no', $mobile);
		if($otp) {
			$this->db->where('login_otp', $otp);
		}		
		$this->db->where('status',1);
		$response = $this->db->get()->row_array();

		//echo '<pre>';print_r($this->db->last_query());exit;
		return $response;
	}

	public function loginOtp($mobile, $customerName) {		
		$otp = $this->login_model->generate_otp();
		$message = "Dear ".$customerName.", Your OTP No is ".$otp." Thank you. From kammavaari.com";
		$this->login_model->send_sms($mobile, $message);	
		return $otp;
	}

	public function updateOtpToAccount($userId, $otp) {
		$data = array(
		    'login_otp' => $otp
		);
	
		$this->db->where('id',$userId);
		$result = $this->db->update("tbl_admin_data", $data);
	}

	

}