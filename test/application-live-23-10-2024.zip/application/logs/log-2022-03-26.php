<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-26 00:03:19 --> 404 Page Not Found: /index
ERROR - 2022-03-26 00:32:07 --> 404 Page Not Found: /index
ERROR - 2022-03-26 00:40:31 --> 404 Page Not Found: /index
ERROR - 2022-03-26 00:40:41 --> 404 Page Not Found: /index
ERROR - 2022-03-26 00:43:34 --> 404 Page Not Found: /index
ERROR - 2022-03-26 00:47:49 --> 404 Page Not Found: /index
ERROR - 2022-03-26 00:47:49 --> 404 Page Not Found: /index
ERROR - 2022-03-26 00:47:55 --> 404 Page Not Found: /index
ERROR - 2022-03-26 00:48:02 --> 404 Page Not Found: /index
ERROR - 2022-03-26 00:48:11 --> 404 Page Not Found: /index
ERROR - 2022-03-26 00:48:30 --> 404 Page Not Found: /index
ERROR - 2022-03-26 00:48:30 --> 404 Page Not Found: /index
ERROR - 2022-03-26 01:04:49 --> 404 Page Not Found: /index
ERROR - 2022-03-26 01:05:25 --> 404 Page Not Found: /index
ERROR - 2022-03-26 01:09:58 --> 404 Page Not Found: /index
ERROR - 2022-03-26 01:10:14 --> 404 Page Not Found: /index
ERROR - 2022-03-26 01:13:16 --> 404 Page Not Found: /index
ERROR - 2022-03-26 01:13:53 --> 404 Page Not Found: /index
ERROR - 2022-03-26 01:23:19 --> To Id is not available for User - 4019
ERROR - 2022-03-26 01:37:53 --> 404 Page Not Found: /index
ERROR - 2022-03-26 01:39:31 --> 404 Page Not Found: /index
ERROR - 2022-03-26 01:43:27 --> 404 Page Not Found: /index
ERROR - 2022-03-26 01:43:51 --> 404 Page Not Found: /index
ERROR - 2022-03-26 01:46:59 --> 404 Page Not Found: /index
ERROR - 2022-03-26 01:52:18 --> 404 Page Not Found: /index
ERROR - 2022-03-26 01:55:36 --> 404 Page Not Found: /index
ERROR - 2022-03-26 02:24:41 --> 404 Page Not Found: /index
ERROR - 2022-03-26 02:33:31 --> 404 Page Not Found: /index
ERROR - 2022-03-26 02:38:27 --> 404 Page Not Found: /index
ERROR - 2022-03-26 03:10:50 --> 404 Page Not Found: /index
ERROR - 2022-03-26 03:15:12 --> 404 Page Not Found: /index
ERROR - 2022-03-26 03:22:29 --> 404 Page Not Found: /index
ERROR - 2022-03-26 03:23:38 --> 404 Page Not Found: /index
ERROR - 2022-03-26 03:25:30 --> 404 Page Not Found: /index
ERROR - 2022-03-26 03:32:15 --> 404 Page Not Found: /index
ERROR - 2022-03-26 03:33:03 --> 404 Page Not Found: /index
ERROR - 2022-03-26 03:35:11 --> 404 Page Not Found: /index
ERROR - 2022-03-26 03:38:38 --> 404 Page Not Found: /index
ERROR - 2022-03-26 03:44:30 --> 404 Page Not Found: /index
ERROR - 2022-03-26 04:08:44 --> 404 Page Not Found: /index
ERROR - 2022-03-26 04:10:01 --> 404 Page Not Found: /index
ERROR - 2022-03-26 04:26:35 --> 404 Page Not Found: /index
ERROR - 2022-03-26 04:31:12 --> 404 Page Not Found: /index
ERROR - 2022-03-26 04:44:31 --> 404 Page Not Found: /index
ERROR - 2022-03-26 04:45:19 --> 404 Page Not Found: /index
ERROR - 2022-03-26 04:47:17 --> 404 Page Not Found: /index
ERROR - 2022-03-26 04:48:41 --> 404 Page Not Found: /index
ERROR - 2022-03-26 04:51:41 --> 404 Page Not Found: /index
ERROR - 2022-03-26 04:52:23 --> 404 Page Not Found: /index
ERROR - 2022-03-26 05:04:53 --> 404 Page Not Found: /index
ERROR - 2022-03-26 05:11:10 --> 404 Page Not Found: /index
ERROR - 2022-03-26 05:15:34 --> 404 Page Not Found: /index
ERROR - 2022-03-26 05:17:27 --> 404 Page Not Found: /index
ERROR - 2022-03-26 05:20:49 --> 404 Page Not Found: /index
ERROR - 2022-03-26 05:24:10 --> 404 Page Not Found: /index
ERROR - 2022-03-26 05:26:10 --> 404 Page Not Found: /index
ERROR - 2022-03-26 05:26:20 --> 404 Page Not Found: /index
ERROR - 2022-03-26 05:32:21 --> 404 Page Not Found: /index
ERROR - 2022-03-26 05:32:22 --> 404 Page Not Found: /index
ERROR - 2022-03-26 05:32:22 --> 404 Page Not Found: /index
ERROR - 2022-03-26 05:32:23 --> 404 Page Not Found: /index
ERROR - 2022-03-26 05:32:23 --> 404 Page Not Found: /index
ERROR - 2022-03-26 05:32:23 --> 404 Page Not Found: /index
ERROR - 2022-03-26 05:32:24 --> 404 Page Not Found: /index
ERROR - 2022-03-26 05:32:24 --> 404 Page Not Found: /index
ERROR - 2022-03-26 05:32:25 --> 404 Page Not Found: /index
ERROR - 2022-03-26 05:32:25 --> 404 Page Not Found: /index
ERROR - 2022-03-26 05:35:54 --> 404 Page Not Found: /index
ERROR - 2022-03-26 05:37:17 --> 404 Page Not Found: /index
ERROR - 2022-03-26 05:47:56 --> 404 Page Not Found: /index
ERROR - 2022-03-26 05:48:14 --> 404 Page Not Found: /index
ERROR - 2022-03-26 05:48:24 --> 404 Page Not Found: /index
ERROR - 2022-03-26 05:48:34 --> 404 Page Not Found: /index
ERROR - 2022-03-26 05:51:49 --> 404 Page Not Found: /index
ERROR - 2022-03-26 05:53:23 --> 404 Page Not Found: /index
ERROR - 2022-03-26 05:53:52 --> Query error: Table 'cowcdrmy_kammamarriage.ms_shortlist_viewedd_ignored' doesn't exist - Invalid query: SELECT `v`.*, `p`.`gender`, `p`.`id`, `p`.`status`, `p`.`age`, `p`.`living_in`, `p`.`profile_id`, `p`.`first_name`, `last_name`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `s`.*
FROM `kv_profileview` as `v`
LEFT JOIN `tbl_primary_info` as `p` ON `v`.`kv_profileview_on` = `p`.`id`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`ms_id`
INNER JOIN `ms_profilesetting` as `s` ON `p`.`id`=`s`.`ms_id`
WHERE `s`.`elite` = 'no'
AND `p`.`status` = 1
AND `v`.`kv_userfkid` = '3581'
AND `u`.`ismain` = 1
AND  `p`.`id` not in(select kv_msi_interested_on from kv_mysideinterests where kv_msi_profilefkid="3581")
AND  p.id not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid = "3581" AND `shortlist_status` = 1)
AND  `p`.`id` not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid="3581"AND ignore_status=1)
ORDER BY `v`.`kv_profileview_created_date` DESC
 LIMIT 10
ERROR - 2022-03-26 05:54:05 --> Query error: Table 'cowcdrmy_kammamarriage.ms_shortlist_viewedd_ignored' doesn't exist - Invalid query: SELECT `v`.*, `p`.`gender`, `p`.`id`, `p`.`status`, `p`.`age`, `p`.`living_in`, `p`.`profile_id`, `p`.`first_name`, `last_name`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `s`.*
FROM `kv_profileview` as `v`
LEFT JOIN `tbl_primary_info` as `p` ON `v`.`kv_profileview_on` = `p`.`id`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`ms_id`
INNER JOIN `ms_profilesetting` as `s` ON `p`.`id`=`s`.`ms_id`
WHERE `s`.`elite` = 'no'
AND `p`.`status` = 1
AND `v`.`kv_userfkid` = '3581'
AND `u`.`ismain` = 1
AND  `p`.`id` not in(select kv_msi_interested_on from kv_mysideinterests where kv_msi_profilefkid="3581")
AND  p.id not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid = "3581" AND `shortlist_status` = 1)
AND  `p`.`id` not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid="3581"AND ignore_status=1)
ORDER BY `v`.`kv_profileview_created_date` DESC
 LIMIT 10
ERROR - 2022-03-26 05:56:42 --> 404 Page Not Found: /index
ERROR - 2022-03-26 05:58:05 --> 404 Page Not Found: /index
ERROR - 2022-03-26 06:00:31 --> 404 Page Not Found: /index
ERROR - 2022-03-26 06:02:35 --> Query error: Table 'cowcdrmy_kammamarriage.ms_shortlist_viewedd_ignored' doesn't exist - Invalid query: SELECT `v`.*, `p`.`gender`, `p`.`id`, `p`.`status`, `p`.`age`, `p`.`living_in`, `p`.`profile_id`, `p`.`first_name`, `last_name`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `s`.*
FROM `kv_profileview` as `v`
LEFT JOIN `tbl_primary_info` as `p` ON `v`.`kv_profileview_on` = `p`.`id`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`ms_id`
INNER JOIN `ms_profilesetting` as `s` ON `p`.`id`=`s`.`ms_id`
WHERE `s`.`elite` = 'no'
AND `p`.`status` = 1
AND `v`.`kv_userfkid` = '3581'
AND `u`.`ismain` = 1
AND  `p`.`id` not in(select kv_msi_interested_on from kv_mysideinterests where kv_msi_profilefkid="3581")
AND  p.id not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid = "3581" AND `shortlist_status` = 1)
AND  `p`.`id` not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid="3581"AND ignore_status=1)
ORDER BY `v`.`kv_profileview_created_date` DESC
 LIMIT 10
ERROR - 2022-03-26 06:02:45 --> Query error: Table 'cowcdrmy_kammamarriage.ms_shortlist_viewedd_ignored' doesn't exist - Invalid query: SELECT `v`.*, `p`.`gender`, `p`.`id`, `p`.`status`, `p`.`age`, `p`.`living_in`, `p`.`profile_id`, `p`.`first_name`, `last_name`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `s`.*
FROM `kv_profileview` as `v`
LEFT JOIN `tbl_primary_info` as `p` ON `v`.`kv_profileview_on` = `p`.`id`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`ms_id`
INNER JOIN `ms_profilesetting` as `s` ON `p`.`id`=`s`.`ms_id`
WHERE `s`.`elite` = 'no'
AND `p`.`status` = 1
AND `v`.`kv_userfkid` = '3581'
AND `u`.`ismain` = 1
AND  `p`.`id` not in(select kv_msi_interested_on from kv_mysideinterests where kv_msi_profilefkid="3581")
AND  p.id not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid = "3581" AND `shortlist_status` = 1)
AND  `p`.`id` not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid="3581"AND ignore_status=1)
ORDER BY `v`.`kv_profileview_created_date` DESC
 LIMIT 10
ERROR - 2022-03-26 06:02:55 --> Query error: Table 'cowcdrmy_kammamarriage.ms_shortlist_viewedd_ignored' doesn't exist - Invalid query: SELECT `v`.*, `p`.`gender`, `p`.`id`, `p`.`status`, `p`.`age`, `p`.`living_in`, `p`.`profile_id`, `p`.`first_name`, `last_name`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `s`.*
FROM `kv_profileview` as `v`
LEFT JOIN `tbl_primary_info` as `p` ON `v`.`kv_profileview_on` = `p`.`id`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`ms_id`
INNER JOIN `ms_profilesetting` as `s` ON `p`.`id`=`s`.`ms_id`
WHERE `s`.`elite` = 'no'
AND `p`.`status` = 1
AND `v`.`kv_userfkid` = '3581'
AND `u`.`ismain` = 1
AND  `p`.`id` not in(select kv_msi_interested_on from kv_mysideinterests where kv_msi_profilefkid="3581")
AND  p.id not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid = "3581" AND `shortlist_status` = 1)
AND  `p`.`id` not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid="3581"AND ignore_status=1)
ORDER BY `v`.`kv_profileview_created_date` DESC
 LIMIT 10
ERROR - 2022-03-26 06:03:52 --> Query error: Table 'cowcdrmy_kammamarriage.ms_shortlist_viewedd_ignored' doesn't exist - Invalid query: SELECT `v`.*, `p`.`gender`, `p`.`id`, `p`.`status`, `p`.`age`, `p`.`living_in`, `p`.`profile_id`, `p`.`first_name`, `last_name`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `s`.*
FROM `kv_profileview` as `v`
LEFT JOIN `tbl_primary_info` as `p` ON `v`.`kv_profileview_on` = `p`.`id`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`ms_id`
INNER JOIN `ms_profilesetting` as `s` ON `p`.`id`=`s`.`ms_id`
WHERE `s`.`elite` = 'no'
AND `p`.`status` = 1
AND `v`.`kv_userfkid` = '3581'
AND `u`.`ismain` = 1
AND  `p`.`id` not in(select kv_msi_interested_on from kv_mysideinterests where kv_msi_profilefkid="3581")
AND  p.id not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid = "3581" AND `shortlist_status` = 1)
AND  `p`.`id` not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid="3581"AND ignore_status=1)
ORDER BY `v`.`kv_profileview_created_date` DESC
 LIMIT 10
ERROR - 2022-03-26 06:05:11 --> 404 Page Not Found: /index
ERROR - 2022-03-26 06:05:27 --> 404 Page Not Found: /index
ERROR - 2022-03-26 06:05:44 --> 404 Page Not Found: /index
ERROR - 2022-03-26 06:05:57 --> 404 Page Not Found: /index
ERROR - 2022-03-26 06:06:12 --> 404 Page Not Found: /index
ERROR - 2022-03-26 06:06:15 --> 404 Page Not Found: /index
ERROR - 2022-03-26 06:06:48 --> 404 Page Not Found: /index
ERROR - 2022-03-26 06:06:57 --> 404 Page Not Found: /index
ERROR - 2022-03-26 06:07:15 --> 404 Page Not Found: /index
ERROR - 2022-03-26 06:07:18 --> 404 Page Not Found: /index
ERROR - 2022-03-26 06:07:21 --> 404 Page Not Found: /index
ERROR - 2022-03-26 06:07:21 --> 404 Page Not Found: /index
ERROR - 2022-03-26 06:07:52 --> 404 Page Not Found: /index
ERROR - 2022-03-26 06:15:28 --> 404 Page Not Found: /index
ERROR - 2022-03-26 06:16:14 --> 404 Page Not Found: /index
ERROR - 2022-03-26 06:17:06 --> 404 Page Not Found: /index
ERROR - 2022-03-26 06:17:13 --> Query error: Table 'cowcdrmy_kammamarriage.ms_shortlist_viewedd_ignored' doesn't exist - Invalid query: SELECT `v`.*, `p`.`gender`, `p`.`id`, `p`.`status`, `p`.`age`, `p`.`living_in`, `p`.`profile_id`, `p`.`first_name`, `last_name`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `s`.*
FROM `kv_profileview` as `v`
LEFT JOIN `tbl_primary_info` as `p` ON `v`.`kv_profileview_on` = `p`.`id`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`ms_id`
INNER JOIN `ms_profilesetting` as `s` ON `p`.`id`=`s`.`ms_id`
WHERE `s`.`elite` = 'no'
AND `p`.`status` = 1
AND `v`.`kv_userfkid` = '3581'
AND `u`.`ismain` = 1
AND  `p`.`id` not in(select kv_msi_interested_on from kv_mysideinterests where kv_msi_profilefkid="3581")
AND  p.id not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid = "3581" AND `shortlist_status` = 1)
AND  `p`.`id` not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid="3581"AND ignore_status=1)
ORDER BY `v`.`kv_profileview_created_date` DESC
 LIMIT 10
ERROR - 2022-03-26 06:17:24 --> 404 Page Not Found: /index
ERROR - 2022-03-26 06:18:57 --> 404 Page Not Found: /index
ERROR - 2022-03-26 06:23:58 --> 404 Page Not Found: /index
ERROR - 2022-03-26 06:24:18 --> 404 Page Not Found: /index
ERROR - 2022-03-26 06:25:33 --> 404 Page Not Found: /index
ERROR - 2022-03-26 06:26:29 --> 404 Page Not Found: /index
ERROR - 2022-03-26 06:34:39 --> 404 Page Not Found: /index
ERROR - 2022-03-26 06:36:46 --> 404 Page Not Found: /index
ERROR - 2022-03-26 06:37:46 --> 404 Page Not Found: /index
ERROR - 2022-03-26 06:38:05 --> 404 Page Not Found: /index
ERROR - 2022-03-26 06:38:25 --> 404 Page Not Found: /index
ERROR - 2022-03-26 06:40:23 --> 404 Page Not Found: /index
ERROR - 2022-03-26 06:43:21 --> 404 Page Not Found: /index
ERROR - 2022-03-26 06:44:27 --> 404 Page Not Found: /index
ERROR - 2022-03-26 06:45:08 --> 404 Page Not Found: /index
ERROR - 2022-03-26 06:46:11 --> 404 Page Not Found: /index
ERROR - 2022-03-26 06:48:47 --> 404 Page Not Found: /index
ERROR - 2022-03-26 06:53:17 --> 404 Page Not Found: /index
ERROR - 2022-03-26 06:53:30 --> 404 Page Not Found: /index
ERROR - 2022-03-26 06:55:30 --> 404 Page Not Found: /index
ERROR - 2022-03-26 06:57:06 --> 404 Page Not Found: /index
ERROR - 2022-03-26 06:57:59 --> 404 Page Not Found: /index
ERROR - 2022-03-26 06:58:07 --> 404 Page Not Found: /index
ERROR - 2022-03-26 07:02:09 --> 404 Page Not Found: /index
ERROR - 2022-03-26 07:02:46 --> 404 Page Not Found: /index
ERROR - 2022-03-26 07:06:45 --> 404 Page Not Found: /index
ERROR - 2022-03-26 07:07:48 --> 404 Page Not Found: /index
ERROR - 2022-03-26 07:11:08 --> 404 Page Not Found: /index
ERROR - 2022-03-26 07:12:46 --> 404 Page Not Found: /index
ERROR - 2022-03-26 07:14:03 --> 404 Page Not Found: /index
ERROR - 2022-03-26 07:16:00 --> 404 Page Not Found: /index
ERROR - 2022-03-26 07:17:44 --> 404 Page Not Found: /index
ERROR - 2022-03-26 07:18:22 --> 404 Page Not Found: /index
ERROR - 2022-03-26 07:18:23 --> 404 Page Not Found: /index
ERROR - 2022-03-26 07:18:23 --> 404 Page Not Found: /index
ERROR - 2022-03-26 07:18:23 --> 404 Page Not Found: /index
ERROR - 2022-03-26 07:18:24 --> 404 Page Not Found: /index
ERROR - 2022-03-26 07:18:24 --> 404 Page Not Found: /index
ERROR - 2022-03-26 07:18:25 --> 404 Page Not Found: /index
ERROR - 2022-03-26 07:18:25 --> 404 Page Not Found: /index
ERROR - 2022-03-26 07:18:26 --> 404 Page Not Found: /index
ERROR - 2022-03-26 07:18:26 --> 404 Page Not Found: /index
ERROR - 2022-03-26 07:19:45 --> 404 Page Not Found: /index
ERROR - 2022-03-26 07:21:10 --> 404 Page Not Found: /index
ERROR - 2022-03-26 07:22:37 --> 404 Page Not Found: /index
ERROR - 2022-03-26 07:25:12 --> 404 Page Not Found: /index
ERROR - 2022-03-26 07:26:50 --> 404 Page Not Found: /index
ERROR - 2022-03-26 07:26:58 --> 404 Page Not Found: /index
ERROR - 2022-03-26 07:28:29 --> 404 Page Not Found: /index
ERROR - 2022-03-26 07:33:20 --> 404 Page Not Found: /index
ERROR - 2022-03-26 07:37:43 --> 404 Page Not Found: /index
ERROR - 2022-03-26 07:37:43 --> 404 Page Not Found: /index
ERROR - 2022-03-26 07:38:58 --> 404 Page Not Found: /index
ERROR - 2022-03-26 07:41:32 --> 404 Page Not Found: /index
ERROR - 2022-03-26 07:45:24 --> 404 Page Not Found: /index
ERROR - 2022-03-26 07:48:35 --> 404 Page Not Found: /index
ERROR - 2022-03-26 07:53:23 --> 404 Page Not Found: /index
ERROR - 2022-03-26 07:59:33 --> 404 Page Not Found: /index
ERROR - 2022-03-26 08:02:23 --> 404 Page Not Found: /index
ERROR - 2022-03-26 08:05:45 --> 404 Page Not Found: /index
ERROR - 2022-03-26 08:05:52 --> 404 Page Not Found: /index
ERROR - 2022-03-26 08:07:00 --> 404 Page Not Found: /index
ERROR - 2022-03-26 08:09:26 --> 404 Page Not Found: /index
ERROR - 2022-03-26 08:16:35 --> 404 Page Not Found: /index
ERROR - 2022-03-26 08:16:53 --> 404 Page Not Found: /index
ERROR - 2022-03-26 08:17:39 --> 404 Page Not Found: /index
ERROR - 2022-03-26 08:24:36 --> 404 Page Not Found: /index
ERROR - 2022-03-26 08:27:09 --> 404 Page Not Found: /index
ERROR - 2022-03-26 08:34:01 --> 404 Page Not Found: /index
ERROR - 2022-03-26 08:34:20 --> 404 Page Not Found: /index
ERROR - 2022-03-26 08:35:44 --> 404 Page Not Found: /index
ERROR - 2022-03-26 08:36:32 --> 404 Page Not Found: /index
ERROR - 2022-03-26 08:39:14 --> 404 Page Not Found: /index
ERROR - 2022-03-26 08:39:57 --> 404 Page Not Found: /index
ERROR - 2022-03-26 08:40:10 --> 404 Page Not Found: /index
ERROR - 2022-03-26 08:41:11 --> 404 Page Not Found: /index
ERROR - 2022-03-26 08:42:18 --> 404 Page Not Found: /index
ERROR - 2022-03-26 08:42:34 --> 404 Page Not Found: /index
ERROR - 2022-03-26 08:43:22 --> 404 Page Not Found: /index
ERROR - 2022-03-26 08:43:46 --> 404 Page Not Found: /index
ERROR - 2022-03-26 08:45:27 --> 404 Page Not Found: /index
ERROR - 2022-03-26 08:46:04 --> 404 Page Not Found: /index
ERROR - 2022-03-26 08:47:40 --> 404 Page Not Found: /index
ERROR - 2022-03-26 08:50:57 --> 404 Page Not Found: /index
ERROR - 2022-03-26 08:51:13 --> 404 Page Not Found: /index
ERROR - 2022-03-26 08:52:11 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-26 08:52:16 --> 404 Page Not Found: /index
ERROR - 2022-03-26 08:54:29 --> 404 Page Not Found: /index
ERROR - 2022-03-26 08:55:17 --> 404 Page Not Found: /index
ERROR - 2022-03-26 08:56:03 --> 404 Page Not Found: /index
ERROR - 2022-03-26 08:57:14 --> 404 Page Not Found: /index
ERROR - 2022-03-26 08:57:43 --> 404 Page Not Found: /index
ERROR - 2022-03-26 08:57:47 --> 404 Page Not Found: /index
ERROR - 2022-03-26 09:00:27 --> 404 Page Not Found: /index
ERROR - 2022-03-26 09:02:34 --> 404 Page Not Found: /index
ERROR - 2022-03-26 09:03:43 --> 404 Page Not Found: /index
ERROR - 2022-03-26 09:05:28 --> 404 Page Not Found: /index
ERROR - 2022-03-26 09:07:50 --> 404 Page Not Found: /index
ERROR - 2022-03-26 09:08:04 --> 404 Page Not Found: /index
ERROR - 2022-03-26 09:08:33 --> 404 Page Not Found: /index
ERROR - 2022-03-26 09:08:45 --> 404 Page Not Found: /index
ERROR - 2022-03-26 09:11:41 --> 404 Page Not Found: /index
ERROR - 2022-03-26 09:13:18 --> 404 Page Not Found: /index
ERROR - 2022-03-26 09:14:17 --> 404 Page Not Found: /index
ERROR - 2022-03-26 09:16:41 --> 404 Page Not Found: /index
ERROR - 2022-03-26 09:17:06 --> 404 Page Not Found: /index
ERROR - 2022-03-26 09:19:12 --> 404 Page Not Found: /index
ERROR - 2022-03-26 09:19:22 --> 404 Page Not Found: /index
ERROR - 2022-03-26 09:21:31 --> 404 Page Not Found: /index
ERROR - 2022-03-26 09:21:40 --> 404 Page Not Found: /index
ERROR - 2022-03-26 09:21:46 --> 404 Page Not Found: /index
ERROR - 2022-03-26 09:24:50 --> 404 Page Not Found: /index
ERROR - 2022-03-26 09:27:34 --> 404 Page Not Found: /index
ERROR - 2022-03-26 09:28:39 --> 404 Page Not Found: /index
ERROR - 2022-03-26 09:29:29 --> 404 Page Not Found: /index
ERROR - 2022-03-26 09:30:44 --> 404 Page Not Found: /index
ERROR - 2022-03-26 09:31:00 --> 404 Page Not Found: /index
ERROR - 2022-03-26 09:31:44 --> 404 Page Not Found: /index
ERROR - 2022-03-26 09:34:30 --> 404 Page Not Found: /index
ERROR - 2022-03-26 09:34:46 --> 404 Page Not Found: /index
ERROR - 2022-03-26 09:37:54 --> 404 Page Not Found: /index
ERROR - 2022-03-26 09:40:23 --> 404 Page Not Found: /index
ERROR - 2022-03-26 09:40:46 --> 404 Page Not Found: /index
ERROR - 2022-03-26 09:40:49 --> 404 Page Not Found: /index
ERROR - 2022-03-26 09:42:50 --> 404 Page Not Found: /index
ERROR - 2022-03-26 09:42:50 --> 404 Page Not Found: /index
ERROR - 2022-03-26 09:43:10 --> 404 Page Not Found: /index
ERROR - 2022-03-26 09:43:22 --> 404 Page Not Found: /index
ERROR - 2022-03-26 09:43:38 --> 404 Page Not Found: /index
ERROR - 2022-03-26 09:43:59 --> 404 Page Not Found: /index
ERROR - 2022-03-26 09:45:20 --> 404 Page Not Found: /index
ERROR - 2022-03-26 09:45:26 --> 404 Page Not Found: /index
ERROR - 2022-03-26 09:45:45 --> 404 Page Not Found: /index
ERROR - 2022-03-26 09:45:49 --> 404 Page Not Found: /index
ERROR - 2022-03-26 09:45:58 --> 404 Page Not Found: /index
ERROR - 2022-03-26 09:46:25 --> 404 Page Not Found: /index
ERROR - 2022-03-26 09:48:29 --> 404 Page Not Found: /index
ERROR - 2022-03-26 09:48:31 --> 404 Page Not Found: /index
ERROR - 2022-03-26 09:49:22 --> 404 Page Not Found: /index
ERROR - 2022-03-26 09:49:43 --> 404 Page Not Found: /index
ERROR - 2022-03-26 09:50:19 --> 404 Page Not Found: /index
ERROR - 2022-03-26 09:51:26 --> 404 Page Not Found: /index
ERROR - 2022-03-26 09:51:59 --> 404 Page Not Found: /index
ERROR - 2022-03-26 09:52:21 --> 404 Page Not Found: /index
ERROR - 2022-03-26 09:52:31 --> 404 Page Not Found: /index
ERROR - 2022-03-26 09:53:23 --> 404 Page Not Found: /index
ERROR - 2022-03-26 09:55:27 --> 404 Page Not Found: /index
ERROR - 2022-03-26 09:55:46 --> 404 Page Not Found: /index
ERROR - 2022-03-26 09:55:50 --> 404 Page Not Found: /index
ERROR - 2022-03-26 09:56:08 --> 404 Page Not Found: /index
ERROR - 2022-03-26 09:57:17 --> 404 Page Not Found: /index
ERROR - 2022-03-26 09:57:48 --> 404 Page Not Found: /index
ERROR - 2022-03-26 09:57:52 --> 404 Page Not Found: /index
ERROR - 2022-03-26 09:57:52 --> 404 Page Not Found: /index
ERROR - 2022-03-26 09:58:45 --> 404 Page Not Found: /index
ERROR - 2022-03-26 09:59:43 --> 404 Page Not Found: /index
ERROR - 2022-03-26 09:59:57 --> 404 Page Not Found: /index
ERROR - 2022-03-26 10:03:30 --> 404 Page Not Found: /index
ERROR - 2022-03-26 10:05:18 --> 404 Page Not Found: /index
ERROR - 2022-03-26 10:09:18 --> 404 Page Not Found: /index
ERROR - 2022-03-26 10:10:44 --> 404 Page Not Found: /index
ERROR - 2022-03-26 10:16:24 --> 404 Page Not Found: /index
ERROR - 2022-03-26 10:16:28 --> 404 Page Not Found: /index
ERROR - 2022-03-26 10:16:39 --> 404 Page Not Found: /index
ERROR - 2022-03-26 10:16:41 --> 404 Page Not Found: /index
ERROR - 2022-03-26 10:16:41 --> 404 Page Not Found: /index
ERROR - 2022-03-26 10:18:00 --> 404 Page Not Found: /index
ERROR - 2022-03-26 10:19:24 --> 404 Page Not Found: /index
ERROR - 2022-03-26 10:21:28 --> 404 Page Not Found: /index
ERROR - 2022-03-26 10:23:15 --> 404 Page Not Found: /index
ERROR - 2022-03-26 10:23:31 --> 404 Page Not Found: /index
ERROR - 2022-03-26 10:23:35 --> 404 Page Not Found: /index
ERROR - 2022-03-26 10:24:44 --> 404 Page Not Found: /index
ERROR - 2022-03-26 10:25:01 --> 404 Page Not Found: /index
ERROR - 2022-03-26 10:25:06 --> To Id is not available for User - 3369
ERROR - 2022-03-26 10:26:09 --> 404 Page Not Found: /index
ERROR - 2022-03-26 10:26:10 --> 404 Page Not Found: /index
ERROR - 2022-03-26 10:26:41 --> 404 Page Not Found: /index
ERROR - 2022-03-26 10:28:15 --> 404 Page Not Found: /index
ERROR - 2022-03-26 10:30:19 --> 404 Page Not Found: /index
ERROR - 2022-03-26 10:30:28 --> 404 Page Not Found: ../modules/admin/controllers/Admin/Admin_pwwwv
ERROR - 2022-03-26 10:30:30 --> 404 Page Not Found: ../modules/admin/controllers/Admin/Admin_pwwwv
ERROR - 2022-03-26 10:31:18 --> 404 Page Not Found: /index
ERROR - 2022-03-26 10:32:00 --> 404 Page Not Found: /index
ERROR - 2022-03-26 10:33:09 --> 404 Page Not Found: /index
ERROR - 2022-03-26 10:34:52 --> 404 Page Not Found: /index
ERROR - 2022-03-26 10:36:14 --> 404 Page Not Found: /index
ERROR - 2022-03-26 10:36:28 --> 404 Page Not Found: /index
ERROR - 2022-03-26 10:37:19 --> 404 Page Not Found: /index
ERROR - 2022-03-26 10:37:37 --> 404 Page Not Found: /index
ERROR - 2022-03-26 10:37:41 --> 404 Page Not Found: /index
ERROR - 2022-03-26 10:38:48 --> 404 Page Not Found: /index
ERROR - 2022-03-26 10:39:51 --> 404 Page Not Found: /index
ERROR - 2022-03-26 10:40:03 --> 404 Page Not Found: /index
ERROR - 2022-03-26 10:41:17 --> 404 Page Not Found: /index
ERROR - 2022-03-26 10:44:43 --> 404 Page Not Found: /index
ERROR - 2022-03-26 10:45:39 --> 404 Page Not Found: /index
ERROR - 2022-03-26 10:46:19 --> 404 Page Not Found: /index
ERROR - 2022-03-26 10:47:11 --> 404 Page Not Found: /index
ERROR - 2022-03-26 10:47:13 --> 404 Page Not Found: /index
ERROR - 2022-03-26 10:47:17 --> 404 Page Not Found: /index
ERROR - 2022-03-26 10:49:14 --> 404 Page Not Found: /index
ERROR - 2022-03-26 10:50:14 --> To Id is not available for User - 1499
ERROR - 2022-03-26 10:50:15 --> 404 Page Not Found: /index
ERROR - 2022-03-26 10:51:11 --> 404 Page Not Found: /index
ERROR - 2022-03-26 10:52:23 --> 404 Page Not Found: /index
ERROR - 2022-03-26 10:53:36 --> 404 Page Not Found: /index
ERROR - 2022-03-26 10:54:18 --> 404 Page Not Found: /index
ERROR - 2022-03-26 10:56:01 --> 404 Page Not Found: /index
ERROR - 2022-03-26 10:56:01 --> 404 Page Not Found: /index
ERROR - 2022-03-26 10:56:01 --> 404 Page Not Found: /index
ERROR - 2022-03-26 10:56:01 --> 404 Page Not Found: /index
ERROR - 2022-03-26 10:56:02 --> 404 Page Not Found: /index
ERROR - 2022-03-26 10:56:03 --> 404 Page Not Found: /index
ERROR - 2022-03-26 10:56:03 --> 404 Page Not Found: /index
ERROR - 2022-03-26 10:56:03 --> 404 Page Not Found: /index
ERROR - 2022-03-26 10:56:03 --> 404 Page Not Found: /index
ERROR - 2022-03-26 10:56:04 --> 404 Page Not Found: /index
ERROR - 2022-03-26 10:56:52 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:04:07 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:04:27 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:05:30 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:05:56 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:07:09 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:08:45 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:10:28 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:11:16 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:11:16 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:11:16 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:11:16 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:11:16 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:11:16 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:11:16 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:11:16 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:11:18 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:11:18 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:11:18 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:11:18 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:11:18 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:11:18 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:11:18 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:11:18 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:11:18 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:11:18 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:11:19 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:11:19 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:11:19 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:11:19 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:11:23 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`?bWUd`)' at line 3 - Invalid query: SELECT *
FROM `ms_servicelist`
WHERE (`from_msID` = 361 AND `to_msID` = 1935 `�bWUd`)
ERROR - 2022-03-26 11:11:24 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:13:17 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:14:37 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:14:46 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:14:46 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:14:56 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:16:38 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:18:18 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:19:29 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:19:39 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:20:17 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:21:09 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:21:09 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:21:09 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:21:31 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:22:24 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:22:45 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:24:02 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-26 11:24:02')
ERROR - 2022-03-26 11:24:04 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:25:27 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:25:27 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:25:27 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:26:06 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:27:01 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:27:16 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:27:48 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:27:50 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:28:00 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:28:18 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:28:46 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:32:17 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:32:18 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:35:04 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:35:04 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:35:04 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:35:18 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:35:18 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:35:18 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:35:18 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:38:45 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:40:38 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:40:49 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:42:08 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:42:20 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:43:35 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:44:38 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:45:43 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:45:49 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:48:13 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:49:33 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:50:33 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-26 11:50:33')
ERROR - 2022-03-26 11:51:36 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:55:15 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:56:21 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:57:13 --> 404 Page Not Found: /index
ERROR - 2022-03-26 11:59:04 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:00:42 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:01:03 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:01:36 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:01:42 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:02:04 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:03:46 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:03:55 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:04:39 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:07:43 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:11:00 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:12:24 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:12:24 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:12:36 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:12:37 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:13:08 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:13:09 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:13:24 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:14:06 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:15:08 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:16:18 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:16:32 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-26 12:16:32')
ERROR - 2022-03-26 12:17:48 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:19:04 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:19:07 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:19:21 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:19:35 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:21:13 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-26 12:21:53 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:21:53 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:22:03 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:22:20 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:23:09 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:24:24 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:24:39 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:24:44 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:25:03 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:26:18 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:26:26 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:27:04 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:27:19 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-26 12:27:19')
ERROR - 2022-03-26 12:27:20 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:28:52 --> To Id is not available for User - 3740
ERROR - 2022-03-26 12:28:52 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:28:58 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:29:05 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:29:31 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:31:04 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:33:56 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:34:13 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:35:32 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:35:47 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:35:48 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:35:48 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:38:04 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:38:04 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:38:04 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:38:06 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:39:13 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:40:21 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:40:22 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:41:39 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:43:10 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:43:32 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:44:19 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:45:06 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:45:13 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:45:18 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:45:39 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:48:33 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:48:42 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:49:09 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:50:15 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:50:33 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:50:58 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:50:58 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:51:27 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:51:45 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-26 12:51:45')
ERROR - 2022-03-26 12:51:46 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-26 12:51:46')
ERROR - 2022-03-26 12:52:12 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:53:54 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:54:19 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:54:20 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:55:00 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:55:16 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:56:47 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:57:13 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:58:00 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:58:11 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:58:11 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:58:12 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:58:12 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:58:12 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:58:19 --> 404 Page Not Found: /index
ERROR - 2022-03-26 12:59:04 --> 404 Page Not Found: /index
ERROR - 2022-03-26 13:00:10 --> 404 Page Not Found: /index
ERROR - 2022-03-26 13:01:27 --> 404 Page Not Found: /index
ERROR - 2022-03-26 13:02:59 --> 404 Page Not Found: /index
ERROR - 2022-03-26 13:03:00 --> 404 Page Not Found: /index
ERROR - 2022-03-26 13:04:14 --> 404 Page Not Found: /index
ERROR - 2022-03-26 13:05:13 --> 404 Page Not Found: /index
ERROR - 2022-03-26 13:07:08 --> 404 Page Not Found: /index
ERROR - 2022-03-26 13:07:14 --> 404 Page Not Found: /index
ERROR - 2022-03-26 13:07:16 --> 404 Page Not Found: /index
ERROR - 2022-03-26 13:07:17 --> To Id is not available for User - 322
ERROR - 2022-03-26 13:07:19 --> 404 Page Not Found: /index
ERROR - 2022-03-26 13:07:21 --> 404 Page Not Found: /index
ERROR - 2022-03-26 13:09:15 --> 404 Page Not Found: /index
ERROR - 2022-03-26 13:12:03 --> To Id is not available for User - 4213
ERROR - 2022-03-26 13:12:19 --> 404 Page Not Found: /index
ERROR - 2022-03-26 13:14:39 --> 404 Page Not Found: /index
ERROR - 2022-03-26 13:15:41 --> 404 Page Not Found: /index
ERROR - 2022-03-26 13:15:47 --> 404 Page Not Found: /index
ERROR - 2022-03-26 13:15:48 --> 404 Page Not Found: /index
ERROR - 2022-03-26 13:16:12 --> 404 Page Not Found: /index
ERROR - 2022-03-26 13:17:28 --> 404 Page Not Found: /index
ERROR - 2022-03-26 13:17:47 --> 404 Page Not Found: /index
ERROR - 2022-03-26 13:18:29 --> 404 Page Not Found: /index
ERROR - 2022-03-26 13:19:04 --> 404 Page Not Found: /index
ERROR - 2022-03-26 13:19:59 --> 404 Page Not Found: /index
ERROR - 2022-03-26 13:21:02 --> 404 Page Not Found: /index
ERROR - 2022-03-26 13:23:38 --> 404 Page Not Found: /index
ERROR - 2022-03-26 13:23:42 --> 404 Page Not Found: /index
ERROR - 2022-03-26 13:25:06 --> 404 Page Not Found: /index
ERROR - 2022-03-26 13:26:20 --> 404 Page Not Found: /index
ERROR - 2022-03-26 13:27:26 --> 404 Page Not Found: /index
ERROR - 2022-03-26 13:29:19 --> 404 Page Not Found: /index
ERROR - 2022-03-26 13:31:16 --> 404 Page Not Found: /index
ERROR - 2022-03-26 13:31:32 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-26 13:32:19 --> 404 Page Not Found: /index
ERROR - 2022-03-26 13:32:28 --> 404 Page Not Found: /index
ERROR - 2022-03-26 13:34:31 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '<script>alert("xssvuln")</script> AND <script>alert("xssvuln") < `/script>`
AND ' at line 8 - Invalid query: SELECT `p`.`gender`, `p`.`id`, `p`.`status`, `p`.`age`, `p`.`living_in`, `p`.`profile_id`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`
FROM `tbl_primary_info` as `p`
INNER JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`MS_id`
INNER JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
INNER JOIN `ms_profilesetting` as `s` ON `p`.`id`=`s`.`ms_id`
WHERE `p`.`gender` = '<script>alert(\"xssvuln\")</script>'
AND `p`.`age` BETWEEN <script>alert("xssvuln")</script> AND <script>alert("xssvuln") < `/script>`
AND `r`.`religion` = '<script>alert(\"xssvuln\")</script>'
AND `r`.`mother_tounge` = '<script>alert(\"xssvuln\")</script>'
AND `p`.`status` = 1
AND `s`.`elite` = 'no'
AND `s`.`ms_usertype` = 'regular'
AND `u`.`ismain` = 1
AND `u`.`photoname` != ''
AND `u`.`applicationphotopath` != ''
GROUP BY `u`.`MS_id`
ORDER BY `registered_on` DESC
 LIMIT 8
ERROR - 2022-03-26 13:35:46 --> 404 Page Not Found: /index
ERROR - 2022-03-26 13:36:11 --> 404 Page Not Found: /index
ERROR - 2022-03-26 13:37:23 --> 404 Page Not Found: /index
ERROR - 2022-03-26 13:38:22 --> 404 Page Not Found: /index
ERROR - 2022-03-26 13:39:33 --> 404 Page Not Found: /index
ERROR - 2022-03-26 13:40:27 --> 404 Page Not Found: /index
ERROR - 2022-03-26 13:42:44 --> 404 Page Not Found: /index
ERROR - 2022-03-26 13:43:11 --> 404 Page Not Found: /index
ERROR - 2022-03-26 13:43:35 --> 404 Page Not Found: /index
ERROR - 2022-03-26 13:45:56 --> 404 Page Not Found: /index
ERROR - 2022-03-26 13:46:13 --> 404 Page Not Found: /index
ERROR - 2022-03-26 13:46:38 --> 404 Page Not Found: /index
ERROR - 2022-03-26 13:47:06 --> 404 Page Not Found: /index
ERROR - 2022-03-26 13:49:02 --> 404 Page Not Found: /index
ERROR - 2022-03-26 13:49:17 --> 404 Page Not Found: /index
ERROR - 2022-03-26 13:49:23 --> 404 Page Not Found: /index
ERROR - 2022-03-26 13:49:36 --> 404 Page Not Found: /index
ERROR - 2022-03-26 13:49:37 --> 404 Page Not Found: /index
ERROR - 2022-03-26 13:49:50 --> 404 Page Not Found: /index
ERROR - 2022-03-26 13:51:42 --> 404 Page Not Found: /index
ERROR - 2022-03-26 13:52:32 --> 404 Page Not Found: /index
ERROR - 2022-03-26 13:54:39 --> 404 Page Not Found: /index
ERROR - 2022-03-26 13:55:52 --> 404 Page Not Found: /index
ERROR - 2022-03-26 14:00:26 --> 404 Page Not Found: /index
ERROR - 2022-03-26 14:00:26 --> 404 Page Not Found: /index
ERROR - 2022-03-26 14:00:36 --> 404 Page Not Found: /index
ERROR - 2022-03-26 14:03:22 --> 404 Page Not Found: /index
ERROR - 2022-03-26 14:03:45 --> 404 Page Not Found: /index
ERROR - 2022-03-26 14:04:39 --> 404 Page Not Found: /index
ERROR - 2022-03-26 14:04:41 --> 404 Page Not Found: /index
ERROR - 2022-03-26 14:04:44 --> 404 Page Not Found: /index
ERROR - 2022-03-26 14:04:59 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-26 14:04:59')
ERROR - 2022-03-26 14:05:03 --> 404 Page Not Found: /index
ERROR - 2022-03-26 14:06:11 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-26 14:06:20 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-26 14:06:22 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-26 14:07:41 --> 404 Page Not Found: /index
ERROR - 2022-03-26 14:08:06 --> 404 Page Not Found: /index
ERROR - 2022-03-26 14:08:30 --> 404 Page Not Found: /index
ERROR - 2022-03-26 14:08:32 --> 404 Page Not Found: /index
ERROR - 2022-03-26 14:09:02 --> 404 Page Not Found: /index
ERROR - 2022-03-26 14:10:32 --> 404 Page Not Found: /index
ERROR - 2022-03-26 14:11:56 --> 404 Page Not Found: /index
ERROR - 2022-03-26 14:11:56 --> 404 Page Not Found: /index
ERROR - 2022-03-26 14:12:25 --> 404 Page Not Found: /index
ERROR - 2022-03-26 14:13:25 --> 404 Page Not Found: /index
ERROR - 2022-03-26 14:13:44 --> 404 Page Not Found: /index
ERROR - 2022-03-26 14:13:58 --> 404 Page Not Found: /index
ERROR - 2022-03-26 14:15:11 --> 404 Page Not Found: /index
ERROR - 2022-03-26 14:15:53 --> 404 Page Not Found: /index
ERROR - 2022-03-26 14:16:54 --> 404 Page Not Found: /index
ERROR - 2022-03-26 14:17:28 --> 404 Page Not Found: /index
ERROR - 2022-03-26 14:20:26 --> 404 Page Not Found: /index
ERROR - 2022-03-26 14:23:52 --> 404 Page Not Found: /index
ERROR - 2022-03-26 14:24:01 --> 404 Page Not Found: /index
ERROR - 2022-03-26 14:24:16 --> 404 Page Not Found: /index
ERROR - 2022-03-26 14:24:32 --> 404 Page Not Found: /index
ERROR - 2022-03-26 14:25:25 --> 404 Page Not Found: /index
ERROR - 2022-03-26 14:25:30 --> 404 Page Not Found: /index
ERROR - 2022-03-26 14:27:45 --> 404 Page Not Found: /index
ERROR - 2022-03-26 14:28:55 --> 404 Page Not Found: /index
ERROR - 2022-03-26 14:30:43 --> 404 Page Not Found: /index
ERROR - 2022-03-26 14:31:12 --> 404 Page Not Found: /index
ERROR - 2022-03-26 14:31:25 --> 404 Page Not Found: /index
ERROR - 2022-03-26 14:31:53 --> 404 Page Not Found: /index
ERROR - 2022-03-26 14:32:04 --> 404 Page Not Found: /index
ERROR - 2022-03-26 14:32:48 --> 404 Page Not Found: /index
ERROR - 2022-03-26 14:37:16 --> 404 Page Not Found: /index
ERROR - 2022-03-26 14:37:19 --> 404 Page Not Found: /index
ERROR - 2022-03-26 14:37:31 --> 404 Page Not Found: /index
ERROR - 2022-03-26 14:37:53 --> 404 Page Not Found: /index
ERROR - 2022-03-26 14:38:37 --> 404 Page Not Found: /index
ERROR - 2022-03-26 14:38:41 --> 404 Page Not Found: /index
ERROR - 2022-03-26 14:40:12 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-26 14:40:12')
ERROR - 2022-03-26 14:40:43 --> 404 Page Not Found: /index
ERROR - 2022-03-26 14:41:23 --> 404 Page Not Found: /index
ERROR - 2022-03-26 14:45:23 --> 404 Page Not Found: /index
ERROR - 2022-03-26 14:47:59 --> 404 Page Not Found: /index
ERROR - 2022-03-26 14:49:43 --> 404 Page Not Found: /index
ERROR - 2022-03-26 14:52:38 --> 404 Page Not Found: /index
ERROR - 2022-03-26 14:53:49 --> 404 Page Not Found: /index
ERROR - 2022-03-26 14:54:18 --> 404 Page Not Found: /index
ERROR - 2022-03-26 14:54:32 --> 404 Page Not Found: /index
ERROR - 2022-03-26 14:54:45 --> 404 Page Not Found: /index
ERROR - 2022-03-26 14:54:47 --> 404 Page Not Found: /index
ERROR - 2022-03-26 14:55:43 --> 404 Page Not Found: /index
ERROR - 2022-03-26 14:56:53 --> 404 Page Not Found: /index
ERROR - 2022-03-26 14:57:01 --> 404 Page Not Found: /index
ERROR - 2022-03-26 14:57:07 --> 404 Page Not Found: /index
ERROR - 2022-03-26 14:57:07 --> 404 Page Not Found: /index
ERROR - 2022-03-26 14:58:04 --> 404 Page Not Found: /index
ERROR - 2022-03-26 15:06:56 --> 404 Page Not Found: /index
ERROR - 2022-03-26 15:07:39 --> 404 Page Not Found: /index
ERROR - 2022-03-26 15:07:48 --> 404 Page Not Found: /index
ERROR - 2022-03-26 15:08:12 --> 404 Page Not Found: /index
ERROR - 2022-03-26 15:12:44 --> 404 Page Not Found: /index
ERROR - 2022-03-26 15:13:07 --> 404 Page Not Found: /index
ERROR - 2022-03-26 15:13:37 --> 404 Page Not Found: /index
ERROR - 2022-03-26 15:15:45 --> 404 Page Not Found: /index
ERROR - 2022-03-26 15:16:05 --> 404 Page Not Found: /index
ERROR - 2022-03-26 15:16:49 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-26 15:16:49')
ERROR - 2022-03-26 15:17:01 --> 404 Page Not Found: /index
ERROR - 2022-03-26 15:17:29 --> 404 Page Not Found: /index
ERROR - 2022-03-26 15:17:30 --> 404 Page Not Found: /index
ERROR - 2022-03-26 15:18:56 --> 404 Page Not Found: /index
ERROR - 2022-03-26 15:20:37 --> 404 Page Not Found: /index
ERROR - 2022-03-26 15:21:37 --> 404 Page Not Found: /index
ERROR - 2022-03-26 15:22:51 --> 404 Page Not Found: /index
ERROR - 2022-03-26 15:23:20 --> 404 Page Not Found: /index
ERROR - 2022-03-26 15:25:18 --> 404 Page Not Found: /index
ERROR - 2022-03-26 15:25:31 --> To Id is not available for User - 4224
ERROR - 2022-03-26 15:25:37 --> To Id is not available for User - 4224
ERROR - 2022-03-26 15:25:58 --> 404 Page Not Found: /index
ERROR - 2022-03-26 15:27:55 --> 404 Page Not Found: /index
ERROR - 2022-03-26 15:28:18 --> 404 Page Not Found: /index
ERROR - 2022-03-26 15:29:38 --> 404 Page Not Found: /index
ERROR - 2022-03-26 15:32:37 --> 404 Page Not Found: /index
ERROR - 2022-03-26 15:33:26 --> 404 Page Not Found: /index
ERROR - 2022-03-26 15:36:03 --> 404 Page Not Found: /index
ERROR - 2022-03-26 15:36:32 --> 404 Page Not Found: /index
ERROR - 2022-03-26 15:37:48 --> 404 Page Not Found: /index
ERROR - 2022-03-26 15:38:15 --> 404 Page Not Found: /index
ERROR - 2022-03-26 15:39:52 --> 404 Page Not Found: /index
ERROR - 2022-03-26 15:39:52 --> 404 Page Not Found: /index
ERROR - 2022-03-26 15:40:02 --> 404 Page Not Found: /index
ERROR - 2022-03-26 15:40:51 --> 404 Page Not Found: /index
ERROR - 2022-03-26 15:41:40 --> 404 Page Not Found: /index
ERROR - 2022-03-26 15:43:05 --> 404 Page Not Found: /index
ERROR - 2022-03-26 15:43:26 --> 404 Page Not Found: /index
ERROR - 2022-03-26 15:44:11 --> 404 Page Not Found: /index
ERROR - 2022-03-26 15:47:57 --> 404 Page Not Found: /index
ERROR - 2022-03-26 15:48:08 --> 404 Page Not Found: /index
ERROR - 2022-03-26 15:49:11 --> 404 Page Not Found: /index
ERROR - 2022-03-26 15:50:51 --> 404 Page Not Found: /index
ERROR - 2022-03-26 15:52:23 --> 404 Page Not Found: /index
ERROR - 2022-03-26 15:52:28 --> 404 Page Not Found: /index
ERROR - 2022-03-26 15:52:32 --> 404 Page Not Found: /index
ERROR - 2022-03-26 15:53:07 --> 404 Page Not Found: /index
ERROR - 2022-03-26 15:54:24 --> 404 Page Not Found: /index
ERROR - 2022-03-26 15:56:53 --> 404 Page Not Found: /index
ERROR - 2022-03-26 15:58:01 --> 404 Page Not Found: /index
ERROR - 2022-03-26 15:58:54 --> 404 Page Not Found: /index
ERROR - 2022-03-26 16:03:20 --> 404 Page Not Found: /index
ERROR - 2022-03-26 16:03:20 --> 404 Page Not Found: /index
ERROR - 2022-03-26 16:03:20 --> 404 Page Not Found: /index
ERROR - 2022-03-26 16:03:21 --> 404 Page Not Found: /index
ERROR - 2022-03-26 16:03:22 --> 404 Page Not Found: /index
ERROR - 2022-03-26 16:04:10 --> 404 Page Not Found: /index
ERROR - 2022-03-26 16:04:31 --> 404 Page Not Found: /index
ERROR - 2022-03-26 16:06:28 --> 404 Page Not Found: /index
ERROR - 2022-03-26 16:09:40 --> 404 Page Not Found: /index
ERROR - 2022-03-26 16:10:36 --> 404 Page Not Found: /index
ERROR - 2022-03-26 16:11:20 --> 404 Page Not Found: /index
ERROR - 2022-03-26 16:11:51 --> 404 Page Not Found: /index
ERROR - 2022-03-26 16:12:30 --> 404 Page Not Found: /index
ERROR - 2022-03-26 16:16:16 --> 404 Page Not Found: /index
ERROR - 2022-03-26 16:16:55 --> 404 Page Not Found: /index
ERROR - 2022-03-26 16:17:13 --> 404 Page Not Found: /index
ERROR - 2022-03-26 16:18:23 --> 404 Page Not Found: /index
ERROR - 2022-03-26 16:20:20 --> 404 Page Not Found: /index
ERROR - 2022-03-26 16:24:17 --> 404 Page Not Found: /index
ERROR - 2022-03-26 16:24:57 --> 404 Page Not Found: /index
ERROR - 2022-03-26 16:25:36 --> 404 Page Not Found: /index
ERROR - 2022-03-26 16:25:50 --> 404 Page Not Found: /index
ERROR - 2022-03-26 16:27:51 --> 404 Page Not Found: /index
ERROR - 2022-03-26 16:34:37 --> 404 Page Not Found: /index
ERROR - 2022-03-26 16:35:05 --> 404 Page Not Found: /index
ERROR - 2022-03-26 16:35:25 --> 404 Page Not Found: /index
ERROR - 2022-03-26 16:35:50 --> 404 Page Not Found: /index
ERROR - 2022-03-26 16:37:54 --> 404 Page Not Found: /index
ERROR - 2022-03-26 16:41:56 --> 404 Page Not Found: /index
ERROR - 2022-03-26 16:42:15 --> 404 Page Not Found: /index
ERROR - 2022-03-26 16:42:41 --> 404 Page Not Found: /index
ERROR - 2022-03-26 16:43:12 --> 404 Page Not Found: /index
ERROR - 2022-03-26 16:49:06 --> 404 Page Not Found: /index
ERROR - 2022-03-26 16:49:22 --> 404 Page Not Found: /index
ERROR - 2022-03-26 16:51:30 --> 404 Page Not Found: /index
ERROR - 2022-03-26 16:55:13 --> 404 Page Not Found: /index
ERROR - 2022-03-26 16:56:03 --> 404 Page Not Found: /index
ERROR - 2022-03-26 16:56:51 --> 404 Page Not Found: /index
ERROR - 2022-03-26 16:57:14 --> 404 Page Not Found: /index
ERROR - 2022-03-26 16:57:40 --> 404 Page Not Found: /index
ERROR - 2022-03-26 17:04:52 --> 404 Page Not Found: /index
ERROR - 2022-03-26 17:06:09 --> 404 Page Not Found: /index
ERROR - 2022-03-26 17:06:13 --> 404 Page Not Found: /index
ERROR - 2022-03-26 17:10:13 --> 404 Page Not Found: /index
ERROR - 2022-03-26 17:10:30 --> 404 Page Not Found: /index
ERROR - 2022-03-26 17:11:36 --> 404 Page Not Found: /index
ERROR - 2022-03-26 17:11:51 --> 404 Page Not Found: /index
ERROR - 2022-03-26 17:12:23 --> 404 Page Not Found: /index
ERROR - 2022-03-26 17:12:55 --> 404 Page Not Found: /index
ERROR - 2022-03-26 17:13:08 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-26 17:13:08')
ERROR - 2022-03-26 17:13:31 --> 404 Page Not Found: /index
ERROR - 2022-03-26 17:13:55 --> 404 Page Not Found: /index
ERROR - 2022-03-26 17:15:33 --> To Id is not available for User - 4019
ERROR - 2022-03-26 17:16:45 --> 404 Page Not Found: /index
ERROR - 2022-03-26 17:17:37 --> 404 Page Not Found: /index
ERROR - 2022-03-26 17:18:10 --> 404 Page Not Found: /index
ERROR - 2022-03-26 17:19:16 --> 404 Page Not Found: /index
ERROR - 2022-03-26 17:19:18 --> 404 Page Not Found: /index
ERROR - 2022-03-26 17:21:41 --> 404 Page Not Found: /index
ERROR - 2022-03-26 17:24:02 --> 404 Page Not Found: /index
ERROR - 2022-03-26 17:24:39 --> 404 Page Not Found: /index
ERROR - 2022-03-26 17:25:00 --> 404 Page Not Found: /index
ERROR - 2022-03-26 17:25:33 --> 404 Page Not Found: /index
ERROR - 2022-03-26 17:26:38 --> 404 Page Not Found: /index
ERROR - 2022-03-26 17:27:00 --> 404 Page Not Found: /index
ERROR - 2022-03-26 17:31:40 --> 404 Page Not Found: /index
ERROR - 2022-03-26 17:32:02 --> 404 Page Not Found: /index
ERROR - 2022-03-26 17:35:45 --> 404 Page Not Found: /index
ERROR - 2022-03-26 17:35:50 --> 404 Page Not Found: /index
ERROR - 2022-03-26 17:39:16 --> 404 Page Not Found: /index
ERROR - 2022-03-26 17:40:46 --> 404 Page Not Found: /index
ERROR - 2022-03-26 17:40:46 --> 404 Page Not Found: /index
ERROR - 2022-03-26 17:40:47 --> 404 Page Not Found: /index
ERROR - 2022-03-26 17:42:36 --> 404 Page Not Found: /index
ERROR - 2022-03-26 17:42:52 --> 404 Page Not Found: /index
ERROR - 2022-03-26 17:43:09 --> 404 Page Not Found: /index
ERROR - 2022-03-26 17:43:39 --> 404 Page Not Found: /index
ERROR - 2022-03-26 17:43:43 --> 404 Page Not Found: /index
ERROR - 2022-03-26 17:44:10 --> 404 Page Not Found: /index
ERROR - 2022-03-26 17:48:02 --> To Id is not available for User - 4019
ERROR - 2022-03-26 17:50:18 --> 404 Page Not Found: /index
ERROR - 2022-03-26 17:51:33 --> 404 Page Not Found: /index
ERROR - 2022-03-26 17:51:43 --> 404 Page Not Found: /index
ERROR - 2022-03-26 17:53:28 --> 404 Page Not Found: /index
ERROR - 2022-03-26 17:54:42 --> 404 Page Not Found: /index
ERROR - 2022-03-26 17:54:51 --> 404 Page Not Found: /index
ERROR - 2022-03-26 17:54:56 --> 404 Page Not Found: /index
ERROR - 2022-03-26 17:55:10 --> 404 Page Not Found: /index
ERROR - 2022-03-26 18:00:43 --> 404 Page Not Found: /index
ERROR - 2022-03-26 18:01:19 --> 404 Page Not Found: /index
ERROR - 2022-03-26 18:01:26 --> 404 Page Not Found: /index
ERROR - 2022-03-26 18:05:27 --> 404 Page Not Found: /index
ERROR - 2022-03-26 18:07:32 --> 404 Page Not Found: /index
ERROR - 2022-03-26 18:10:28 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: select SUM(IFNULL(`basicdetails`, 0) + IFNULL(`religion`, 0) + IFNULL(`edu_prof`, 0) + IFNULL(`parents`, 0) + IFNULL(`Siblings`, 0) + IFNULL(`photo`, 0)) as total,photo,basicdetails,religion,edu_prof,parents,Siblings from tbl_profilebattery where user_id=
ERROR - 2022-03-26 18:10:29 --> 404 Page Not Found: /index
ERROR - 2022-03-26 18:10:45 --> 404 Page Not Found: /index
ERROR - 2022-03-26 18:11:01 --> 404 Page Not Found: /index
ERROR - 2022-03-26 18:11:03 --> Query error: Table 'cowcdrmy_kammamarriage.ms_shortlist_viewedd_ignored' doesn't exist - Invalid query: SELECT `v`.*, `p`.`gender`, `p`.`id`, `p`.`status`, `p`.`age`, `p`.`living_in`, `p`.`profile_id`, `p`.`first_name`, `last_name`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `s`.*
FROM `kv_profileview` as `v`
LEFT JOIN `tbl_primary_info` as `p` ON `v`.`kv_profileview_on` = `p`.`id`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`ms_id`
INNER JOIN `ms_profilesetting` as `s` ON `p`.`id`=`s`.`ms_id`
WHERE `s`.`elite` = 'no'
AND `p`.`status` = 1
AND `v`.`kv_userfkid` = '3581'
AND `u`.`ismain` = 1
AND  `p`.`id` not in(select kv_msi_interested_on from kv_mysideinterests where kv_msi_profilefkid="3581")
AND  p.id not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid = "3581" AND `shortlist_status` = 1)
AND  `p`.`id` not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid="3581"AND ignore_status=1)
ORDER BY `v`.`kv_profileview_created_date` DESC
 LIMIT 10
ERROR - 2022-03-26 18:11:48 --> 404 Page Not Found: /index
ERROR - 2022-03-26 18:12:10 --> 404 Page Not Found: /index
ERROR - 2022-03-26 18:12:11 --> 404 Page Not Found: /index
ERROR - 2022-03-26 18:12:11 --> 404 Page Not Found: /index
ERROR - 2022-03-26 18:12:13 --> 404 Page Not Found: /index
ERROR - 2022-03-26 18:12:15 --> 404 Page Not Found: /index
ERROR - 2022-03-26 18:12:18 --> 404 Page Not Found: /index
ERROR - 2022-03-26 18:12:21 --> 404 Page Not Found: /index
ERROR - 2022-03-26 18:12:22 --> 404 Page Not Found: /index
ERROR - 2022-03-26 18:12:31 --> 404 Page Not Found: /index
ERROR - 2022-03-26 18:12:31 --> 404 Page Not Found: /index
ERROR - 2022-03-26 18:17:40 --> 404 Page Not Found: /index
ERROR - 2022-03-26 18:18:41 --> Query error: Table 'cowcdrmy_kammamarriage.ms_shortlist_viewedd_ignored' doesn't exist - Invalid query: SELECT `v`.*, `p`.`gender`, `p`.`id`, `p`.`status`, `p`.`age`, `p`.`living_in`, `p`.`profile_id`, `p`.`first_name`, `last_name`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `s`.*
FROM `kv_profileview` as `v`
LEFT JOIN `tbl_primary_info` as `p` ON `v`.`kv_profileview_on` = `p`.`id`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`ms_id`
INNER JOIN `ms_profilesetting` as `s` ON `p`.`id`=`s`.`ms_id`
WHERE `s`.`elite` = 'no'
AND `p`.`status` = 1
AND `v`.`kv_userfkid` = '3581'
AND `u`.`ismain` = 1
AND  `p`.`id` not in(select kv_msi_interested_on from kv_mysideinterests where kv_msi_profilefkid="3581")
AND  p.id not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid = "3581" AND `shortlist_status` = 1)
AND  `p`.`id` not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid="3581"AND ignore_status=1)
ORDER BY `v`.`kv_profileview_created_date` DESC
 LIMIT 10
ERROR - 2022-03-26 18:19:26 --> 404 Page Not Found: /index
ERROR - 2022-03-26 18:20:15 --> Severity: error --> Exception: Call to a member function result_array() on null /home4/cowcdrmy/public_html/application/modules/dashboard/models/My_account_model.php 911
ERROR - 2022-03-26 18:20:17 --> Query error: Table 'cowcdrmy_kammamarriage.ms_shortlist_viewedd_ignored' doesn't exist - Invalid query: SELECT `v`.*, `p`.`gender`, `p`.`id`, `p`.`status`, `p`.`age`, `p`.`living_in`, `p`.`profile_id`, `p`.`first_name`, `last_name`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `s`.*
FROM `kv_profileview` as `v`
LEFT JOIN `tbl_primary_info` as `p` ON `v`.`kv_profileview_on` = `p`.`id`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`ms_id`
INNER JOIN `ms_profilesetting` as `s` ON `p`.`id`=`s`.`ms_id`
WHERE `s`.`elite` = 'no'
AND `p`.`status` = 1
AND `v`.`kv_userfkid` = '3581'
AND `u`.`ismain` = 1
AND  `p`.`id` not in(select kv_msi_interested_on from kv_mysideinterests where kv_msi_profilefkid="3581")
AND  p.id not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid = "3581" AND `shortlist_status` = 1)
AND  `p`.`id` not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid="3581"AND ignore_status=1)
ORDER BY `v`.`kv_profileview_created_date` DESC
 LIMIT 10
ERROR - 2022-03-26 18:20:18 --> 404 Page Not Found: /index
ERROR - 2022-03-26 18:20:19 --> Severity: error --> Exception: Call to a member function result_array() on null /home4/cowcdrmy/public_html/application/modules/dashboard/models/My_account_model.php 911
ERROR - 2022-03-26 18:20:23 --> Query error: Table 'cowcdrmy_kammamarriage.ms_shortlist_viewedd_ignored' doesn't exist - Invalid query: SELECT `v`.*, `p`.`gender`, `p`.`id`, `p`.`status`, `p`.`age`, `p`.`living_in`, `p`.`profile_id`, `p`.`first_name`, `last_name`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `s`.*
FROM `kv_profileview` as `v`
LEFT JOIN `tbl_primary_info` as `p` ON `v`.`kv_profileview_on` = `p`.`id`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`ms_id`
INNER JOIN `ms_profilesetting` as `s` ON `p`.`id`=`s`.`ms_id`
WHERE `s`.`elite` = 'no'
AND `p`.`status` = 1
AND `v`.`kv_userfkid` = '3581'
AND `u`.`ismain` = 1
AND  `p`.`id` not in(select kv_msi_interested_on from kv_mysideinterests where kv_msi_profilefkid="3581")
AND  p.id not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid = "3581" AND `shortlist_status` = 1)
AND  `p`.`id` not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid="3581"AND ignore_status=1)
ORDER BY `v`.`kv_profileview_created_date` DESC
 LIMIT 10
ERROR - 2022-03-26 18:20:25 --> Severity: error --> Exception: Call to a member function result_array() on null /home4/cowcdrmy/public_html/application/modules/dashboard/models/My_account_model.php 911
ERROR - 2022-03-26 18:20:36 --> 404 Page Not Found: /index
ERROR - 2022-03-26 18:20:36 --> 404 Page Not Found: /index
ERROR - 2022-03-26 18:20:36 --> 404 Page Not Found: /index
ERROR - 2022-03-26 18:20:52 --> 404 Page Not Found: /index
ERROR - 2022-03-26 18:20:57 --> 404 Page Not Found: /index
ERROR - 2022-03-26 18:20:58 --> 404 Page Not Found: /index
ERROR - 2022-03-26 18:22:10 --> 404 Page Not Found: /index
ERROR - 2022-03-26 18:25:51 --> 404 Page Not Found: /index
ERROR - 2022-03-26 18:28:47 --> 404 Page Not Found: /index
ERROR - 2022-03-26 18:28:59 --> 404 Page Not Found: /index
ERROR - 2022-03-26 18:29:01 --> 404 Page Not Found: /index
ERROR - 2022-03-26 18:29:50 --> 404 Page Not Found: /index
ERROR - 2022-03-26 18:30:41 --> 404 Page Not Found: /index
ERROR - 2022-03-26 18:31:07 --> 404 Page Not Found: /index
ERROR - 2022-03-26 18:31:54 --> 404 Page Not Found: /index
ERROR - 2022-03-26 18:32:37 --> 404 Page Not Found: /index
ERROR - 2022-03-26 18:33:18 --> 404 Page Not Found: /index
ERROR - 2022-03-26 18:33:34 --> 404 Page Not Found: /index
ERROR - 2022-03-26 18:33:41 --> 404 Page Not Found: /index
ERROR - 2022-03-26 18:35:43 --> 404 Page Not Found: /index
ERROR - 2022-03-26 18:35:43 --> 404 Page Not Found: /index
ERROR - 2022-03-26 18:36:04 --> 404 Page Not Found: /index
ERROR - 2022-03-26 18:36:49 --> 404 Page Not Found: /index
ERROR - 2022-03-26 18:37:38 --> 404 Page Not Found: /index
ERROR - 2022-03-26 18:40:04 --> 404 Page Not Found: /index
ERROR - 2022-03-26 18:40:05 --> 404 Page Not Found: /index
ERROR - 2022-03-26 18:42:29 --> 404 Page Not Found: /index
ERROR - 2022-03-26 18:42:29 --> 404 Page Not Found: /index
ERROR - 2022-03-26 18:42:44 --> 404 Page Not Found: /index
ERROR - 2022-03-26 18:46:59 --> 404 Page Not Found: /index
ERROR - 2022-03-26 18:47:27 --> 404 Page Not Found: /index
ERROR - 2022-03-26 18:48:18 --> 404 Page Not Found: /index
ERROR - 2022-03-26 18:49:28 --> 404 Page Not Found: /index
ERROR - 2022-03-26 18:52:48 --> 404 Page Not Found: /index
ERROR - 2022-03-26 18:53:12 --> 404 Page Not Found: /index
ERROR - 2022-03-26 18:53:13 --> 404 Page Not Found: /index
ERROR - 2022-03-26 18:58:21 --> 404 Page Not Found: /index
ERROR - 2022-03-26 18:59:10 --> 404 Page Not Found: /index
ERROR - 2022-03-26 18:59:18 --> 404 Page Not Found: /index
ERROR - 2022-03-26 19:00:32 --> 404 Page Not Found: /index
ERROR - 2022-03-26 19:03:10 --> To Id is not available for User - 4316
ERROR - 2022-03-26 19:03:26 --> To Id is not available for User - 4316
ERROR - 2022-03-26 19:03:42 --> To Id is not available for User - 4316
ERROR - 2022-03-26 19:04:26 --> 404 Page Not Found: /index
ERROR - 2022-03-26 19:05:16 --> 404 Page Not Found: /index
ERROR - 2022-03-26 19:06:40 --> 404 Page Not Found: /index
ERROR - 2022-03-26 19:06:52 --> 404 Page Not Found: /index
ERROR - 2022-03-26 19:07:03 --> 404 Page Not Found: /index
ERROR - 2022-03-26 19:08:51 --> 404 Page Not Found: /index
ERROR - 2022-03-26 19:09:48 --> 404 Page Not Found: /index
ERROR - 2022-03-26 19:10:02 --> 404 Page Not Found: /index
ERROR - 2022-03-26 19:10:07 --> 404 Page Not Found: /index
ERROR - 2022-03-26 19:17:05 --> 404 Page Not Found: /index
ERROR - 2022-03-26 19:18:54 --> 404 Page Not Found: /index
ERROR - 2022-03-26 19:18:56 --> To Id is not available for User - 4319
ERROR - 2022-03-26 19:20:47 --> 404 Page Not Found: /index
ERROR - 2022-03-26 19:20:48 --> 404 Page Not Found: /index
ERROR - 2022-03-26 19:21:17 --> 404 Page Not Found: /index
ERROR - 2022-03-26 19:22:23 --> 404 Page Not Found: /index
ERROR - 2022-03-26 19:23:32 --> 404 Page Not Found: /index
ERROR - 2022-03-26 19:25:21 --> 404 Page Not Found: /index
ERROR - 2022-03-26 19:25:27 --> 404 Page Not Found: /index
ERROR - 2022-03-26 19:25:45 --> 404 Page Not Found: /index
ERROR - 2022-03-26 19:25:54 --> 404 Page Not Found: /index
ERROR - 2022-03-26 19:26:26 --> 404 Page Not Found: /index
ERROR - 2022-03-26 19:27:14 --> 404 Page Not Found: /index
ERROR - 2022-03-26 19:29:16 --> 404 Page Not Found: /index
ERROR - 2022-03-26 19:30:08 --> 404 Page Not Found: /index
ERROR - 2022-03-26 19:30:38 --> 404 Page Not Found: /index
ERROR - 2022-03-26 19:31:17 --> 404 Page Not Found: /index
ERROR - 2022-03-26 19:31:34 --> 404 Page Not Found: /index
ERROR - 2022-03-26 19:31:46 --> 404 Page Not Found: /index
ERROR - 2022-03-26 19:31:59 --> 404 Page Not Found: /index
ERROR - 2022-03-26 19:32:34 --> 404 Page Not Found: /index
ERROR - 2022-03-26 19:32:51 --> 404 Page Not Found: /index
ERROR - 2022-03-26 19:34:10 --> 404 Page Not Found: /index
ERROR - 2022-03-26 19:34:50 --> 404 Page Not Found: /index
ERROR - 2022-03-26 19:39:33 --> 404 Page Not Found: /index
ERROR - 2022-03-26 19:40:58 --> 404 Page Not Found: /index
ERROR - 2022-03-26 19:40:59 --> 404 Page Not Found: /index
ERROR - 2022-03-26 19:40:59 --> 404 Page Not Found: /index
ERROR - 2022-03-26 19:41:00 --> 404 Page Not Found: /index
ERROR - 2022-03-26 19:41:00 --> 404 Page Not Found: /index
ERROR - 2022-03-26 19:41:01 --> 404 Page Not Found: /index
ERROR - 2022-03-26 19:41:02 --> 404 Page Not Found: /index
ERROR - 2022-03-26 19:41:02 --> 404 Page Not Found: /index
ERROR - 2022-03-26 19:41:03 --> 404 Page Not Found: /index
ERROR - 2022-03-26 19:41:03 --> 404 Page Not Found: /index
ERROR - 2022-03-26 19:41:38 --> 404 Page Not Found: /index
ERROR - 2022-03-26 19:43:32 --> 404 Page Not Found: /index
ERROR - 2022-03-26 19:43:49 --> 404 Page Not Found: /index
ERROR - 2022-03-26 19:45:21 --> 404 Page Not Found: /index
ERROR - 2022-03-26 19:45:21 --> 404 Page Not Found: /index
ERROR - 2022-03-26 19:45:21 --> 404 Page Not Found: /index
ERROR - 2022-03-26 19:45:21 --> 404 Page Not Found: /index
ERROR - 2022-03-26 19:45:21 --> 404 Page Not Found: /index
ERROR - 2022-03-26 19:47:20 --> 404 Page Not Found: /index
ERROR - 2022-03-26 19:47:45 --> 404 Page Not Found: /index
ERROR - 2022-03-26 19:48:08 --> 404 Page Not Found: /index
ERROR - 2022-03-26 19:52:35 --> 404 Page Not Found: /index
ERROR - 2022-03-26 20:01:41 --> 404 Page Not Found: /index
ERROR - 2022-03-26 20:05:39 --> 404 Page Not Found: /index
ERROR - 2022-03-26 20:06:28 --> 404 Page Not Found: /index
ERROR - 2022-03-26 20:07:48 --> 404 Page Not Found: /index
ERROR - 2022-03-26 20:10:06 --> 404 Page Not Found: /index
ERROR - 2022-03-26 20:11:53 --> 404 Page Not Found: /index
ERROR - 2022-03-26 20:12:03 --> 404 Page Not Found: /index
ERROR - 2022-03-26 20:13:48 --> 404 Page Not Found: /index
ERROR - 2022-03-26 20:17:41 --> 404 Page Not Found: /index
ERROR - 2022-03-26 20:21:57 --> 404 Page Not Found: /index
ERROR - 2022-03-26 20:25:59 --> 404 Page Not Found: /index
ERROR - 2022-03-26 20:26:04 --> 404 Page Not Found: /index
ERROR - 2022-03-26 20:26:59 --> 404 Page Not Found: /index
ERROR - 2022-03-26 20:27:53 --> 404 Page Not Found: /index
ERROR - 2022-03-26 20:32:47 --> 404 Page Not Found: /index
ERROR - 2022-03-26 20:32:57 --> 404 Page Not Found: /index
ERROR - 2022-03-26 20:33:38 --> 404 Page Not Found: /index
ERROR - 2022-03-26 20:34:38 --> 404 Page Not Found: /index
ERROR - 2022-03-26 20:37:09 --> 404 Page Not Found: /index
ERROR - 2022-03-26 20:38:13 --> 404 Page Not Found: /index
ERROR - 2022-03-26 20:38:26 --> 404 Page Not Found: /index
ERROR - 2022-03-26 20:41:03 --> 404 Page Not Found: /index
ERROR - 2022-03-26 20:41:45 --> 404 Page Not Found: /index
ERROR - 2022-03-26 20:43:22 --> 404 Page Not Found: /index
ERROR - 2022-03-26 20:46:07 --> 404 Page Not Found: /index
ERROR - 2022-03-26 20:46:38 --> 404 Page Not Found: /index
ERROR - 2022-03-26 20:46:42 --> 404 Page Not Found: /index
ERROR - 2022-03-26 20:47:02 --> 404 Page Not Found: /index
ERROR - 2022-03-26 20:49:33 --> 404 Page Not Found: /index
ERROR - 2022-03-26 20:50:26 --> 404 Page Not Found: /index
ERROR - 2022-03-26 20:51:42 --> 404 Page Not Found: /index
ERROR - 2022-03-26 20:52:11 --> 404 Page Not Found: /index
ERROR - 2022-03-26 20:53:58 --> 404 Page Not Found: /index
ERROR - 2022-03-26 20:55:33 --> 404 Page Not Found: /index
ERROR - 2022-03-26 20:56:05 --> 404 Page Not Found: /index
ERROR - 2022-03-26 20:56:20 --> 404 Page Not Found: /index
ERROR - 2022-03-26 20:56:58 --> 404 Page Not Found: /index
ERROR - 2022-03-26 20:58:09 --> 404 Page Not Found: /index
ERROR - 2022-03-26 21:01:06 --> 404 Page Not Found: /index
ERROR - 2022-03-26 21:03:52 --> 404 Page Not Found: /index
ERROR - 2022-03-26 21:04:55 --> 404 Page Not Found: /index
ERROR - 2022-03-26 21:04:55 --> 404 Page Not Found: /index
ERROR - 2022-03-26 21:05:26 --> 404 Page Not Found: /index
ERROR - 2022-03-26 21:12:22 --> 404 Page Not Found: /index
ERROR - 2022-03-26 21:12:35 --> 404 Page Not Found: /index
ERROR - 2022-03-26 21:12:54 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-26 21:14:34 --> 404 Page Not Found: /index
ERROR - 2022-03-26 21:16:56 --> 404 Page Not Found: /index
ERROR - 2022-03-26 21:20:08 --> To Id is not available for User - 4019
ERROR - 2022-03-26 21:20:14 --> 404 Page Not Found: /index
ERROR - 2022-03-26 21:21:06 --> 404 Page Not Found: /index
ERROR - 2022-03-26 21:21:55 --> 404 Page Not Found: /index
ERROR - 2022-03-26 21:22:23 --> 404 Page Not Found: /index
ERROR - 2022-03-26 21:22:31 --> 404 Page Not Found: /index
ERROR - 2022-03-26 21:22:43 --> 404 Page Not Found: /index
ERROR - 2022-03-26 21:23:33 --> 404 Page Not Found: /index
ERROR - 2022-03-26 21:23:35 --> 404 Page Not Found: /index
ERROR - 2022-03-26 21:24:51 --> 404 Page Not Found: /index
ERROR - 2022-03-26 21:24:51 --> 404 Page Not Found: /index
ERROR - 2022-03-26 21:25:40 --> 404 Page Not Found: /index
ERROR - 2022-03-26 21:26:42 --> 404 Page Not Found: /index
ERROR - 2022-03-26 21:27:00 --> 404 Page Not Found: /index
ERROR - 2022-03-26 21:27:00 --> 404 Page Not Found: /index
ERROR - 2022-03-26 21:27:40 --> 404 Page Not Found: /index
ERROR - 2022-03-26 21:28:05 --> 404 Page Not Found: /index
ERROR - 2022-03-26 21:28:18 --> 404 Page Not Found: /index
ERROR - 2022-03-26 21:31:41 --> 404 Page Not Found: /index
ERROR - 2022-03-26 21:31:41 --> 404 Page Not Found: /index
ERROR - 2022-03-26 21:31:51 --> 404 Page Not Found: /index
ERROR - 2022-03-26 21:32:09 --> 404 Page Not Found: /index
ERROR - 2022-03-26 21:32:09 --> 404 Page Not Found: /index
ERROR - 2022-03-26 21:32:19 --> 404 Page Not Found: /index
ERROR - 2022-03-26 21:34:52 --> 404 Page Not Found: /index
ERROR - 2022-03-26 21:35:38 --> 404 Page Not Found: /index
ERROR - 2022-03-26 21:35:38 --> 404 Page Not Found: /index
ERROR - 2022-03-26 21:35:38 --> 404 Page Not Found: /index
ERROR - 2022-03-26 21:35:38 --> 404 Page Not Found: /index
ERROR - 2022-03-26 21:35:39 --> 404 Page Not Found: /index
ERROR - 2022-03-26 21:35:49 --> 404 Page Not Found: /index
ERROR - 2022-03-26 21:36:16 --> 404 Page Not Found: /index
ERROR - 2022-03-26 21:39:14 --> 404 Page Not Found: /index
ERROR - 2022-03-26 21:40:00 --> 404 Page Not Found: /index
ERROR - 2022-03-26 21:41:03 --> 404 Page Not Found: /index
ERROR - 2022-03-26 21:43:29 --> 404 Page Not Found: /index
ERROR - 2022-03-26 21:44:08 --> 404 Page Not Found: /index
ERROR - 2022-03-26 21:48:04 --> 404 Page Not Found: /index
ERROR - 2022-03-26 21:49:12 --> 404 Page Not Found: /index
ERROR - 2022-03-26 21:50:35 --> 404 Page Not Found: /index
ERROR - 2022-03-26 21:50:44 --> 404 Page Not Found: /index
ERROR - 2022-03-26 21:50:44 --> 404 Page Not Found: /index
ERROR - 2022-03-26 21:52:23 --> 404 Page Not Found: /index
ERROR - 2022-03-26 21:54:56 --> 404 Page Not Found: /index
ERROR - 2022-03-26 21:59:32 --> 404 Page Not Found: /index
ERROR - 2022-03-26 21:59:36 --> 404 Page Not Found: /index
ERROR - 2022-03-26 21:59:36 --> 404 Page Not Found: /index
ERROR - 2022-03-26 21:59:43 --> 404 Page Not Found: /index
ERROR - 2022-03-26 22:01:37 --> 404 Page Not Found: /index
ERROR - 2022-03-26 22:02:38 --> 404 Page Not Found: /index
ERROR - 2022-03-26 22:05:48 --> 404 Page Not Found: /index
ERROR - 2022-03-26 22:07:24 --> 404 Page Not Found: /index
ERROR - 2022-03-26 22:10:28 --> 404 Page Not Found: /index
ERROR - 2022-03-26 22:10:56 --> 404 Page Not Found: /index
ERROR - 2022-03-26 22:13:52 --> 404 Page Not Found: /index
ERROR - 2022-03-26 22:14:06 --> 404 Page Not Found: /index
ERROR - 2022-03-26 22:14:33 --> 404 Page Not Found: /index
ERROR - 2022-03-26 22:17:39 --> 404 Page Not Found: /index
ERROR - 2022-03-26 22:19:15 --> 404 Page Not Found: /index
ERROR - 2022-03-26 22:21:07 --> 404 Page Not Found: /index
ERROR - 2022-03-26 22:23:44 --> 404 Page Not Found: /index
ERROR - 2022-03-26 22:25:44 --> 404 Page Not Found: /index
ERROR - 2022-03-26 22:28:14 --> To Id is not available for User - 4189
ERROR - 2022-03-26 22:28:15 --> 404 Page Not Found: /index
ERROR - 2022-03-26 22:28:29 --> 404 Page Not Found: /index
ERROR - 2022-03-26 22:28:31 --> 404 Page Not Found: /index
ERROR - 2022-03-26 22:29:11 --> 404 Page Not Found: /index
ERROR - 2022-03-26 22:29:48 --> 404 Page Not Found: /index
ERROR - 2022-03-26 22:31:26 --> 404 Page Not Found: /index
ERROR - 2022-03-26 22:32:23 --> 404 Page Not Found: /index
ERROR - 2022-03-26 22:33:28 --> 404 Page Not Found: /index
ERROR - 2022-03-26 22:34:31 --> 404 Page Not Found: /index
ERROR - 2022-03-26 22:34:51 --> 404 Page Not Found: /index
ERROR - 2022-03-26 22:35:24 --> 404 Page Not Found: /index
ERROR - 2022-03-26 22:35:27 --> 404 Page Not Found: /index
ERROR - 2022-03-26 22:36:42 --> 404 Page Not Found: /index
ERROR - 2022-03-26 22:36:50 --> 404 Page Not Found: /index
ERROR - 2022-03-26 22:36:56 --> 404 Page Not Found: /index
ERROR - 2022-03-26 22:37:50 --> 404 Page Not Found: /index
ERROR - 2022-03-26 22:38:13 --> 404 Page Not Found: /index
ERROR - 2022-03-26 22:39:11 --> 404 Page Not Found: /index
ERROR - 2022-03-26 22:39:28 --> 404 Page Not Found: /index
ERROR - 2022-03-26 22:39:34 --> 404 Page Not Found: /index
ERROR - 2022-03-26 22:39:55 --> 404 Page Not Found: /index
ERROR - 2022-03-26 22:40:45 --> 404 Page Not Found: /index
ERROR - 2022-03-26 22:41:02 --> 404 Page Not Found: /index
ERROR - 2022-03-26 22:42:25 --> 404 Page Not Found: /index
ERROR - 2022-03-26 22:42:25 --> 404 Page Not Found: /index
ERROR - 2022-03-26 22:44:54 --> 404 Page Not Found: /index
ERROR - 2022-03-26 22:44:54 --> 404 Page Not Found: /index
ERROR - 2022-03-26 22:45:52 --> 404 Page Not Found: /index
ERROR - 2022-03-26 22:46:37 --> 404 Page Not Found: /index
ERROR - 2022-03-26 22:48:31 --> 404 Page Not Found: /index
ERROR - 2022-03-26 22:49:54 --> 404 Page Not Found: /index
ERROR - 2022-03-26 22:50:14 --> 404 Page Not Found: /index
ERROR - 2022-03-26 22:50:14 --> 404 Page Not Found: /index
ERROR - 2022-03-26 22:50:30 --> 404 Page Not Found: /index
ERROR - 2022-03-26 22:52:45 --> 404 Page Not Found: /index
ERROR - 2022-03-26 22:53:42 --> 404 Page Not Found: /index
ERROR - 2022-03-26 22:54:16 --> 404 Page Not Found: /index
ERROR - 2022-03-26 22:54:24 --> 404 Page Not Found: /index
ERROR - 2022-03-26 22:54:52 --> 404 Page Not Found: /index
ERROR - 2022-03-26 22:55:50 --> 404 Page Not Found: /index
ERROR - 2022-03-26 22:55:56 --> 404 Page Not Found: /index
ERROR - 2022-03-26 22:56:11 --> 404 Page Not Found: /index
ERROR - 2022-03-26 22:56:33 --> 404 Page Not Found: /index
ERROR - 2022-03-26 22:57:08 --> 404 Page Not Found: /index
ERROR - 2022-03-26 22:59:23 --> 404 Page Not Found: /index
ERROR - 2022-03-26 22:59:37 --> 404 Page Not Found: /index
ERROR - 2022-03-26 23:01:48 --> 404 Page Not Found: /index
ERROR - 2022-03-26 23:03:58 --> 404 Page Not Found: /index
ERROR - 2022-03-26 23:03:58 --> 404 Page Not Found: /index
ERROR - 2022-03-26 23:04:34 --> 404 Page Not Found: /index
ERROR - 2022-03-26 23:07:31 --> 404 Page Not Found: /index
ERROR - 2022-03-26 23:07:36 --> 404 Page Not Found: /index
ERROR - 2022-03-26 23:07:36 --> 404 Page Not Found: /index
ERROR - 2022-03-26 23:07:36 --> 404 Page Not Found: /index
ERROR - 2022-03-26 23:07:36 --> 404 Page Not Found: /index
ERROR - 2022-03-26 23:07:36 --> 404 Page Not Found: /index
ERROR - 2022-03-26 23:07:36 --> 404 Page Not Found: /index
ERROR - 2022-03-26 23:07:36 --> 404 Page Not Found: /index
ERROR - 2022-03-26 23:07:45 --> 404 Page Not Found: /index
ERROR - 2022-03-26 23:07:48 --> 404 Page Not Found: /index
ERROR - 2022-03-26 23:07:48 --> 404 Page Not Found: /index
ERROR - 2022-03-26 23:07:48 --> 404 Page Not Found: /index
ERROR - 2022-03-26 23:07:49 --> 404 Page Not Found: /index
ERROR - 2022-03-26 23:07:49 --> 404 Page Not Found: /index
ERROR - 2022-03-26 23:07:49 --> 404 Page Not Found: /index
ERROR - 2022-03-26 23:08:10 --> 404 Page Not Found: /index
ERROR - 2022-03-26 23:08:11 --> 404 Page Not Found: /index
ERROR - 2022-03-26 23:08:11 --> 404 Page Not Found: /index
ERROR - 2022-03-26 23:08:11 --> 404 Page Not Found: /index
ERROR - 2022-03-26 23:08:11 --> 404 Page Not Found: /index
ERROR - 2022-03-26 23:08:11 --> 404 Page Not Found: /index
ERROR - 2022-03-26 23:08:11 --> 404 Page Not Found: /index
ERROR - 2022-03-26 23:08:14 --> 404 Page Not Found: /index
ERROR - 2022-03-26 23:08:14 --> 404 Page Not Found: /index
ERROR - 2022-03-26 23:08:14 --> 404 Page Not Found: /index
ERROR - 2022-03-26 23:08:15 --> 404 Page Not Found: /index
ERROR - 2022-03-26 23:08:15 --> 404 Page Not Found: /index
ERROR - 2022-03-26 23:08:15 --> 404 Page Not Found: /index
ERROR - 2022-03-26 23:08:24 --> 404 Page Not Found: /index
ERROR - 2022-03-26 23:08:24 --> 404 Page Not Found: /index
ERROR - 2022-03-26 23:08:24 --> 404 Page Not Found: /index
ERROR - 2022-03-26 23:08:24 --> 404 Page Not Found: /index
ERROR - 2022-03-26 23:08:24 --> 404 Page Not Found: /index
ERROR - 2022-03-26 23:08:24 --> 404 Page Not Found: /index
ERROR - 2022-03-26 23:08:27 --> 404 Page Not Found: /index
ERROR - 2022-03-26 23:08:27 --> 404 Page Not Found: /index
ERROR - 2022-03-26 23:08:27 --> 404 Page Not Found: /index
ERROR - 2022-03-26 23:08:28 --> 404 Page Not Found: /index
ERROR - 2022-03-26 23:08:28 --> 404 Page Not Found: /index
ERROR - 2022-03-26 23:08:28 --> 404 Page Not Found: /index
ERROR - 2022-03-26 23:08:28 --> 404 Page Not Found: /index
ERROR - 2022-03-26 23:08:28 --> 404 Page Not Found: /index
ERROR - 2022-03-26 23:08:35 --> 404 Page Not Found: /index
ERROR - 2022-03-26 23:08:35 --> 404 Page Not Found: /index
ERROR - 2022-03-26 23:08:35 --> 404 Page Not Found: /index
ERROR - 2022-03-26 23:08:35 --> 404 Page Not Found: /index
ERROR - 2022-03-26 23:08:35 --> 404 Page Not Found: /index
ERROR - 2022-03-26 23:08:35 --> 404 Page Not Found: /index
ERROR - 2022-03-26 23:11:24 --> 404 Page Not Found: /index
ERROR - 2022-03-26 23:11:46 --> 404 Page Not Found: /index
ERROR - 2022-03-26 23:13:13 --> 404 Page Not Found: /index
ERROR - 2022-03-26 23:15:04 --> 404 Page Not Found: /index
ERROR - 2022-03-26 23:16:12 --> 404 Page Not Found: /index
ERROR - 2022-03-26 23:23:20 --> 404 Page Not Found: /index
ERROR - 2022-03-26 23:23:30 --> 404 Page Not Found: /index
ERROR - 2022-03-26 23:23:53 --> 404 Page Not Found: /index
ERROR - 2022-03-26 23:24:32 --> 404 Page Not Found: /index
ERROR - 2022-03-26 23:24:53 --> 404 Page Not Found: /index
ERROR - 2022-03-26 23:29:57 --> 404 Page Not Found: /index
ERROR - 2022-03-26 23:30:56 --> 404 Page Not Found: /index
ERROR - 2022-03-26 23:33:43 --> 404 Page Not Found: /index
ERROR - 2022-03-26 23:36:57 --> Query error: Table 'cowcdrmy_kammamarriage.ms_shortlist_viewedd_ignored' doesn't exist - Invalid query: SELECT `v`.*, `p`.`gender`, `p`.`id`, `p`.`status`, `p`.`age`, `p`.`living_in`, `p`.`profile_id`, `p`.`first_name`, `last_name`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `s`.*
FROM `kv_profileview` as `v`
LEFT JOIN `tbl_primary_info` as `p` ON `v`.`kv_profileview_on` = `p`.`id`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`ms_id`
INNER JOIN `ms_profilesetting` as `s` ON `p`.`id`=`s`.`ms_id`
WHERE `s`.`elite` = 'no'
AND `p`.`status` = 1
AND `v`.`kv_userfkid` = '4320'
AND `u`.`ismain` = 1
AND  `p`.`id` not in(select kv_msi_interested_on from kv_mysideinterests where kv_msi_profilefkid="4320")
AND  p.id not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid = "4320" AND `shortlist_status` = 1)
AND  `p`.`id` not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid="4320"AND ignore_status=1)
ORDER BY `v`.`kv_profileview_created_date` DESC
 LIMIT 10
ERROR - 2022-03-26 23:37:11 --> 404 Page Not Found: /index
ERROR - 2022-03-26 23:37:12 --> 404 Page Not Found: /index
ERROR - 2022-03-26 23:38:51 --> 404 Page Not Found: /index
ERROR - 2022-03-26 23:39:38 --> 404 Page Not Found: /index
ERROR - 2022-03-26 23:42:55 --> 404 Page Not Found: /index
ERROR - 2022-03-26 23:48:08 --> 404 Page Not Found: /index
ERROR - 2022-03-26 23:48:58 --> 404 Page Not Found: /index
ERROR - 2022-03-26 23:53:16 --> 404 Page Not Found: /index
