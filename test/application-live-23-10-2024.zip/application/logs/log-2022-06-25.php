<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-06-25 02:12:47 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cowcdrmy_kammavri'@'localhost' (using password: YES) /home/kammavaari/public_html/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2022-06-25 02:12:47 --> Severity: error --> Exception: Unable to connect to the database. /home/kammavaari/public_html/system/database/DB_driver.php 433
