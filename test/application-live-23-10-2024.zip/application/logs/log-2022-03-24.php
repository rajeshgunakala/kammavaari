<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-24 00:02:00 --> 404 Page Not Found: /index
ERROR - 2022-03-24 00:04:55 --> 404 Page Not Found: /index
ERROR - 2022-03-24 00:12:16 --> 404 Page Not Found: /index
ERROR - 2022-03-24 00:17:48 --> 404 Page Not Found: /index
ERROR - 2022-03-24 00:19:38 --> 404 Page Not Found: /index
ERROR - 2022-03-24 00:20:06 --> 404 Page Not Found: ../modules/admin/controllers/Admin/fileupload
ERROR - 2022-03-24 00:43:18 --> 404 Page Not Found: /index
ERROR - 2022-03-24 00:54:16 --> 404 Page Not Found: /index
ERROR - 2022-03-24 00:55:45 --> 404 Page Not Found: /index
ERROR - 2022-03-24 00:58:12 --> 404 Page Not Found: /index
ERROR - 2022-03-24 01:02:11 --> 404 Page Not Found: /index
ERROR - 2022-03-24 01:03:43 --> 404 Page Not Found: /index
ERROR - 2022-03-24 01:06:46 --> 404 Page Not Found: /index
ERROR - 2022-03-24 01:34:38 --> 404 Page Not Found: /index
ERROR - 2022-03-24 01:54:38 --> 404 Page Not Found: /index
ERROR - 2022-03-24 01:57:49 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-24 01:57:49')
ERROR - 2022-03-24 01:57:57 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-24 01:57:57')
ERROR - 2022-03-24 01:58:03 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-24 01:58:03')
ERROR - 2022-03-24 02:07:03 --> 404 Page Not Found: /index
ERROR - 2022-03-24 02:09:13 --> 404 Page Not Found: /index
ERROR - 2022-03-24 02:13:09 --> 404 Page Not Found: /index
ERROR - 2022-03-24 02:19:45 --> 404 Page Not Found: /index
ERROR - 2022-03-24 02:28:43 --> To Id is not available for User - 4019
ERROR - 2022-03-24 02:34:03 --> 404 Page Not Found: /index
ERROR - 2022-03-24 02:35:30 --> 404 Page Not Found: /index
ERROR - 2022-03-24 02:49:35 --> 404 Page Not Found: /index
ERROR - 2022-03-24 03:13:37 --> 404 Page Not Found: /index
ERROR - 2022-03-24 03:25:41 --> 404 Page Not Found: /index
ERROR - 2022-03-24 03:26:46 --> 404 Page Not Found: /index
ERROR - 2022-03-24 03:47:55 --> 404 Page Not Found: /index
ERROR - 2022-03-24 03:49:01 --> 404 Page Not Found: /index
ERROR - 2022-03-24 04:02:26 --> 404 Page Not Found: /index
ERROR - 2022-03-24 04:07:52 --> 404 Page Not Found: /index
ERROR - 2022-03-24 04:10:07 --> To Id is not available for User - 4019
ERROR - 2022-03-24 04:12:11 --> 404 Page Not Found: /index
ERROR - 2022-03-24 04:14:34 --> 404 Page Not Found: /index
ERROR - 2022-03-24 04:28:11 --> 404 Page Not Found: /index
ERROR - 2022-03-24 04:39:26 --> 404 Page Not Found: /index
ERROR - 2022-03-24 04:39:27 --> 404 Page Not Found: /index
ERROR - 2022-03-24 04:39:27 --> 404 Page Not Found: /index
ERROR - 2022-03-24 04:39:28 --> 404 Page Not Found: /index
ERROR - 2022-03-24 04:39:28 --> 404 Page Not Found: /index
ERROR - 2022-03-24 04:39:29 --> 404 Page Not Found: /index
ERROR - 2022-03-24 04:39:29 --> 404 Page Not Found: /index
ERROR - 2022-03-24 04:39:30 --> 404 Page Not Found: /index
ERROR - 2022-03-24 04:39:30 --> 404 Page Not Found: /index
ERROR - 2022-03-24 04:39:30 --> 404 Page Not Found: /index
ERROR - 2022-03-24 04:49:44 --> 404 Page Not Found: /index
ERROR - 2022-03-24 04:51:58 --> 404 Page Not Found: /index
ERROR - 2022-03-24 04:52:15 --> 404 Page Not Found: /index
ERROR - 2022-03-24 04:52:26 --> 404 Page Not Found: /index
ERROR - 2022-03-24 04:53:30 --> 404 Page Not Found: /index
ERROR - 2022-03-24 04:59:52 --> 404 Page Not Found: /index
ERROR - 2022-03-24 05:02:39 --> 404 Page Not Found: /index
ERROR - 2022-03-24 05:05:37 --> 404 Page Not Found: /index
ERROR - 2022-03-24 05:06:19 --> 404 Page Not Found: /index
ERROR - 2022-03-24 05:06:49 --> 404 Page Not Found: /index
ERROR - 2022-03-24 05:09:24 --> 404 Page Not Found: /index
ERROR - 2022-03-24 05:24:28 --> 404 Page Not Found: /index
ERROR - 2022-03-24 05:27:19 --> 404 Page Not Found: /index
ERROR - 2022-03-24 05:28:37 --> 404 Page Not Found: /index
ERROR - 2022-03-24 05:31:22 --> 404 Page Not Found: /index
ERROR - 2022-03-24 05:35:25 --> 404 Page Not Found: /index
ERROR - 2022-03-24 05:45:50 --> 404 Page Not Found: /index
ERROR - 2022-03-24 05:47:10 --> 404 Page Not Found: /index
ERROR - 2022-03-24 05:51:04 --> 404 Page Not Found: /index
ERROR - 2022-03-24 05:56:29 --> 404 Page Not Found: /index
ERROR - 2022-03-24 05:58:05 --> 404 Page Not Found: /index
ERROR - 2022-03-24 06:02:10 --> 404 Page Not Found: /index
ERROR - 2022-03-24 06:02:33 --> 404 Page Not Found: /index
ERROR - 2022-03-24 06:02:43 --> 404 Page Not Found: /index
ERROR - 2022-03-24 06:06:14 --> Query error: Table 'cowcdrmy_kammamarriage.ms_shortlist_viewedd_ignored' doesn't exist - Invalid query: SELECT `v`.*, `p`.`gender`, `p`.`id`, `p`.`status`, `p`.`age`, `p`.`living_in`, `p`.`profile_id`, `p`.`first_name`, `last_name`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `s`.*
FROM `kv_profileview` as `v`
LEFT JOIN `tbl_primary_info` as `p` ON `v`.`kv_profileview_on` = `p`.`id`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`ms_id`
INNER JOIN `ms_profilesetting` as `s` ON `p`.`id`=`s`.`ms_id`
WHERE `s`.`elite` = 'no'
AND `p`.`status` = 1
AND `v`.`kv_userfkid` = '3581'
AND `u`.`ismain` = 1
AND  `p`.`id` not in(select kv_msi_interested_on from kv_mysideinterests where kv_msi_profilefkid="3581")
AND  p.id not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid = "3581" AND `shortlist_status` = 1)
AND  `p`.`id` not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid="3581"AND ignore_status=1)
ORDER BY `v`.`kv_profileview_created_date` DESC
 LIMIT 10
ERROR - 2022-03-24 06:07:38 --> 404 Page Not Found: /index
ERROR - 2022-03-24 06:08:43 --> 404 Page Not Found: /index
ERROR - 2022-03-24 06:09:12 --> 404 Page Not Found: /index
ERROR - 2022-03-24 06:12:28 --> 404 Page Not Found: /index
ERROR - 2022-03-24 06:12:52 --> 404 Page Not Found: /index
ERROR - 2022-03-24 06:15:11 --> 404 Page Not Found: /index
ERROR - 2022-03-24 06:17:44 --> Query error: Table 'cowcdrmy_kammamarriage.ms_shortlist_viewedd_ignored' doesn't exist - Invalid query: SELECT `v`.*, `p`.`gender`, `p`.`id`, `p`.`status`, `p`.`age`, `p`.`living_in`, `p`.`profile_id`, `p`.`first_name`, `last_name`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `s`.*
FROM `kv_profileview` as `v`
LEFT JOIN `tbl_primary_info` as `p` ON `v`.`kv_profileview_on` = `p`.`id`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`ms_id`
INNER JOIN `ms_profilesetting` as `s` ON `p`.`id`=`s`.`ms_id`
WHERE `s`.`elite` = 'no'
AND `p`.`status` = 1
AND `v`.`kv_userfkid` = '4218'
AND `u`.`ismain` = 1
AND  `p`.`id` not in(select kv_msi_interested_on from kv_mysideinterests where kv_msi_profilefkid="4218")
AND  p.id not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid = "4218" AND `shortlist_status` = 1)
AND  `p`.`id` not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid="4218"AND ignore_status=1)
ORDER BY `v`.`kv_profileview_created_date` DESC
 LIMIT 10
ERROR - 2022-03-24 06:18:03 --> Severity: error --> Exception: Call to a member function result_array() on null /home4/cowcdrmy/public_html/application/modules/dashboard/models/My_account_model.php 911
ERROR - 2022-03-24 06:18:08 --> Severity: error --> Exception: Call to a member function result_array() on null /home4/cowcdrmy/public_html/application/modules/dashboard/models/My_account_model.php 911
ERROR - 2022-03-24 06:18:22 --> Severity: error --> Exception: Call to a member function result_array() on null /home4/cowcdrmy/public_html/application/modules/dashboard/models/My_account_model.php 911
ERROR - 2022-03-24 06:18:25 --> Severity: error --> Exception: Call to a member function result_array() on null /home4/cowcdrmy/public_html/application/modules/dashboard/models/My_account_model.php 911
ERROR - 2022-03-24 06:19:29 --> 404 Page Not Found: /index
ERROR - 2022-03-24 06:21:45 --> 404 Page Not Found: /index
ERROR - 2022-03-24 06:23:25 --> 404 Page Not Found: /index
ERROR - 2022-03-24 06:26:04 --> 404 Page Not Found: /index
ERROR - 2022-03-24 06:26:14 --> 404 Page Not Found: /index
ERROR - 2022-03-24 06:28:15 --> 404 Page Not Found: /index
ERROR - 2022-03-24 06:28:31 --> 404 Page Not Found: /index
ERROR - 2022-03-24 06:28:57 --> 404 Page Not Found: /index
ERROR - 2022-03-24 06:35:14 --> 404 Page Not Found: /index
ERROR - 2022-03-24 06:36:39 --> 404 Page Not Found: /index
ERROR - 2022-03-24 06:40:26 --> 404 Page Not Found: /index
ERROR - 2022-03-24 06:45:50 --> 404 Page Not Found: /index
ERROR - 2022-03-24 06:50:03 --> 404 Page Not Found: /index
ERROR - 2022-03-24 06:51:09 --> 404 Page Not Found: /index
ERROR - 2022-03-24 06:51:41 --> 404 Page Not Found: /index
ERROR - 2022-03-24 06:54:13 --> 404 Page Not Found: /index
ERROR - 2022-03-24 06:54:57 --> 404 Page Not Found: /index
ERROR - 2022-03-24 06:56:41 --> 404 Page Not Found: /index
ERROR - 2022-03-24 06:59:37 --> 404 Page Not Found: /index
ERROR - 2022-03-24 07:05:10 --> To Id is not available for User - 4019
ERROR - 2022-03-24 07:07:37 --> 404 Page Not Found: /index
ERROR - 2022-03-24 07:08:12 --> 404 Page Not Found: /index
ERROR - 2022-03-24 07:08:46 --> 404 Page Not Found: /index
ERROR - 2022-03-24 07:11:17 --> 404 Page Not Found: /index
ERROR - 2022-03-24 07:19:39 --> 404 Page Not Found: /index
ERROR - 2022-03-24 07:19:39 --> 404 Page Not Found: /index
ERROR - 2022-03-24 07:20:00 --> 404 Page Not Found: /index
ERROR - 2022-03-24 07:22:16 --> 404 Page Not Found: /index
ERROR - 2022-03-24 07:23:50 --> 404 Page Not Found: /index
ERROR - 2022-03-24 07:24:06 --> 404 Page Not Found: /index
ERROR - 2022-03-24 07:25:07 --> 404 Page Not Found: /index
ERROR - 2022-03-24 07:25:38 --> 404 Page Not Found: /index
ERROR - 2022-03-24 07:30:08 --> 404 Page Not Found: /index
ERROR - 2022-03-24 07:32:03 --> 404 Page Not Found: /index
ERROR - 2022-03-24 07:32:53 --> 404 Page Not Found: /index
ERROR - 2022-03-24 07:37:03 --> 404 Page Not Found: /index
ERROR - 2022-03-24 07:38:49 --> 404 Page Not Found: /index
ERROR - 2022-03-24 07:43:31 --> 404 Page Not Found: /index
ERROR - 2022-03-24 07:44:20 --> 404 Page Not Found: /index
ERROR - 2022-03-24 07:44:26 --> 404 Page Not Found: /index
ERROR - 2022-03-24 07:46:24 --> 404 Page Not Found: /index
ERROR - 2022-03-24 07:48:25 --> 404 Page Not Found: /index
ERROR - 2022-03-24 07:51:00 --> 404 Page Not Found: /index
ERROR - 2022-03-24 07:54:56 --> 404 Page Not Found: /index
ERROR - 2022-03-24 07:55:34 --> 404 Page Not Found: /index
ERROR - 2022-03-24 08:06:07 --> 404 Page Not Found: /index
ERROR - 2022-03-24 08:08:34 --> 404 Page Not Found: /index
ERROR - 2022-03-24 08:09:39 --> 404 Page Not Found: /index
ERROR - 2022-03-24 08:10:07 --> 404 Page Not Found: /index
ERROR - 2022-03-24 08:11:08 --> 404 Page Not Found: /index
ERROR - 2022-03-24 08:11:24 --> 404 Page Not Found: /index
ERROR - 2022-03-24 08:11:28 --> 404 Page Not Found: /index
ERROR - 2022-03-24 08:12:02 --> 404 Page Not Found: /index
ERROR - 2022-03-24 08:12:24 --> 404 Page Not Found: /index
ERROR - 2022-03-24 08:15:46 --> 404 Page Not Found: /index
ERROR - 2022-03-24 08:15:46 --> 404 Page Not Found: /index
ERROR - 2022-03-24 08:15:46 --> 404 Page Not Found: /index
ERROR - 2022-03-24 08:15:47 --> 404 Page Not Found: /index
ERROR - 2022-03-24 08:15:47 --> 404 Page Not Found: /index
ERROR - 2022-03-24 08:15:47 --> 404 Page Not Found: /index
ERROR - 2022-03-24 08:15:47 --> 404 Page Not Found: /index
ERROR - 2022-03-24 08:15:48 --> 404 Page Not Found: /index
ERROR - 2022-03-24 08:15:48 --> 404 Page Not Found: /index
ERROR - 2022-03-24 08:15:48 --> 404 Page Not Found: /index
ERROR - 2022-03-24 08:17:06 --> 404 Page Not Found: /index
ERROR - 2022-03-24 08:18:12 --> 404 Page Not Found: /index
ERROR - 2022-03-24 08:19:10 --> 404 Page Not Found: /index
ERROR - 2022-03-24 08:24:03 --> 404 Page Not Found: /index
ERROR - 2022-03-24 08:24:07 --> 404 Page Not Found: /index
ERROR - 2022-03-24 08:24:22 --> 404 Page Not Found: /index
ERROR - 2022-03-24 08:27:21 --> 404 Page Not Found: /index
ERROR - 2022-03-24 08:29:02 --> 404 Page Not Found: /index
ERROR - 2022-03-24 08:29:17 --> 404 Page Not Found: /index
ERROR - 2022-03-24 08:29:22 --> 404 Page Not Found: /index
ERROR - 2022-03-24 08:30:15 --> 404 Page Not Found: /index
ERROR - 2022-03-24 08:30:45 --> 404 Page Not Found: /index
ERROR - 2022-03-24 08:30:45 --> 404 Page Not Found: /index
ERROR - 2022-03-24 08:30:45 --> 404 Page Not Found: /index
ERROR - 2022-03-24 08:30:51 --> 404 Page Not Found: /index
ERROR - 2022-03-24 08:31:04 --> 404 Page Not Found: /index
ERROR - 2022-03-24 08:34:02 --> Query error: Table 'cowcdrmy_kammamarriage.ms_shortlist_viewedd_ignored' doesn't exist - Invalid query: SELECT `v`.*, `p`.`gender`, `p`.`id`, `p`.`status`, `p`.`age`, `p`.`living_in`, `p`.`profile_id`, `p`.`first_name`, `last_name`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `s`.*
FROM `kv_profileview` as `v`
LEFT JOIN `tbl_primary_info` as `p` ON `v`.`kv_profileview_on` = `p`.`id`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`ms_id`
INNER JOIN `ms_profilesetting` as `s` ON `p`.`id`=`s`.`ms_id`
WHERE `s`.`elite` = 'no'
AND `p`.`status` = 1
AND `v`.`kv_userfkid` = '1036'
AND `u`.`ismain` = 1
AND  `p`.`id` not in(select kv_msi_interested_on from kv_mysideinterests where kv_msi_profilefkid="1036")
AND  p.id not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid = "1036" AND `shortlist_status` = 1)
AND  `p`.`id` not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid="1036"AND ignore_status=1)
ORDER BY `v`.`kv_profileview_created_date` DESC
 LIMIT 10
ERROR - 2022-03-24 08:34:02 --> 404 Page Not Found: /index
ERROR - 2022-03-24 08:38:42 --> 404 Page Not Found: /index
ERROR - 2022-03-24 08:38:56 --> 404 Page Not Found: /index
ERROR - 2022-03-24 08:39:42 --> 404 Page Not Found: /index
ERROR - 2022-03-24 08:42:12 --> Severity: error --> Exception: Call to a member function result_array() on null /home4/cowcdrmy/public_html/application/modules/dashboard/models/My_account_model.php 911
ERROR - 2022-03-24 08:42:34 --> 404 Page Not Found: /index
ERROR - 2022-03-24 08:47:41 --> Query error: Table 'cowcdrmy_kammamarriage.ms_shortlist_viewedd_ignored' doesn't exist - Invalid query: SELECT `v`.*, `p`.`gender`, `p`.`id`, `p`.`status`, `p`.`age`, `p`.`living_in`, `p`.`profile_id`, `p`.`first_name`, `last_name`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `s`.*
FROM `kv_profileview` as `v`
LEFT JOIN `tbl_primary_info` as `p` ON `v`.`kv_profileview_on` = `p`.`id`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`ms_id`
INNER JOIN `ms_profilesetting` as `s` ON `p`.`id`=`s`.`ms_id`
WHERE `s`.`elite` = 'no'
AND `p`.`status` = 1
AND `v`.`kv_userfkid` = '299'
AND `u`.`ismain` = 1
AND  `p`.`id` not in(select kv_msi_interested_on from kv_mysideinterests where kv_msi_profilefkid="299")
AND  p.id not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid = "299" AND `shortlist_status` = 1)
AND  `p`.`id` not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid="299"AND ignore_status=1)
ORDER BY `v`.`kv_profileview_created_date` DESC
 LIMIT 10
ERROR - 2022-03-24 08:48:27 --> Query error: Table 'cowcdrmy_kammamarriage.ms_shortlist_viewedd_ignored' doesn't exist - Invalid query: SELECT `v`.*, `p`.`gender`, `p`.`id`, `p`.`status`, `p`.`age`, `p`.`living_in`, `p`.`profile_id`, `p`.`first_name`, `last_name`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `s`.*
FROM `kv_profileview` as `v`
LEFT JOIN `tbl_primary_info` as `p` ON `v`.`kv_profileview_on` = `p`.`id`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`ms_id`
INNER JOIN `ms_profilesetting` as `s` ON `p`.`id`=`s`.`ms_id`
WHERE `s`.`elite` = 'no'
AND `p`.`status` = 1
AND `v`.`kv_userfkid` = '299'
AND `u`.`ismain` = 1
AND  `p`.`id` not in(select kv_msi_interested_on from kv_mysideinterests where kv_msi_profilefkid="299")
AND  p.id not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid = "299" AND `shortlist_status` = 1)
AND  `p`.`id` not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid="299"AND ignore_status=1)
ORDER BY `v`.`kv_profileview_created_date` DESC
 LIMIT 10
ERROR - 2022-03-24 08:48:37 --> Severity: error --> Exception: Call to a member function result_array() on null /home4/cowcdrmy/public_html/application/modules/dashboard/models/My_account_model.php 911
ERROR - 2022-03-24 08:48:40 --> 404 Page Not Found: /index
ERROR - 2022-03-24 08:49:34 --> 404 Page Not Found: /index
ERROR - 2022-03-24 08:52:02 --> 404 Page Not Found: /index
ERROR - 2022-03-24 08:58:08 --> 404 Page Not Found: /index
ERROR - 2022-03-24 08:58:17 --> 404 Page Not Found: /index
ERROR - 2022-03-24 08:59:16 --> 404 Page Not Found: /index
ERROR - 2022-03-24 08:59:33 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:00:35 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:00:50 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:00:51 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:00:59 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:01:14 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:01:14 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:01:14 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:01:14 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:01:14 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:01:14 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:01:14 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:01:14 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:01:14 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:01:14 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:01:14 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:01:14 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:01:14 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:01:14 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:01:14 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:01:14 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:01:14 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:01:14 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:01:15 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:01:15 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:01:15 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:01:15 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:01:16 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:02:39 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:02:43 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:04:21 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`?bWUd`)' at line 3 - Invalid query: SELECT *
FROM `ms_servicelist`
WHERE (`from_msID` = 361 AND `to_msID` = 1935 `�bWUd`)
ERROR - 2022-03-24 09:04:28 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`?bWUd`)' at line 3 - Invalid query: SELECT *
FROM `ms_servicelist`
WHERE (`from_msID` = 361 AND `to_msID` = 1935 `�bWUd`)
ERROR - 2022-03-24 09:04:38 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`?U3' at line 3 - Invalid query: SELECT *
FROM `ms_servicelist`
WHERE (`from_msID` = 361 AND `to_msID` = 1913 `�U3 R0`)
ERROR - 2022-03-24 09:05:56 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:05:56 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:05:56 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:05:56 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:05:56 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:05:56 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:05:56 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:05:56 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:06:02 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`?bWUd`)' at line 3 - Invalid query: SELECT *
FROM `ms_servicelist`
WHERE (`from_msID` = 361 AND `to_msID` = 1935 `�bWUd`)
ERROR - 2022-03-24 09:06:03 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:06:32 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:06:39 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:06:39 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:06:39 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:06:39 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:06:39 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:06:39 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:06:39 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:06:39 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:06:39 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:06:39 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:06:39 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:06:39 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:06:39 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:06:39 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:06:39 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:06:39 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:06:39 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:06:40 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:06:40 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:06:40 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:06:40 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:06:40 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:06:43 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:07:02 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:07:44 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-24 09:07:44')
ERROR - 2022-03-24 09:07:56 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-24 09:07:56')
ERROR - 2022-03-24 09:08:41 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-24 09:08:41')
ERROR - 2022-03-24 09:09:12 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:11:22 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:11:26 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:13:14 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:13:33 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:13:38 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:13:40 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:15:22 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '`?bWUd`)' at line 3 - Invalid query: SELECT *
FROM `ms_servicelist`
WHERE (`from_msID` = 361 AND `to_msID` = 1935 `�bWUd`)
ERROR - 2022-03-24 09:15:43 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:15:58 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:16:07 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:19:36 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:19:49 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:20:11 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-24 09:20:11')
ERROR - 2022-03-24 09:22:08 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:22:56 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:24:19 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:25:11 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:26:29 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:27:01 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:27:02 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:27:02 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:27:19 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:27:19 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:27:27 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:27:28 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:27:46 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:27:47 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:27:49 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:27:49 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:27:56 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:28:17 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:28:31 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:30:11 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:30:20 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:31:20 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:31:21 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:31:44 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:32:54 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:33:11 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:34:38 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:37:05 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:37:09 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:37:59 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:38:04 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:38:15 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:40:26 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:41:32 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:42:17 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:44:28 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:46:20 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:46:58 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:50:07 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:50:17 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:51:08 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:51:37 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:52:03 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:52:11 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:54:14 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:54:21 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:55:04 --> 404 Page Not Found: ../modules/admin/controllers/Admin_ap/confidentialprofiles
ERROR - 2022-03-24 09:55:14 --> 404 Page Not Found: ../modules/admin/controllers/Admin_ap/eliteprofiles
ERROR - 2022-03-24 09:56:04 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:56:56 --> 404 Page Not Found: /index
ERROR - 2022-03-24 09:57:00 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:00:57 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:01:21 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:02:06 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:02:32 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:04:15 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:04:16 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:04:49 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:06:06 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:07:30 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:09:39 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:09:49 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:10:06 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:11:05 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:11:05 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:12:43 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:12:45 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:12:47 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:12:57 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:13:16 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:15:57 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:16:56 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:17:00 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:17:01 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:17:16 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:18:13 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:18:21 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:19:39 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:20:07 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:20:20 --> To Id is not available for User - 85
ERROR - 2022-03-24 10:21:02 --> Severity: error --> Exception: Invalid address:  (to):  /home4/cowcdrmy/public_html/application/third_party/phpmailer/src/PHPMailer.php 1092
ERROR - 2022-03-24 10:23:47 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:24:53 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:25:27 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:25:42 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:26:28 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:27:39 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:27:42 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:27:54 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:27:58 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:27:59 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:28:19 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:29:34 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:29:34 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:30:12 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:30:27 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:30:28 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:30:35 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:30:44 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:31:46 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:32:41 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:32:41 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:32:43 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:33:12 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:33:25 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:33:26 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:33:46 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:34:17 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:34:24 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:35:31 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:35:40 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:35:51 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:36:06 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:36:37 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:36:37 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:36:40 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:37:14 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:37:31 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:37:33 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:38:27 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:38:59 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:39:01 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:39:11 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:39:49 --> Query error: Table 'cowcdrmy_kammamarriage.ms_shortlist_viewedd_ignored' doesn't exist - Invalid query: SELECT `v`.*, `p`.`gender`, `p`.`id`, `p`.`status`, `p`.`age`, `p`.`living_in`, `p`.`profile_id`, `p`.`first_name`, `last_name`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `s`.*
FROM `kv_profileview` as `v`
LEFT JOIN `tbl_primary_info` as `p` ON `v`.`kv_profileview_on` = `p`.`id`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`ms_id`
INNER JOIN `ms_profilesetting` as `s` ON `p`.`id`=`s`.`ms_id`
WHERE `s`.`elite` = 'no'
AND `p`.`status` = 1
AND `v`.`kv_userfkid` = '2021'
AND `u`.`ismain` = 1
AND  `p`.`id` not in(select kv_msi_interested_on from kv_mysideinterests where kv_msi_profilefkid="2021")
AND  p.id not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid = "2021" AND `shortlist_status` = 1)
AND  `p`.`id` not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid="2021"AND ignore_status=1)
ORDER BY `v`.`kv_profileview_created_date` DESC
 LIMIT 10
ERROR - 2022-03-24 10:39:56 --> Query error: Table 'cowcdrmy_kammamarriage.ms_shortlist_viewedd_ignored' doesn't exist - Invalid query: SELECT `v`.*, `p`.`gender`, `p`.`id`, `p`.`status`, `p`.`age`, `p`.`living_in`, `p`.`profile_id`, `p`.`first_name`, `last_name`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `s`.*
FROM `kv_profileview` as `v`
LEFT JOIN `tbl_primary_info` as `p` ON `v`.`kv_profileview_on` = `p`.`id`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`ms_id`
INNER JOIN `ms_profilesetting` as `s` ON `p`.`id`=`s`.`ms_id`
WHERE `s`.`elite` = 'no'
AND `p`.`status` = 1
AND `v`.`kv_userfkid` = '4073'
AND `u`.`ismain` = 1
AND  `p`.`id` not in(select kv_msi_interested_on from kv_mysideinterests where kv_msi_profilefkid="4073")
AND  p.id not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid = "4073" AND `shortlist_status` = 1)
AND  `p`.`id` not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid="4073"AND ignore_status=1)
ORDER BY `v`.`kv_profileview_created_date` DESC
 LIMIT 10
ERROR - 2022-03-24 10:39:58 --> Query error: Table 'cowcdrmy_kammamarriage.ms_shortlist_viewedd_ignored' doesn't exist - Invalid query: SELECT `v`.*, `p`.`gender`, `p`.`id`, `p`.`status`, `p`.`age`, `p`.`living_in`, `p`.`profile_id`, `p`.`first_name`, `last_name`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `s`.*
FROM `kv_profileview` as `v`
LEFT JOIN `tbl_primary_info` as `p` ON `v`.`kv_profileview_on` = `p`.`id`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`ms_id`
INNER JOIN `ms_profilesetting` as `s` ON `p`.`id`=`s`.`ms_id`
WHERE `s`.`elite` = 'no'
AND `p`.`status` = 1
AND `v`.`kv_userfkid` = '2021'
AND `u`.`ismain` = 1
AND  `p`.`id` not in(select kv_msi_interested_on from kv_mysideinterests where kv_msi_profilefkid="2021")
AND  p.id not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid = "2021" AND `shortlist_status` = 1)
AND  `p`.`id` not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid="2021"AND ignore_status=1)
ORDER BY `v`.`kv_profileview_created_date` DESC
 LIMIT 10
ERROR - 2022-03-24 10:40:06 --> Severity: error --> Exception: Call to a member function result_array() on null /home4/cowcdrmy/public_html/application/modules/dashboard/models/My_account_model.php 911
ERROR - 2022-03-24 10:40:07 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:40:08 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:41:17 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:41:42 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:41:45 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:43:22 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:45:32 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:46:45 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:47:41 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:47:51 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:49:05 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:49:11 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:49:24 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:50:46 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:50:47 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:51:13 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:51:52 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:51:52 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:52:02 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:52:09 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:52:10 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:52:12 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:52:55 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:52:56 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:52:59 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:53:29 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:53:38 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-24 10:53:42 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-24 10:54:37 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:54:38 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:55:28 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:55:39 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:56:23 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:56:41 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:56:49 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:56:49 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:57:14 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:57:20 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:57:34 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:57:54 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:57:55 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:59:38 --> 404 Page Not Found: /index
ERROR - 2022-03-24 10:59:47 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:03:00 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:04:00 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:04:38 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:05:25 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:05:54 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:06:01 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:06:01 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:06:02 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:06:05 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:06:26 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:07:21 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:08:22 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:08:47 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:09:50 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:10:20 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:10:32 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:11:12 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:11:32 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:12:10 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:12:20 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:12:24 --> 404 Page Not Found: ../modules/dashboard/controllers/Dashboard/getCustomerPaymentStatistics
ERROR - 2022-03-24 11:12:46 --> 404 Page Not Found: ../modules/dashboard/controllers/My_account/getCustomerPaymentStatistics
ERROR - 2022-03-24 11:12:57 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:12:59 --> 404 Page Not Found: ../modules/dashboard/controllers/My_account/getCustomerPaymentStatistics
ERROR - 2022-03-24 11:13:22 --> 404 Page Not Found: ../modules/dashboard/controllers/My_account/getCustomerPaymentStatistics
ERROR - 2022-03-24 11:14:36 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:15:24 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:15:36 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:15:41 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:15:50 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-24 11:15:50')
ERROR - 2022-03-24 11:15:52 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-24 11:15:52')
ERROR - 2022-03-24 11:16:22 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:16:30 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:17:34 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:17:34 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:18:02 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:18:48 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:18:51 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:19:06 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:19:50 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:19:53 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:19:56 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:20:20 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:21:01 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:21:15 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:21:28 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:22:30 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-24 11:23:20 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:23:27 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:24:25 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:25:13 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:25:24 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:26:07 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:26:07 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:26:07 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:27:28 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:28:08 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:29:47 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:30:37 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:30:56 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:31:24 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:31:24 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:32:05 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:32:48 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:33:14 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:33:14 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:33:33 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:34:47 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:34:50 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:35:19 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:35:48 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:36:32 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:37:06 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:39:10 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:41:48 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:42:02 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:42:08 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:42:58 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:43:23 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:43:51 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:44:19 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:44:23 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:44:39 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:45:33 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:46:17 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:46:31 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:46:47 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:47:13 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:47:47 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:49:23 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:49:57 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:49:59 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:50:06 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:51:06 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:51:35 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:51:38 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:53:39 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:53:39 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:53:44 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:54:33 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:54:53 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:54:59 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:54:59 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:55:06 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:55:12 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:55:37 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:56:50 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:56:51 --> To Id is not available for User - 4189
ERROR - 2022-03-24 11:57:08 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:57:34 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:57:59 --> To Id is not available for User - 4189
ERROR - 2022-03-24 11:58:20 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:58:35 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:58:43 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-24 11:58:43')
ERROR - 2022-03-24 11:58:49 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:59:03 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:59:29 --> 404 Page Not Found: /index
ERROR - 2022-03-24 11:59:54 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:01:24 --> To Id is not available for User - 4189
ERROR - 2022-03-24 12:01:28 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:02:11 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:03:17 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:03:45 --> To Id is not available for User - 4189
ERROR - 2022-03-24 12:04:38 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:04:50 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:05:47 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:06:28 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:08:26 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:08:26 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:08:38 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:09:12 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:10:29 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:11:42 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:13:01 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:13:44 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:14:52 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:14:52 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:14:55 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:15:04 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:15:44 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:15:46 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:16:39 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:16:45 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:19:52 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:19:52 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:20:22 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:20:35 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:20:35 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:20:47 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:20:52 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:21:00 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:21:57 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:22:08 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:22:27 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:23:00 --> Severity: error --> Exception: Call to a member function result_array() on null /home4/cowcdrmy/public_html/application/modules/dashboard/models/My_account_model.php 911
ERROR - 2022-03-24 12:23:10 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:25:08 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:25:11 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:27:24 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:28:29 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:29:35 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:30:56 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:31:25 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:32:18 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:33:08 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:34:16 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:35:31 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:36:05 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:36:08 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:36:14 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:36:24 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:36:55 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:36:56 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:37:18 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:38:30 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:38:38 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:38:56 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:39:02 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:39:24 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:39:41 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:40:16 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:41:45 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:43:06 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:43:36 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:43:56 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:44:59 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:45:22 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:46:12 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:46:17 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:47:07 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:47:38 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:47:41 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:47:52 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:48:04 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:48:29 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:48:37 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:48:52 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:49:36 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:49:59 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:50:30 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:51:16 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:52:38 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:53:07 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:54:06 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:54:59 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:56:17 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:56:31 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:56:52 --> 404 Page Not Found: /index
ERROR - 2022-03-24 12:59:41 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:00:00 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:00:48 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:01:49 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:02:09 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:02:32 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:03:38 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:05:06 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:05:30 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:06:55 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:07:20 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:07:42 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:08:05 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:08:05 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:08:32 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:08:42 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:08:42 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:08:51 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:08:55 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:09:52 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:09:57 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:10:02 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:10:07 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:10:15 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:10:22 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:10:31 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:10:44 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:10:44 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:11:21 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:11:25 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:12:10 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:12:26 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:12:32 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:12:39 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:12:41 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:13:11 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:14:24 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:14:41 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:15:17 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:15:35 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:15:42 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:15:58 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:17:39 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:18:40 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:19:50 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:21:36 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:21:48 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:22:16 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:22:36 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:23:17 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:23:28 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:23:37 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:25:11 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:26:00 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:26:02 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:26:17 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:26:31 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:26:41 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:26:47 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:27:12 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:28:56 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:30:31 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:30:32 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:31:08 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:31:26 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:32:46 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:32:49 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:33:28 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:34:13 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:34:23 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:36:57 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '<script>alert("xssvuln")</script> AND <script>alert("xssvuln") < `/script>`
AND ' at line 8 - Invalid query: SELECT `p`.`gender`, `p`.`id`, `p`.`status`, `p`.`age`, `p`.`living_in`, `p`.`profile_id`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`
FROM `tbl_primary_info` as `p`
INNER JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`MS_id`
INNER JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
INNER JOIN `ms_profilesetting` as `s` ON `p`.`id`=`s`.`ms_id`
WHERE `p`.`gender` = '<script>alert(\"xssvuln\")</script>'
AND `p`.`age` BETWEEN <script>alert("xssvuln")</script> AND <script>alert("xssvuln") < `/script>`
AND `r`.`religion` = '<script>alert(\"xssvuln\")</script>'
AND `r`.`mother_tounge` = '<script>alert(\"xssvuln\")</script>'
AND `p`.`status` = 1
AND `s`.`elite` = 'no'
AND `s`.`ms_usertype` = 'regular'
AND `u`.`ismain` = 1
AND `u`.`photoname` != ''
AND `u`.`applicationphotopath` != ''
GROUP BY `u`.`MS_id`
ORDER BY `registered_on` DESC
 LIMIT 8
ERROR - 2022-03-24 13:36:58 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:41:08 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:42:11 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:42:25 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:42:36 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:42:54 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:45:26 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:45:36 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:45:45 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:46:28 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:46:35 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:47:59 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:48:47 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:49:08 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:49:16 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:49:36 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:50:03 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:51:37 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:53:28 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:53:48 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:55:09 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:55:12 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:55:59 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:56:45 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:57:22 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:57:56 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:58:51 --> 404 Page Not Found: /index
ERROR - 2022-03-24 13:59:28 --> 404 Page Not Found: /index
ERROR - 2022-03-24 14:01:12 --> 404 Page Not Found: /index
ERROR - 2022-03-24 14:01:34 --> 404 Page Not Found: /index
ERROR - 2022-03-24 14:01:48 --> 404 Page Not Found: /index
ERROR - 2022-03-24 14:02:33 --> 404 Page Not Found: /index
ERROR - 2022-03-24 14:03:16 --> 404 Page Not Found: /index
ERROR - 2022-03-24 14:04:20 --> 404 Page Not Found: /index
ERROR - 2022-03-24 14:06:20 --> 404 Page Not Found: /index
ERROR - 2022-03-24 14:07:25 --> 404 Page Not Found: /index
ERROR - 2022-03-24 14:07:25 --> 404 Page Not Found: /index
ERROR - 2022-03-24 14:07:33 --> To Id is not available for User - 3740
ERROR - 2022-03-24 14:07:34 --> 404 Page Not Found: /index
ERROR - 2022-03-24 14:08:31 --> 404 Page Not Found: /index
ERROR - 2022-03-24 14:08:34 --> 404 Page Not Found: /index
ERROR - 2022-03-24 14:09:12 --> 404 Page Not Found: /index
ERROR - 2022-03-24 14:09:18 --> 404 Page Not Found: /index
ERROR - 2022-03-24 14:10:15 --> 404 Page Not Found: /index
ERROR - 2022-03-24 14:10:28 --> Query error: Illegal mix of collations (latin1_swedish_ci,IMPLICIT) and (utf8_general_ci,COERCIBLE) for operation 'like' - Invalid query: SELECT `p`.*, `r`.`caste`, `r`.`height`, `r`.`star`, `r`.`time_of_birth`, `r`.`raasi`, `prp`.`property_value`, `e`.`occupation`, `e`.`education_degree`, `e`.`visatype`, `e`.`city`, `e`.`country`, `e`.`annual_income`, `pfs`.`payment_status`, `pfs`.`profilesetting_id` as `pfs_id`, `pfs`.`last_call_updated`, `adm`.`username` as `profile_owner`
FROM `tbl_primary_info` as `p`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `ms_property_info` as `prp` ON `p`.`id`=`prp`.`ms_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `ms_profilesetting` as `pfs` ON `p`.`id`=`pfs`.`ms_id`
LEFT JOIN `tbl_admin_data` as `adm` ON `pfs`.`profileowner`=`adm`.`id`
WHERE `p`.`profile_id` LIKE '%K̤V̤93319%' ESCAPE '!'
AND `p`.`status` = '1'
GROUP BY `p`.`id`
ERROR - 2022-03-24 14:10:31 --> Query error: Illegal mix of collations (latin1_swedish_ci,IMPLICIT) and (utf8_general_ci,COERCIBLE) for operation 'like' - Invalid query: SELECT `p`.*, `r`.`caste`, `r`.`height`, `r`.`star`, `r`.`time_of_birth`, `r`.`raasi`, `prp`.`property_value`, `e`.`occupation`, `e`.`education_degree`, `e`.`visatype`, `e`.`city`, `e`.`country`, `e`.`annual_income`, `pfs`.`payment_status`, `pfs`.`profilesetting_id` as `pfs_id`, `pfs`.`last_call_updated`, `adm`.`username` as `profile_owner`
FROM `tbl_primary_info` as `p`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `ms_property_info` as `prp` ON `p`.`id`=`prp`.`ms_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `ms_profilesetting` as `pfs` ON `p`.`id`=`pfs`.`ms_id`
LEFT JOIN `tbl_admin_data` as `adm` ON `pfs`.`profileowner`=`adm`.`id`
WHERE `p`.`profile_id` LIKE '%K̤V̤93319%' ESCAPE '!'
AND `p`.`status` = '1'
GROUP BY `p`.`id`
ERROR - 2022-03-24 14:11:02 --> Query error: Illegal mix of collations (latin1_swedish_ci,IMPLICIT) and (utf8_general_ci,COERCIBLE) for operation 'like' - Invalid query: SELECT `p`.*, `r`.`caste`, `r`.`height`, `r`.`star`, `r`.`time_of_birth`, `r`.`raasi`, `prp`.`property_value`, `e`.`occupation`, `e`.`education_degree`, `e`.`visatype`, `e`.`city`, `e`.`country`, `e`.`annual_income`, `pfs`.`payment_status`, `pfs`.`profilesetting_id` as `pfs_id`, `pfs`.`last_call_updated`, `adm`.`username` as `profile_owner`
FROM `tbl_primary_info` as `p`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `ms_property_info` as `prp` ON `p`.`id`=`prp`.`ms_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `ms_profilesetting` as `pfs` ON `p`.`id`=`pfs`.`ms_id`
LEFT JOIN `tbl_admin_data` as `adm` ON `pfs`.`profileowner`=`adm`.`id`
WHERE `p`.`profile_id` LIKE '%K̤V̤93319%' ESCAPE '!'
AND `p`.`status` = '1'
GROUP BY `p`.`id`
ERROR - 2022-03-24 14:11:10 --> 404 Page Not Found: /index
ERROR - 2022-03-24 14:11:20 --> 404 Page Not Found: /index
ERROR - 2022-03-24 14:11:29 --> 404 Page Not Found: /index
ERROR - 2022-03-24 14:12:25 --> 404 Page Not Found: /index
ERROR - 2022-03-24 14:12:49 --> 404 Page Not Found: /index
ERROR - 2022-03-24 14:13:15 --> 404 Page Not Found: /index
ERROR - 2022-03-24 14:13:17 --> 404 Page Not Found: /index
ERROR - 2022-03-24 14:13:17 --> 404 Page Not Found: /index
ERROR - 2022-03-24 14:13:18 --> 404 Page Not Found: /index
ERROR - 2022-03-24 14:13:20 --> 404 Page Not Found: /index
ERROR - 2022-03-24 14:14:53 --> 404 Page Not Found: /index
ERROR - 2022-03-24 14:15:16 --> 404 Page Not Found: /index
ERROR - 2022-03-24 14:15:30 --> 404 Page Not Found: /index
ERROR - 2022-03-24 14:17:02 --> 404 Page Not Found: /index
ERROR - 2022-03-24 14:18:33 --> 404 Page Not Found: /index
ERROR - 2022-03-24 14:18:41 --> 404 Page Not Found: /index
ERROR - 2022-03-24 14:20:14 --> 404 Page Not Found: /index
ERROR - 2022-03-24 14:20:54 --> 404 Page Not Found: /index
ERROR - 2022-03-24 14:21:03 --> 404 Page Not Found: /index
ERROR - 2022-03-24 14:21:59 --> 404 Page Not Found: /index
ERROR - 2022-03-24 14:23:20 --> 404 Page Not Found: /index
ERROR - 2022-03-24 14:24:35 --> 404 Page Not Found: /index
ERROR - 2022-03-24 14:25:01 --> 404 Page Not Found: /index
ERROR - 2022-03-24 14:25:33 --> 404 Page Not Found: /index
ERROR - 2022-03-24 14:27:47 --> 404 Page Not Found: /index
ERROR - 2022-03-24 14:27:49 --> 404 Page Not Found: /index
ERROR - 2022-03-24 14:28:51 --> 404 Page Not Found: /index
ERROR - 2022-03-24 14:29:45 --> 404 Page Not Found: /index
ERROR - 2022-03-24 14:30:20 --> 404 Page Not Found: /index
ERROR - 2022-03-24 14:30:26 --> 404 Page Not Found: /index
ERROR - 2022-03-24 14:31:50 --> 404 Page Not Found: /index
ERROR - 2022-03-24 14:32:35 --> 404 Page Not Found: /index
ERROR - 2022-03-24 14:34:30 --> 404 Page Not Found: /index
ERROR - 2022-03-24 14:35:19 --> 404 Page Not Found: /index
ERROR - 2022-03-24 14:35:55 --> To Id is not available for User - 3819
ERROR - 2022-03-24 14:35:56 --> 404 Page Not Found: /index
ERROR - 2022-03-24 14:37:26 --> 404 Page Not Found: /index
ERROR - 2022-03-24 14:38:19 --> To Id is not available for User - 4213
ERROR - 2022-03-24 14:38:28 --> To Id is not available for User - 4213
ERROR - 2022-03-24 14:39:00 --> 404 Page Not Found: /index
ERROR - 2022-03-24 14:40:03 --> 404 Page Not Found: /index
ERROR - 2022-03-24 14:40:30 --> 404 Page Not Found: /index
ERROR - 2022-03-24 14:41:21 --> 404 Page Not Found: /index
ERROR - 2022-03-24 14:41:22 --> 404 Page Not Found: /index
ERROR - 2022-03-24 14:41:39 --> 404 Page Not Found: /index
ERROR - 2022-03-24 14:42:17 --> 404 Page Not Found: /index
ERROR - 2022-03-24 14:42:38 --> 404 Page Not Found: /index
ERROR - 2022-03-24 14:42:39 --> 404 Page Not Found: /index
ERROR - 2022-03-24 14:42:55 --> 404 Page Not Found: /index
ERROR - 2022-03-24 14:44:41 --> 404 Page Not Found: /index
ERROR - 2022-03-24 14:48:38 --> 404 Page Not Found: /index
ERROR - 2022-03-24 14:49:07 --> 404 Page Not Found: /index
ERROR - 2022-03-24 14:49:14 --> 404 Page Not Found: /index
ERROR - 2022-03-24 14:49:54 --> 404 Page Not Found: /index
ERROR - 2022-03-24 14:50:27 --> 404 Page Not Found: /index
ERROR - 2022-03-24 14:50:29 --> 404 Page Not Found: /index
ERROR - 2022-03-24 14:50:47 --> 404 Page Not Found: /index
ERROR - 2022-03-24 14:51:28 --> 404 Page Not Found: /index
ERROR - 2022-03-24 14:52:46 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-24 14:54:17 --> 404 Page Not Found: /index
ERROR - 2022-03-24 14:54:21 --> 404 Page Not Found: /index
ERROR - 2022-03-24 14:55:08 --> 404 Page Not Found: /index
ERROR - 2022-03-24 14:55:30 --> 404 Page Not Found: /index
ERROR - 2022-03-24 14:57:02 --> 404 Page Not Found: /index
ERROR - 2022-03-24 14:57:45 --> 404 Page Not Found: /index
ERROR - 2022-03-24 14:58:26 --> 404 Page Not Found: /index
ERROR - 2022-03-24 14:58:40 --> 404 Page Not Found: /index
ERROR - 2022-03-24 14:58:51 --> 404 Page Not Found: /index
ERROR - 2022-03-24 14:59:11 --> 404 Page Not Found: /index
ERROR - 2022-03-24 14:59:30 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:01:15 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:01:27 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:01:27 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:01:51 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:02:17 --> Severity: error --> Exception: Invalid address:  (to): Gogineni @gmail.com /home4/cowcdrmy/public_html/application/third_party/phpmailer/src/PHPMailer.php 1157
ERROR - 2022-03-24 15:02:46 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:04:14 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:04:20 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:05:16 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:06:27 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:06:54 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:07:40 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:07:46 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:08:04 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:08:50 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:09:03 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:09:19 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:10:05 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:10:28 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:12:16 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:12:18 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:12:27 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:13:37 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-24 15:13:37')
ERROR - 2022-03-24 15:14:11 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:14:33 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:14:37 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:14:53 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:14:59 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:15:19 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:15:33 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:16:30 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:19:21 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:19:29 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:20:13 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:20:58 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:21:00 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:21:05 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:21:23 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:22:43 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:22:58 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:23:05 --> To Id is not available for User - 4140
ERROR - 2022-03-24 15:23:23 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:23:25 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:23:52 --> To Id is not available for User - 4140
ERROR - 2022-03-24 15:23:53 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:23:58 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:24:08 --> To Id is not available for User - 4140
ERROR - 2022-03-24 15:24:12 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:24:15 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:24:17 --> To Id is not available for User - 4140
ERROR - 2022-03-24 15:25:22 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:25:34 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:25:53 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:26:03 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:26:13 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:26:46 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:26:47 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:27:38 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:28:42 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:28:58 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:29:19 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:29:21 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:29:29 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:29:48 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:30:16 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:30:26 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:30:39 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:30:49 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:30:51 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-24 15:30:51')
ERROR - 2022-03-24 15:30:52 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:31:09 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:31:20 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:31:59 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:33:23 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:34:36 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:34:41 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:36:39 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:37:38 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:38:02 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:38:05 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:38:25 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:39:22 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-24 15:39:22')
ERROR - 2022-03-24 15:39:22 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-24 15:39:22')
ERROR - 2022-03-24 15:40:58 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:41:34 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:41:35 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:42:20 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:44:12 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:44:25 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:44:31 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:46:10 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:46:37 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:46:43 --> To Id is not available for User - 4224
ERROR - 2022-03-24 15:46:57 --> To Id is not available for User - 4224
ERROR - 2022-03-24 15:47:38 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:47:58 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:50:24 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:50:28 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:50:35 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:50:51 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:51:28 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:52:19 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:55:10 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:55:21 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:56:24 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:56:34 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:56:36 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:57:05 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-24 15:57:15 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-24 15:57:17 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:57:45 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:57:47 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:57:55 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:58:04 --> 404 Page Not Found: /index
ERROR - 2022-03-24 15:59:08 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:00:49 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:01:28 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:01:54 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:02:43 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:03:06 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:03:56 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:04:57 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:05:33 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:06:49 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:09:19 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:09:33 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:09:34 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:09:41 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:09:47 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:09:47 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:10:02 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:10:17 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:10:23 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:10:23 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:10:38 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:10:52 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:11:15 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:11:22 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:11:38 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:13:42 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:13:55 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:13:55 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:14:01 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:14:01 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:14:18 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:15:06 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:16:34 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:16:37 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:16:48 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:18:42 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:18:47 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:19:10 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:19:13 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:19:38 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:20:28 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:20:36 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:20:53 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:22:03 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:22:23 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:23:36 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:23:59 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:24:27 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:25:02 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-24 16:25:19 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:26:00 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:26:42 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:27:56 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:29:19 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:29:27 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:29:33 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:29:44 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:30:18 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:31:41 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:34:03 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:35:07 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:35:57 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:36:39 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-24 16:36:39')
ERROR - 2022-03-24 16:36:42 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:37:20 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:37:34 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:37:39 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:37:45 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:37:55 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:38:02 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:38:47 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:39:48 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:40:09 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:40:42 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:41:08 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:41:45 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:43:05 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:43:13 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:43:34 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:44:09 --> Severity: error --> Exception: Invalid address:  (to):  /home4/cowcdrmy/public_html/application/third_party/phpmailer/src/PHPMailer.php 1092
ERROR - 2022-03-24 16:44:15 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:45:21 --> Severity: error --> Exception: Invalid address:  (to): tarun .t@gmail.com /home4/cowcdrmy/public_html/application/third_party/phpmailer/src/PHPMailer.php 1157
ERROR - 2022-03-24 16:45:33 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:46:40 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:48:08 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:49:08 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:49:25 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:49:41 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:50:01 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:50:34 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:51:10 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:51:38 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:51:52 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:51:55 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:52:03 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:52:10 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:52:27 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-24 16:52:27')
ERROR - 2022-03-24 16:54:03 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:55:16 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:55:31 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:55:35 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:55:40 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:57:34 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:58:33 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:58:53 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:59:38 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:59:41 --> 404 Page Not Found: /index
ERROR - 2022-03-24 16:59:59 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:00:00 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:00:37 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:00:46 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:01:02 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:01:22 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:01:56 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:02:15 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:02:19 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:02:20 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:02:59 --> To Id is not available for User - 4224
ERROR - 2022-03-24 17:03:38 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:04:27 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:04:37 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:05:50 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:06:16 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:06:28 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:06:38 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:07:06 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:07:44 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:08:39 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:09:05 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:09:51 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:09:54 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:10:44 --> Severity: error --> Exception: Invalid address:  (to):  /home4/cowcdrmy/public_html/application/third_party/phpmailer/src/PHPMailer.php 1092
ERROR - 2022-03-24 17:11:22 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:12:07 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:12:11 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:12:12 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:15:03 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:15:04 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:15:13 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:15:20 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:16:18 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:16:24 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:17:00 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:17:35 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:17:43 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:18:08 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:19:57 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:21:09 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:21:22 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:21:43 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:22:19 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:23:25 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:23:36 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:24:57 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:25:46 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:26:04 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:28:10 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:31:11 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:31:34 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:32:39 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:33:55 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:34:22 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:34:36 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:36:26 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:36:26 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:36:27 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:36:27 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:36:27 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:36:27 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:36:27 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:36:27 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:36:28 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:36:28 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:36:28 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:36:29 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:36:29 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:36:30 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:36:58 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:37:44 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:38:00 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:38:45 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:38:59 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:39:29 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:40:27 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:40:27 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:40:40 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:44:06 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:44:34 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:46:26 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:46:27 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:46:27 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:46:27 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:46:28 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:46:28 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:46:28 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:46:29 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:46:29 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:46:29 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:47:50 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:49:39 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:52:30 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:53:01 --> To Id is not available for User - 4189
ERROR - 2022-03-24 17:53:03 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:54:43 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:55:13 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:55:23 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:55:38 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:57:34 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:57:36 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:57:43 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:57:50 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-24 17:58:16 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:59:39 --> 404 Page Not Found: /index
ERROR - 2022-03-24 17:59:51 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:00:30 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:01:15 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:01:40 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:01:49 --> To Id is not available for User - 4224
ERROR - 2022-03-24 18:06:59 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:07:24 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:09:58 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:11:26 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:14:21 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:18:21 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:18:45 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:18:59 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:19:27 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:20:26 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:21:33 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:22:31 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:22:41 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:22:46 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:24:18 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:24:25 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:24:25 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:24:26 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:24:26 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:24:26 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:24:26 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:24:26 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:24:26 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:24:27 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:24:27 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:25:02 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:25:42 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:25:57 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:26:16 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:26:36 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:27:59 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:28:29 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:30:28 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:30:29 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:31:10 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:31:27 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:33:17 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:34:40 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:34:40 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:35:00 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:35:03 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:35:33 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:35:52 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:35:59 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:36:52 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:37:57 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:38:14 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:38:27 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:38:32 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:38:33 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:38:54 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-24 18:38:54')
ERROR - 2022-03-24 18:38:56 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:39:01 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:39:23 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:41:04 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:43:10 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:43:35 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:43:42 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:45:03 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:47:17 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:48:07 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:49:33 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:49:40 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-24 18:49:49 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:50:16 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:51:14 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:52:33 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:52:44 --> Severity: error --> Exception: Call to a member function result_array() on null /home4/cowcdrmy/public_html/application/modules/dashboard/models/My_account_model.php 911
ERROR - 2022-03-24 18:52:46 --> Query error: Table 'cowcdrmy_kammamarriage.ms_shortlist_viewedd_ignored' doesn't exist - Invalid query: SELECT `v`.*, `p`.`gender`, `p`.`id`, `p`.`status`, `p`.`age`, `p`.`living_in`, `p`.`profile_id`, `p`.`first_name`, `last_name`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `s`.*
FROM `kv_profileview` as `v`
LEFT JOIN `tbl_primary_info` as `p` ON `v`.`kv_profileview_on` = `p`.`id`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`ms_id`
INNER JOIN `ms_profilesetting` as `s` ON `p`.`id`=`s`.`ms_id`
WHERE `s`.`elite` = 'no'
AND `p`.`status` = 1
AND `v`.`kv_userfkid` = '906'
AND `u`.`ismain` = 1
AND  `p`.`id` not in(select kv_msi_interested_on from kv_mysideinterests where kv_msi_profilefkid="906")
AND  p.id not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid = "906" AND `shortlist_status` = 1)
AND  `p`.`id` not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid="906"AND ignore_status=1)
ORDER BY `v`.`kv_profileview_created_date` DESC
 LIMIT 10
ERROR - 2022-03-24 18:52:51 --> Severity: error --> Exception: Call to a member function result_array() on null /home4/cowcdrmy/public_html/application/modules/dashboard/models/My_account_model.php 911
ERROR - 2022-03-24 18:52:53 --> Query error: Table 'cowcdrmy_kammamarriage.ms_shortlist_viewedd_ignored' doesn't exist - Invalid query: SELECT `v`.*, `p`.`gender`, `p`.`id`, `p`.`status`, `p`.`age`, `p`.`living_in`, `p`.`profile_id`, `p`.`first_name`, `last_name`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `s`.*
FROM `kv_profileview` as `v`
LEFT JOIN `tbl_primary_info` as `p` ON `v`.`kv_profileview_on` = `p`.`id`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`ms_id`
INNER JOIN `ms_profilesetting` as `s` ON `p`.`id`=`s`.`ms_id`
WHERE `s`.`elite` = 'no'
AND `p`.`status` = 1
AND `v`.`kv_userfkid` = '906'
AND `u`.`ismain` = 1
AND  `p`.`id` not in(select kv_msi_interested_on from kv_mysideinterests where kv_msi_profilefkid="906")
AND  p.id not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid = "906" AND `shortlist_status` = 1)
AND  `p`.`id` not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid="906"AND ignore_status=1)
ORDER BY `v`.`kv_profileview_created_date` DESC
 LIMIT 10
ERROR - 2022-03-24 18:52:54 --> Severity: error --> Exception: Call to a member function result_array() on null /home4/cowcdrmy/public_html/application/modules/dashboard/models/My_account_model.php 911
ERROR - 2022-03-24 18:53:08 --> Severity: error --> Exception: Call to a member function result_array() on null /home4/cowcdrmy/public_html/application/modules/dashboard/models/My_account_model.php 911
ERROR - 2022-03-24 18:53:18 --> Query error: Table 'cowcdrmy_kammamarriage.ms_shortlist_viewedd_ignored' doesn't exist - Invalid query: SELECT `v`.*, `p`.`gender`, `p`.`id`, `p`.`status`, `p`.`age`, `p`.`living_in`, `p`.`profile_id`, `p`.`first_name`, `last_name`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `s`.*
FROM `kv_profileview` as `v`
LEFT JOIN `tbl_primary_info` as `p` ON `v`.`kv_profileview_on` = `p`.`id`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`ms_id`
INNER JOIN `ms_profilesetting` as `s` ON `p`.`id`=`s`.`ms_id`
WHERE `s`.`elite` = 'no'
AND `p`.`status` = 1
AND `v`.`kv_userfkid` = '906'
AND `u`.`ismain` = 1
AND  `p`.`id` not in(select kv_msi_interested_on from kv_mysideinterests where kv_msi_profilefkid="906")
AND  p.id not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid = "906" AND `shortlist_status` = 1)
AND  `p`.`id` not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid="906"AND ignore_status=1)
ORDER BY `v`.`kv_profileview_created_date` DESC
 LIMIT 10
ERROR - 2022-03-24 18:53:19 --> Severity: error --> Exception: Call to a member function result_array() on null /home4/cowcdrmy/public_html/application/modules/dashboard/models/My_account_model.php 911
ERROR - 2022-03-24 18:53:21 --> Severity: error --> Exception: Call to a member function result_array() on null /home4/cowcdrmy/public_html/application/modules/dashboard/models/My_account_model.php 911
ERROR - 2022-03-24 18:53:29 --> Severity: error --> Exception: Call to a member function result_array() on null /home4/cowcdrmy/public_html/application/modules/dashboard/models/My_account_model.php 911
ERROR - 2022-03-24 18:53:59 --> To Id is not available for User - 4224
ERROR - 2022-03-24 18:54:23 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:55:29 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:56:14 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:56:55 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:59:01 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:59:43 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:59:43 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:59:43 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:59:44 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:59:44 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:59:45 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:59:45 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:59:45 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:59:46 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:59:46 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:59:47 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:59:47 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:59:47 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:59:48 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:59:48 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:59:49 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:59:49 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:59:49 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:59:50 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:59:50 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:59:50 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:59:51 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:59:51 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:59:52 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:59:52 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:59:52 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:59:53 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:59:53 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:59:53 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:59:54 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:59:54 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:59:55 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:59:55 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:59:55 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:59:56 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:59:56 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:59:57 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:59:57 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:59:57 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:59:58 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:59:58 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:59:59 --> 404 Page Not Found: /index
ERROR - 2022-03-24 18:59:59 --> 404 Page Not Found: /index
ERROR - 2022-03-24 19:01:46 --> 404 Page Not Found: /index
ERROR - 2022-03-24 19:02:01 --> 404 Page Not Found: /index
ERROR - 2022-03-24 19:05:19 --> 404 Page Not Found: /index
ERROR - 2022-03-24 19:05:33 --> 404 Page Not Found: /index
ERROR - 2022-03-24 19:06:18 --> 404 Page Not Found: /index
ERROR - 2022-03-24 19:08:19 --> 404 Page Not Found: /index
ERROR - 2022-03-24 19:08:21 --> 404 Page Not Found: /index
ERROR - 2022-03-24 19:09:02 --> 404 Page Not Found: /index
ERROR - 2022-03-24 19:09:09 --> 404 Page Not Found: /index
ERROR - 2022-03-24 19:11:34 --> 404 Page Not Found: /index
ERROR - 2022-03-24 19:12:19 --> 404 Page Not Found: /index
ERROR - 2022-03-24 19:12:19 --> 404 Page Not Found: /index
ERROR - 2022-03-24 19:12:20 --> 404 Page Not Found: /index
ERROR - 2022-03-24 19:12:21 --> 404 Page Not Found: /index
ERROR - 2022-03-24 19:12:22 --> 404 Page Not Found: /index
ERROR - 2022-03-24 19:12:43 --> 404 Page Not Found: /index
ERROR - 2022-03-24 19:14:22 --> 404 Page Not Found: /index
ERROR - 2022-03-24 19:16:40 --> 404 Page Not Found: /index
ERROR - 2022-03-24 19:16:52 --> 404 Page Not Found: /index
ERROR - 2022-03-24 19:17:06 --> 404 Page Not Found: /index
ERROR - 2022-03-24 19:18:38 --> 404 Page Not Found: /index
ERROR - 2022-03-24 19:20:02 --> 404 Page Not Found: /index
ERROR - 2022-03-24 19:20:10 --> 404 Page Not Found: /index
ERROR - 2022-03-24 19:20:20 --> 404 Page Not Found: /index
ERROR - 2022-03-24 19:20:39 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-24 19:20:39')
ERROR - 2022-03-24 19:22:17 --> 404 Page Not Found: /index
ERROR - 2022-03-24 19:23:17 --> 404 Page Not Found: /index
ERROR - 2022-03-24 19:23:24 --> 404 Page Not Found: /index
ERROR - 2022-03-24 19:23:54 --> 404 Page Not Found: /index
ERROR - 2022-03-24 19:24:02 --> 404 Page Not Found: /index
ERROR - 2022-03-24 19:25:42 --> To Id is not available for User - 4140
ERROR - 2022-03-24 19:30:23 --> 404 Page Not Found: /index
ERROR - 2022-03-24 19:30:23 --> 404 Page Not Found: /index
ERROR - 2022-03-24 19:30:24 --> 404 Page Not Found: /index
ERROR - 2022-03-24 19:30:24 --> 404 Page Not Found: /index
ERROR - 2022-03-24 19:30:31 --> 404 Page Not Found: /index
ERROR - 2022-03-24 19:30:32 --> 404 Page Not Found: /index
ERROR - 2022-03-24 19:30:39 --> 404 Page Not Found: /index
ERROR - 2022-03-24 19:31:57 --> 404 Page Not Found: /index
ERROR - 2022-03-24 19:31:57 --> 404 Page Not Found: /index
ERROR - 2022-03-24 19:33:03 --> 404 Page Not Found: /index
ERROR - 2022-03-24 19:33:27 --> 404 Page Not Found: /index
ERROR - 2022-03-24 19:33:42 --> 404 Page Not Found: /index
ERROR - 2022-03-24 19:33:46 --> 404 Page Not Found: /index
ERROR - 2022-03-24 19:35:36 --> 404 Page Not Found: /index
ERROR - 2022-03-24 19:37:34 --> 404 Page Not Found: /index
ERROR - 2022-03-24 19:40:01 --> 404 Page Not Found: /index
ERROR - 2022-03-24 19:40:20 --> 404 Page Not Found: /index
ERROR - 2022-03-24 19:40:51 --> 404 Page Not Found: /index
ERROR - 2022-03-24 19:41:19 --> 404 Page Not Found: /index
ERROR - 2022-03-24 19:43:16 --> 404 Page Not Found: /index
ERROR - 2022-03-24 19:43:28 --> 404 Page Not Found: /index
ERROR - 2022-03-24 19:43:56 --> 404 Page Not Found: /index
ERROR - 2022-03-24 19:44:53 --> 404 Page Not Found: /index
ERROR - 2022-03-24 19:45:22 --> 404 Page Not Found: /index
ERROR - 2022-03-24 19:46:25 --> 404 Page Not Found: /index
ERROR - 2022-03-24 19:46:28 --> 404 Page Not Found: /index
ERROR - 2022-03-24 19:46:48 --> 404 Page Not Found: /index
ERROR - 2022-03-24 19:47:30 --> 404 Page Not Found: /index
ERROR - 2022-03-24 19:48:43 --> 404 Page Not Found: /index
ERROR - 2022-03-24 19:50:32 --> 404 Page Not Found: /index
ERROR - 2022-03-24 19:50:45 --> 404 Page Not Found: /index
ERROR - 2022-03-24 19:50:46 --> 404 Page Not Found: /index
ERROR - 2022-03-24 19:51:14 --> 404 Page Not Found: /index
ERROR - 2022-03-24 19:52:02 --> 404 Page Not Found: /index
ERROR - 2022-03-24 19:52:46 --> 404 Page Not Found: /index
ERROR - 2022-03-24 19:53:16 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: select SUM(IFNULL(`basicdetails`, 0) + IFNULL(`religion`, 0) + IFNULL(`edu_prof`, 0) + IFNULL(`parents`, 0) + IFNULL(`Siblings`, 0) + IFNULL(`photo`, 0)) as total,photo,basicdetails,religion,edu_prof,parents,Siblings from tbl_profilebattery where user_id=
ERROR - 2022-03-24 19:53:20 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: select SUM(IFNULL(`basicdetails`, 0) + IFNULL(`religion`, 0) + IFNULL(`edu_prof`, 0) + IFNULL(`parents`, 0) + IFNULL(`Siblings`, 0) + IFNULL(`photo`, 0)) as total,photo,basicdetails,religion,edu_prof,parents,Siblings from tbl_profilebattery where user_id=
ERROR - 2022-03-24 19:53:22 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: select SUM(IFNULL(`basicdetails`, 0) + IFNULL(`religion`, 0) + IFNULL(`edu_prof`, 0) + IFNULL(`parents`, 0) + IFNULL(`Siblings`, 0) + IFNULL(`photo`, 0)) as total,photo,basicdetails,religion,edu_prof,parents,Siblings from tbl_profilebattery where user_id=
ERROR - 2022-03-24 19:53:30 --> 404 Page Not Found: /index
ERROR - 2022-03-24 19:53:56 --> 404 Page Not Found: /index
ERROR - 2022-03-24 19:54:01 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-24 19:54:01')
ERROR - 2022-03-24 19:55:03 --> 404 Page Not Found: /index
ERROR - 2022-03-24 19:55:51 --> 404 Page Not Found: /index
ERROR - 2022-03-24 19:56:09 --> 404 Page Not Found: /index
ERROR - 2022-03-24 19:59:45 --> 404 Page Not Found: /index
ERROR - 2022-03-24 20:00:19 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-24 20:00:19')
ERROR - 2022-03-24 20:00:20 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-24 20:00:20')
ERROR - 2022-03-24 20:00:26 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-24 20:00:26')
ERROR - 2022-03-24 20:00:42 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-24 20:00:42')
ERROR - 2022-03-24 20:00:53 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-24 20:00:53')
ERROR - 2022-03-24 20:01:01 --> To Id is not available for User - 922
ERROR - 2022-03-24 20:01:03 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-24 20:01:03')
ERROR - 2022-03-24 20:02:38 --> 404 Page Not Found: /index
ERROR - 2022-03-24 20:06:44 --> 404 Page Not Found: /index
ERROR - 2022-03-24 20:07:58 --> 404 Page Not Found: /index
ERROR - 2022-03-24 20:10:02 --> 404 Page Not Found: /index
ERROR - 2022-03-24 20:10:30 --> 404 Page Not Found: /index
ERROR - 2022-03-24 20:11:50 --> 404 Page Not Found: /index
ERROR - 2022-03-24 20:12:04 --> 404 Page Not Found: /index
ERROR - 2022-03-24 20:12:19 --> 404 Page Not Found: /index
ERROR - 2022-03-24 20:13:09 --> 404 Page Not Found: /index
ERROR - 2022-03-24 20:14:11 --> 404 Page Not Found: /index
ERROR - 2022-03-24 20:15:10 --> 404 Page Not Found: /index
ERROR - 2022-03-24 20:16:30 --> 404 Page Not Found: /index
ERROR - 2022-03-24 20:16:34 --> 404 Page Not Found: /index
ERROR - 2022-03-24 20:17:40 --> 404 Page Not Found: /index
ERROR - 2022-03-24 20:17:41 --> 404 Page Not Found: /index
ERROR - 2022-03-24 20:17:42 --> 404 Page Not Found: /index
ERROR - 2022-03-24 20:17:42 --> 404 Page Not Found: /index
ERROR - 2022-03-24 20:17:43 --> 404 Page Not Found: /index
ERROR - 2022-03-24 20:17:43 --> 404 Page Not Found: /index
ERROR - 2022-03-24 20:17:44 --> 404 Page Not Found: /index
ERROR - 2022-03-24 20:17:44 --> 404 Page Not Found: /index
ERROR - 2022-03-24 20:17:45 --> 404 Page Not Found: /index
ERROR - 2022-03-24 20:17:45 --> 404 Page Not Found: /index
ERROR - 2022-03-24 20:18:20 --> 404 Page Not Found: /index
ERROR - 2022-03-24 20:18:59 --> 404 Page Not Found: /index
ERROR - 2022-03-24 20:20:44 --> 404 Page Not Found: /index
ERROR - 2022-03-24 20:20:44 --> 404 Page Not Found: /index
ERROR - 2022-03-24 20:21:40 --> 404 Page Not Found: /index
ERROR - 2022-03-24 20:23:01 --> 404 Page Not Found: /index
ERROR - 2022-03-24 20:24:12 --> 404 Page Not Found: /index
ERROR - 2022-03-24 20:24:32 --> 404 Page Not Found: /index
ERROR - 2022-03-24 20:27:00 --> 404 Page Not Found: /index
ERROR - 2022-03-24 20:27:10 --> 404 Page Not Found: /index
ERROR - 2022-03-24 20:28:28 --> 404 Page Not Found: /index
ERROR - 2022-03-24 20:30:09 --> 404 Page Not Found: /index
ERROR - 2022-03-24 20:31:58 --> 404 Page Not Found: /index
ERROR - 2022-03-24 20:31:58 --> 404 Page Not Found: /index
ERROR - 2022-03-24 20:33:00 --> 404 Page Not Found: /index
ERROR - 2022-03-24 20:35:52 --> 404 Page Not Found: /index
ERROR - 2022-03-24 20:37:13 --> To Id is not available for User - 4019
ERROR - 2022-03-24 20:37:21 --> 404 Page Not Found: /index
ERROR - 2022-03-24 20:39:30 --> 404 Page Not Found: /index
ERROR - 2022-03-24 20:39:42 --> 404 Page Not Found: /index
ERROR - 2022-03-24 20:40:03 --> 404 Page Not Found: /index
ERROR - 2022-03-24 20:42:01 --> To Id is not available for User - 4189
ERROR - 2022-03-24 20:42:04 --> 404 Page Not Found: /index
ERROR - 2022-03-24 20:43:18 --> To Id is not available for User - 4189
ERROR - 2022-03-24 20:44:06 --> 404 Page Not Found: /index
ERROR - 2022-03-24 20:45:26 --> 404 Page Not Found: /index
ERROR - 2022-03-24 20:45:29 --> 404 Page Not Found: /index
ERROR - 2022-03-24 20:46:31 --> 404 Page Not Found: /index
ERROR - 2022-03-24 20:46:57 --> 404 Page Not Found: /index
ERROR - 2022-03-24 20:47:33 --> 404 Page Not Found: /index
ERROR - 2022-03-24 20:47:47 --> To Id is not available for User - 4140
ERROR - 2022-03-24 20:48:02 --> 404 Page Not Found: /index
ERROR - 2022-03-24 20:48:15 --> 404 Page Not Found: /index
ERROR - 2022-03-24 20:48:30 --> 404 Page Not Found: /index
ERROR - 2022-03-24 20:48:53 --> 404 Page Not Found: /index
ERROR - 2022-03-24 20:49:05 --> 404 Page Not Found: /index
ERROR - 2022-03-24 20:50:20 --> 404 Page Not Found: /index
ERROR - 2022-03-24 20:51:07 --> 404 Page Not Found: /index
ERROR - 2022-03-24 20:51:41 --> 404 Page Not Found: /index
ERROR - 2022-03-24 20:52:04 --> 404 Page Not Found: /index
ERROR - 2022-03-24 20:53:13 --> 404 Page Not Found: /index
ERROR - 2022-03-24 20:53:36 --> 404 Page Not Found: /index
ERROR - 2022-03-24 20:53:55 --> 404 Page Not Found: /index
ERROR - 2022-03-24 20:54:30 --> 404 Page Not Found: /index
ERROR - 2022-03-24 20:55:16 --> 404 Page Not Found: /index
ERROR - 2022-03-24 20:55:17 --> 404 Page Not Found: /index
ERROR - 2022-03-24 20:55:24 --> 404 Page Not Found: /index
ERROR - 2022-03-24 20:56:00 --> 404 Page Not Found: /index
ERROR - 2022-03-24 20:56:37 --> 404 Page Not Found: /index
ERROR - 2022-03-24 20:57:53 --> 404 Page Not Found: /index
ERROR - 2022-03-24 20:59:09 --> 404 Page Not Found: /index
ERROR - 2022-03-24 21:01:12 --> 404 Page Not Found: /index
ERROR - 2022-03-24 21:03:18 --> 404 Page Not Found: /index
ERROR - 2022-03-24 21:07:29 --> 404 Page Not Found: /index
ERROR - 2022-03-24 21:07:29 --> 404 Page Not Found: /index
ERROR - 2022-03-24 21:08:04 --> To Id is not available for User - 4019
ERROR - 2022-03-24 21:08:13 --> To Id is not available for User - 4019
ERROR - 2022-03-24 21:08:15 --> To Id is not available for User - 4019
ERROR - 2022-03-24 21:08:16 --> To Id is not available for User - 4189
ERROR - 2022-03-24 21:08:23 --> 404 Page Not Found: /index
ERROR - 2022-03-24 21:08:34 --> 404 Page Not Found: /index
ERROR - 2022-03-24 21:10:20 --> 404 Page Not Found: /index
ERROR - 2022-03-24 21:10:36 --> 404 Page Not Found: /index
ERROR - 2022-03-24 21:12:56 --> 404 Page Not Found: /index
ERROR - 2022-03-24 21:16:00 --> 404 Page Not Found: /index
ERROR - 2022-03-24 21:16:07 --> 404 Page Not Found: /index
ERROR - 2022-03-24 21:16:17 --> 404 Page Not Found: /index
ERROR - 2022-03-24 21:16:19 --> 404 Page Not Found: /index
ERROR - 2022-03-24 21:17:51 --> 404 Page Not Found: /index
ERROR - 2022-03-24 21:19:03 --> 404 Page Not Found: /index
ERROR - 2022-03-24 21:19:25 --> 404 Page Not Found: /index
ERROR - 2022-03-24 21:19:35 --> 404 Page Not Found: /index
ERROR - 2022-03-24 21:20:01 --> 404 Page Not Found: /index
ERROR - 2022-03-24 21:20:37 --> 404 Page Not Found: /index
ERROR - 2022-03-24 21:21:40 --> 404 Page Not Found: /index
ERROR - 2022-03-24 21:23:19 --> 404 Page Not Found: /index
ERROR - 2022-03-24 21:23:36 --> 404 Page Not Found: /index
ERROR - 2022-03-24 21:25:14 --> 404 Page Not Found: /index
ERROR - 2022-03-24 21:25:25 --> 404 Page Not Found: /index
ERROR - 2022-03-24 21:25:38 --> 404 Page Not Found: /index
ERROR - 2022-03-24 21:27:58 --> 404 Page Not Found: /index
ERROR - 2022-03-24 21:28:20 --> 404 Page Not Found: /index
ERROR - 2022-03-24 21:28:45 --> 404 Page Not Found: /index
ERROR - 2022-03-24 21:29:28 --> 404 Page Not Found: /index
ERROR - 2022-03-24 21:29:54 --> 404 Page Not Found: /index
ERROR - 2022-03-24 21:30:52 --> 404 Page Not Found: /index
ERROR - 2022-03-24 21:30:54 --> 404 Page Not Found: /index
ERROR - 2022-03-24 21:33:12 --> 404 Page Not Found: /index
ERROR - 2022-03-24 21:33:13 --> 404 Page Not Found: /index
ERROR - 2022-03-24 21:35:43 --> 404 Page Not Found: /index
ERROR - 2022-03-24 21:36:01 --> 404 Page Not Found: /index
ERROR - 2022-03-24 21:36:21 --> 404 Page Not Found: /index
ERROR - 2022-03-24 21:37:00 --> 404 Page Not Found: /index
ERROR - 2022-03-24 21:39:28 --> 404 Page Not Found: /index
ERROR - 2022-03-24 21:41:29 --> 404 Page Not Found: /index
ERROR - 2022-03-24 21:42:05 --> 404 Page Not Found: /index
ERROR - 2022-03-24 21:43:20 --> 404 Page Not Found: /index
ERROR - 2022-03-24 21:43:20 --> 404 Page Not Found: /index
ERROR - 2022-03-24 21:43:40 --> 404 Page Not Found: /index
ERROR - 2022-03-24 21:45:06 --> 404 Page Not Found: /index
ERROR - 2022-03-24 21:45:58 --> 404 Page Not Found: /index
ERROR - 2022-03-24 21:45:58 --> 404 Page Not Found: /index
ERROR - 2022-03-24 21:47:48 --> 404 Page Not Found: /index
ERROR - 2022-03-24 21:48:15 --> 404 Page Not Found: /index
ERROR - 2022-03-24 21:49:35 --> 404 Page Not Found: /index
ERROR - 2022-03-24 21:49:59 --> 404 Page Not Found: /index
ERROR - 2022-03-24 21:50:37 --> To Id is not available for User - 4019
ERROR - 2022-03-24 21:50:53 --> 404 Page Not Found: /index
ERROR - 2022-03-24 21:51:17 --> 404 Page Not Found: /index
ERROR - 2022-03-24 21:51:34 --> 404 Page Not Found: /index
ERROR - 2022-03-24 21:52:09 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-24 21:52:09')
ERROR - 2022-03-24 21:52:13 --> 404 Page Not Found: /index
ERROR - 2022-03-24 21:52:27 --> 404 Page Not Found: /index
ERROR - 2022-03-24 21:54:01 --> 404 Page Not Found: /index
ERROR - 2022-03-24 21:54:20 --> 404 Page Not Found: /index
ERROR - 2022-03-24 21:54:40 --> 404 Page Not Found: /index
ERROR - 2022-03-24 21:55:33 --> 404 Page Not Found: /index
ERROR - 2022-03-24 21:56:19 --> 404 Page Not Found: /index
ERROR - 2022-03-24 21:56:50 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-24 21:56:50')
ERROR - 2022-03-24 21:57:49 --> 404 Page Not Found: /index
ERROR - 2022-03-24 21:59:19 --> 404 Page Not Found: /index
ERROR - 2022-03-24 21:59:52 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:01:03 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:01:03 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:01:57 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:02:25 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:03:18 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:04:18 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:05:10 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:05:52 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:06:54 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:11:01 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:11:20 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:11:22 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:11:22 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:11:29 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:11:37 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:11:37 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:12:08 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:12:09 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:13:07 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:13:51 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:14:18 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:14:26 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:15:25 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:15:53 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:15:53 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:16:14 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:16:25 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:16:54 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:17:00 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:17:06 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:18:27 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:18:51 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:20:38 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:24:03 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:24:22 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:24:46 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:24:55 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:25:13 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:27:07 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:27:25 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:27:25 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:27:39 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:27:39 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:27:56 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:30:07 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:30:40 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:30:43 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:31:29 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:31:35 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:31:35 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:31:42 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:31:49 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:31:49 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:32:05 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:32:51 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:33:29 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:34:02 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:34:26 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:34:29 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:36:36 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:36:39 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:38:57 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:44:00 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:45:40 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:45:40 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:47:01 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:47:27 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:47:57 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:49:04 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:49:27 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:49:30 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:50:03 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:50:03 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:50:16 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-24 22:50:16')
ERROR - 2022-03-24 22:51:51 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:51:51 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:52:01 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:52:13 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:52:13 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:52:21 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:54:11 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:54:40 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:55:24 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:56:15 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:56:20 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:56:28 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:56:46 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:57:12 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-24 22:57:12')
ERROR - 2022-03-24 22:59:37 --> 404 Page Not Found: /index
ERROR - 2022-03-24 22:59:38 --> 404 Page Not Found: /index
ERROR - 2022-03-24 23:02:15 --> 404 Page Not Found: /index
ERROR - 2022-03-24 23:05:16 --> 404 Page Not Found: /index
ERROR - 2022-03-24 23:07:15 --> 404 Page Not Found: /index
ERROR - 2022-03-24 23:09:36 --> 404 Page Not Found: /index
ERROR - 2022-03-24 23:10:01 --> 404 Page Not Found: /index
ERROR - 2022-03-24 23:11:03 --> 404 Page Not Found: /index
ERROR - 2022-03-24 23:11:03 --> 404 Page Not Found: /index
ERROR - 2022-03-24 23:11:14 --> 404 Page Not Found: /index
ERROR - 2022-03-24 23:11:14 --> 404 Page Not Found: /index
ERROR - 2022-03-24 23:12:18 --> 404 Page Not Found: /index
ERROR - 2022-03-24 23:15:08 --> 404 Page Not Found: /index
ERROR - 2022-03-24 23:15:24 --> 404 Page Not Found: /index
ERROR - 2022-03-24 23:16:20 --> To Id is not available for User - 933
ERROR - 2022-03-24 23:16:32 --> 404 Page Not Found: /index
ERROR - 2022-03-24 23:17:29 --> 404 Page Not Found: /index
ERROR - 2022-03-24 23:17:37 --> 404 Page Not Found: /index
ERROR - 2022-03-24 23:18:28 --> 404 Page Not Found: /index
ERROR - 2022-03-24 23:18:41 --> 404 Page Not Found: /index
ERROR - 2022-03-24 23:19:29 --> 404 Page Not Found: /index
ERROR - 2022-03-24 23:19:32 --> 404 Page Not Found: /index
ERROR - 2022-03-24 23:19:41 --> 404 Page Not Found: /index
ERROR - 2022-03-24 23:20:46 --> 404 Page Not Found: /index
ERROR - 2022-03-24 23:26:15 --> 404 Page Not Found: /index
ERROR - 2022-03-24 23:29:44 --> 404 Page Not Found: /index
ERROR - 2022-03-24 23:30:56 --> 404 Page Not Found: /index
ERROR - 2022-03-24 23:37:30 --> 404 Page Not Found: /index
ERROR - 2022-03-24 23:38:53 --> 404 Page Not Found: /index
ERROR - 2022-03-24 23:40:51 --> 404 Page Not Found: /index
ERROR - 2022-03-24 23:48:29 --> 404 Page Not Found: /index
ERROR - 2022-03-24 23:48:31 --> 404 Page Not Found: /index
ERROR - 2022-03-24 23:50:45 --> 404 Page Not Found: /index
ERROR - 2022-03-24 23:54:32 --> 404 Page Not Found: /index
ERROR - 2022-03-24 23:55:39 --> 404 Page Not Found: /index
ERROR - 2022-03-24 23:57:46 --> 404 Page Not Found: /index
ERROR - 2022-03-24 23:58:41 --> 404 Page Not Found: /index
