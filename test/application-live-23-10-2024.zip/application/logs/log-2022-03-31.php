<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-31 00:04:53 --> 404 Page Not Found: /index
ERROR - 2022-03-31 00:06:26 --> 404 Page Not Found: /index
ERROR - 2022-03-31 00:12:21 --> 404 Page Not Found: /index
ERROR - 2022-03-31 00:18:33 --> 404 Page Not Found: /index
ERROR - 2022-03-31 00:18:49 --> 404 Page Not Found: /index
ERROR - 2022-03-31 00:37:29 --> 404 Page Not Found: /index
ERROR - 2022-03-31 00:44:56 --> 404 Page Not Found: /index
ERROR - 2022-03-31 00:55:10 --> 404 Page Not Found: /index
ERROR - 2022-03-31 00:55:15 --> 404 Page Not Found: /index
ERROR - 2022-03-31 00:55:34 --> 404 Page Not Found: /index
ERROR - 2022-03-31 00:56:43 --> 404 Page Not Found: /index
ERROR - 2022-03-31 00:56:48 --> 404 Page Not Found: /index
ERROR - 2022-03-31 00:57:49 --> 404 Page Not Found: /index
ERROR - 2022-03-31 00:57:55 --> 404 Page Not Found: /index
ERROR - 2022-03-31 01:14:16 --> 404 Page Not Found: /index
ERROR - 2022-03-31 02:04:38 --> 404 Page Not Found: /index
ERROR - 2022-03-31 02:18:22 --> 404 Page Not Found: /index
ERROR - 2022-03-31 02:28:03 --> 404 Page Not Found: /index
ERROR - 2022-03-31 02:32:30 --> 404 Page Not Found: /index
ERROR - 2022-03-31 02:40:25 --> 404 Page Not Found: /index
ERROR - 2022-03-31 02:40:34 --> 404 Page Not Found: /index
ERROR - 2022-03-31 02:43:00 --> 404 Page Not Found: /index
ERROR - 2022-03-31 02:51:11 --> 404 Page Not Found: /index
ERROR - 2022-03-31 03:00:50 --> 404 Page Not Found: /index
ERROR - 2022-03-31 03:17:14 --> 404 Page Not Found: /index
ERROR - 2022-03-31 03:24:05 --> 404 Page Not Found: /index
ERROR - 2022-03-31 03:34:57 --> 404 Page Not Found: /index
ERROR - 2022-03-31 04:23:43 --> 404 Page Not Found: /index
ERROR - 2022-03-31 04:40:08 --> 404 Page Not Found: /index
ERROR - 2022-03-31 04:46:33 --> 404 Page Not Found: /index
ERROR - 2022-03-31 04:46:34 --> 404 Page Not Found: /index
ERROR - 2022-03-31 04:46:34 --> 404 Page Not Found: /index
ERROR - 2022-03-31 04:46:34 --> 404 Page Not Found: /index
ERROR - 2022-03-31 04:46:35 --> 404 Page Not Found: /index
ERROR - 2022-03-31 04:46:35 --> 404 Page Not Found: /index
ERROR - 2022-03-31 04:46:36 --> 404 Page Not Found: /index
ERROR - 2022-03-31 04:46:36 --> 404 Page Not Found: /index
ERROR - 2022-03-31 04:46:36 --> 404 Page Not Found: /index
ERROR - 2022-03-31 04:46:37 --> 404 Page Not Found: /index
ERROR - 2022-03-31 04:47:30 --> 404 Page Not Found: /index
ERROR - 2022-03-31 04:57:37 --> 404 Page Not Found: /index
ERROR - 2022-03-31 05:00:58 --> 404 Page Not Found: /index
ERROR - 2022-03-31 05:05:53 --> 404 Page Not Found: /index
ERROR - 2022-03-31 05:11:01 --> 404 Page Not Found: /index
ERROR - 2022-03-31 05:16:56 --> 404 Page Not Found: /index
ERROR - 2022-03-31 05:22:00 --> 404 Page Not Found: /index
ERROR - 2022-03-31 05:26:08 --> 404 Page Not Found: /index
ERROR - 2022-03-31 05:42:37 --> 404 Page Not Found: /index
ERROR - 2022-03-31 05:44:22 --> 404 Page Not Found: /index
ERROR - 2022-03-31 05:48:27 --> 404 Page Not Found: /index
ERROR - 2022-03-31 05:59:20 --> 404 Page Not Found: /index
ERROR - 2022-03-31 06:01:27 --> 404 Page Not Found: /index
ERROR - 2022-03-31 06:02:16 --> 404 Page Not Found: /index
ERROR - 2022-03-31 06:05:21 --> 404 Page Not Found: /index
ERROR - 2022-03-31 06:16:57 --> 404 Page Not Found: /index
ERROR - 2022-03-31 06:35:16 --> 404 Page Not Found: /index
ERROR - 2022-03-31 06:36:40 --> 404 Page Not Found: /index
ERROR - 2022-03-31 06:38:27 --> 404 Page Not Found: /index
ERROR - 2022-03-31 06:39:04 --> 404 Page Not Found: /index
ERROR - 2022-03-31 06:39:45 --> 404 Page Not Found: /index
ERROR - 2022-03-31 06:40:22 --> 404 Page Not Found: /index
ERROR - 2022-03-31 06:44:45 --> 404 Page Not Found: /index
ERROR - 2022-03-31 06:50:20 --> 404 Page Not Found: /index
ERROR - 2022-03-31 06:52:36 --> 404 Page Not Found: /index
ERROR - 2022-03-31 06:52:47 --> 404 Page Not Found: /index
ERROR - 2022-03-31 06:54:54 --> 404 Page Not Found: /index
ERROR - 2022-03-31 06:57:16 --> 404 Page Not Found: /index
ERROR - 2022-03-31 07:00:30 --> 404 Page Not Found: /index
ERROR - 2022-03-31 07:09:47 --> 404 Page Not Found: /index
ERROR - 2022-03-31 07:11:10 --> 404 Page Not Found: /index
ERROR - 2022-03-31 07:17:37 --> 404 Page Not Found: /index
ERROR - 2022-03-31 07:20:25 --> 404 Page Not Found: /index
ERROR - 2022-03-31 07:25:25 --> 404 Page Not Found: /index
ERROR - 2022-03-31 07:27:44 --> 404 Page Not Found: /index
ERROR - 2022-03-31 07:28:00 --> 404 Page Not Found: /index
ERROR - 2022-03-31 07:31:44 --> 404 Page Not Found: /index
ERROR - 2022-03-31 07:35:22 --> 404 Page Not Found: /index
ERROR - 2022-03-31 07:35:53 --> To Id is not available for User - 3046
ERROR - 2022-03-31 07:35:57 --> 404 Page Not Found: /index
ERROR - 2022-03-31 07:38:06 --> 404 Page Not Found: /index
ERROR - 2022-03-31 07:38:20 --> To Id is not available for User - 3046
ERROR - 2022-03-31 07:38:23 --> 404 Page Not Found: /index
ERROR - 2022-03-31 07:51:10 --> 404 Page Not Found: /index
ERROR - 2022-03-31 07:51:17 --> 404 Page Not Found: /index
ERROR - 2022-03-31 07:57:34 --> 404 Page Not Found: /index
ERROR - 2022-03-31 08:02:15 --> 404 Page Not Found: /index
ERROR - 2022-03-31 08:06:29 --> 404 Page Not Found: /index
ERROR - 2022-03-31 08:07:08 --> 404 Page Not Found: /index
ERROR - 2022-03-31 08:11:42 --> 404 Page Not Found: /index
ERROR - 2022-03-31 08:18:37 --> 404 Page Not Found: /index
ERROR - 2022-03-31 08:21:22 --> 404 Page Not Found: /index
ERROR - 2022-03-31 08:50:39 --> 404 Page Not Found: /index
ERROR - 2022-03-31 08:51:01 --> To Id is not available for User - 4019
ERROR - 2022-03-31 08:51:09 --> 404 Page Not Found: /index
ERROR - 2022-03-31 08:52:47 --> 404 Page Not Found: /index
ERROR - 2022-03-31 08:57:18 --> 404 Page Not Found: /index
ERROR - 2022-03-31 09:02:21 --> 404 Page Not Found: /index
ERROR - 2022-03-31 09:03:51 --> 404 Page Not Found: /index
ERROR - 2022-03-31 09:03:53 --> To Id is not available for User - 3046
ERROR - 2022-03-31 09:04:07 --> 404 Page Not Found: /index
ERROR - 2022-03-31 09:04:19 --> 404 Page Not Found: /index
ERROR - 2022-03-31 09:04:33 --> 404 Page Not Found: /index
ERROR - 2022-03-31 09:09:03 --> 404 Page Not Found: /index
ERROR - 2022-03-31 09:09:27 --> 404 Page Not Found: /index
ERROR - 2022-03-31 09:10:24 --> 404 Page Not Found: /index
ERROR - 2022-03-31 09:14:15 --> 404 Page Not Found: /index
ERROR - 2022-03-31 09:14:25 --> 404 Page Not Found: /index
ERROR - 2022-03-31 09:15:48 --> 404 Page Not Found: /index
ERROR - 2022-03-31 09:16:00 --> 404 Page Not Found: /index
ERROR - 2022-03-31 09:17:31 --> 404 Page Not Found: /index
ERROR - 2022-03-31 09:17:43 --> 404 Page Not Found: /index
ERROR - 2022-03-31 09:17:55 --> 404 Page Not Found: /index
ERROR - 2022-03-31 09:18:36 --> 404 Page Not Found: /index
ERROR - 2022-03-31 09:19:32 --> 404 Page Not Found: /index
ERROR - 2022-03-31 09:21:46 --> 404 Page Not Found: /index
ERROR - 2022-03-31 09:22:16 --> 404 Page Not Found: /index
ERROR - 2022-03-31 09:24:21 --> 404 Page Not Found: /index
ERROR - 2022-03-31 09:26:11 --> 404 Page Not Found: /index
ERROR - 2022-03-31 09:27:17 --> 404 Page Not Found: /index
ERROR - 2022-03-31 09:27:19 --> 404 Page Not Found: /index
ERROR - 2022-03-31 09:31:41 --> 404 Page Not Found: /index
ERROR - 2022-03-31 09:32:22 --> 404 Page Not Found: /index
ERROR - 2022-03-31 09:33:30 --> 404 Page Not Found: /index
ERROR - 2022-03-31 09:36:32 --> 404 Page Not Found: /index
ERROR - 2022-03-31 09:38:25 --> 404 Page Not Found: /index
ERROR - 2022-03-31 09:39:19 --> 404 Page Not Found: /index
ERROR - 2022-03-31 09:40:15 --> 404 Page Not Found: /index
ERROR - 2022-03-31 09:42:03 --> 404 Page Not Found: /index
ERROR - 2022-03-31 09:44:05 --> 404 Page Not Found: /index
ERROR - 2022-03-31 09:45:59 --> 404 Page Not Found: /index
ERROR - 2022-03-31 09:46:00 --> 404 Page Not Found: /index
ERROR - 2022-03-31 09:47:43 --> 404 Page Not Found: /index
ERROR - 2022-03-31 09:48:46 --> 404 Page Not Found: /index
ERROR - 2022-03-31 09:49:07 --> 404 Page Not Found: /index
ERROR - 2022-03-31 09:50:04 --> 404 Page Not Found: /index
ERROR - 2022-03-31 09:53:21 --> 404 Page Not Found: /index
ERROR - 2022-03-31 09:53:28 --> 404 Page Not Found: /index
ERROR - 2022-03-31 09:57:18 --> 404 Page Not Found: /index
ERROR - 2022-03-31 09:57:42 --> 404 Page Not Found: /index
ERROR - 2022-03-31 09:59:27 --> 404 Page Not Found: /index
ERROR - 2022-03-31 10:00:03 --> 404 Page Not Found: /index
ERROR - 2022-03-31 10:00:35 --> 404 Page Not Found: /index
ERROR - 2022-03-31 10:00:35 --> 404 Page Not Found: /index
ERROR - 2022-03-31 10:00:56 --> 404 Page Not Found: /index
ERROR - 2022-03-31 10:01:52 --> 404 Page Not Found: /index
ERROR - 2022-03-31 10:01:52 --> 404 Page Not Found: /index
ERROR - 2022-03-31 10:03:03 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-31 10:03:03 --> 404 Page Not Found: /index
ERROR - 2022-03-31 10:03:05 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-31 10:03:19 --> 404 Page Not Found: /index
ERROR - 2022-03-31 10:03:42 --> 404 Page Not Found: /index
ERROR - 2022-03-31 10:04:02 --> 404 Page Not Found: /index
ERROR - 2022-03-31 10:04:11 --> 404 Page Not Found: /index
ERROR - 2022-03-31 10:04:24 --> 404 Page Not Found: /index
ERROR - 2022-03-31 10:04:24 --> 404 Page Not Found: /index
ERROR - 2022-03-31 10:04:24 --> 404 Page Not Found: /index
ERROR - 2022-03-31 10:05:39 --> 404 Page Not Found: /index
ERROR - 2022-03-31 10:07:45 --> 404 Page Not Found: /index
ERROR - 2022-03-31 10:10:26 --> 404 Page Not Found: /index
ERROR - 2022-03-31 10:11:07 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-31 10:11:38 --> 404 Page Not Found: /index
ERROR - 2022-03-31 10:14:23 --> 404 Page Not Found: /index
ERROR - 2022-03-31 10:14:37 --> 404 Page Not Found: /index
ERROR - 2022-03-31 10:17:06 --> 404 Page Not Found: /index
ERROR - 2022-03-31 10:18:26 --> 404 Page Not Found: /index
ERROR - 2022-03-31 10:18:35 --> 404 Page Not Found: /index
ERROR - 2022-03-31 10:18:58 --> 404 Page Not Found: /index
ERROR - 2022-03-31 10:22:57 --> 404 Page Not Found: /index
ERROR - 2022-03-31 10:23:21 --> 404 Page Not Found: /index
ERROR - 2022-03-31 10:26:15 --> 404 Page Not Found: /index
ERROR - 2022-03-31 10:27:01 --> 404 Page Not Found: /index
ERROR - 2022-03-31 10:29:57 --> 404 Page Not Found: /index
ERROR - 2022-03-31 10:30:55 --> 404 Page Not Found: /index
ERROR - 2022-03-31 10:31:00 --> 404 Page Not Found: /index
ERROR - 2022-03-31 10:32:36 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-31 10:32:40 --> 404 Page Not Found: /index
ERROR - 2022-03-31 10:33:10 --> 404 Page Not Found: /index
ERROR - 2022-03-31 10:34:54 --> 404 Page Not Found: /index
ERROR - 2022-03-31 10:37:44 --> 404 Page Not Found: /index
ERROR - 2022-03-31 10:38:35 --> 404 Page Not Found: /index
ERROR - 2022-03-31 10:39:32 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-31 10:39:32')
ERROR - 2022-03-31 10:39:49 --> 404 Page Not Found: /index
ERROR - 2022-03-31 10:40:13 --> 404 Page Not Found: /index
ERROR - 2022-03-31 10:41:10 --> 404 Page Not Found: /index
ERROR - 2022-03-31 10:41:31 --> 404 Page Not Found: /index
ERROR - 2022-03-31 10:41:46 --> 404 Page Not Found: /index
ERROR - 2022-03-31 10:42:03 --> 404 Page Not Found: /index
ERROR - 2022-03-31 10:42:40 --> 404 Page Not Found: /index
ERROR - 2022-03-31 10:43:01 --> 404 Page Not Found: /index
ERROR - 2022-03-31 10:43:01 --> 404 Page Not Found: /index
ERROR - 2022-03-31 10:44:26 --> 404 Page Not Found: /index
ERROR - 2022-03-31 10:45:57 --> 404 Page Not Found: /index
ERROR - 2022-03-31 10:46:42 --> 404 Page Not Found: /index
ERROR - 2022-03-31 10:47:18 --> 404 Page Not Found: /index
ERROR - 2022-03-31 10:47:34 --> 404 Page Not Found: /index
ERROR - 2022-03-31 10:48:25 --> 404 Page Not Found: /index
ERROR - 2022-03-31 10:48:56 --> 404 Page Not Found: /index
ERROR - 2022-03-31 10:50:07 --> 404 Page Not Found: /index
ERROR - 2022-03-31 10:50:37 --> 404 Page Not Found: /index
ERROR - 2022-03-31 10:50:40 --> 404 Page Not Found: /index
ERROR - 2022-03-31 10:52:52 --> 404 Page Not Found: /index
ERROR - 2022-03-31 10:54:35 --> 404 Page Not Found: /index
ERROR - 2022-03-31 10:54:45 --> 404 Page Not Found: /index
ERROR - 2022-03-31 10:54:54 --> 404 Page Not Found: /index
ERROR - 2022-03-31 10:56:57 --> 404 Page Not Found: /index
ERROR - 2022-03-31 10:57:32 --> 404 Page Not Found: /index
ERROR - 2022-03-31 10:57:38 --> 404 Page Not Found: /index
ERROR - 2022-03-31 10:57:40 --> 404 Page Not Found: /index
ERROR - 2022-03-31 10:58:22 --> 404 Page Not Found: /index
ERROR - 2022-03-31 10:58:37 --> 404 Page Not Found: /index
ERROR - 2022-03-31 10:59:25 --> 404 Page Not Found: /index
ERROR - 2022-03-31 11:01:32 --> 404 Page Not Found: /index
ERROR - 2022-03-31 11:02:24 --> 404 Page Not Found: /index
ERROR - 2022-03-31 11:02:36 --> 404 Page Not Found: /index
ERROR - 2022-03-31 11:03:11 --> 404 Page Not Found: /index
ERROR - 2022-03-31 11:06:12 --> 404 Page Not Found: /index
ERROR - 2022-03-31 11:06:46 --> 404 Page Not Found: /index
ERROR - 2022-03-31 11:07:21 --> 404 Page Not Found: /index
ERROR - 2022-03-31 11:09:48 --> 404 Page Not Found: /index
ERROR - 2022-03-31 11:09:53 --> 404 Page Not Found: /index
ERROR - 2022-03-31 11:10:06 --> 404 Page Not Found: /index
ERROR - 2022-03-31 11:10:07 --> 404 Page Not Found: /index
ERROR - 2022-03-31 11:12:08 --> 404 Page Not Found: /index
ERROR - 2022-03-31 11:16:41 --> 404 Page Not Found: /index
ERROR - 2022-03-31 11:18:00 --> 404 Page Not Found: /index
ERROR - 2022-03-31 11:18:08 --> 404 Page Not Found: /index
ERROR - 2022-03-31 11:18:51 --> 404 Page Not Found: /index
ERROR - 2022-03-31 11:19:48 --> 404 Page Not Found: /index
ERROR - 2022-03-31 11:20:21 --> 404 Page Not Found: /index
ERROR - 2022-03-31 11:21:16 --> 404 Page Not Found: /index
ERROR - 2022-03-31 11:22:39 --> 404 Page Not Found: /index
ERROR - 2022-03-31 11:23:36 --> 404 Page Not Found: /index
ERROR - 2022-03-31 11:25:00 --> 404 Page Not Found: /index
ERROR - 2022-03-31 11:25:01 --> 404 Page Not Found: /index
ERROR - 2022-03-31 11:30:11 --> 404 Page Not Found: /index
ERROR - 2022-03-31 11:30:11 --> 404 Page Not Found: /index
ERROR - 2022-03-31 11:30:12 --> 404 Page Not Found: /index
ERROR - 2022-03-31 11:30:12 --> 404 Page Not Found: /index
ERROR - 2022-03-31 11:30:27 --> 404 Page Not Found: /index
ERROR - 2022-03-31 11:31:48 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-31 11:33:00 --> 404 Page Not Found: /index
ERROR - 2022-03-31 11:33:00 --> 404 Page Not Found: /index
ERROR - 2022-03-31 11:33:07 --> 404 Page Not Found: /index
ERROR - 2022-03-31 11:33:08 --> 404 Page Not Found: /index
ERROR - 2022-03-31 11:34:50 --> 404 Page Not Found: /index
ERROR - 2022-03-31 11:34:50 --> 404 Page Not Found: /index
ERROR - 2022-03-31 11:35:09 --> 404 Page Not Found: /index
ERROR - 2022-03-31 11:35:11 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT `p`.*, `r`.`caste`, `r`.`height`, `r`.`star`, `r`.`time_of_birth`, `r`.`raasi`, `prp`.`property_value`, `e`.`occupation`, `e`.`education_degree`, `e`.`visatype`, `e`.`city`, `e`.`country`, `e`.`annual_income`, `pfs`.`payment_status`, `pfs`.`profilesetting_id` as `pfs_id`, `pfs`.`last_call_updated`, `adm`.`username` as `profile_owner`
FROM `tbl_primary_info` as `p`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `ms_property_info` as `prp` ON `p`.`id`=`prp`.`ms_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `ms_profilesetting` as `pfs` ON `p`.`id`=`pfs`.`ms_id`
LEFT JOIN `tbl_admin_data` as `adm` ON `pfs`.`profileowner`=`adm`.`id`
WHERE `p`.`gender` = 'male'
AND `p`.`status` = '1'
AND `r`.`caste` = `Array`
AND `adm`.`id` = '15'
GROUP BY `p`.`id`
ERROR - 2022-03-31 11:35:29 --> 404 Page Not Found: /index
ERROR - 2022-03-31 11:35:30 --> 404 Page Not Found: /index
ERROR - 2022-03-31 11:35:47 --> 404 Page Not Found: /index
ERROR - 2022-03-31 11:35:47 --> 404 Page Not Found: /index
ERROR - 2022-03-31 11:35:48 --> 404 Page Not Found: /index
ERROR - 2022-03-31 11:36:26 --> 404 Page Not Found: /index
ERROR - 2022-03-31 11:36:26 --> 404 Page Not Found: /index
ERROR - 2022-03-31 11:36:30 --> 404 Page Not Found: /index
ERROR - 2022-03-31 11:36:31 --> 404 Page Not Found: /index
ERROR - 2022-03-31 11:36:53 --> 404 Page Not Found: /index
ERROR - 2022-03-31 11:36:53 --> 404 Page Not Found: /index
ERROR - 2022-03-31 11:37:08 --> 404 Page Not Found: /index
ERROR - 2022-03-31 11:38:38 --> Query error: Illegal mix of collations (latin1_swedish_ci,IMPLICIT) and (utf8_general_ci,COERCIBLE) for operation 'like' - Invalid query: SELECT `p`.`first_name`, `p`.`last_name`, `p`.`gender`, `p`.`id`, `p`.`status`, `p`.`age`, `p`.`living_in`, `p`.`profile_id`, `p`.`date`, `p`.`month`, `p`.`year`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `r`.`time_of_birth`, `r`.`place_of_birth`, `r`.`gothram`, `r`.`star`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `e`.`country`, `pa`.`fathers_father_district`, `pa`.`mothers_father_district`, `pa`.`father_mobile`, `pa`.`mother_mobile`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `payment_status`, `elite`, `profileowner`, `pr`.`property_value`, `pr`.`property_type`, `pr`.`property_Desc`
FROM `tbl_primary_info` as `p`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `tbl_parents_info` as `pa` ON `p`.`id`=`pa`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`MS_id`
LEFT JOIN `ms_profilesetting` as `mprosetting` ON `p`.`id`=`mprosetting`.`MS_id`
LEFT JOIN `ms_property_info` as `pr` ON `p`.`id`=`pr`.`ms_id`
WHERE `p`.`profile_id` LIKE '%K̤V̤964019%' ESCAPE '!'
AND `u`.`ismain` = 1 AND `u`.`isactive` = 1
AND `p`.`status` = 1
GROUP BY `p`.`id`
ORDER BY `p`.`registered_on` DESC
ERROR - 2022-03-31 11:38:52 --> Query error: Illegal mix of collations (latin1_swedish_ci,IMPLICIT) and (utf8_general_ci,COERCIBLE) for operation 'like' - Invalid query: SELECT `p`.`first_name`, `p`.`last_name`, `p`.`gender`, `p`.`id`, `p`.`status`, `p`.`age`, `p`.`living_in`, `p`.`profile_id`, `p`.`date`, `p`.`month`, `p`.`year`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `r`.`time_of_birth`, `r`.`place_of_birth`, `r`.`gothram`, `r`.`star`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `e`.`country`, `pa`.`fathers_father_district`, `pa`.`mothers_father_district`, `pa`.`father_mobile`, `pa`.`mother_mobile`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `payment_status`, `elite`, `profileowner`, `pr`.`property_value`, `pr`.`property_type`, `pr`.`property_Desc`
FROM `tbl_primary_info` as `p`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `tbl_parents_info` as `pa` ON `p`.`id`=`pa`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`MS_id`
LEFT JOIN `ms_profilesetting` as `mprosetting` ON `p`.`id`=`mprosetting`.`MS_id`
LEFT JOIN `ms_property_info` as `pr` ON `p`.`id`=`pr`.`ms_id`
WHERE `p`.`profile_id` LIKE '%K̤V̤964019%' ESCAPE '!'
AND `u`.`ismain` = 1 AND `u`.`isactive` = 1
AND `p`.`status` = 1
GROUP BY `p`.`id`
ORDER BY `p`.`registered_on` DESC
ERROR - 2022-03-31 11:38:53 --> 404 Page Not Found: /index
ERROR - 2022-03-31 11:39:41 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-31 11:40:49 --> 404 Page Not Found: /index
ERROR - 2022-03-31 11:41:45 --> 404 Page Not Found: /index
ERROR - 2022-03-31 11:45:26 --> 404 Page Not Found: /index
ERROR - 2022-03-31 11:45:58 --> 404 Page Not Found: /index
ERROR - 2022-03-31 11:46:04 --> 404 Page Not Found: /index
ERROR - 2022-03-31 11:46:07 --> 404 Page Not Found: /index
ERROR - 2022-03-31 11:46:38 --> 404 Page Not Found: /index
ERROR - 2022-03-31 11:47:30 --> 404 Page Not Found: /index
ERROR - 2022-03-31 11:47:36 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-31 11:47:36')
ERROR - 2022-03-31 11:47:41 --> 404 Page Not Found: /index
ERROR - 2022-03-31 11:47:51 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-31 11:48:04 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-31 11:48:09 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-31 11:48:42 --> 404 Page Not Found: /index
ERROR - 2022-03-31 11:49:34 --> 404 Page Not Found: /index
ERROR - 2022-03-31 11:49:40 --> 404 Page Not Found: /index
ERROR - 2022-03-31 11:52:37 --> 404 Page Not Found: /index
ERROR - 2022-03-31 11:52:44 --> 404 Page Not Found: /index
ERROR - 2022-03-31 11:52:47 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-31 11:53:03 --> 404 Page Not Found: /index
ERROR - 2022-03-31 11:54:02 --> 404 Page Not Found: /index
ERROR - 2022-03-31 11:54:02 --> 404 Page Not Found: /index
ERROR - 2022-03-31 11:54:02 --> 404 Page Not Found: /index
ERROR - 2022-03-31 11:55:15 --> 404 Page Not Found: /index
ERROR - 2022-03-31 11:55:20 --> 404 Page Not Found: /index
ERROR - 2022-03-31 11:55:20 --> 404 Page Not Found: /index
ERROR - 2022-03-31 11:55:20 --> 404 Page Not Found: /index
ERROR - 2022-03-31 11:56:58 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-31 11:57:07 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-31 11:58:22 --> 404 Page Not Found: /index
ERROR - 2022-03-31 11:58:53 --> 404 Page Not Found: /index
ERROR - 2022-03-31 12:03:09 --> 404 Page Not Found: /index
ERROR - 2022-03-31 12:03:09 --> 404 Page Not Found: /index
ERROR - 2022-03-31 12:03:40 --> 404 Page Not Found: /index
ERROR - 2022-03-31 12:04:11 --> 404 Page Not Found: /index
ERROR - 2022-03-31 12:06:39 --> 404 Page Not Found: /index
ERROR - 2022-03-31 12:08:58 --> 404 Page Not Found: /index
ERROR - 2022-03-31 12:09:01 --> 404 Page Not Found: /index
ERROR - 2022-03-31 12:11:06 --> 404 Page Not Found: /index
ERROR - 2022-03-31 12:11:07 --> 404 Page Not Found: /index
ERROR - 2022-03-31 12:11:08 --> 404 Page Not Found: /index
ERROR - 2022-03-31 12:11:09 --> 404 Page Not Found: /index
ERROR - 2022-03-31 12:11:23 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-31 12:11:46 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-31 12:16:26 --> 404 Page Not Found: /index
ERROR - 2022-03-31 12:16:58 --> 404 Page Not Found: /index
ERROR - 2022-03-31 12:17:49 --> 404 Page Not Found: /index
ERROR - 2022-03-31 12:18:18 --> 404 Page Not Found: /index
ERROR - 2022-03-31 12:19:07 --> Query error: Illegal mix of collations (latin1_swedish_ci,IMPLICIT) and (utf8_general_ci,COERCIBLE) for operation 'like' - Invalid query: SELECT `p`.`first_name`, `p`.`last_name`, `p`.`gender`, `p`.`id`, `p`.`status`, `p`.`age`, `p`.`living_in`, `p`.`profile_id`, `p`.`date`, `p`.`month`, `p`.`year`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `r`.`time_of_birth`, `r`.`place_of_birth`, `r`.`gothram`, `r`.`star`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `e`.`country`, `pa`.`fathers_father_district`, `pa`.`mothers_father_district`, `pa`.`father_mobile`, `pa`.`mother_mobile`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `payment_status`, `elite`, `profileowner`, `pr`.`property_value`, `pr`.`property_type`, `pr`.`property_Desc`
FROM `tbl_primary_info` as `p`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `tbl_parents_info` as `pa` ON `p`.`id`=`pa`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`MS_id`
LEFT JOIN `ms_profilesetting` as `mprosetting` ON `p`.`id`=`mprosetting`.`MS_id`
LEFT JOIN `ms_property_info` as `pr` ON `p`.`id`=`pr`.`ms_id`
WHERE `p`.`profile_id` LIKE '%K̤V̤984130%' ESCAPE '!'
AND `u`.`ismain` = 1 AND `u`.`isactive` = 1
AND `p`.`status` = 1
GROUP BY `p`.`id`
ORDER BY `p`.`registered_on` DESC
ERROR - 2022-03-31 12:19:53 --> 404 Page Not Found: /index
ERROR - 2022-03-31 12:20:34 --> 404 Page Not Found: /index
ERROR - 2022-03-31 12:20:42 --> 404 Page Not Found: /index
ERROR - 2022-03-31 12:21:02 --> 404 Page Not Found: /index
ERROR - 2022-03-31 12:21:34 --> 404 Page Not Found: /index
ERROR - 2022-03-31 12:22:07 --> 404 Page Not Found: /index
ERROR - 2022-03-31 12:22:41 --> 404 Page Not Found: /index
ERROR - 2022-03-31 12:23:10 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-31 12:23:25 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-31 12:23:38 --> 404 Page Not Found: /index
ERROR - 2022-03-31 12:26:42 --> 404 Page Not Found: /index
ERROR - 2022-03-31 12:31:04 --> 404 Page Not Found: /index
ERROR - 2022-03-31 12:31:16 --> 404 Page Not Found: /index
ERROR - 2022-03-31 12:32:02 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-31 12:32:12 --> 404 Page Not Found: /index
ERROR - 2022-03-31 12:33:44 --> 404 Page Not Found: /index
ERROR - 2022-03-31 12:34:29 --> 404 Page Not Found: /index
ERROR - 2022-03-31 12:34:52 --> 404 Page Not Found: /index
ERROR - 2022-03-31 12:37:35 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-31 12:37:58 --> 404 Page Not Found: /index
ERROR - 2022-03-31 12:38:11 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-31 12:38:13 --> 404 Page Not Found: /index
ERROR - 2022-03-31 12:40:04 --> 404 Page Not Found: /index
ERROR - 2022-03-31 12:41:11 --> 404 Page Not Found: /index
ERROR - 2022-03-31 12:41:12 --> 404 Page Not Found: /index
ERROR - 2022-03-31 12:42:20 --> 404 Page Not Found: /index
ERROR - 2022-03-31 12:42:51 --> 404 Page Not Found: /index
ERROR - 2022-03-31 12:42:57 --> 404 Page Not Found: /index
ERROR - 2022-03-31 12:44:40 --> 404 Page Not Found: /index
ERROR - 2022-03-31 12:46:15 --> 404 Page Not Found: /index
ERROR - 2022-03-31 12:46:36 --> 404 Page Not Found: /index
ERROR - 2022-03-31 12:47:25 --> 404 Page Not Found: /index
ERROR - 2022-03-31 12:48:05 --> 404 Page Not Found: /index
ERROR - 2022-03-31 12:48:32 --> 404 Page Not Found: /index
ERROR - 2022-03-31 12:49:45 --> 404 Page Not Found: /index
ERROR - 2022-03-31 12:50:25 --> 404 Page Not Found: /index
ERROR - 2022-03-31 12:50:40 --> 404 Page Not Found: /index
ERROR - 2022-03-31 12:50:44 --> 404 Page Not Found: /index
ERROR - 2022-03-31 12:50:58 --> 404 Page Not Found: /index
ERROR - 2022-03-31 12:53:23 --> 404 Page Not Found: /index
ERROR - 2022-03-31 12:54:05 --> 404 Page Not Found: /index
ERROR - 2022-03-31 12:55:28 --> 404 Page Not Found: /index
ERROR - 2022-03-31 12:56:22 --> 404 Page Not Found: /index
ERROR - 2022-03-31 12:56:33 --> 404 Page Not Found: /index
ERROR - 2022-03-31 12:57:20 --> 404 Page Not Found: /index
ERROR - 2022-03-31 12:57:36 --> 404 Page Not Found: /index
ERROR - 2022-03-31 12:58:03 --> 404 Page Not Found: /index
ERROR - 2022-03-31 12:58:58 --> 404 Page Not Found: /index
ERROR - 2022-03-31 12:59:36 --> 404 Page Not Found: /index
ERROR - 2022-03-31 13:02:17 --> 404 Page Not Found: /index
ERROR - 2022-03-31 13:04:49 --> 404 Page Not Found: /index
ERROR - 2022-03-31 13:11:52 --> 404 Page Not Found: /index
ERROR - 2022-03-31 13:12:25 --> 404 Page Not Found: /index
ERROR - 2022-03-31 13:14:09 --> 404 Page Not Found: /index
ERROR - 2022-03-31 13:18:20 --> To Id is not available for User - 2182
ERROR - 2022-03-31 13:18:27 --> 404 Page Not Found: /index
ERROR - 2022-03-31 13:19:45 --> To Id is not available for User - 924
ERROR - 2022-03-31 13:19:52 --> To Id is not available for User - 924
ERROR - 2022-03-31 13:20:32 --> To Id is not available for User - 1434
ERROR - 2022-03-31 13:20:37 --> To Id is not available for User - 1434
ERROR - 2022-03-31 13:21:04 --> 404 Page Not Found: /index
ERROR - 2022-03-31 13:21:04 --> To Id is not available for User - 1710
ERROR - 2022-03-31 13:25:08 --> 404 Page Not Found: /index
ERROR - 2022-03-31 13:27:44 --> 404 Page Not Found: /index
ERROR - 2022-03-31 13:28:47 --> 404 Page Not Found: /index
ERROR - 2022-03-31 13:29:21 --> 404 Page Not Found: /index
ERROR - 2022-03-31 13:29:26 --> 404 Page Not Found: /index
ERROR - 2022-03-31 13:30:11 --> 404 Page Not Found: /index
ERROR - 2022-03-31 13:30:50 --> 404 Page Not Found: /index
ERROR - 2022-03-31 13:31:16 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-31 13:33:13 --> 404 Page Not Found: /index
ERROR - 2022-03-31 13:33:39 --> 404 Page Not Found: /index
ERROR - 2022-03-31 13:35:39 --> 404 Page Not Found: /index
ERROR - 2022-03-31 13:36:00 --> 404 Page Not Found: /index
ERROR - 2022-03-31 13:37:08 --> 404 Page Not Found: /index
ERROR - 2022-03-31 13:38:18 --> 404 Page Not Found: /index
ERROR - 2022-03-31 13:39:40 --> 404 Page Not Found: /index
ERROR - 2022-03-31 13:39:48 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '<script>alert("xssvuln")</script> AND <script>alert("xssvuln") < `/script>`
AND ' at line 8 - Invalid query: SELECT `p`.`gender`, `p`.`id`, `p`.`status`, `p`.`age`, `p`.`living_in`, `p`.`profile_id`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`
FROM `tbl_primary_info` as `p`
INNER JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`MS_id`
INNER JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
INNER JOIN `ms_profilesetting` as `s` ON `p`.`id`=`s`.`ms_id`
WHERE `p`.`gender` = '<script>alert(\"xssvuln\")</script>'
AND `p`.`age` BETWEEN <script>alert("xssvuln")</script> AND <script>alert("xssvuln") < `/script>`
AND `r`.`religion` = '<script>alert(\"xssvuln\")</script>'
AND `r`.`mother_tounge` = '<script>alert(\"xssvuln\")</script>'
AND `p`.`status` = 1
AND `s`.`elite` = 'no'
AND `s`.`ms_usertype` = 'regular'
AND `u`.`ismain` = 1
AND `u`.`photoname` != ''
AND `u`.`applicationphotopath` != ''
GROUP BY `u`.`MS_id`
ORDER BY `registered_on` DESC
 LIMIT 8
ERROR - 2022-03-31 13:41:14 --> 404 Page Not Found: /index
ERROR - 2022-03-31 13:42:38 --> To Id is not available for User - 1710
ERROR - 2022-03-31 13:42:41 --> 404 Page Not Found: /index
ERROR - 2022-03-31 13:43:15 --> To Id is not available for User - 1710
ERROR - 2022-03-31 13:43:21 --> 404 Page Not Found: /index
ERROR - 2022-03-31 13:43:29 --> To Id is not available for User - 2182
ERROR - 2022-03-31 13:43:38 --> To Id is not available for User - 924
ERROR - 2022-03-31 13:44:01 --> To Id is not available for User - 1434
ERROR - 2022-03-31 13:48:11 --> 404 Page Not Found: /index
ERROR - 2022-03-31 13:54:05 --> 404 Page Not Found: /index
ERROR - 2022-03-31 13:54:05 --> 404 Page Not Found: /index
ERROR - 2022-03-31 13:54:52 --> 404 Page Not Found: /index
ERROR - 2022-03-31 13:56:27 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-31 13:57:59 --> 404 Page Not Found: /index
ERROR - 2022-03-31 13:59:00 --> 404 Page Not Found: /index
ERROR - 2022-03-31 14:01:11 --> 404 Page Not Found: /index
ERROR - 2022-03-31 14:07:32 --> 404 Page Not Found: /index
ERROR - 2022-03-31 14:07:48 --> 404 Page Not Found: /index
ERROR - 2022-03-31 14:12:09 --> To Id is not available for User - 1710
ERROR - 2022-03-31 14:12:11 --> 404 Page Not Found: /index
ERROR - 2022-03-31 14:13:52 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-31 14:14:02 --> 404 Page Not Found: /index
ERROR - 2022-03-31 14:14:30 --> 404 Page Not Found: /index
ERROR - 2022-03-31 14:14:31 --> 404 Page Not Found: /index
ERROR - 2022-03-31 14:16:09 --> 404 Page Not Found: /index
ERROR - 2022-03-31 14:16:09 --> 404 Page Not Found: /index
ERROR - 2022-03-31 14:16:09 --> 404 Page Not Found: /index
ERROR - 2022-03-31 14:16:10 --> 404 Page Not Found: /index
ERROR - 2022-03-31 14:16:10 --> 404 Page Not Found: /index
ERROR - 2022-03-31 14:16:10 --> 404 Page Not Found: /index
ERROR - 2022-03-31 14:19:10 --> 404 Page Not Found: /index
ERROR - 2022-03-31 14:19:43 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-31 14:19:43')
ERROR - 2022-03-31 14:19:57 --> 404 Page Not Found: /index
ERROR - 2022-03-31 14:20:03 --> 404 Page Not Found: /index
ERROR - 2022-03-31 14:21:50 --> 404 Page Not Found: /index
ERROR - 2022-03-31 14:22:26 --> 404 Page Not Found: /index
ERROR - 2022-03-31 14:23:05 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-31 14:23:05')
ERROR - 2022-03-31 14:23:19 --> 404 Page Not Found: /index
ERROR - 2022-03-31 14:24:04 --> 404 Page Not Found: /index
ERROR - 2022-03-31 14:24:22 --> 404 Page Not Found: /index
ERROR - 2022-03-31 14:26:28 --> 404 Page Not Found: /index
ERROR - 2022-03-31 14:27:08 --> 404 Page Not Found: /index
ERROR - 2022-03-31 14:27:50 --> Severity: error --> Exception: Invalid address:  (to):  /home4/cowcdrmy/public_html/application/third_party/phpmailer/src/PHPMailer.php 1092
ERROR - 2022-03-31 14:27:57 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-31 14:28:11 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-31 14:28:16 --> To Id is not available for User - 3046
ERROR - 2022-03-31 14:28:22 --> 404 Page Not Found: /index
ERROR - 2022-03-31 14:28:24 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-31 14:28:46 --> 404 Page Not Found: /index
ERROR - 2022-03-31 14:28:54 --> 404 Page Not Found: /index
ERROR - 2022-03-31 14:29:47 --> 404 Page Not Found: /index
ERROR - 2022-03-31 14:30:58 --> 404 Page Not Found: /index
ERROR - 2022-03-31 14:33:08 --> 404 Page Not Found: /index
ERROR - 2022-03-31 14:33:37 --> 404 Page Not Found: /index
ERROR - 2022-03-31 14:35:13 --> 404 Page Not Found: /index
ERROR - 2022-03-31 14:35:16 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-31 14:36:20 --> 404 Page Not Found: /index
ERROR - 2022-03-31 14:36:22 --> 404 Page Not Found: /index
ERROR - 2022-03-31 14:36:32 --> 404 Page Not Found: /index
ERROR - 2022-03-31 14:36:58 --> 404 Page Not Found: /index
ERROR - 2022-03-31 14:37:52 --> 404 Page Not Found: /index
ERROR - 2022-03-31 14:38:24 --> 404 Page Not Found: /index
ERROR - 2022-03-31 14:39:46 --> 404 Page Not Found: /index
ERROR - 2022-03-31 14:41:18 --> 404 Page Not Found: /index
ERROR - 2022-03-31 14:41:18 --> 404 Page Not Found: /index
ERROR - 2022-03-31 14:43:13 --> 404 Page Not Found: /index
ERROR - 2022-03-31 14:43:41 --> To Id is not available for User - 1965
ERROR - 2022-03-31 14:44:00 --> 404 Page Not Found: /index
ERROR - 2022-03-31 14:44:41 --> 404 Page Not Found: /index
ERROR - 2022-03-31 14:44:46 --> 404 Page Not Found: /index
ERROR - 2022-03-31 14:44:52 --> To Id is not available for User - 1729
ERROR - 2022-03-31 14:45:28 --> 404 Page Not Found: /index
ERROR - 2022-03-31 14:45:33 --> 404 Page Not Found: /index
ERROR - 2022-03-31 14:45:55 --> 404 Page Not Found: /index
ERROR - 2022-03-31 14:47:53 --> 404 Page Not Found: /index
ERROR - 2022-03-31 14:48:27 --> 404 Page Not Found: /index
ERROR - 2022-03-31 14:49:49 --> 404 Page Not Found: /index
ERROR - 2022-03-31 14:50:19 --> 404 Page Not Found: /index
ERROR - 2022-03-31 14:52:19 --> 404 Page Not Found: /index
ERROR - 2022-03-31 14:52:51 --> 404 Page Not Found: /index
ERROR - 2022-03-31 14:54:25 --> 404 Page Not Found: /index
ERROR - 2022-03-31 14:54:47 --> 404 Page Not Found: /index
ERROR - 2022-03-31 14:56:47 --> 404 Page Not Found: /index
ERROR - 2022-03-31 14:58:28 --> 404 Page Not Found: /index
ERROR - 2022-03-31 14:58:30 --> 404 Page Not Found: /index
ERROR - 2022-03-31 14:58:45 --> 404 Page Not Found: /index
ERROR - 2022-03-31 14:58:51 --> 404 Page Not Found: /index
ERROR - 2022-03-31 15:01:25 --> 404 Page Not Found: /index
ERROR - 2022-03-31 15:03:41 --> 404 Page Not Found: /index
ERROR - 2022-03-31 15:03:46 --> 404 Page Not Found: /index
ERROR - 2022-03-31 15:03:51 --> 404 Page Not Found: /index
ERROR - 2022-03-31 15:06:22 --> 404 Page Not Found: /index
ERROR - 2022-03-31 15:06:32 --> 404 Page Not Found: /index
ERROR - 2022-03-31 15:07:48 --> 404 Page Not Found: /index
ERROR - 2022-03-31 15:10:07 --> 404 Page Not Found: /index
ERROR - 2022-03-31 15:10:21 --> 404 Page Not Found: /index
ERROR - 2022-03-31 15:12:21 --> 404 Page Not Found: /index
ERROR - 2022-03-31 15:12:55 --> 404 Page Not Found: /index
ERROR - 2022-03-31 15:13:08 --> 404 Page Not Found: /index
ERROR - 2022-03-31 15:15:03 --> 404 Page Not Found: /index
ERROR - 2022-03-31 15:15:33 --> 404 Page Not Found: /index
ERROR - 2022-03-31 15:15:43 --> 404 Page Not Found: /index
ERROR - 2022-03-31 15:17:40 --> 404 Page Not Found: /index
ERROR - 2022-03-31 15:18:01 --> 404 Page Not Found: /index
ERROR - 2022-03-31 15:18:52 --> Severity: error --> Exception: Invalid address:  (to):  /home4/cowcdrmy/public_html/application/third_party/phpmailer/src/PHPMailer.php 1092
ERROR - 2022-03-31 15:20:05 --> 404 Page Not Found: /index
ERROR - 2022-03-31 15:21:52 --> 404 Page Not Found: /index
ERROR - 2022-03-31 15:23:36 --> 404 Page Not Found: /index
ERROR - 2022-03-31 15:23:53 --> 404 Page Not Found: /index
ERROR - 2022-03-31 15:25:00 --> 404 Page Not Found: /index
ERROR - 2022-03-31 15:25:05 --> 404 Page Not Found: /index
ERROR - 2022-03-31 15:25:20 --> 404 Page Not Found: /index
ERROR - 2022-03-31 15:26:12 --> Severity: error --> Exception: Invalid address:  (to):  /home4/cowcdrmy/public_html/application/third_party/phpmailer/src/PHPMailer.php 1092
ERROR - 2022-03-31 15:27:40 --> 404 Page Not Found: /index
ERROR - 2022-03-31 15:29:07 --> 404 Page Not Found: /index
ERROR - 2022-03-31 15:29:53 --> 404 Page Not Found: /index
ERROR - 2022-03-31 15:30:15 --> 404 Page Not Found: /index
ERROR - 2022-03-31 15:31:26 --> 404 Page Not Found: /index
ERROR - 2022-03-31 15:31:41 --> Severity: error --> Exception: Invalid address:  (to):  /home4/cowcdrmy/public_html/application/third_party/phpmailer/src/PHPMailer.php 1092
ERROR - 2022-03-31 15:32:42 --> Severity: error --> Exception: Invalid address:  (to):  /home4/cowcdrmy/public_html/application/third_party/phpmailer/src/PHPMailer.php 1092
ERROR - 2022-03-31 15:32:53 --> 404 Page Not Found: /index
ERROR - 2022-03-31 15:32:54 --> 404 Page Not Found: /index
ERROR - 2022-03-31 15:33:10 --> 404 Page Not Found: /index
ERROR - 2022-03-31 15:33:29 --> 404 Page Not Found: /index
ERROR - 2022-03-31 15:33:38 --> 404 Page Not Found: /index
ERROR - 2022-03-31 15:33:38 --> 404 Page Not Found: /index
ERROR - 2022-03-31 15:33:55 --> Severity: error --> Exception: Invalid address:  (to):  /home4/cowcdrmy/public_html/application/third_party/phpmailer/src/PHPMailer.php 1092
ERROR - 2022-03-31 15:34:43 --> 404 Page Not Found: /index
ERROR - 2022-03-31 15:34:52 --> 404 Page Not Found: /index
ERROR - 2022-03-31 15:36:28 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-31 15:37:12 --> Query error: Illegal mix of collations (latin1_swedish_ci,IMPLICIT) and (utf8_general_ci,COERCIBLE) for operation '=' - Invalid query: SELECT `id`
FROM `tbl_primary_info`
WHERE `profile_id` = 'K̤V̤964019'
ERROR - 2022-03-31 15:37:48 --> Query error: Illegal mix of collations (latin1_swedish_ci,IMPLICIT) and (utf8_general_ci,COERCIBLE) for operation '=' - Invalid query: SELECT `id`
FROM `tbl_primary_info`
WHERE `profile_id` = 'K̤V̤964019'
ERROR - 2022-03-31 15:38:32 --> Query error: Illegal mix of collations (latin1_swedish_ci,IMPLICIT) and (utf8_general_ci,COERCIBLE) for operation 'like' - Invalid query: SELECT `p`.`first_name`, `p`.`last_name`, `p`.`gender`, `p`.`id`, `p`.`status`, `p`.`age`, `p`.`living_in`, `p`.`profile_id`, `p`.`date`, `p`.`month`, `p`.`year`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `r`.`time_of_birth`, `r`.`place_of_birth`, `r`.`gothram`, `r`.`star`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `e`.`country`, `pa`.`fathers_father_district`, `pa`.`mothers_father_district`, `pa`.`father_mobile`, `pa`.`mother_mobile`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `payment_status`, `elite`, `profileowner`, `pr`.`property_value`, `pr`.`property_type`, `pr`.`property_Desc`
FROM `tbl_primary_info` as `p`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `tbl_parents_info` as `pa` ON `p`.`id`=`pa`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`MS_id`
LEFT JOIN `ms_profilesetting` as `mprosetting` ON `p`.`id`=`mprosetting`.`MS_id`
LEFT JOIN `ms_property_info` as `pr` ON `p`.`id`=`pr`.`ms_id`
WHERE `p`.`profile_id` LIKE '%K̤V̤964019%' ESCAPE '!'
AND `u`.`ismain` = 1 AND `u`.`isactive` = 1
AND `p`.`status` = 1
GROUP BY `p`.`id`
ORDER BY `p`.`registered_on` DESC
ERROR - 2022-03-31 15:39:27 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-31 15:39:31 --> 404 Page Not Found: /index
ERROR - 2022-03-31 15:39:31 --> 404 Page Not Found: /index
ERROR - 2022-03-31 15:39:32 --> 404 Page Not Found: /index
ERROR - 2022-03-31 15:39:52 --> 404 Page Not Found: /index
ERROR - 2022-03-31 15:40:09 --> 404 Page Not Found: /index
ERROR - 2022-03-31 15:40:25 --> 404 Page Not Found: /index
ERROR - 2022-03-31 15:40:40 --> 404 Page Not Found: /index
ERROR - 2022-03-31 15:40:49 --> 404 Page Not Found: /index
ERROR - 2022-03-31 15:41:16 --> Severity: error --> Exception: Invalid address:  (to):  /home4/cowcdrmy/public_html/application/third_party/phpmailer/src/PHPMailer.php 1092
ERROR - 2022-03-31 15:43:28 --> 404 Page Not Found: /index
ERROR - 2022-03-31 15:43:56 --> 404 Page Not Found: /index
ERROR - 2022-03-31 15:44:27 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AND `to_msID` =)' at line 3 - Invalid query: SELECT *
FROM `ms_servicelist`
WHERE (`from_msID` = AND `to_msID` =)
ERROR - 2022-03-31 15:44:27 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'AND `to_msID` =)' at line 3 - Invalid query: SELECT *
FROM `ms_servicelist`
WHERE (`from_msID` = AND `to_msID` =)
ERROR - 2022-03-31 15:44:39 --> 404 Page Not Found: /index
ERROR - 2022-03-31 15:44:39 --> 404 Page Not Found: /index
ERROR - 2022-03-31 15:44:39 --> 404 Page Not Found: /index
ERROR - 2022-03-31 15:47:45 --> 404 Page Not Found: /index
ERROR - 2022-03-31 15:48:42 --> 404 Page Not Found: /index
ERROR - 2022-03-31 15:49:05 --> 404 Page Not Found: /index
ERROR - 2022-03-31 15:49:29 --> 404 Page Not Found: /index
ERROR - 2022-03-31 15:51:33 --> 404 Page Not Found: /index
ERROR - 2022-03-31 15:51:44 --> 404 Page Not Found: /index
ERROR - 2022-03-31 15:53:08 --> 404 Page Not Found: /index
ERROR - 2022-03-31 15:53:12 --> 404 Page Not Found: /index
ERROR - 2022-03-31 15:54:42 --> 404 Page Not Found: /index
ERROR - 2022-03-31 15:54:59 --> 404 Page Not Found: /index
ERROR - 2022-03-31 15:55:01 --> 404 Page Not Found: /index
ERROR - 2022-03-31 15:55:06 --> 404 Page Not Found: /index
ERROR - 2022-03-31 15:55:38 --> 404 Page Not Found: /index
ERROR - 2022-03-31 15:55:39 --> 404 Page Not Found: /index
ERROR - 2022-03-31 15:56:32 --> Severity: error --> Exception: Invalid address:  (to):  /home4/cowcdrmy/public_html/application/third_party/phpmailer/src/PHPMailer.php 1092
ERROR - 2022-03-31 15:56:56 --> 404 Page Not Found: /index
ERROR - 2022-03-31 15:57:12 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-31 16:01:49 --> 404 Page Not Found: /index
ERROR - 2022-03-31 16:02:05 --> 404 Page Not Found: /index
ERROR - 2022-03-31 16:02:33 --> To Id is not available for User - 1710
ERROR - 2022-03-31 16:02:45 --> To Id is not available for User - 1710
ERROR - 2022-03-31 16:02:49 --> 404 Page Not Found: /index
ERROR - 2022-03-31 16:02:58 --> 404 Page Not Found: /index
ERROR - 2022-03-31 16:03:11 --> 404 Page Not Found: /index
ERROR - 2022-03-31 16:03:52 --> 404 Page Not Found: /index
ERROR - 2022-03-31 16:03:52 --> 404 Page Not Found: /index
ERROR - 2022-03-31 16:04:56 --> 404 Page Not Found: /index
ERROR - 2022-03-31 16:05:21 --> 404 Page Not Found: /index
ERROR - 2022-03-31 16:06:12 --> 404 Page Not Found: /index
ERROR - 2022-03-31 16:08:31 --> 404 Page Not Found: /index
ERROR - 2022-03-31 16:08:31 --> 404 Page Not Found: /index
ERROR - 2022-03-31 16:08:31 --> 404 Page Not Found: /index
ERROR - 2022-03-31 16:08:41 --> 404 Page Not Found: /index
ERROR - 2022-03-31 16:08:42 --> 404 Page Not Found: /index
ERROR - 2022-03-31 16:09:11 --> 404 Page Not Found: /index
ERROR - 2022-03-31 16:10:10 --> 404 Page Not Found: /index
ERROR - 2022-03-31 16:10:33 --> 404 Page Not Found: /index
ERROR - 2022-03-31 16:10:43 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-31 16:12:20 --> 404 Page Not Found: /index
ERROR - 2022-03-31 16:16:10 --> 404 Page Not Found: /index
ERROR - 2022-03-31 16:17:29 --> 404 Page Not Found: /index
ERROR - 2022-03-31 16:19:19 --> 404 Page Not Found: /index
ERROR - 2022-03-31 16:19:40 --> 404 Page Not Found: /index
ERROR - 2022-03-31 16:20:08 --> 404 Page Not Found: /index
ERROR - 2022-03-31 16:20:13 --> 404 Page Not Found: /index
ERROR - 2022-03-31 16:20:50 --> 404 Page Not Found: /index
ERROR - 2022-03-31 16:21:17 --> 404 Page Not Found: /index
ERROR - 2022-03-31 16:21:31 --> 404 Page Not Found: /index
ERROR - 2022-03-31 16:22:18 --> 404 Page Not Found: /index
ERROR - 2022-03-31 16:23:23 --> 404 Page Not Found: /index
ERROR - 2022-03-31 16:23:43 --> 404 Page Not Found: /index
ERROR - 2022-03-31 16:23:55 --> 404 Page Not Found: /index
ERROR - 2022-03-31 16:24:09 --> To Id is not available for User - 4455
ERROR - 2022-03-31 16:25:45 --> To Id is not available for User - 4455
ERROR - 2022-03-31 16:25:54 --> 404 Page Not Found: /index
ERROR - 2022-03-31 16:26:03 --> To Id is not available for User - 4455
ERROR - 2022-03-31 16:26:21 --> 404 Page Not Found: /index
ERROR - 2022-03-31 16:26:53 --> 404 Page Not Found: /index
ERROR - 2022-03-31 16:27:26 --> 404 Page Not Found: /index
ERROR - 2022-03-31 16:27:26 --> 404 Page Not Found: /index
ERROR - 2022-03-31 16:29:05 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-31 16:30:12 --> 404 Page Not Found: /index
ERROR - 2022-03-31 16:30:15 --> 404 Page Not Found: /index
ERROR - 2022-03-31 16:30:57 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT `p`.*, `r`.`caste`, `r`.`height`, `r`.`star`, `r`.`time_of_birth`, `r`.`raasi`, `prp`.`property_value`, `e`.`occupation`, `e`.`education_degree`, `e`.`visatype`, `e`.`city`, `e`.`country`, `e`.`annual_income`, `pfs`.`payment_status`, `pfs`.`profilesetting_id` as `pfs_id`, `pfs`.`last_call_updated`, `adm`.`username` as `profile_owner`
FROM `tbl_primary_info` as `p`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `ms_property_info` as `prp` ON `p`.`id`=`prp`.`ms_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `ms_profilesetting` as `pfs` ON `p`.`id`=`pfs`.`ms_id`
LEFT JOIN `tbl_admin_data` as `adm` ON `pfs`.`profileowner`=`adm`.`id`
WHERE `p`.`gender` = 'female'
AND `p`.`status` = '1'
AND `r`.`caste` = `Array`
AND `adm`.`id` = '3'
GROUP BY `p`.`id`
ERROR - 2022-03-31 16:30:59 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT `p`.*, `r`.`caste`, `r`.`height`, `r`.`star`, `r`.`time_of_birth`, `r`.`raasi`, `prp`.`property_value`, `e`.`occupation`, `e`.`education_degree`, `e`.`visatype`, `e`.`city`, `e`.`country`, `e`.`annual_income`, `pfs`.`payment_status`, `pfs`.`profilesetting_id` as `pfs_id`, `pfs`.`last_call_updated`, `adm`.`username` as `profile_owner`
FROM `tbl_primary_info` as `p`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `ms_property_info` as `prp` ON `p`.`id`=`prp`.`ms_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `ms_profilesetting` as `pfs` ON `p`.`id`=`pfs`.`ms_id`
LEFT JOIN `tbl_admin_data` as `adm` ON `pfs`.`profileowner`=`adm`.`id`
WHERE `p`.`gender` = 'female'
AND `p`.`status` = '1'
AND `r`.`caste` = `Array`
AND `adm`.`id` = '3'
GROUP BY `p`.`id`
ERROR - 2022-03-31 16:31:01 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT `p`.*, `r`.`caste`, `r`.`height`, `r`.`star`, `r`.`time_of_birth`, `r`.`raasi`, `prp`.`property_value`, `e`.`occupation`, `e`.`education_degree`, `e`.`visatype`, `e`.`city`, `e`.`country`, `e`.`annual_income`, `pfs`.`payment_status`, `pfs`.`profilesetting_id` as `pfs_id`, `pfs`.`last_call_updated`, `adm`.`username` as `profile_owner`
FROM `tbl_primary_info` as `p`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `ms_property_info` as `prp` ON `p`.`id`=`prp`.`ms_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `ms_profilesetting` as `pfs` ON `p`.`id`=`pfs`.`ms_id`
LEFT JOIN `tbl_admin_data` as `adm` ON `pfs`.`profileowner`=`adm`.`id`
WHERE `p`.`gender` = 'female'
AND `p`.`status` = '1'
AND `r`.`caste` = `Array`
AND `adm`.`id` = '3'
GROUP BY `p`.`id`
ERROR - 2022-03-31 16:31:07 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT `p`.*, `r`.`caste`, `r`.`height`, `r`.`star`, `r`.`time_of_birth`, `r`.`raasi`, `prp`.`property_value`, `e`.`occupation`, `e`.`education_degree`, `e`.`visatype`, `e`.`city`, `e`.`country`, `e`.`annual_income`, `pfs`.`payment_status`, `pfs`.`profilesetting_id` as `pfs_id`, `pfs`.`last_call_updated`, `adm`.`username` as `profile_owner`
FROM `tbl_primary_info` as `p`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `ms_property_info` as `prp` ON `p`.`id`=`prp`.`ms_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `ms_profilesetting` as `pfs` ON `p`.`id`=`pfs`.`ms_id`
LEFT JOIN `tbl_admin_data` as `adm` ON `pfs`.`profileowner`=`adm`.`id`
WHERE `p`.`gender` = 'female'
AND `p`.`status` = '1'
AND `r`.`caste` = `Array`
AND `adm`.`id` = '3'
GROUP BY `p`.`id`
ERROR - 2022-03-31 16:31:22 --> 404 Page Not Found: /index
ERROR - 2022-03-31 16:31:32 --> 404 Page Not Found: /index
ERROR - 2022-03-31 16:32:56 --> 404 Page Not Found: /index
ERROR - 2022-03-31 16:33:30 --> 404 Page Not Found: /index
ERROR - 2022-03-31 16:34:20 --> 404 Page Not Found: /index
ERROR - 2022-03-31 16:34:28 --> 404 Page Not Found: /index
ERROR - 2022-03-31 16:36:56 --> 404 Page Not Found: /index
ERROR - 2022-03-31 16:38:01 --> 404 Page Not Found: /index
ERROR - 2022-03-31 16:38:33 --> 404 Page Not Found: /index
ERROR - 2022-03-31 16:39:11 --> 404 Page Not Found: /index
ERROR - 2022-03-31 16:39:15 --> 404 Page Not Found: /index
ERROR - 2022-03-31 16:41:03 --> 404 Page Not Found: /index
ERROR - 2022-03-31 16:42:21 --> 404 Page Not Found: /index
ERROR - 2022-03-31 16:42:25 --> To Id is not available for User - 3740
ERROR - 2022-03-31 16:42:25 --> 404 Page Not Found: /index
ERROR - 2022-03-31 16:43:52 --> 404 Page Not Found: /index
ERROR - 2022-03-31 16:44:05 --> 404 Page Not Found: /index
ERROR - 2022-03-31 16:44:05 --> 404 Page Not Found: /index
ERROR - 2022-03-31 16:45:33 --> 404 Page Not Found: /index
ERROR - 2022-03-31 16:45:34 --> 404 Page Not Found: /index
ERROR - 2022-03-31 16:48:06 --> 404 Page Not Found: /index
ERROR - 2022-03-31 16:49:19 --> 404 Page Not Found: /index
ERROR - 2022-03-31 16:49:19 --> 404 Page Not Found: /index
ERROR - 2022-03-31 16:49:58 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-31 16:50:26 --> 404 Page Not Found: /index
ERROR - 2022-03-31 16:52:19 --> 404 Page Not Found: /index
ERROR - 2022-03-31 16:52:32 --> 404 Page Not Found: /index
ERROR - 2022-03-31 16:52:50 --> 404 Page Not Found: /index
ERROR - 2022-03-31 16:53:09 --> 404 Page Not Found: /index
ERROR - 2022-03-31 16:53:18 --> 404 Page Not Found: /index
ERROR - 2022-03-31 16:53:22 --> 404 Page Not Found: /index
ERROR - 2022-03-31 16:53:24 --> 404 Page Not Found: /index
ERROR - 2022-03-31 16:54:43 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-31 16:54:49 --> 404 Page Not Found: /index
ERROR - 2022-03-31 16:54:51 --> 404 Page Not Found: /index
ERROR - 2022-03-31 16:56:19 --> 404 Page Not Found: /index
ERROR - 2022-03-31 16:59:10 --> 404 Page Not Found: /index
ERROR - 2022-03-31 16:59:59 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-31 17:02:39 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-31 17:03:34 --> 404 Page Not Found: /index
ERROR - 2022-03-31 17:04:24 --> 404 Page Not Found: /index
ERROR - 2022-03-31 17:06:00 --> 404 Page Not Found: /index
ERROR - 2022-03-31 17:06:00 --> 404 Page Not Found: /index
ERROR - 2022-03-31 17:08:16 --> 404 Page Not Found: /index
ERROR - 2022-03-31 17:09:04 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-31 17:09:04')
ERROR - 2022-03-31 17:10:13 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-31 17:10:13')
ERROR - 2022-03-31 17:10:15 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-31 17:10:15')
ERROR - 2022-03-31 17:10:36 --> 404 Page Not Found: /index
ERROR - 2022-03-31 17:12:02 --> 404 Page Not Found: /index
ERROR - 2022-03-31 17:12:48 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-31 17:13:07 --> 404 Page Not Found: /index
ERROR - 2022-03-31 17:13:33 --> 404 Page Not Found: /index
ERROR - 2022-03-31 17:15:11 --> 404 Page Not Found: /index
ERROR - 2022-03-31 17:15:23 --> 404 Page Not Found: /index
ERROR - 2022-03-31 17:15:44 --> 404 Page Not Found: /index
ERROR - 2022-03-31 17:17:40 --> 404 Page Not Found: /index
ERROR - 2022-03-31 17:18:21 --> 404 Page Not Found: /index
ERROR - 2022-03-31 17:18:52 --> 404 Page Not Found: /index
ERROR - 2022-03-31 17:19:20 --> 404 Page Not Found: /index
ERROR - 2022-03-31 17:20:30 --> 404 Page Not Found: /index
ERROR - 2022-03-31 17:20:31 --> 404 Page Not Found: /index
ERROR - 2022-03-31 17:20:35 --> 404 Page Not Found: /index
ERROR - 2022-03-31 17:21:11 --> 404 Page Not Found: /index
ERROR - 2022-03-31 17:21:14 --> 404 Page Not Found: /index
ERROR - 2022-03-31 17:21:57 --> 404 Page Not Found: /index
ERROR - 2022-03-31 17:22:44 --> 404 Page Not Found: /index
ERROR - 2022-03-31 17:23:03 --> 404 Page Not Found: /index
ERROR - 2022-03-31 17:24:05 --> 404 Page Not Found: /index
ERROR - 2022-03-31 17:24:15 --> 404 Page Not Found: /index
ERROR - 2022-03-31 17:24:25 --> 404 Page Not Found: /index
ERROR - 2022-03-31 17:24:38 --> 404 Page Not Found: /index
ERROR - 2022-03-31 17:26:27 --> 404 Page Not Found: /index
ERROR - 2022-03-31 17:26:29 --> 404 Page Not Found: /index
ERROR - 2022-03-31 17:26:32 --> 404 Page Not Found: /index
ERROR - 2022-03-31 17:26:37 --> 404 Page Not Found: /index
ERROR - 2022-03-31 17:26:38 --> 404 Page Not Found: /index
ERROR - 2022-03-31 17:27:06 --> 404 Page Not Found: /index
ERROR - 2022-03-31 17:27:37 --> 404 Page Not Found: /index
ERROR - 2022-03-31 17:27:39 --> 404 Page Not Found: /index
ERROR - 2022-03-31 17:28:58 --> 404 Page Not Found: /index
ERROR - 2022-03-31 17:29:14 --> 404 Page Not Found: /index
ERROR - 2022-03-31 17:29:27 --> 404 Page Not Found: /index
ERROR - 2022-03-31 17:29:46 --> Severity: error --> Exception: Invalid address:  (to):  /home4/cowcdrmy/public_html/application/third_party/phpmailer/src/PHPMailer.php 1092
ERROR - 2022-03-31 17:30:09 --> Severity: error --> Exception: Invalid address:  (to):  /home4/cowcdrmy/public_html/application/third_party/phpmailer/src/PHPMailer.php 1092
ERROR - 2022-03-31 17:30:25 --> 404 Page Not Found: /index
ERROR - 2022-03-31 17:31:41 --> 404 Page Not Found: /index
ERROR - 2022-03-31 17:32:11 --> 404 Page Not Found: /index
ERROR - 2022-03-31 17:34:13 --> 404 Page Not Found: /index
ERROR - 2022-03-31 17:37:07 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-31 17:37:58 --> 404 Page Not Found: /index
ERROR - 2022-03-31 17:38:06 --> 404 Page Not Found: /index
ERROR - 2022-03-31 17:38:25 --> 404 Page Not Found: /index
ERROR - 2022-03-31 17:38:25 --> 404 Page Not Found: /index
ERROR - 2022-03-31 17:38:37 --> 404 Page Not Found: /index
ERROR - 2022-03-31 17:39:50 --> 404 Page Not Found: /index
ERROR - 2022-03-31 17:40:29 --> 404 Page Not Found: /index
ERROR - 2022-03-31 17:40:29 --> 404 Page Not Found: /index
ERROR - 2022-03-31 17:41:22 --> 404 Page Not Found: /index
ERROR - 2022-03-31 17:42:05 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-31 17:42:07 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-31 17:42:12 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-31 17:42:26 --> To Id is not available for User - 3046
ERROR - 2022-03-31 17:42:32 --> 404 Page Not Found: /index
ERROR - 2022-03-31 17:42:53 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-31 17:44:13 --> 404 Page Not Found: /index
ERROR - 2022-03-31 17:44:30 --> 404 Page Not Found: /index
ERROR - 2022-03-31 17:44:47 --> 404 Page Not Found: /index
ERROR - 2022-03-31 17:44:53 --> 404 Page Not Found: /index
ERROR - 2022-03-31 17:44:57 --> 404 Page Not Found: /index
ERROR - 2022-03-31 17:45:45 --> 404 Page Not Found: /index
ERROR - 2022-03-31 17:45:57 --> 404 Page Not Found: /index
ERROR - 2022-03-31 17:45:59 --> 404 Page Not Found: /index
ERROR - 2022-03-31 17:48:25 --> 404 Page Not Found: /index
ERROR - 2022-03-31 17:50:12 --> 404 Page Not Found: /index
ERROR - 2022-03-31 17:54:29 --> 404 Page Not Found: /index
ERROR - 2022-03-31 17:54:46 --> 404 Page Not Found: /index
ERROR - 2022-03-31 17:56:37 --> 404 Page Not Found: /index
ERROR - 2022-03-31 17:59:16 --> 404 Page Not Found: /index
ERROR - 2022-03-31 17:59:31 --> 404 Page Not Found: /index
ERROR - 2022-03-31 18:02:25 --> 404 Page Not Found: /index
ERROR - 2022-03-31 18:02:58 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-31 18:03:07 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-31 18:03:59 --> 404 Page Not Found: /index
ERROR - 2022-03-31 18:04:27 --> 404 Page Not Found: /index
ERROR - 2022-03-31 18:04:48 --> 404 Page Not Found: /index
ERROR - 2022-03-31 18:06:10 --> 404 Page Not Found: /index
ERROR - 2022-03-31 18:07:10 --> 404 Page Not Found: /index
ERROR - 2022-03-31 18:07:11 --> 404 Page Not Found: /index
ERROR - 2022-03-31 18:07:11 --> 404 Page Not Found: /index
ERROR - 2022-03-31 18:08:32 --> 404 Page Not Found: /index
ERROR - 2022-03-31 18:09:14 --> 404 Page Not Found: /index
ERROR - 2022-03-31 18:10:05 --> 404 Page Not Found: /index
ERROR - 2022-03-31 18:10:15 --> 404 Page Not Found: /index
ERROR - 2022-03-31 18:11:20 --> 404 Page Not Found: /index
ERROR - 2022-03-31 18:11:44 --> 404 Page Not Found: /index
ERROR - 2022-03-31 18:13:42 --> 404 Page Not Found: /index
ERROR - 2022-03-31 18:15:22 --> 404 Page Not Found: /index
ERROR - 2022-03-31 18:16:06 --> 404 Page Not Found: /index
ERROR - 2022-03-31 18:16:34 --> 404 Page Not Found: /index
ERROR - 2022-03-31 18:17:41 --> 404 Page Not Found: /index
ERROR - 2022-03-31 18:20:09 --> 404 Page Not Found: /index
ERROR - 2022-03-31 18:20:19 --> 404 Page Not Found: /index
ERROR - 2022-03-31 18:22:37 --> 404 Page Not Found: /index
ERROR - 2022-03-31 18:23:04 --> 404 Page Not Found: /index
ERROR - 2022-03-31 18:24:39 --> 404 Page Not Found: /index
ERROR - 2022-03-31 18:25:10 --> 404 Page Not Found: /index
ERROR - 2022-03-31 18:28:02 --> 404 Page Not Found: /index
ERROR - 2022-03-31 18:29:22 --> 404 Page Not Found: /index
ERROR - 2022-03-31 18:30:22 --> 404 Page Not Found: /index
ERROR - 2022-03-31 18:31:08 --> 404 Page Not Found: /index
ERROR - 2022-03-31 18:31:11 --> 404 Page Not Found: /index
ERROR - 2022-03-31 18:31:11 --> 404 Page Not Found: /index
ERROR - 2022-03-31 18:31:12 --> 404 Page Not Found: /index
ERROR - 2022-03-31 18:31:12 --> 404 Page Not Found: /index
ERROR - 2022-03-31 18:31:12 --> 404 Page Not Found: /index
ERROR - 2022-03-31 18:31:12 --> 404 Page Not Found: /index
ERROR - 2022-03-31 18:31:13 --> 404 Page Not Found: /index
ERROR - 2022-03-31 18:31:13 --> 404 Page Not Found: /index
ERROR - 2022-03-31 18:31:13 --> 404 Page Not Found: /index
ERROR - 2022-03-31 18:31:13 --> 404 Page Not Found: /index
ERROR - 2022-03-31 18:33:33 --> 404 Page Not Found: /index
ERROR - 2022-03-31 18:34:06 --> 404 Page Not Found: /index
ERROR - 2022-03-31 18:35:26 --> 404 Page Not Found: /index
ERROR - 2022-03-31 18:36:18 --> 404 Page Not Found: /index
ERROR - 2022-03-31 18:36:38 --> 404 Page Not Found: /index
ERROR - 2022-03-31 18:37:25 --> 404 Page Not Found: /index
ERROR - 2022-03-31 18:40:15 --> 404 Page Not Found: /index
ERROR - 2022-03-31 18:42:13 --> 404 Page Not Found: /index
ERROR - 2022-03-31 18:42:45 --> 404 Page Not Found: /index
ERROR - 2022-03-31 18:42:52 --> 404 Page Not Found: /index
ERROR - 2022-03-31 18:45:14 --> 404 Page Not Found: /index
ERROR - 2022-03-31 18:48:58 --> 404 Page Not Found: /index
ERROR - 2022-03-31 18:49:05 --> 404 Page Not Found: /index
ERROR - 2022-03-31 18:50:13 --> 404 Page Not Found: /index
ERROR - 2022-03-31 18:50:45 --> 404 Page Not Found: /index
ERROR - 2022-03-31 18:51:37 --> 404 Page Not Found: /index
ERROR - 2022-03-31 18:52:04 --> 404 Page Not Found: /index
ERROR - 2022-03-31 18:54:05 --> 404 Page Not Found: /index
ERROR - 2022-03-31 18:54:08 --> 404 Page Not Found: /index
ERROR - 2022-03-31 18:54:37 --> 404 Page Not Found: /index
ERROR - 2022-03-31 18:55:07 --> 404 Page Not Found: /index
ERROR - 2022-03-31 18:55:52 --> 404 Page Not Found: /index
ERROR - 2022-03-31 18:56:00 --> 404 Page Not Found: /index
ERROR - 2022-03-31 18:56:32 --> 404 Page Not Found: /index
ERROR - 2022-03-31 18:56:36 --> 404 Page Not Found: /index
ERROR - 2022-03-31 18:56:51 --> 404 Page Not Found: /index
ERROR - 2022-03-31 18:57:33 --> 404 Page Not Found: /index
ERROR - 2022-03-31 18:57:36 --> 404 Page Not Found: /index
ERROR - 2022-03-31 18:58:21 --> 404 Page Not Found: /index
ERROR - 2022-03-31 18:58:46 --> 404 Page Not Found: /index
ERROR - 2022-03-31 19:00:02 --> To Id is not available for User - 1710
ERROR - 2022-03-31 19:00:57 --> 404 Page Not Found: /index
ERROR - 2022-03-31 19:02:44 --> 404 Page Not Found: /index
ERROR - 2022-03-31 19:02:49 --> 404 Page Not Found: /index
ERROR - 2022-03-31 19:03:33 --> 404 Page Not Found: /index
ERROR - 2022-03-31 19:03:45 --> 404 Page Not Found: /index
ERROR - 2022-03-31 19:04:27 --> 404 Page Not Found: /index
ERROR - 2022-03-31 19:04:56 --> 404 Page Not Found: /index
ERROR - 2022-03-31 19:05:05 --> 404 Page Not Found: /index
ERROR - 2022-03-31 19:06:12 --> 404 Page Not Found: /index
ERROR - 2022-03-31 19:07:38 --> 404 Page Not Found: /index
ERROR - 2022-03-31 19:08:28 --> 404 Page Not Found: /index
ERROR - 2022-03-31 19:08:29 --> 404 Page Not Found: /index
ERROR - 2022-03-31 19:10:42 --> 404 Page Not Found: /index
ERROR - 2022-03-31 19:10:43 --> 404 Page Not Found: /index
ERROR - 2022-03-31 19:11:17 --> 404 Page Not Found: /index
ERROR - 2022-03-31 19:13:27 --> 404 Page Not Found: /index
ERROR - 2022-03-31 19:13:35 --> 404 Page Not Found: /index
ERROR - 2022-03-31 19:16:12 --> 404 Page Not Found: /index
ERROR - 2022-03-31 19:16:51 --> 404 Page Not Found: /index
ERROR - 2022-03-31 19:17:21 --> 404 Page Not Found: /index
ERROR - 2022-03-31 19:18:17 --> 404 Page Not Found: /index
ERROR - 2022-03-31 19:18:41 --> 404 Page Not Found: /index
ERROR - 2022-03-31 19:19:46 --> 404 Page Not Found: /index
ERROR - 2022-03-31 19:21:12 --> 404 Page Not Found: /index
ERROR - 2022-03-31 19:23:38 --> 404 Page Not Found: /index
ERROR - 2022-03-31 19:25:42 --> 404 Page Not Found: /index
ERROR - 2022-03-31 19:25:50 --> 404 Page Not Found: /index
ERROR - 2022-03-31 19:27:34 --> 404 Page Not Found: /index
ERROR - 2022-03-31 19:27:59 --> 404 Page Not Found: /index
ERROR - 2022-03-31 19:28:34 --> 404 Page Not Found: /index
ERROR - 2022-03-31 19:30:08 --> 404 Page Not Found: /index
ERROR - 2022-03-31 19:31:38 --> 404 Page Not Found: /index
ERROR - 2022-03-31 19:35:01 --> 404 Page Not Found: /index
ERROR - 2022-03-31 19:35:02 --> 404 Page Not Found: /index
ERROR - 2022-03-31 19:38:40 --> 404 Page Not Found: /index
ERROR - 2022-03-31 19:39:02 --> 404 Page Not Found: /index
ERROR - 2022-03-31 19:39:31 --> 404 Page Not Found: /index
ERROR - 2022-03-31 19:40:24 --> 404 Page Not Found: /index
ERROR - 2022-03-31 19:40:48 --> Query error: Table 'cowcdrmy_kammamarriage.ms_shortlist_viewedd_ignored' doesn't exist - Invalid query: SELECT `v`.*, `p`.`gender`, `p`.`id`, `p`.`status`, `p`.`age`, `p`.`living_in`, `p`.`profile_id`, `p`.`first_name`, `last_name`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `s`.*
FROM `kv_profileview` as `v`
LEFT JOIN `tbl_primary_info` as `p` ON `v`.`kv_profileview_on` = `p`.`id`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`ms_id`
INNER JOIN `ms_profilesetting` as `s` ON `p`.`id`=`s`.`ms_id`
WHERE `s`.`elite` = 'no'
AND `p`.`status` = 1
AND `v`.`kv_userfkid` = '3581'
AND `u`.`ismain` = 1
AND  `p`.`id` not in(select kv_msi_interested_on from kv_mysideinterests where kv_msi_profilefkid="3581")
AND  p.id not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid = "3581" AND `shortlist_status` = 1)
AND  `p`.`id` not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid="3581"AND ignore_status=1)
ORDER BY `v`.`kv_profileview_created_date` DESC
 LIMIT 10
ERROR - 2022-03-31 19:40:59 --> 404 Page Not Found: /index
ERROR - 2022-03-31 19:41:33 --> 404 Page Not Found: /index
ERROR - 2022-03-31 19:42:21 --> 404 Page Not Found: /index
ERROR - 2022-03-31 19:42:44 --> 404 Page Not Found: /index
ERROR - 2022-03-31 19:43:13 --> 404 Page Not Found: /index
ERROR - 2022-03-31 19:43:14 --> 404 Page Not Found: /index
ERROR - 2022-03-31 19:43:14 --> 404 Page Not Found: /index
ERROR - 2022-03-31 19:43:15 --> 404 Page Not Found: /index
ERROR - 2022-03-31 19:43:15 --> 404 Page Not Found: /index
ERROR - 2022-03-31 19:43:15 --> 404 Page Not Found: /index
ERROR - 2022-03-31 19:43:16 --> 404 Page Not Found: /index
ERROR - 2022-03-31 19:43:16 --> 404 Page Not Found: /index
ERROR - 2022-03-31 19:43:17 --> 404 Page Not Found: /index
ERROR - 2022-03-31 19:43:17 --> 404 Page Not Found: /index
ERROR - 2022-03-31 19:45:04 --> 404 Page Not Found: /index
ERROR - 2022-03-31 19:45:34 --> 404 Page Not Found: /index
ERROR - 2022-03-31 19:45:44 --> 404 Page Not Found: /index
ERROR - 2022-03-31 19:46:21 --> 404 Page Not Found: /index
ERROR - 2022-03-31 19:47:36 --> 404 Page Not Found: /index
ERROR - 2022-03-31 19:48:04 --> 404 Page Not Found: /index
ERROR - 2022-03-31 19:48:07 --> 404 Page Not Found: /index
ERROR - 2022-03-31 19:50:12 --> 404 Page Not Found: /index
ERROR - 2022-03-31 19:54:54 --> 404 Page Not Found: /index
ERROR - 2022-03-31 20:02:57 --> 404 Page Not Found: /index
ERROR - 2022-03-31 20:03:00 --> 404 Page Not Found: /index
ERROR - 2022-03-31 20:03:00 --> 404 Page Not Found: /index
ERROR - 2022-03-31 20:03:00 --> 404 Page Not Found: /index
ERROR - 2022-03-31 20:03:27 --> 404 Page Not Found: /index
ERROR - 2022-03-31 20:03:27 --> 404 Page Not Found: /index
ERROR - 2022-03-31 20:03:27 --> 404 Page Not Found: /index
ERROR - 2022-03-31 20:04:23 --> 404 Page Not Found: /index
ERROR - 2022-03-31 20:06:21 --> 404 Page Not Found: /index
ERROR - 2022-03-31 20:06:43 --> 404 Page Not Found: /index
ERROR - 2022-03-31 20:07:51 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-31 20:07:51')
ERROR - 2022-03-31 20:10:04 --> 404 Page Not Found: /index
ERROR - 2022-03-31 20:11:29 --> 404 Page Not Found: /index
ERROR - 2022-03-31 20:14:24 --> 404 Page Not Found: /index
ERROR - 2022-03-31 20:15:23 --> 404 Page Not Found: /index
ERROR - 2022-03-31 20:15:34 --> 404 Page Not Found: /index
ERROR - 2022-03-31 20:15:42 --> 404 Page Not Found: /index
ERROR - 2022-03-31 20:16:07 --> 404 Page Not Found: /index
ERROR - 2022-03-31 20:16:26 --> 404 Page Not Found: /index
ERROR - 2022-03-31 20:17:05 --> 404 Page Not Found: /index
ERROR - 2022-03-31 20:19:26 --> 404 Page Not Found: /index
ERROR - 2022-03-31 20:19:53 --> 404 Page Not Found: /index
ERROR - 2022-03-31 20:20:04 --> 404 Page Not Found: /index
ERROR - 2022-03-31 20:21:11 --> 404 Page Not Found: /index
ERROR - 2022-03-31 20:23:33 --> 404 Page Not Found: /index
ERROR - 2022-03-31 20:24:04 --> 404 Page Not Found: /index
ERROR - 2022-03-31 20:24:16 --> 404 Page Not Found: /index
ERROR - 2022-03-31 20:25:22 --> 404 Page Not Found: /index
ERROR - 2022-03-31 20:26:08 --> 404 Page Not Found: /index
ERROR - 2022-03-31 20:26:14 --> 404 Page Not Found: /index
ERROR - 2022-03-31 20:27:57 --> 404 Page Not Found: /index
ERROR - 2022-03-31 20:28:23 --> 404 Page Not Found: /index
ERROR - 2022-03-31 20:28:23 --> 404 Page Not Found: /index
ERROR - 2022-03-31 20:32:08 --> 404 Page Not Found: /index
ERROR - 2022-03-31 20:33:04 --> 404 Page Not Found: /index
ERROR - 2022-03-31 20:33:04 --> 404 Page Not Found: /index
ERROR - 2022-03-31 20:33:04 --> 404 Page Not Found: /index
ERROR - 2022-03-31 20:34:28 --> 404 Page Not Found: /index
ERROR - 2022-03-31 20:35:20 --> 404 Page Not Found: /index
ERROR - 2022-03-31 20:35:20 --> 404 Page Not Found: /index
ERROR - 2022-03-31 20:35:20 --> 404 Page Not Found: /index
ERROR - 2022-03-31 20:35:33 --> 404 Page Not Found: /index
ERROR - 2022-03-31 20:35:33 --> 404 Page Not Found: /index
ERROR - 2022-03-31 20:35:33 --> 404 Page Not Found: /index
ERROR - 2022-03-31 20:36:19 --> 404 Page Not Found: /index
ERROR - 2022-03-31 20:36:19 --> 404 Page Not Found: /index
ERROR - 2022-03-31 20:36:19 --> 404 Page Not Found: /index
ERROR - 2022-03-31 20:36:49 --> 404 Page Not Found: /index
ERROR - 2022-03-31 20:37:34 --> 404 Page Not Found: /index
ERROR - 2022-03-31 20:42:07 --> 404 Page Not Found: /index
ERROR - 2022-03-31 20:42:08 --> 404 Page Not Found: /index
ERROR - 2022-03-31 20:42:25 --> 404 Page Not Found: /index
ERROR - 2022-03-31 20:44:23 --> 404 Page Not Found: /index
ERROR - 2022-03-31 20:45:14 --> 404 Page Not Found: /index
ERROR - 2022-03-31 20:45:55 --> 404 Page Not Found: /index
ERROR - 2022-03-31 20:46:30 --> 404 Page Not Found: /index
ERROR - 2022-03-31 20:48:12 --> 404 Page Not Found: /index
ERROR - 2022-03-31 20:50:23 --> 404 Page Not Found: /index
ERROR - 2022-03-31 20:51:14 --> 404 Page Not Found: /index
ERROR - 2022-03-31 20:52:54 --> 404 Page Not Found: /index
ERROR - 2022-03-31 20:55:22 --> 404 Page Not Found: /index
ERROR - 2022-03-31 20:55:22 --> 404 Page Not Found: /index
ERROR - 2022-03-31 20:55:35 --> 404 Page Not Found: /index
ERROR - 2022-03-31 20:55:51 --> 404 Page Not Found: /index
ERROR - 2022-03-31 20:56:26 --> 404 Page Not Found: /index
ERROR - 2022-03-31 20:56:26 --> 404 Page Not Found: /index
ERROR - 2022-03-31 20:57:51 --> 404 Page Not Found: /index
ERROR - 2022-03-31 20:57:51 --> 404 Page Not Found: /index
ERROR - 2022-03-31 20:59:00 --> To Id is not available for User - 2465
ERROR - 2022-03-31 20:59:03 --> 404 Page Not Found: /index
ERROR - 2022-03-31 20:59:55 --> 404 Page Not Found: /index
ERROR - 2022-03-31 20:59:55 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:00:24 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:01:32 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:03:37 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:04:28 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:04:47 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:05:04 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:05:18 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:05:19 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:05:19 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:05:20 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:05:59 --> To Id is not available for User - 1765
ERROR - 2022-03-31 21:06:43 --> To Id is not available for User - 2465
ERROR - 2022-03-31 21:08:00 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:08:00 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:08:16 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:09:09 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:09:37 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:09:53 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:09:53 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:09:53 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:10:21 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:10:33 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:10:49 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:12:03 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:12:42 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:13:19 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:13:19 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:13:25 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:13:43 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:14:07 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:14:18 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:15:03 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:15:03 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:15:11 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:16:22 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:16:22 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:17:14 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:20:12 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:20:17 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:21:23 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:21:23 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:22:41 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:22:41 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:23:59 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:23:59 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:24:44 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:27:05 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:27:21 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:27:55 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:28:19 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:29:23 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:30:55 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:31:16 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:31:19 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:32:59 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:33:13 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:33:14 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:33:14 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:33:15 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:33:15 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:33:15 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:33:16 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:33:16 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:33:17 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:33:17 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:34:31 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:35:07 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:36:01 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:36:19 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:36:56 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:39:03 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:39:18 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:41:10 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:41:17 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:42:09 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:42:15 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:44:49 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:45:40 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:47:18 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:47:46 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:49:34 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:53:01 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:54:26 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:54:52 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:55:04 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:55:21 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:55:36 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:57:59 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:58:13 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:58:13 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:58:23 --> 404 Page Not Found: /index
ERROR - 2022-03-31 21:58:25 --> 404 Page Not Found: /index
ERROR - 2022-03-31 22:01:07 --> 404 Page Not Found: /index
ERROR - 2022-03-31 22:01:07 --> 404 Page Not Found: /index
ERROR - 2022-03-31 22:02:25 --> 404 Page Not Found: /index
ERROR - 2022-03-31 22:02:39 --> 404 Page Not Found: /index
ERROR - 2022-03-31 22:02:54 --> 404 Page Not Found: /index
ERROR - 2022-03-31 22:04:22 --> 404 Page Not Found: /index
ERROR - 2022-03-31 22:04:22 --> 404 Page Not Found: /index
ERROR - 2022-03-31 22:04:29 --> 404 Page Not Found: /index
ERROR - 2022-03-31 22:05:49 --> 404 Page Not Found: /index
ERROR - 2022-03-31 22:07:21 --> 404 Page Not Found: /index
ERROR - 2022-03-31 22:07:24 --> 404 Page Not Found: /index
ERROR - 2022-03-31 22:09:57 --> 404 Page Not Found: /index
ERROR - 2022-03-31 22:10:16 --> 404 Page Not Found: /index
ERROR - 2022-03-31 22:10:50 --> 404 Page Not Found: /index
ERROR - 2022-03-31 22:11:59 --> 404 Page Not Found: /index
ERROR - 2022-03-31 22:12:28 --> 404 Page Not Found: /index
ERROR - 2022-03-31 22:12:42 --> 404 Page Not Found: /index
ERROR - 2022-03-31 22:12:51 --> 404 Page Not Found: /index
ERROR - 2022-03-31 22:14:31 --> 404 Page Not Found: /index
ERROR - 2022-03-31 22:14:31 --> 404 Page Not Found: /index
ERROR - 2022-03-31 22:14:47 --> 404 Page Not Found: /index
ERROR - 2022-03-31 22:15:03 --> 404 Page Not Found: /index
ERROR - 2022-03-31 22:15:21 --> 404 Page Not Found: /index
ERROR - 2022-03-31 22:16:24 --> 404 Page Not Found: /index
ERROR - 2022-03-31 22:17:21 --> 404 Page Not Found: /index
ERROR - 2022-03-31 22:17:21 --> 404 Page Not Found: /index
ERROR - 2022-03-31 22:17:41 --> 404 Page Not Found: /index
ERROR - 2022-03-31 22:19:23 --> To Id is not available for User - 1887
ERROR - 2022-03-31 22:19:44 --> To Id is not available for User - 1887
ERROR - 2022-03-31 22:19:49 --> 404 Page Not Found: /index
ERROR - 2022-03-31 22:19:49 --> 404 Page Not Found: /index
ERROR - 2022-03-31 22:22:27 --> 404 Page Not Found: /index
ERROR - 2022-03-31 22:23:04 --> 404 Page Not Found: /index
ERROR - 2022-03-31 22:23:13 --> 404 Page Not Found: /index
ERROR - 2022-03-31 22:26:11 --> 404 Page Not Found: /index
ERROR - 2022-03-31 22:26:20 --> 404 Page Not Found: /index
ERROR - 2022-03-31 22:27:10 --> 404 Page Not Found: /index
ERROR - 2022-03-31 22:31:19 --> 404 Page Not Found: /index
ERROR - 2022-03-31 22:32:19 --> 404 Page Not Found: /index
ERROR - 2022-03-31 22:34:36 --> 404 Page Not Found: /index
ERROR - 2022-03-31 22:34:36 --> 404 Page Not Found: /index
ERROR - 2022-03-31 22:35:20 --> 404 Page Not Found: /index
ERROR - 2022-03-31 22:35:20 --> 404 Page Not Found: /index
ERROR - 2022-03-31 22:36:42 --> 404 Page Not Found: /index
ERROR - 2022-03-31 22:37:57 --> 404 Page Not Found: /index
ERROR - 2022-03-31 22:38:50 --> 404 Page Not Found: /index
ERROR - 2022-03-31 22:38:50 --> 404 Page Not Found: /index
ERROR - 2022-03-31 22:39:17 --> 404 Page Not Found: /index
ERROR - 2022-03-31 22:41:36 --> 404 Page Not Found: /index
ERROR - 2022-03-31 22:42:40 --> 404 Page Not Found: /index
ERROR - 2022-03-31 22:43:11 --> 404 Page Not Found: /index
ERROR - 2022-03-31 22:43:23 --> 404 Page Not Found: /index
ERROR - 2022-03-31 22:43:30 --> 404 Page Not Found: /index
ERROR - 2022-03-31 22:43:35 --> 404 Page Not Found: /index
ERROR - 2022-03-31 22:48:48 --> 404 Page Not Found: /index
ERROR - 2022-03-31 22:49:52 --> 404 Page Not Found: /index
ERROR - 2022-03-31 22:51:14 --> 404 Page Not Found: /index
ERROR - 2022-03-31 22:52:50 --> 404 Page Not Found: /index
ERROR - 2022-03-31 22:52:51 --> 404 Page Not Found: /index
ERROR - 2022-03-31 22:52:51 --> 404 Page Not Found: /index
ERROR - 2022-03-31 22:53:04 --> 404 Page Not Found: /index
ERROR - 2022-03-31 22:53:05 --> 404 Page Not Found: /index
ERROR - 2022-03-31 22:53:05 --> 404 Page Not Found: /index
ERROR - 2022-03-31 22:53:06 --> 404 Page Not Found: /index
ERROR - 2022-03-31 22:53:06 --> 404 Page Not Found: /index
ERROR - 2022-03-31 22:53:06 --> 404 Page Not Found: /index
ERROR - 2022-03-31 22:53:07 --> 404 Page Not Found: /index
ERROR - 2022-03-31 22:53:07 --> 404 Page Not Found: /index
ERROR - 2022-03-31 22:53:08 --> 404 Page Not Found: /index
ERROR - 2022-03-31 22:53:08 --> 404 Page Not Found: /index
ERROR - 2022-03-31 22:56:37 --> 404 Page Not Found: /index
ERROR - 2022-03-31 22:56:52 --> 404 Page Not Found: /index
ERROR - 2022-03-31 22:58:38 --> 404 Page Not Found: /index
ERROR - 2022-03-31 22:58:38 --> 404 Page Not Found: /index
ERROR - 2022-03-31 23:00:52 --> 404 Page Not Found: /index
ERROR - 2022-03-31 23:01:06 --> 404 Page Not Found: /index
ERROR - 2022-03-31 23:04:00 --> 404 Page Not Found: /index
ERROR - 2022-03-31 23:05:16 --> 404 Page Not Found: /index
ERROR - 2022-03-31 23:05:36 --> 404 Page Not Found: /index
ERROR - 2022-03-31 23:05:43 --> 404 Page Not Found: /index
ERROR - 2022-03-31 23:06:01 --> 404 Page Not Found: /index
ERROR - 2022-03-31 23:06:54 --> 404 Page Not Found: /index
ERROR - 2022-03-31 23:09:29 --> 404 Page Not Found: /index
ERROR - 2022-03-31 23:16:49 --> 404 Page Not Found: /index
ERROR - 2022-03-31 23:16:49 --> 404 Page Not Found: /index
ERROR - 2022-03-31 23:19:44 --> 404 Page Not Found: /index
ERROR - 2022-03-31 23:20:57 --> 404 Page Not Found: /index
ERROR - 2022-03-31 23:22:35 --> 404 Page Not Found: /index
ERROR - 2022-03-31 23:22:36 --> 404 Page Not Found: /index
ERROR - 2022-03-31 23:26:37 --> 404 Page Not Found: /index
ERROR - 2022-03-31 23:31:37 --> 404 Page Not Found: /index
ERROR - 2022-03-31 23:32:34 --> 404 Page Not Found: /index
ERROR - 2022-03-31 23:33:51 --> 404 Page Not Found: /index
ERROR - 2022-03-31 23:34:59 --> 404 Page Not Found: /index
ERROR - 2022-03-31 23:39:22 --> 404 Page Not Found: /index
ERROR - 2022-03-31 23:42:55 --> 404 Page Not Found: /index
ERROR - 2022-03-31 23:42:56 --> 404 Page Not Found: /index
ERROR - 2022-03-31 23:43:23 --> 404 Page Not Found: /index
ERROR - 2022-03-31 23:43:32 --> 404 Page Not Found: /index
ERROR - 2022-03-31 23:44:36 --> 404 Page Not Found: /index
ERROR - 2022-03-31 23:46:21 --> To Id is not available for User - 2118
ERROR - 2022-03-31 23:48:02 --> To Id is not available for User - 2118
ERROR - 2022-03-31 23:48:23 --> To Id is not available for User - 1869
ERROR - 2022-03-31 23:48:41 --> To Id is not available for User - 1869
ERROR - 2022-03-31 23:49:00 --> 404 Page Not Found: /index
ERROR - 2022-03-31 23:49:27 --> To Id is not available for User - 1883
ERROR - 2022-03-31 23:51:16 --> To Id is not available for User - 2009
ERROR - 2022-03-31 23:53:54 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-31 23:53:54')
ERROR - 2022-03-31 23:55:26 --> 404 Page Not Found: /index
ERROR - 2022-03-31 23:55:30 --> 404 Page Not Found: /index
ERROR - 2022-03-31 23:58:59 --> 404 Page Not Found: /index
ERROR - 2022-03-31 23:59:03 --> 404 Page Not Found: /index
ERROR - 2022-03-31 23:59:15 --> To Id is not available for User - 1869
ERROR - 2022-03-31 23:59:38 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-31 23:59:38')
