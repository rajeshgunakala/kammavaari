<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-04-03 00:06:01 --> 404 Page Not Found: /index
ERROR - 2022-04-03 00:07:07 --> 404 Page Not Found: /index
ERROR - 2022-04-03 00:18:17 --> 404 Page Not Found: /index
ERROR - 2022-04-03 00:18:45 --> 404 Page Not Found: /index
ERROR - 2022-04-03 00:25:29 --> 404 Page Not Found: /index
ERROR - 2022-04-03 00:40:09 --> 404 Page Not Found: /index
ERROR - 2022-04-03 00:44:09 --> 404 Page Not Found: /index
ERROR - 2022-04-03 00:44:41 --> 404 Page Not Found: /index
ERROR - 2022-04-03 01:00:27 --> 404 Page Not Found: /index
ERROR - 2022-04-03 01:02:03 --> 404 Page Not Found: /index
ERROR - 2022-04-03 01:02:56 --> 404 Page Not Found: /index
ERROR - 2022-04-03 01:09:45 --> 404 Page Not Found: /index
ERROR - 2022-04-03 01:11:07 --> 404 Page Not Found: /index
ERROR - 2022-04-03 01:12:02 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-04-03 01:12:02')
ERROR - 2022-04-03 01:24:50 --> 404 Page Not Found: /index
ERROR - 2022-04-03 01:26:01 --> 404 Page Not Found: /index
ERROR - 2022-04-03 01:27:09 --> 404 Page Not Found: /index
ERROR - 2022-04-03 01:33:44 --> 404 Page Not Found: /index
ERROR - 2022-04-03 01:38:17 --> 404 Page Not Found: /index
ERROR - 2022-04-03 01:53:44 --> 404 Page Not Found: /index
ERROR - 2022-04-03 02:02:44 --> 404 Page Not Found: /index
ERROR - 2022-04-03 02:16:15 --> 404 Page Not Found: /index
ERROR - 2022-04-03 02:46:52 --> 404 Page Not Found: /index
ERROR - 2022-04-03 02:46:52 --> 404 Page Not Found: /index
ERROR - 2022-04-03 02:46:52 --> 404 Page Not Found: /index
ERROR - 2022-04-03 02:46:54 --> 404 Page Not Found: /index
ERROR - 2022-04-03 02:46:54 --> 404 Page Not Found: /index
ERROR - 2022-04-03 02:46:55 --> 404 Page Not Found: /index
ERROR - 2022-04-03 02:47:30 --> 404 Page Not Found: /index
ERROR - 2022-04-03 02:52:54 --> 404 Page Not Found: /index
ERROR - 2022-04-03 02:52:54 --> 404 Page Not Found: /index
ERROR - 2022-04-03 02:52:54 --> 404 Page Not Found: /index
ERROR - 2022-04-03 02:52:56 --> 404 Page Not Found: /index
ERROR - 2022-04-03 02:52:57 --> 404 Page Not Found: /index
ERROR - 2022-04-03 02:52:57 --> 404 Page Not Found: /index
ERROR - 2022-04-03 02:56:23 --> 404 Page Not Found: /index
ERROR - 2022-04-03 03:03:54 --> 404 Page Not Found: /index
ERROR - 2022-04-03 03:27:18 --> 404 Page Not Found: /index
ERROR - 2022-04-03 03:59:59 --> 404 Page Not Found: /index
ERROR - 2022-04-03 04:08:24 --> 404 Page Not Found: /index
ERROR - 2022-04-03 04:11:58 --> 404 Page Not Found: /index
ERROR - 2022-04-03 04:16:36 --> 404 Page Not Found: /index
ERROR - 2022-04-03 04:20:06 --> 404 Page Not Found: /index
ERROR - 2022-04-03 04:29:59 --> 404 Page Not Found: /index
ERROR - 2022-04-03 04:32:01 --> 404 Page Not Found: /index
ERROR - 2022-04-03 04:32:41 --> 404 Page Not Found: /index
ERROR - 2022-04-03 04:48:16 --> 404 Page Not Found: /index
ERROR - 2022-04-03 04:58:47 --> 404 Page Not Found: /index
ERROR - 2022-04-03 04:59:09 --> 404 Page Not Found: /index
ERROR - 2022-04-03 04:59:31 --> 404 Page Not Found: /index
ERROR - 2022-04-03 05:02:11 --> 404 Page Not Found: /index
ERROR - 2022-04-03 05:03:04 --> 404 Page Not Found: /index
ERROR - 2022-04-03 05:09:48 --> 404 Page Not Found: /index
ERROR - 2022-04-03 05:15:18 --> 404 Page Not Found: /index
ERROR - 2022-04-03 05:15:22 --> 404 Page Not Found: /index
ERROR - 2022-04-03 05:15:22 --> 404 Page Not Found: /index
ERROR - 2022-04-03 05:15:22 --> 404 Page Not Found: /index
ERROR - 2022-04-03 05:15:23 --> 404 Page Not Found: /index
ERROR - 2022-04-03 05:15:23 --> 404 Page Not Found: /index
ERROR - 2022-04-03 05:15:24 --> 404 Page Not Found: /index
ERROR - 2022-04-03 05:15:24 --> 404 Page Not Found: /index
ERROR - 2022-04-03 05:15:24 --> 404 Page Not Found: /index
ERROR - 2022-04-03 05:15:25 --> 404 Page Not Found: /index
ERROR - 2022-04-03 05:15:25 --> 404 Page Not Found: /index
ERROR - 2022-04-03 05:18:00 --> 404 Page Not Found: /index
ERROR - 2022-04-03 05:23:17 --> 404 Page Not Found: /index
ERROR - 2022-04-03 05:27:11 --> 404 Page Not Found: /index
ERROR - 2022-04-03 05:29:23 --> 404 Page Not Found: /index
ERROR - 2022-04-03 05:35:13 --> 404 Page Not Found: /index
ERROR - 2022-04-03 05:58:40 --> To Id is not available for User - 4389
ERROR - 2022-04-03 05:58:47 --> 404 Page Not Found: /index
ERROR - 2022-04-03 05:58:59 --> To Id is not available for User - 4389
ERROR - 2022-04-03 05:59:04 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
GROUP BY `profileowner`' at line 3 - Invalid query: SELECT *
FROM `ms_profilesetting`
WHERE `ms_id` in()
GROUP BY `profileowner`
ERROR - 2022-04-03 06:00:15 --> 404 Page Not Found: /index
ERROR - 2022-04-03 06:16:20 --> 404 Page Not Found: /index
ERROR - 2022-04-03 06:17:02 --> 404 Page Not Found: /index
ERROR - 2022-04-03 06:18:56 --> 404 Page Not Found: /index
ERROR - 2022-04-03 06:27:44 --> 404 Page Not Found: /index
ERROR - 2022-04-03 06:28:43 --> 404 Page Not Found: /index
ERROR - 2022-04-03 06:31:59 --> 404 Page Not Found: /index
ERROR - 2022-04-03 06:39:22 --> 404 Page Not Found: /index
ERROR - 2022-04-03 06:41:48 --> 404 Page Not Found: /index
ERROR - 2022-04-03 06:42:12 --> 404 Page Not Found: /index
ERROR - 2022-04-03 06:42:42 --> 404 Page Not Found: /index
ERROR - 2022-04-03 06:42:42 --> 404 Page Not Found: /index
ERROR - 2022-04-03 06:42:42 --> 404 Page Not Found: /index
ERROR - 2022-04-03 06:47:01 --> 404 Page Not Found: ../modules/admin/controllers/Admin/assets
ERROR - 2022-04-03 06:49:08 --> 404 Page Not Found: /index
ERROR - 2022-04-03 06:49:27 --> 404 Page Not Found: /index
ERROR - 2022-04-03 06:50:43 --> 404 Page Not Found: /index
ERROR - 2022-04-03 07:01:36 --> 404 Page Not Found: /index
ERROR - 2022-04-03 07:04:56 --> 404 Page Not Found: /index
ERROR - 2022-04-03 07:04:58 --> 404 Page Not Found: /index
ERROR - 2022-04-03 07:09:11 --> 404 Page Not Found: /index
ERROR - 2022-04-03 07:12:08 --> 404 Page Not Found: /index
ERROR - 2022-04-03 07:18:23 --> 404 Page Not Found: /index
ERROR - 2022-04-03 07:19:35 --> To Id is not available for User - 4189
ERROR - 2022-04-03 07:19:38 --> 404 Page Not Found: /index
ERROR - 2022-04-03 07:20:10 --> To Id is not available for User - 4189
ERROR - 2022-04-03 07:25:57 --> 404 Page Not Found: /index
ERROR - 2022-04-03 07:27:25 --> 404 Page Not Found: /index
ERROR - 2022-04-03 07:30:02 --> 404 Page Not Found: /index
ERROR - 2022-04-03 07:39:04 --> 404 Page Not Found: /index
ERROR - 2022-04-03 07:40:33 --> 404 Page Not Found: /index
ERROR - 2022-04-03 07:42:36 --> 404 Page Not Found: /index
ERROR - 2022-04-03 07:47:11 --> 404 Page Not Found: /index
ERROR - 2022-04-03 07:51:56 --> 404 Page Not Found: /index
ERROR - 2022-04-03 07:55:13 --> 404 Page Not Found: /index
ERROR - 2022-04-03 07:55:17 --> 404 Page Not Found: /index
ERROR - 2022-04-03 07:55:19 --> 404 Page Not Found: /index
ERROR - 2022-04-03 08:05:23 --> 404 Page Not Found: /index
ERROR - 2022-04-03 08:15:02 --> 404 Page Not Found: /index
ERROR - 2022-04-03 08:17:12 --> 404 Page Not Found: /index
ERROR - 2022-04-03 08:19:12 --> 404 Page Not Found: /index
ERROR - 2022-04-03 08:21:42 --> 404 Page Not Found: /index
ERROR - 2022-04-03 08:28:36 --> 404 Page Not Found: /index
ERROR - 2022-04-03 08:28:42 --> 404 Page Not Found: /index
ERROR - 2022-04-03 08:31:40 --> 404 Page Not Found: /index
ERROR - 2022-04-03 08:32:04 --> 404 Page Not Found: /index
ERROR - 2022-04-03 08:32:04 --> 404 Page Not Found: /index
ERROR - 2022-04-03 08:32:04 --> 404 Page Not Found: /index
ERROR - 2022-04-03 08:37:25 --> 404 Page Not Found: /index
ERROR - 2022-04-03 08:38:27 --> 404 Page Not Found: /index
ERROR - 2022-04-03 08:40:58 --> 404 Page Not Found: /index
ERROR - 2022-04-03 08:42:32 --> 404 Page Not Found: /index
ERROR - 2022-04-03 08:46:25 --> 404 Page Not Found: /index
ERROR - 2022-04-03 08:47:10 --> 404 Page Not Found: /index
ERROR - 2022-04-03 08:47:24 --> 404 Page Not Found: /index
ERROR - 2022-04-03 08:51:01 --> 404 Page Not Found: /index
ERROR - 2022-04-03 08:51:38 --> 404 Page Not Found: /index
ERROR - 2022-04-03 08:52:12 --> 404 Page Not Found: /index
ERROR - 2022-04-03 08:54:10 --> 404 Page Not Found: /index
ERROR - 2022-04-03 08:54:10 --> 404 Page Not Found: /index
ERROR - 2022-04-03 08:54:12 --> 404 Page Not Found: /index
ERROR - 2022-04-03 08:57:04 --> 404 Page Not Found: /index
ERROR - 2022-04-03 08:57:22 --> 404 Page Not Found: /index
ERROR - 2022-04-03 08:57:22 --> 404 Page Not Found: /index
ERROR - 2022-04-03 08:57:23 --> 404 Page Not Found: /index
ERROR - 2022-04-03 08:57:24 --> 404 Page Not Found: /index
ERROR - 2022-04-03 08:58:49 --> 404 Page Not Found: /index
ERROR - 2022-04-03 09:00:09 --> 404 Page Not Found: /index
ERROR - 2022-04-03 09:00:11 --> 404 Page Not Found: /index
ERROR - 2022-04-03 09:00:11 --> 404 Page Not Found: /index
ERROR - 2022-04-03 09:00:11 --> 404 Page Not Found: /index
ERROR - 2022-04-03 09:00:13 --> 404 Page Not Found: /index
ERROR - 2022-04-03 09:00:53 --> 404 Page Not Found: /index
ERROR - 2022-04-03 09:08:39 --> 404 Page Not Found: /index
ERROR - 2022-04-03 09:09:34 --> 404 Page Not Found: /index
ERROR - 2022-04-03 09:12:06 --> 404 Page Not Found: /index
ERROR - 2022-04-03 09:12:39 --> 404 Page Not Found: /index
ERROR - 2022-04-03 09:15:48 --> 404 Page Not Found: /index
ERROR - 2022-04-03 09:18:33 --> 404 Page Not Found: /index
ERROR - 2022-04-03 09:20:33 --> 404 Page Not Found: /index
ERROR - 2022-04-03 09:23:48 --> 404 Page Not Found: /index
ERROR - 2022-04-03 09:28:36 --> 404 Page Not Found: /index
ERROR - 2022-04-03 09:33:09 --> 404 Page Not Found: /index
ERROR - 2022-04-03 09:34:09 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-04-03 09:38:18 --> 404 Page Not Found: /index
ERROR - 2022-04-03 09:40:19 --> 404 Page Not Found: /index
ERROR - 2022-04-03 09:40:20 --> 404 Page Not Found: /index
ERROR - 2022-04-03 09:40:21 --> 404 Page Not Found: /index
ERROR - 2022-04-03 09:40:21 --> 404 Page Not Found: /index
ERROR - 2022-04-03 09:40:21 --> 404 Page Not Found: /index
ERROR - 2022-04-03 09:40:22 --> 404 Page Not Found: /index
ERROR - 2022-04-03 09:40:23 --> 404 Page Not Found: /index
ERROR - 2022-04-03 09:40:24 --> 404 Page Not Found: /index
ERROR - 2022-04-03 09:40:58 --> 404 Page Not Found: /index
ERROR - 2022-04-03 09:42:16 --> 404 Page Not Found: /index
ERROR - 2022-04-03 09:44:10 --> 404 Page Not Found: /index
ERROR - 2022-04-03 09:44:29 --> 404 Page Not Found: /index
ERROR - 2022-04-03 09:45:53 --> 404 Page Not Found: /index
ERROR - 2022-04-03 09:45:54 --> 404 Page Not Found: /index
ERROR - 2022-04-03 09:46:08 --> 404 Page Not Found: /index
ERROR - 2022-04-03 09:47:27 --> To Id is not available for User - 4189
ERROR - 2022-04-03 09:47:27 --> 404 Page Not Found: /index
ERROR - 2022-04-03 09:47:29 --> 404 Page Not Found: /index
ERROR - 2022-04-03 09:48:01 --> 404 Page Not Found: /index
ERROR - 2022-04-03 09:48:44 --> To Id is not available for User - 4389
ERROR - 2022-04-03 09:48:46 --> 404 Page Not Found: /index
ERROR - 2022-04-03 09:49:56 --> 404 Page Not Found: /index
ERROR - 2022-04-03 09:53:07 --> 404 Page Not Found: /index
ERROR - 2022-04-03 09:53:53 --> 404 Page Not Found: /index
ERROR - 2022-04-03 09:53:54 --> 404 Page Not Found: /index
ERROR - 2022-04-03 09:54:18 --> 404 Page Not Found: /index
ERROR - 2022-04-03 09:59:12 --> 404 Page Not Found: /index
ERROR - 2022-04-03 09:59:19 --> 404 Page Not Found: /index
ERROR - 2022-04-03 09:59:26 --> 404 Page Not Found: /index
ERROR - 2022-04-03 10:00:28 --> 404 Page Not Found: /index
ERROR - 2022-04-03 10:01:16 --> 404 Page Not Found: /index
ERROR - 2022-04-03 10:01:33 --> 404 Page Not Found: /index
ERROR - 2022-04-03 10:02:19 --> 404 Page Not Found: /index
ERROR - 2022-04-03 10:05:25 --> 404 Page Not Found: /index
ERROR - 2022-04-03 10:05:38 --> 404 Page Not Found: /index
ERROR - 2022-04-03 10:06:32 --> 404 Page Not Found: /index
ERROR - 2022-04-03 10:07:18 --> 404 Page Not Found: /index
ERROR - 2022-04-03 10:08:25 --> 404 Page Not Found: /index
ERROR - 2022-04-03 10:08:50 --> 404 Page Not Found: /index
ERROR - 2022-04-03 10:09:47 --> 404 Page Not Found: /index
ERROR - 2022-04-03 10:09:53 --> 404 Page Not Found: /index
ERROR - 2022-04-03 10:11:23 --> 404 Page Not Found: /index
ERROR - 2022-04-03 10:11:33 --> 404 Page Not Found: /index
ERROR - 2022-04-03 10:11:36 --> 404 Page Not Found: /index
ERROR - 2022-04-03 10:14:23 --> 404 Page Not Found: /index
ERROR - 2022-04-03 10:14:49 --> 404 Page Not Found: /index
ERROR - 2022-04-03 10:16:19 --> 404 Page Not Found: /index
ERROR - 2022-04-03 10:16:46 --> 404 Page Not Found: /index
ERROR - 2022-04-03 10:17:41 --> 404 Page Not Found: /index
ERROR - 2022-04-03 10:18:51 --> 404 Page Not Found: /index
ERROR - 2022-04-03 10:19:03 --> 404 Page Not Found: /index
ERROR - 2022-04-03 10:20:03 --> 404 Page Not Found: /index
ERROR - 2022-04-03 10:21:36 --> 404 Page Not Found: /index
ERROR - 2022-04-03 10:23:09 --> 404 Page Not Found: /index
ERROR - 2022-04-03 10:25:58 --> 404 Page Not Found: /index
ERROR - 2022-04-03 10:26:00 --> 404 Page Not Found: /index
ERROR - 2022-04-03 10:29:25 --> Severity: error --> Exception: Invalid address:  (to):  /home4/cowcdrmy/public_html/application/third_party/phpmailer/src/PHPMailer.php 1092
ERROR - 2022-04-03 10:31:42 --> 404 Page Not Found: /index
ERROR - 2022-04-03 10:32:10 --> 404 Page Not Found: /index
ERROR - 2022-04-03 10:32:46 --> 404 Page Not Found: /index
ERROR - 2022-04-03 10:32:46 --> 404 Page Not Found: /index
ERROR - 2022-04-03 10:34:59 --> 404 Page Not Found: /index
ERROR - 2022-04-03 10:35:23 --> 404 Page Not Found: /index
ERROR - 2022-04-03 10:35:43 --> 404 Page Not Found: /index
ERROR - 2022-04-03 10:36:36 --> 404 Page Not Found: /index
ERROR - 2022-04-03 10:37:30 --> 404 Page Not Found: /index
ERROR - 2022-04-03 10:37:37 --> 404 Page Not Found: /index
ERROR - 2022-04-03 10:37:52 --> 404 Page Not Found: /index
ERROR - 2022-04-03 10:38:58 --> 404 Page Not Found: /index
ERROR - 2022-04-03 10:39:03 --> 404 Page Not Found: /index
ERROR - 2022-04-03 10:40:47 --> 404 Page Not Found: /index
ERROR - 2022-04-03 10:41:00 --> To Id is not available for User - 2454
ERROR - 2022-04-03 10:41:01 --> To Id is not available for User - 2454
ERROR - 2022-04-03 10:41:05 --> 404 Page Not Found: /index
ERROR - 2022-04-03 10:41:10 --> 404 Page Not Found: /index
ERROR - 2022-04-03 10:41:14 --> 404 Page Not Found: /index
ERROR - 2022-04-03 10:42:01 --> Severity: error --> Exception: Invalid address:  (to):  /home4/cowcdrmy/public_html/application/third_party/phpmailer/src/PHPMailer.php 1092
ERROR - 2022-04-03 10:43:44 --> 404 Page Not Found: /index
ERROR - 2022-04-03 10:44:33 --> 404 Page Not Found: /index
ERROR - 2022-04-03 10:45:31 --> 404 Page Not Found: /index
ERROR - 2022-04-03 10:47:00 --> 404 Page Not Found: /index
ERROR - 2022-04-03 10:48:04 --> 404 Page Not Found: /index
ERROR - 2022-04-03 10:48:35 --> 404 Page Not Found: /index
ERROR - 2022-04-03 10:49:16 --> 404 Page Not Found: /index
ERROR - 2022-04-03 10:50:13 --> 404 Page Not Found: /index
ERROR - 2022-04-03 10:50:49 --> 404 Page Not Found: /index
ERROR - 2022-04-03 10:51:21 --> 404 Page Not Found: /index
ERROR - 2022-04-03 10:51:25 --> 404 Page Not Found: /index
ERROR - 2022-04-03 10:51:26 --> 404 Page Not Found: /index
ERROR - 2022-04-03 10:52:06 --> 404 Page Not Found: /index
ERROR - 2022-04-03 10:52:44 --> 404 Page Not Found: /index
ERROR - 2022-04-03 10:53:05 --> 404 Page Not Found: /index
ERROR - 2022-04-03 10:53:17 --> 404 Page Not Found: /index
ERROR - 2022-04-03 10:54:05 --> 404 Page Not Found: /index
ERROR - 2022-04-03 10:54:34 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:01:08 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:01:51 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:02:36 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:02:42 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:02:43 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:03:29 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:03:39 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:04:43 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:05:35 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:07:10 --> Query error: Table 'cowcdrmy_kammamarriage.ms_shortlist_viewedd_ignored' doesn't exist - Invalid query: SELECT `v`.*, `p`.`gender`, `p`.`id`, `p`.`status`, `p`.`age`, `p`.`living_in`, `p`.`profile_id`, `p`.`first_name`, `last_name`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `s`.*
FROM `kv_profileview` as `v`
LEFT JOIN `tbl_primary_info` as `p` ON `v`.`kv_profileview_on` = `p`.`id`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`ms_id`
INNER JOIN `ms_profilesetting` as `s` ON `p`.`id`=`s`.`ms_id`
WHERE `s`.`elite` = 'no'
AND `p`.`status` = 1
AND `v`.`kv_userfkid` = '4511'
AND `u`.`ismain` = 1
AND  `p`.`id` not in(select kv_msi_interested_on from kv_mysideinterests where kv_msi_profilefkid="4511")
AND  p.id not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid = "4511" AND `shortlist_status` = 1)
AND  `p`.`id` not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid="4511"AND ignore_status=1)
ORDER BY `v`.`kv_profileview_created_date` DESC
 LIMIT 10
ERROR - 2022-04-03 11:07:21 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:07:21 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:07:56 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:08:46 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:09:32 --> Query error: Table 'cowcdrmy_kammamarriage.ms_shortlist_viewedd_ignored' doesn't exist - Invalid query: SELECT `v`.*, `p`.`gender`, `p`.`id`, `p`.`status`, `p`.`age`, `p`.`living_in`, `p`.`profile_id`, `p`.`first_name`, `last_name`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `s`.*
FROM `kv_profileview` as `v`
LEFT JOIN `tbl_primary_info` as `p` ON `v`.`kv_profileview_on` = `p`.`id`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`ms_id`
INNER JOIN `ms_profilesetting` as `s` ON `p`.`id`=`s`.`ms_id`
WHERE `s`.`elite` = 'no'
AND `p`.`status` = 1
AND `v`.`kv_userfkid` = '2967'
AND `u`.`ismain` = 1
AND  `p`.`id` not in(select kv_msi_interested_on from kv_mysideinterests where kv_msi_profilefkid="2967")
AND  p.id not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid = "2967" AND `shortlist_status` = 1)
AND  `p`.`id` not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid="2967"AND ignore_status=1)
ORDER BY `v`.`kv_profileview_created_date` DESC
 LIMIT 10
ERROR - 2022-04-03 11:09:38 --> Severity: error --> Exception: Call to a member function result_array() on null /home4/cowcdrmy/public_html/application/modules/dashboard/models/My_account_model.php 911
ERROR - 2022-04-03 11:10:13 --> Severity: error --> Exception: Call to a member function result_array() on null /home4/cowcdrmy/public_html/application/modules/dashboard/models/My_account_model.php 911
ERROR - 2022-04-03 11:10:20 --> Query error: Table 'cowcdrmy_kammamarriage.ms_shortlist_viewedd_ignored' doesn't exist - Invalid query: SELECT `v`.*, `p`.`gender`, `p`.`id`, `p`.`status`, `p`.`age`, `p`.`living_in`, `p`.`profile_id`, `p`.`first_name`, `last_name`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `s`.*
FROM `kv_profileview` as `v`
LEFT JOIN `tbl_primary_info` as `p` ON `v`.`kv_profileview_on` = `p`.`id`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`ms_id`
INNER JOIN `ms_profilesetting` as `s` ON `p`.`id`=`s`.`ms_id`
WHERE `s`.`elite` = 'no'
AND `p`.`status` = 1
AND `v`.`kv_userfkid` = '2967'
AND `u`.`ismain` = 1
AND  `p`.`id` not in(select kv_msi_interested_on from kv_mysideinterests where kv_msi_profilefkid="2967")
AND  p.id not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid = "2967" AND `shortlist_status` = 1)
AND  `p`.`id` not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid="2967"AND ignore_status=1)
ORDER BY `v`.`kv_profileview_created_date` DESC
 LIMIT 10
ERROR - 2022-04-03 11:11:14 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:13:56 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:14:39 --> Query error: Column 'to_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES ('2967', NULL, 1, '2022-04-03 11:14:39')
ERROR - 2022-04-03 11:16:03 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:17:15 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:18:39 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:21:12 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:21:40 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:22:48 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:23:49 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:25:12 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:25:26 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:26:13 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:27:12 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:27:39 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-04-03 11:27:39')
ERROR - 2022-04-03 11:29:52 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:31:16 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:35:15 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:35:36 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:36:23 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:36:30 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:37:45 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:39:04 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:39:10 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:39:18 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:41:14 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:41:34 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:42:31 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:42:31 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:42:31 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:42:38 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:43:27 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:43:28 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:43:55 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:46:31 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:46:32 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:46:37 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:47:30 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:48:28 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:49:58 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:50:02 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:52:06 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:53:55 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:53:55 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:53:55 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:54:28 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:55:09 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:55:10 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:55:10 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:55:10 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:55:11 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:55:11 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:55:12 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:55:12 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:55:13 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:55:13 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:55:45 --> Severity: error --> Exception: Invalid address:  (to):  /home4/cowcdrmy/public_html/application/third_party/phpmailer/src/PHPMailer.php 1092
ERROR - 2022-04-03 11:55:59 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:56:42 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:57:19 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:57:49 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:57:49 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:57:49 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:57:51 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:57:51 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:57:53 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:57:53 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:57:55 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:58:55 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:58:55 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:58:57 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:58:57 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:58:58 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:59:10 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:59:10 --> 404 Page Not Found: /index
ERROR - 2022-04-03 11:59:18 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:00:41 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:00:49 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:00:49 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:00:51 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:00:51 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:01:09 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:01:21 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:01:28 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:01:29 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:01:38 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:01:38 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:02:24 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:02:45 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:02:45 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:02:45 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:03:03 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:03:03 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:03:41 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-04-03 12:03:41')
ERROR - 2022-04-03 12:04:06 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:05:57 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:06:32 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:07:07 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:07:41 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:07:41 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:07:42 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:08:19 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:08:19 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:09:42 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:10:53 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:11:36 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:11:56 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:12:06 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:12:38 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:12:48 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:13:01 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:13:34 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:14:02 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:15:05 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:15:05 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:15:55 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:16:07 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:16:08 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:18:01 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:18:01 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:18:14 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:18:19 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:19:33 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:24:09 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:24:09 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:24:09 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:26:40 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:27:10 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:28:35 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:28:37 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:28:48 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:31:45 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:32:25 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:32:25 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:33:39 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:34:10 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:34:24 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:34:25 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:35:33 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:36:08 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:36:24 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:36:43 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:36:43 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:38:03 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:38:03 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:38:03 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:39:25 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:41:07 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:41:48 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-04-03 12:42:06 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:42:48 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:43:18 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:43:18 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:43:32 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:44:33 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:47:15 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:49:56 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:50:24 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:50:39 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:51:02 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:52:52 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:52:54 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:52:56 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:53:35 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:54:19 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:54:53 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:54:58 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:55:36 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:58:13 --> 404 Page Not Found: /index
ERROR - 2022-04-03 12:59:43 --> 404 Page Not Found: /index
ERROR - 2022-04-03 13:00:21 --> 404 Page Not Found: /index
ERROR - 2022-04-03 13:03:27 --> 404 Page Not Found: /index
ERROR - 2022-04-03 13:05:35 --> 404 Page Not Found: /index
ERROR - 2022-04-03 13:05:39 --> 404 Page Not Found: /index
ERROR - 2022-04-03 13:06:18 --> 404 Page Not Found: /index
ERROR - 2022-04-03 13:06:27 --> 404 Page Not Found: /index
ERROR - 2022-04-03 13:08:48 --> 404 Page Not Found: /index
ERROR - 2022-04-03 13:13:30 --> 404 Page Not Found: /index
ERROR - 2022-04-03 13:17:20 --> 404 Page Not Found: /index
ERROR - 2022-04-03 13:17:22 --> 404 Page Not Found: /index
ERROR - 2022-04-03 13:17:58 --> 404 Page Not Found: /index
ERROR - 2022-04-03 13:19:47 --> 404 Page Not Found: /index
ERROR - 2022-04-03 13:21:43 --> 404 Page Not Found: /index
ERROR - 2022-04-03 13:22:52 --> 404 Page Not Found: /index
ERROR - 2022-04-03 13:24:09 --> 404 Page Not Found: /index
ERROR - 2022-04-03 13:24:55 --> 404 Page Not Found: /index
ERROR - 2022-04-03 13:25:07 --> 404 Page Not Found: /index
ERROR - 2022-04-03 13:25:12 --> 404 Page Not Found: /index
ERROR - 2022-04-03 13:26:30 --> 404 Page Not Found: /index
ERROR - 2022-04-03 13:28:50 --> 404 Page Not Found: /index
ERROR - 2022-04-03 13:30:46 --> 404 Page Not Found: /index
ERROR - 2022-04-03 13:31:26 --> 404 Page Not Found: /index
ERROR - 2022-04-03 13:33:52 --> 404 Page Not Found: /index
ERROR - 2022-04-03 13:34:19 --> 404 Page Not Found: /index
ERROR - 2022-04-03 13:35:40 --> 404 Page Not Found: /index
ERROR - 2022-04-03 13:35:57 --> 404 Page Not Found: /index
ERROR - 2022-04-03 13:36:07 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '<script>alert("xssvuln")</script> AND <script>alert("xssvuln") < `/script>`
AND ' at line 8 - Invalid query: SELECT `p`.`gender`, `p`.`id`, `p`.`status`, `p`.`age`, `p`.`living_in`, `p`.`profile_id`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`
FROM `tbl_primary_info` as `p`
INNER JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`MS_id`
INNER JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
INNER JOIN `ms_profilesetting` as `s` ON `p`.`id`=`s`.`ms_id`
WHERE `p`.`gender` = '<script>alert(\"xssvuln\")</script>'
AND `p`.`age` BETWEEN <script>alert("xssvuln")</script> AND <script>alert("xssvuln") < `/script>`
AND `r`.`religion` = '<script>alert(\"xssvuln\")</script>'
AND `r`.`mother_tounge` = '<script>alert(\"xssvuln\")</script>'
AND `p`.`status` = 1
AND `s`.`elite` = 'no'
AND `s`.`ms_usertype` = 'regular'
AND `u`.`ismain` = 1
AND `u`.`photoname` != ''
AND `u`.`applicationphotopath` != ''
GROUP BY `u`.`MS_id`
ORDER BY `registered_on` DESC
 LIMIT 8
ERROR - 2022-04-03 13:37:25 --> 404 Page Not Found: /index
ERROR - 2022-04-03 13:37:48 --> 404 Page Not Found: /index
ERROR - 2022-04-03 13:39:59 --> 404 Page Not Found: /index
ERROR - 2022-04-03 13:47:24 --> 404 Page Not Found: /index
ERROR - 2022-04-03 13:48:18 --> 404 Page Not Found: /index
ERROR - 2022-04-03 13:48:25 --> 404 Page Not Found: /index
ERROR - 2022-04-03 13:49:18 --> 404 Page Not Found: /index
ERROR - 2022-04-03 13:50:28 --> 404 Page Not Found: /index
ERROR - 2022-04-03 13:51:31 --> 404 Page Not Found: /index
ERROR - 2022-04-03 13:51:55 --> 404 Page Not Found: /index
ERROR - 2022-04-03 13:52:40 --> 404 Page Not Found: /index
ERROR - 2022-04-03 13:53:35 --> 404 Page Not Found: /index
ERROR - 2022-04-03 13:53:52 --> 404 Page Not Found: /index
ERROR - 2022-04-03 13:54:09 --> 404 Page Not Found: /index
ERROR - 2022-04-03 13:56:59 --> 404 Page Not Found: /index
ERROR - 2022-04-03 14:00:01 --> 404 Page Not Found: /index
ERROR - 2022-04-03 14:00:19 --> 404 Page Not Found: /index
ERROR - 2022-04-03 14:01:08 --> 404 Page Not Found: /index
ERROR - 2022-04-03 14:02:28 --> 404 Page Not Found: /index
ERROR - 2022-04-03 14:02:28 --> 404 Page Not Found: /index
ERROR - 2022-04-03 14:03:04 --> 404 Page Not Found: /index
ERROR - 2022-04-03 14:03:04 --> 404 Page Not Found: /index
ERROR - 2022-04-03 14:03:09 --> 404 Page Not Found: /index
ERROR - 2022-04-03 14:03:09 --> 404 Page Not Found: /index
ERROR - 2022-04-03 14:03:42 --> 404 Page Not Found: /index
ERROR - 2022-04-03 14:05:08 --> 404 Page Not Found: /index
ERROR - 2022-04-03 14:05:11 --> 404 Page Not Found: /index
ERROR - 2022-04-03 14:05:18 --> 404 Page Not Found: /index
ERROR - 2022-04-03 14:06:49 --> 404 Page Not Found: /index
ERROR - 2022-04-03 14:07:27 --> 404 Page Not Found: /index
ERROR - 2022-04-03 14:07:38 --> 404 Page Not Found: /index
ERROR - 2022-04-03 14:08:30 --> 404 Page Not Found: /index
ERROR - 2022-04-03 14:10:20 --> 404 Page Not Found: /index
ERROR - 2022-04-03 14:10:36 --> 404 Page Not Found: /index
ERROR - 2022-04-03 14:11:09 --> 404 Page Not Found: /index
ERROR - 2022-04-03 14:11:17 --> 404 Page Not Found: /index
ERROR - 2022-04-03 14:12:09 --> 404 Page Not Found: /index
ERROR - 2022-04-03 14:12:33 --> 404 Page Not Found: /index
ERROR - 2022-04-03 14:12:56 --> 404 Page Not Found: /index
ERROR - 2022-04-03 14:17:45 --> 404 Page Not Found: /index
ERROR - 2022-04-03 14:17:54 --> 404 Page Not Found: /index
ERROR - 2022-04-03 14:17:56 --> 404 Page Not Found: /index
ERROR - 2022-04-03 14:17:56 --> 404 Page Not Found: /index
ERROR - 2022-04-03 14:17:57 --> 404 Page Not Found: /index
ERROR - 2022-04-03 14:17:59 --> 404 Page Not Found: /index
ERROR - 2022-04-03 14:18:06 --> 404 Page Not Found: /index
ERROR - 2022-04-03 14:18:13 --> 404 Page Not Found: /index
ERROR - 2022-04-03 14:23:41 --> 404 Page Not Found: /index
ERROR - 2022-04-03 14:24:25 --> 404 Page Not Found: /index
ERROR - 2022-04-03 14:25:25 --> 404 Page Not Found: /index
ERROR - 2022-04-03 14:26:00 --> 404 Page Not Found: /index
ERROR - 2022-04-03 14:26:28 --> 404 Page Not Found: /index
ERROR - 2022-04-03 14:26:40 --> 404 Page Not Found: /index
ERROR - 2022-04-03 14:26:58 --> 404 Page Not Found: /index
ERROR - 2022-04-03 14:27:03 --> 404 Page Not Found: /index
ERROR - 2022-04-03 14:27:27 --> 404 Page Not Found: /index
ERROR - 2022-04-03 14:32:38 --> 404 Page Not Found: /index
ERROR - 2022-04-03 14:34:20 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-04-03 14:39:10 --> 404 Page Not Found: /index
ERROR - 2022-04-03 14:42:50 --> 404 Page Not Found: /index
ERROR - 2022-04-03 14:42:59 --> 404 Page Not Found: /index
ERROR - 2022-04-03 14:43:58 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-04-03 14:44:11 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-04-03 14:44:15 --> 404 Page Not Found: /index
ERROR - 2022-04-03 14:44:16 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-04-03 14:45:27 --> 404 Page Not Found: /index
ERROR - 2022-04-03 14:45:27 --> 404 Page Not Found: /index
ERROR - 2022-04-03 14:46:43 --> 404 Page Not Found: /index
ERROR - 2022-04-03 14:47:01 --> 404 Page Not Found: /index
ERROR - 2022-04-03 14:47:36 --> 404 Page Not Found: /index
ERROR - 2022-04-03 14:47:59 --> 404 Page Not Found: /index
ERROR - 2022-04-03 14:48:23 --> 404 Page Not Found: /index
ERROR - 2022-04-03 14:49:42 --> 404 Page Not Found: /index
ERROR - 2022-04-03 14:50:02 --> 404 Page Not Found: /index
ERROR - 2022-04-03 14:51:10 --> 404 Page Not Found: /index
ERROR - 2022-04-03 14:51:14 --> 404 Page Not Found: /index
ERROR - 2022-04-03 14:51:15 --> 404 Page Not Found: /index
ERROR - 2022-04-03 14:52:09 --> 404 Page Not Found: /index
ERROR - 2022-04-03 14:53:07 --> 404 Page Not Found: /index
ERROR - 2022-04-03 14:53:29 --> 404 Page Not Found: /index
ERROR - 2022-04-03 14:54:16 --> 404 Page Not Found: /index
ERROR - 2022-04-03 14:54:16 --> 404 Page Not Found: /index
ERROR - 2022-04-03 14:55:12 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-04-03 14:55:12')
ERROR - 2022-04-03 14:55:13 --> 404 Page Not Found: /index
ERROR - 2022-04-03 14:55:43 --> 404 Page Not Found: /index
ERROR - 2022-04-03 14:56:02 --> 404 Page Not Found: /index
ERROR - 2022-04-03 14:56:54 --> 404 Page Not Found: /index
ERROR - 2022-04-03 14:56:54 --> 404 Page Not Found: /index
ERROR - 2022-04-03 14:57:01 --> 404 Page Not Found: /index
ERROR - 2022-04-03 14:58:33 --> 404 Page Not Found: /index
ERROR - 2022-04-03 14:58:33 --> 404 Page Not Found: /index
ERROR - 2022-04-03 14:59:22 --> 404 Page Not Found: /index
ERROR - 2022-04-03 15:00:06 --> 404 Page Not Found: /index
ERROR - 2022-04-03 15:01:21 --> 404 Page Not Found: /index
ERROR - 2022-04-03 15:06:35 --> 404 Page Not Found: /index
ERROR - 2022-04-03 15:06:43 --> 404 Page Not Found: /index
ERROR - 2022-04-03 15:08:59 --> 404 Page Not Found: /index
ERROR - 2022-04-03 15:09:23 --> 404 Page Not Found: /index
ERROR - 2022-04-03 15:09:28 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-04-03 15:09:47 --> 404 Page Not Found: /index
ERROR - 2022-04-03 15:09:47 --> 404 Page Not Found: /index
ERROR - 2022-04-03 15:09:51 --> 404 Page Not Found: /index
ERROR - 2022-04-03 15:10:09 --> 404 Page Not Found: /index
ERROR - 2022-04-03 15:10:13 --> 404 Page Not Found: /index
ERROR - 2022-04-03 15:10:14 --> 404 Page Not Found: /index
ERROR - 2022-04-03 15:10:21 --> 404 Page Not Found: /index
ERROR - 2022-04-03 15:10:49 --> 404 Page Not Found: /index
ERROR - 2022-04-03 15:10:50 --> 404 Page Not Found: /index
ERROR - 2022-04-03 15:10:50 --> 404 Page Not Found: /index
ERROR - 2022-04-03 15:10:51 --> 404 Page Not Found: /index
ERROR - 2022-04-03 15:10:51 --> 404 Page Not Found: /index
ERROR - 2022-04-03 15:11:04 --> 404 Page Not Found: /index
ERROR - 2022-04-03 15:11:04 --> 404 Page Not Found: /index
ERROR - 2022-04-03 15:11:07 --> 404 Page Not Found: /index
ERROR - 2022-04-03 15:11:07 --> 404 Page Not Found: /index
ERROR - 2022-04-03 15:11:18 --> 404 Page Not Found: /index
ERROR - 2022-04-03 15:11:18 --> 404 Page Not Found: /index
ERROR - 2022-04-03 15:14:16 --> 404 Page Not Found: /index
ERROR - 2022-04-03 15:14:23 --> 404 Page Not Found: /index
ERROR - 2022-04-03 15:14:23 --> 404 Page Not Found: /index
ERROR - 2022-04-03 15:16:28 --> 404 Page Not Found: /index
ERROR - 2022-04-03 15:19:30 --> 404 Page Not Found: /index
ERROR - 2022-04-03 15:19:30 --> 404 Page Not Found: /index
ERROR - 2022-04-03 15:21:15 --> 404 Page Not Found: /index
ERROR - 2022-04-03 15:22:04 --> 404 Page Not Found: /index
ERROR - 2022-04-03 15:24:18 --> 404 Page Not Found: /index
ERROR - 2022-04-03 15:25:39 --> 404 Page Not Found: /index
ERROR - 2022-04-03 15:25:53 --> 404 Page Not Found: /index
ERROR - 2022-04-03 15:26:59 --> 404 Page Not Found: /index
ERROR - 2022-04-03 15:27:39 --> 404 Page Not Found: /index
ERROR - 2022-04-03 15:28:21 --> 404 Page Not Found: /index
ERROR - 2022-04-03 15:28:48 --> 404 Page Not Found: /index
ERROR - 2022-04-03 15:28:48 --> 404 Page Not Found: /index
ERROR - 2022-04-03 15:28:48 --> 404 Page Not Found: /index
ERROR - 2022-04-03 15:29:24 --> 404 Page Not Found: /index
ERROR - 2022-04-03 15:31:07 --> 404 Page Not Found: /index
ERROR - 2022-04-03 15:32:00 --> 404 Page Not Found: /index
ERROR - 2022-04-03 15:32:01 --> 404 Page Not Found: /index
ERROR - 2022-04-03 15:32:10 --> 404 Page Not Found: /index
ERROR - 2022-04-03 15:32:50 --> 404 Page Not Found: /index
ERROR - 2022-04-03 15:32:53 --> 404 Page Not Found: /index
ERROR - 2022-04-03 15:34:03 --> 404 Page Not Found: /index
ERROR - 2022-04-03 15:34:12 --> 404 Page Not Found: /index
ERROR - 2022-04-03 15:34:49 --> 404 Page Not Found: /index
ERROR - 2022-04-03 15:34:55 --> 404 Page Not Found: /index
ERROR - 2022-04-03 15:35:42 --> 404 Page Not Found: /index
ERROR - 2022-04-03 15:35:42 --> 404 Page Not Found: /index
ERROR - 2022-04-03 15:38:52 --> 404 Page Not Found: /index
ERROR - 2022-04-03 15:39:03 --> 404 Page Not Found: /index
ERROR - 2022-04-03 15:40:08 --> 404 Page Not Found: /index
ERROR - 2022-04-03 15:40:33 --> 404 Page Not Found: /index
ERROR - 2022-04-03 15:41:29 --> 404 Page Not Found: /index
ERROR - 2022-04-03 15:41:32 --> 404 Page Not Found: /index
ERROR - 2022-04-03 15:45:12 --> 404 Page Not Found: /index
ERROR - 2022-04-03 15:45:18 --> 404 Page Not Found: /index
ERROR - 2022-04-03 15:48:16 --> 404 Page Not Found: /index
ERROR - 2022-04-03 15:49:59 --> 404 Page Not Found: /index
ERROR - 2022-04-03 15:51:03 --> 404 Page Not Found: /index
ERROR - 2022-04-03 15:51:24 --> 404 Page Not Found: /index
ERROR - 2022-04-03 15:51:28 --> 404 Page Not Found: /index
ERROR - 2022-04-03 15:51:37 --> 404 Page Not Found: /index
ERROR - 2022-04-03 15:52:11 --> 404 Page Not Found: /index
ERROR - 2022-04-03 15:53:01 --> 404 Page Not Found: /index
ERROR - 2022-04-03 15:53:30 --> 404 Page Not Found: /index
ERROR - 2022-04-03 15:53:37 --> 404 Page Not Found: /index
ERROR - 2022-04-03 15:55:22 --> 404 Page Not Found: /index
ERROR - 2022-04-03 15:55:39 --> 404 Page Not Found: /index
ERROR - 2022-04-03 15:56:04 --> 404 Page Not Found: /index
ERROR - 2022-04-03 15:58:03 --> 404 Page Not Found: /index
ERROR - 2022-04-03 15:58:11 --> 404 Page Not Found: /index
ERROR - 2022-04-03 15:58:37 --> 404 Page Not Found: /index
ERROR - 2022-04-03 15:59:08 --> To Id is not available for User - 4256
ERROR - 2022-04-03 16:00:54 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:01:12 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:02:49 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:04:46 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:08:02 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:08:13 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:09:56 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:11:54 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:12:29 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:13:13 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:14:38 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:16:29 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:17:36 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:18:21 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:18:36 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:20:28 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:20:39 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:20:39 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:20:59 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:21:11 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:22:43 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:24:23 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:24:27 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:24:28 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:24:32 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:25:27 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:25:42 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:25:47 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:25:50 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:25:53 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:26:00 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:26:21 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:28:25 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:28:31 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:31:22 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:32:19 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:33:34 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:34:10 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:34:15 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:34:44 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:34:55 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:38:45 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:38:45 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:40:11 --> Severity: error --> Exception: Invalid address:  (to):  /home4/cowcdrmy/public_html/application/third_party/phpmailer/src/PHPMailer.php 1092
ERROR - 2022-04-03 16:40:21 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:41:29 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:41:29 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:41:44 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:41:48 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:42:12 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:42:12 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:42:16 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:42:34 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:42:35 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:42:59 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:43:13 --> To Id is not available for User - 3607
ERROR - 2022-04-03 16:43:27 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:43:35 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:44:02 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:44:08 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:45:02 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:45:03 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:45:10 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:45:44 --> Severity: error --> Exception: Invalid address:  (to):  /home4/cowcdrmy/public_html/application/third_party/phpmailer/src/PHPMailer.php 1092
ERROR - 2022-04-03 16:46:05 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:46:27 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:46:46 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:47:31 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:47:35 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:47:35 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:47:35 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:48:53 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:49:32 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:50:01 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:51:19 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:51:38 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:51:43 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:52:47 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:53:07 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:53:53 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:54:18 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:54:25 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:54:52 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:55:12 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-04-03 16:57:20 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:57:21 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:57:37 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:57:50 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:58:06 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:58:13 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:59:19 --> 404 Page Not Found: /index
ERROR - 2022-04-03 16:59:59 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:01:07 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:01:08 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:01:19 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:03:44 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:03:56 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:04:08 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:04:15 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:04:38 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:04:59 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:05:34 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:05:40 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:05:45 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:06:08 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:06:49 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:07:15 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-04-03 17:07:15')
ERROR - 2022-04-03 17:07:15 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:07:32 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:07:43 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:08:14 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:09:58 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:13:49 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:14:00 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:15:11 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:15:16 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:17:50 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:18:24 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:18:24 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:18:27 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:18:36 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:18:37 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:18:37 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:18:42 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:18:48 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:19:36 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:21:24 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:21:39 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:21:54 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:22:14 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:22:21 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:22:21 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:23:27 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:23:27 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:23:29 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:24:38 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:24:38 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:24:58 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:25:21 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:25:21 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:25:32 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:26:32 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:26:37 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:27:29 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:27:29 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:28:26 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:29:05 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:29:23 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:29:23 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:30:07 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:30:37 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:30:53 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:31:57 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:32:33 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-04-03 17:32:33')
ERROR - 2022-04-03 17:32:43 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:32:54 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:35:26 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:35:26 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:36:00 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:36:03 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:36:04 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:36:06 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:36:14 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:36:29 --> Severity: error --> Exception: Invalid address:  (to):  /home4/cowcdrmy/public_html/application/third_party/phpmailer/src/PHPMailer.php 1092
ERROR - 2022-04-03 17:37:08 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
GROUP BY `tbl_primary_info`.`id`' at line 7 - Invalid query: SELECT `tbl_primary_info`.*, `tbl_religion_info`.`star`, `tbl_religion_info`.`raasi`, `tbl_religion_info`.`height`, `tbl_professional_info`.`heighst_education`, `tbl_professional_info`.`occupation`, `tbl_professional_info`.`annual_income`, `tbl_professional_info`.`country`, `tbl_professional_info`.`city`, `tbl_professional_info`.`state`, `tbl_professional_info`.`education_degree`, `tbl_parents_info`.`fathers_father_native_place`, `tbl_parents_info`.`mothers_father_native_place`, `ms_property_info`.`property_value`
FROM `tbl_primary_info`
LEFT JOIN `tbl_religion_info` ON `tbl_religion_info`.`user_id` = `tbl_primary_info`.`id`
LEFT JOIN `tbl_professional_info` ON `tbl_professional_info`.`user_id` = `tbl_primary_info`.`id`
LEFT JOIN `tbl_parents_info` ON `tbl_parents_info`.`user_id` = `tbl_primary_info`.`id`
LEFT JOIN `ms_property_info` ON `ms_property_info`.`ms_id` = `tbl_primary_info`.`id`
WHERE `tbl_primary_info`.`id` IN ()
GROUP BY `tbl_primary_info`.`id`
ERROR - 2022-04-03 17:37:50 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:38:10 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:40:26 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:40:28 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:40:39 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:40:43 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:42:00 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:42:02 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:42:19 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:42:35 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:42:35 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:42:43 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:42:54 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:43:27 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-04-03 17:43:27')
ERROR - 2022-04-03 17:43:47 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:43:56 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:45:04 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:45:40 --> To Id is not available for User - 4256
ERROR - 2022-04-03 17:45:52 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:45:58 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:46:04 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:46:04 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:46:17 --> To Id is not available for User - 4256
ERROR - 2022-04-03 17:46:20 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:46:21 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:46:23 --> To Id is not available for User - �
ERROR - 2022-04-03 17:46:23 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:46:23 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:46:36 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:46:37 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:46:51 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:46:59 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:47:01 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:47:01 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:47:03 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:47:24 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:47:30 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:47:33 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:47:37 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:47:42 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:47:43 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:48:00 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:48:02 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:48:03 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:48:03 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:48:06 --> To Id is not available for User - 4256
ERROR - 2022-04-03 17:48:07 --> To Id is not available for User - 4256
ERROR - 2022-04-03 17:48:12 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:48:12 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:48:13 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:48:19 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:48:20 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:48:20 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:48:27 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:48:28 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:48:45 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:48:46 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:48:46 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:48:52 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:48:54 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:48:55 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:48:55 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:48:57 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:49:43 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:49:53 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:50:46 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:52:00 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:52:06 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:52:22 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:54:13 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:57:59 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:58:40 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:58:54 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:59:06 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:59:06 --> 404 Page Not Found: /index
ERROR - 2022-04-03 17:59:10 --> 404 Page Not Found: /index
ERROR - 2022-04-03 18:00:26 --> 404 Page Not Found: /index
ERROR - 2022-04-03 18:02:23 --> 404 Page Not Found: /index
ERROR - 2022-04-03 18:02:24 --> 404 Page Not Found: /index
ERROR - 2022-04-03 18:02:38 --> 404 Page Not Found: /index
ERROR - 2022-04-03 18:05:56 --> 404 Page Not Found: /index
ERROR - 2022-04-03 18:06:41 --> 404 Page Not Found: /index
ERROR - 2022-04-03 18:07:12 --> 404 Page Not Found: /index
ERROR - 2022-04-03 18:08:02 --> 404 Page Not Found: /index
ERROR - 2022-04-03 18:08:11 --> To Id is not available for User - 3046
ERROR - 2022-04-03 18:08:43 --> 404 Page Not Found: /index
ERROR - 2022-04-03 18:08:44 --> 404 Page Not Found: /index
ERROR - 2022-04-03 18:09:39 --> 404 Page Not Found: /index
ERROR - 2022-04-03 18:10:19 --> 404 Page Not Found: /index
ERROR - 2022-04-03 18:10:42 --> 404 Page Not Found: /index
ERROR - 2022-04-03 18:10:53 --> 404 Page Not Found: /index
ERROR - 2022-04-03 18:11:19 --> 404 Page Not Found: /index
ERROR - 2022-04-03 18:11:51 --> 404 Page Not Found: /index
ERROR - 2022-04-03 18:12:35 --> 404 Page Not Found: /index
ERROR - 2022-04-03 18:12:57 --> 404 Page Not Found: /index
ERROR - 2022-04-03 18:13:18 --> 404 Page Not Found: /index
ERROR - 2022-04-03 18:13:57 --> 404 Page Not Found: /index
ERROR - 2022-04-03 18:14:21 --> 404 Page Not Found: /index
ERROR - 2022-04-03 18:15:49 --> 404 Page Not Found: /index
ERROR - 2022-04-03 18:17:31 --> 404 Page Not Found: /index
ERROR - 2022-04-03 18:19:04 --> 404 Page Not Found: /index
ERROR - 2022-04-03 18:21:35 --> To Id is not available for User - 3046
ERROR - 2022-04-03 18:22:53 --> 404 Page Not Found: /index
ERROR - 2022-04-03 18:23:44 --> 404 Page Not Found: /index
ERROR - 2022-04-03 18:25:09 --> 404 Page Not Found: /index
ERROR - 2022-04-03 18:25:14 --> 404 Page Not Found: /index
ERROR - 2022-04-03 18:25:16 --> 404 Page Not Found: /index
ERROR - 2022-04-03 18:25:16 --> 404 Page Not Found: /index
ERROR - 2022-04-03 18:26:11 --> 404 Page Not Found: /index
ERROR - 2022-04-03 18:27:32 --> 404 Page Not Found: /index
ERROR - 2022-04-03 18:28:15 --> Query error: Table 'cowcdrmy_kammamarriage.ms_shortlist_viewedd_ignored' doesn't exist - Invalid query: SELECT `v`.*, `p`.`gender`, `p`.`id`, `p`.`status`, `p`.`age`, `p`.`living_in`, `p`.`profile_id`, `p`.`first_name`, `last_name`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `s`.*
FROM `kv_profileview` as `v`
LEFT JOIN `tbl_primary_info` as `p` ON `v`.`kv_profileview_on` = `p`.`id`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`ms_id`
INNER JOIN `ms_profilesetting` as `s` ON `p`.`id`=`s`.`ms_id`
WHERE `s`.`elite` = 'no'
AND `p`.`status` = 1
AND `v`.`kv_userfkid` = '906'
AND `u`.`ismain` = 1
AND  `p`.`id` not in(select kv_msi_interested_on from kv_mysideinterests where kv_msi_profilefkid="906")
AND  p.id not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid = "906" AND `shortlist_status` = 1)
AND  `p`.`id` not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid="906"AND ignore_status=1)
ORDER BY `v`.`kv_profileview_created_date` DESC
 LIMIT 10
ERROR - 2022-04-03 18:29:44 --> 404 Page Not Found: /index
ERROR - 2022-04-03 18:30:02 --> 404 Page Not Found: /index
ERROR - 2022-04-03 18:30:04 --> 404 Page Not Found: /index
ERROR - 2022-04-03 18:30:05 --> 404 Page Not Found: /index
ERROR - 2022-04-03 18:30:05 --> 404 Page Not Found: /index
ERROR - 2022-04-03 18:31:21 --> 404 Page Not Found: /index
ERROR - 2022-04-03 18:31:21 --> 404 Page Not Found: /index
ERROR - 2022-04-03 18:32:12 --> 404 Page Not Found: /index
ERROR - 2022-04-03 18:32:47 --> 404 Page Not Found: /index
ERROR - 2022-04-03 18:33:02 --> 404 Page Not Found: /index
ERROR - 2022-04-03 18:33:53 --> 404 Page Not Found: /index
ERROR - 2022-04-03 18:34:42 --> 404 Page Not Found: /index
ERROR - 2022-04-03 18:35:22 --> 404 Page Not Found: /index
ERROR - 2022-04-03 18:35:27 --> Query error: Table 'cowcdrmy_kammamarriage.ms_shortlist_viewedd_ignored' doesn't exist - Invalid query: SELECT `v`.*, `p`.`gender`, `p`.`id`, `p`.`status`, `p`.`age`, `p`.`living_in`, `p`.`profile_id`, `p`.`first_name`, `last_name`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `s`.*
FROM `kv_profileview` as `v`
LEFT JOIN `tbl_primary_info` as `p` ON `v`.`kv_profileview_on` = `p`.`id`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`ms_id`
INNER JOIN `ms_profilesetting` as `s` ON `p`.`id`=`s`.`ms_id`
WHERE `s`.`elite` = 'no'
AND `p`.`status` = 1
AND `v`.`kv_userfkid` = '906'
AND `u`.`ismain` = 1
AND  `p`.`id` not in(select kv_msi_interested_on from kv_mysideinterests where kv_msi_profilefkid="906")
AND  p.id not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid = "906" AND `shortlist_status` = 1)
AND  `p`.`id` not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid="906"AND ignore_status=1)
ORDER BY `v`.`kv_profileview_created_date` DESC
 LIMIT 10
ERROR - 2022-04-03 18:35:30 --> 404 Page Not Found: /index
ERROR - 2022-04-03 18:35:32 --> Severity: error --> Exception: Call to a member function result_array() on null /home4/cowcdrmy/public_html/application/modules/dashboard/models/My_account_model.php 911
ERROR - 2022-04-03 18:35:39 --> Severity: error --> Exception: Call to a member function result_array() on null /home4/cowcdrmy/public_html/application/modules/dashboard/models/My_account_model.php 911
ERROR - 2022-04-03 18:36:39 --> Query error: Table 'cowcdrmy_kammamarriage.ms_shortlist_viewedd_ignored' doesn't exist - Invalid query: SELECT `v`.*, `p`.`gender`, `p`.`id`, `p`.`status`, `p`.`age`, `p`.`living_in`, `p`.`profile_id`, `p`.`first_name`, `last_name`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `s`.*
FROM `kv_profileview` as `v`
LEFT JOIN `tbl_primary_info` as `p` ON `v`.`kv_profileview_on` = `p`.`id`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`ms_id`
INNER JOIN `ms_profilesetting` as `s` ON `p`.`id`=`s`.`ms_id`
WHERE `s`.`elite` = 'no'
AND `p`.`status` = 1
AND `v`.`kv_userfkid` = '906'
AND `u`.`ismain` = 1
AND  `p`.`id` not in(select kv_msi_interested_on from kv_mysideinterests where kv_msi_profilefkid="906")
AND  p.id not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid = "906" AND `shortlist_status` = 1)
AND  `p`.`id` not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid="906"AND ignore_status=1)
ORDER BY `v`.`kv_profileview_created_date` DESC
 LIMIT 10
ERROR - 2022-04-03 18:36:48 --> Severity: error --> Exception: Call to a member function result_array() on null /home4/cowcdrmy/public_html/application/modules/dashboard/models/My_account_model.php 911
ERROR - 2022-04-03 18:36:52 --> Severity: error --> Exception: Call to a member function result_array() on null /home4/cowcdrmy/public_html/application/modules/dashboard/models/My_account_model.php 911
ERROR - 2022-04-03 18:38:23 --> 404 Page Not Found: /index
ERROR - 2022-04-03 18:38:38 --> 404 Page Not Found: /index
ERROR - 2022-04-03 18:39:37 --> 404 Page Not Found: /index
ERROR - 2022-04-03 18:40:01 --> 404 Page Not Found: /index
ERROR - 2022-04-03 18:41:01 --> 404 Page Not Found: /index
ERROR - 2022-04-03 18:42:49 --> 404 Page Not Found: /index
ERROR - 2022-04-03 18:44:19 --> Query error: Table 'cowcdrmy_kammamarriage.ms_shortlist_viewedd_ignored' doesn't exist - Invalid query: SELECT `v`.*, `p`.`gender`, `p`.`id`, `p`.`status`, `p`.`age`, `p`.`living_in`, `p`.`profile_id`, `p`.`first_name`, `last_name`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `s`.*
FROM `kv_profileview` as `v`
LEFT JOIN `tbl_primary_info` as `p` ON `v`.`kv_profileview_on` = `p`.`id`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`ms_id`
INNER JOIN `ms_profilesetting` as `s` ON `p`.`id`=`s`.`ms_id`
WHERE `s`.`elite` = 'no'
AND `p`.`status` = 1
AND `v`.`kv_userfkid` = '906'
AND `u`.`ismain` = 1
AND  `p`.`id` not in(select kv_msi_interested_on from kv_mysideinterests where kv_msi_profilefkid="906")
AND  p.id not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid = "906" AND `shortlist_status` = 1)
AND  `p`.`id` not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid="906"AND ignore_status=1)
ORDER BY `v`.`kv_profileview_created_date` DESC
 LIMIT 10
ERROR - 2022-04-03 18:44:43 --> 404 Page Not Found: /index
ERROR - 2022-04-03 18:45:03 --> 404 Page Not Found: /index
ERROR - 2022-04-03 18:45:10 --> 404 Page Not Found: /index
ERROR - 2022-04-03 18:46:22 --> 404 Page Not Found: /index
ERROR - 2022-04-03 18:46:25 --> 404 Page Not Found: /index
ERROR - 2022-04-03 18:47:15 --> 404 Page Not Found: /index
ERROR - 2022-04-03 18:48:33 --> 404 Page Not Found: /index
ERROR - 2022-04-03 18:49:20 --> 404 Page Not Found: /index
ERROR - 2022-04-03 18:49:23 --> 404 Page Not Found: /index
ERROR - 2022-04-03 18:49:30 --> 404 Page Not Found: /index
ERROR - 2022-04-03 18:50:18 --> 404 Page Not Found: /index
ERROR - 2022-04-03 18:52:20 --> 404 Page Not Found: /index
ERROR - 2022-04-03 18:53:26 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:00:12 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:03:56 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:04:05 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:04:38 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:05:20 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:07:43 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:08:07 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:08:47 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:09:20 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:09:25 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:09:47 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:09:48 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:09:54 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:13:32 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:16:05 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:16:15 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:16:20 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:16:30 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:16:41 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:16:45 --> 404 Page Not Found: ../modules/admin/controllers/Admin/login.php
ERROR - 2022-04-03 19:16:50 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:16:59 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:17:13 --> 404 Page Not Found: ../modules/admin/controllers/Admin/login.asp
ERROR - 2022-04-03 19:17:20 --> 404 Page Not Found: ../modules/admin/controllers/Admin/login.html
ERROR - 2022-04-03 19:17:27 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:17:29 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:17:34 --> 404 Page Not Found: ../modules/admin/controllers/Admin/login.aspx
ERROR - 2022-04-03 19:17:45 --> 404 Page Not Found: ../modules/admin/controllers/Admin/index.php
ERROR - 2022-04-03 19:17:45 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:19:44 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:20:48 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:20:48 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:21:08 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:21:24 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:21:25 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:22:23 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:23:02 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:23:37 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:23:56 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:24:24 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:25:12 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:26:09 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:26:30 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:27:54 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:28:59 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:29:11 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:29:17 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:29:35 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:29:48 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:30:27 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:30:28 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:30:35 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:30:36 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:30:40 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:30:48 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:31:03 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:31:20 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:32:15 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:32:33 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:32:54 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:33:30 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:34:47 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:35:32 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT `p`.*, `r`.`caste`, `r`.`height`, `r`.`star`, `r`.`time_of_birth`, `r`.`raasi`, `prp`.`property_value`, `e`.`occupation`, `e`.`education_degree`, `e`.`visatype`, `e`.`city`, `e`.`country`, `e`.`annual_income`, `pfs`.`payment_status`, `pfs`.`profilesetting_id` as `pfs_id`, `pfs`.`last_call_updated`, `adm`.`username` as `profile_owner`
FROM `tbl_primary_info` as `p`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `ms_property_info` as `prp` ON `p`.`id`=`prp`.`ms_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `ms_profilesetting` as `pfs` ON `p`.`id`=`pfs`.`ms_id`
LEFT JOIN `tbl_admin_data` as `adm` ON `pfs`.`profileowner`=`adm`.`id`
WHERE `p`.`gender` = 'female'
AND `p`.`status` = '1'
AND `r`.`caste` = `Array`
AND `adm`.`id` = '3'
GROUP BY `p`.`id`
ERROR - 2022-04-03 19:35:34 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT `p`.*, `r`.`caste`, `r`.`height`, `r`.`star`, `r`.`time_of_birth`, `r`.`raasi`, `prp`.`property_value`, `e`.`occupation`, `e`.`education_degree`, `e`.`visatype`, `e`.`city`, `e`.`country`, `e`.`annual_income`, `pfs`.`payment_status`, `pfs`.`profilesetting_id` as `pfs_id`, `pfs`.`last_call_updated`, `adm`.`username` as `profile_owner`
FROM `tbl_primary_info` as `p`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `ms_property_info` as `prp` ON `p`.`id`=`prp`.`ms_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `ms_profilesetting` as `pfs` ON `p`.`id`=`pfs`.`ms_id`
LEFT JOIN `tbl_admin_data` as `adm` ON `pfs`.`profileowner`=`adm`.`id`
WHERE `p`.`gender` = 'female'
AND `p`.`status` = '1'
AND `r`.`caste` = `Array`
AND `adm`.`id` = '3'
GROUP BY `p`.`id`
ERROR - 2022-04-03 19:36:54 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: select SUM(IFNULL(`basicdetails`, 0) + IFNULL(`religion`, 0) + IFNULL(`edu_prof`, 0) + IFNULL(`parents`, 0) + IFNULL(`Siblings`, 0) + IFNULL(`photo`, 0)) as total,photo,basicdetails,religion,edu_prof,parents,Siblings from tbl_profilebattery where user_id=
ERROR - 2022-04-03 19:37:38 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:38:07 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:38:25 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:39:41 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:39:41 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:40:42 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:41:07 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:41:25 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:41:26 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:41:38 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:41:38 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:41:43 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:42:13 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:42:31 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:43:30 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:43:30 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:43:30 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:44:32 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:45:31 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:46:06 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:46:23 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:46:40 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:46:47 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:47:42 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:49:21 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:49:29 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:49:49 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:50:10 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:50:26 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:50:34 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:51:10 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:51:12 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:51:47 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:52:01 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:52:02 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:53:52 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:54:03 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:54:04 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:54:12 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:54:29 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:55:37 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:57:14 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:57:24 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:57:46 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:58:09 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:58:19 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:58:19 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:58:20 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:58:20 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:58:20 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:58:21 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:58:21 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:58:22 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:58:22 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:58:22 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:58:29 --> 404 Page Not Found: /index
ERROR - 2022-04-03 19:59:52 --> 404 Page Not Found: /index
ERROR - 2022-04-03 20:00:08 --> 404 Page Not Found: /index
ERROR - 2022-04-03 20:00:29 --> 404 Page Not Found: /index
ERROR - 2022-04-03 20:01:27 --> 404 Page Not Found: /index
ERROR - 2022-04-03 20:01:39 --> 404 Page Not Found: /index
ERROR - 2022-04-03 20:03:17 --> 404 Page Not Found: /index
ERROR - 2022-04-03 20:05:00 --> 404 Page Not Found: /index
ERROR - 2022-04-03 20:07:16 --> 404 Page Not Found: /index
ERROR - 2022-04-03 20:07:17 --> 404 Page Not Found: /index
ERROR - 2022-04-03 20:07:36 --> 404 Page Not Found: /index
ERROR - 2022-04-03 20:08:31 --> 404 Page Not Found: /index
ERROR - 2022-04-03 20:09:28 --> 404 Page Not Found: /index
ERROR - 2022-04-03 20:09:43 --> 404 Page Not Found: /index
ERROR - 2022-04-03 20:10:03 --> 404 Page Not Found: /index
ERROR - 2022-04-03 20:10:11 --> 404 Page Not Found: /index
ERROR - 2022-04-03 20:10:12 --> 404 Page Not Found: /index
ERROR - 2022-04-03 20:13:14 --> 404 Page Not Found: /index
ERROR - 2022-04-03 20:14:28 --> 404 Page Not Found: /index
ERROR - 2022-04-03 20:15:35 --> 404 Page Not Found: /index
ERROR - 2022-04-03 20:16:15 --> 404 Page Not Found: /index
ERROR - 2022-04-03 20:16:15 --> 404 Page Not Found: /index
ERROR - 2022-04-03 20:16:25 --> 404 Page Not Found: /index
ERROR - 2022-04-03 20:16:25 --> 404 Page Not Found: /index
ERROR - 2022-04-03 20:16:30 --> 404 Page Not Found: /index
ERROR - 2022-04-03 20:17:06 --> 404 Page Not Found: /index
ERROR - 2022-04-03 20:17:48 --> 404 Page Not Found: /index
ERROR - 2022-04-03 20:18:46 --> 404 Page Not Found: /index
ERROR - 2022-04-03 20:19:46 --> 404 Page Not Found: /index
ERROR - 2022-04-03 20:19:54 --> 404 Page Not Found: /index
ERROR - 2022-04-03 20:20:17 --> 404 Page Not Found: /index
ERROR - 2022-04-03 20:20:17 --> 404 Page Not Found: /index
ERROR - 2022-04-03 20:20:28 --> 404 Page Not Found: /index
ERROR - 2022-04-03 20:20:39 --> 404 Page Not Found: /index
ERROR - 2022-04-03 20:20:48 --> 404 Page Not Found: /index
ERROR - 2022-04-03 20:20:48 --> 404 Page Not Found: /index
ERROR - 2022-04-03 20:21:39 --> 404 Page Not Found: /index
ERROR - 2022-04-03 20:23:04 --> To Id is not available for User - 2191
ERROR - 2022-04-03 20:24:54 --> 404 Page Not Found: /index
ERROR - 2022-04-03 20:25:23 --> 404 Page Not Found: /index
ERROR - 2022-04-03 20:27:26 --> 404 Page Not Found: /index
ERROR - 2022-04-03 20:28:13 --> 404 Page Not Found: /index
ERROR - 2022-04-03 20:28:33 --> 404 Page Not Found: /index
ERROR - 2022-04-03 20:29:02 --> 404 Page Not Found: /index
ERROR - 2022-04-03 20:29:33 --> 404 Page Not Found: /index
ERROR - 2022-04-03 20:32:18 --> 404 Page Not Found: /index
ERROR - 2022-04-03 20:32:38 --> 404 Page Not Found: /index
ERROR - 2022-04-03 20:34:52 --> 404 Page Not Found: /index
ERROR - 2022-04-03 20:35:42 --> 404 Page Not Found: /index
ERROR - 2022-04-03 20:36:50 --> 404 Page Not Found: /index
ERROR - 2022-04-03 20:40:01 --> 404 Page Not Found: /index
ERROR - 2022-04-03 20:41:21 --> 404 Page Not Found: /index
ERROR - 2022-04-03 20:41:58 --> 404 Page Not Found: /index
ERROR - 2022-04-03 20:42:13 --> 404 Page Not Found: /index
ERROR - 2022-04-03 20:43:11 --> 404 Page Not Found: /index
ERROR - 2022-04-03 20:43:30 --> 404 Page Not Found: /index
ERROR - 2022-04-03 20:45:43 --> 404 Page Not Found: /index
ERROR - 2022-04-03 20:47:33 --> 404 Page Not Found: /index
ERROR - 2022-04-03 20:48:14 --> 404 Page Not Found: /index
ERROR - 2022-04-03 20:48:16 --> 404 Page Not Found: /index
ERROR - 2022-04-03 20:50:50 --> 404 Page Not Found: /index
ERROR - 2022-04-03 20:54:53 --> 404 Page Not Found: /index
ERROR - 2022-04-03 20:55:35 --> 404 Page Not Found: /index
ERROR - 2022-04-03 20:56:35 --> 404 Page Not Found: /index
ERROR - 2022-04-03 20:57:31 --> 404 Page Not Found: /index
ERROR - 2022-04-03 20:57:55 --> 404 Page Not Found: /index
ERROR - 2022-04-03 20:58:18 --> 404 Page Not Found: /index
ERROR - 2022-04-03 20:58:20 --> 404 Page Not Found: /index
ERROR - 2022-04-03 20:58:24 --> 404 Page Not Found: /index
ERROR - 2022-04-03 20:59:02 --> 404 Page Not Found: /index
ERROR - 2022-04-03 21:01:33 --> 404 Page Not Found: /index
ERROR - 2022-04-03 21:01:33 --> 404 Page Not Found: /index
ERROR - 2022-04-03 21:01:34 --> 404 Page Not Found: /index
ERROR - 2022-04-03 21:01:34 --> 404 Page Not Found: /index
ERROR - 2022-04-03 21:01:34 --> 404 Page Not Found: /index
ERROR - 2022-04-03 21:01:35 --> 404 Page Not Found: /index
ERROR - 2022-04-03 21:01:35 --> 404 Page Not Found: /index
ERROR - 2022-04-03 21:01:36 --> 404 Page Not Found: /index
ERROR - 2022-04-03 21:01:36 --> 404 Page Not Found: /index
ERROR - 2022-04-03 21:01:37 --> 404 Page Not Found: /index
ERROR - 2022-04-03 21:03:08 --> 404 Page Not Found: /index
ERROR - 2022-04-03 21:03:11 --> 404 Page Not Found: /index
ERROR - 2022-04-03 21:04:09 --> 404 Page Not Found: /index
ERROR - 2022-04-03 21:05:16 --> 404 Page Not Found: /index
ERROR - 2022-04-03 21:05:18 --> 404 Page Not Found: /index
ERROR - 2022-04-03 21:05:27 --> 404 Page Not Found: /index
ERROR - 2022-04-03 21:05:28 --> 404 Page Not Found: /index
ERROR - 2022-04-03 21:06:22 --> 404 Page Not Found: /index
ERROR - 2022-04-03 21:09:17 --> 404 Page Not Found: /index
ERROR - 2022-04-03 21:10:20 --> 404 Page Not Found: /index
ERROR - 2022-04-03 21:10:33 --> 404 Page Not Found: /index
ERROR - 2022-04-03 21:13:39 --> 404 Page Not Found: /index
ERROR - 2022-04-03 21:14:06 --> 404 Page Not Found: /index
ERROR - 2022-04-03 21:15:16 --> 404 Page Not Found: /index
ERROR - 2022-04-03 21:15:36 --> Query error: Deadlock found when trying to get lock; try restarting transaction - Invalid query: UPDATE `ms_servicelist` SET `fs_Date` = '2022-04-03 21:15:36'
WHERE (`from_msID` = 3369 AND `to_msID` = 2618 )
ERROR - 2022-04-03 21:17:55 --> 404 Page Not Found: /index
ERROR - 2022-04-03 21:18:07 --> 404 Page Not Found: /index
ERROR - 2022-04-03 21:18:30 --> 404 Page Not Found: /index
ERROR - 2022-04-03 21:19:26 --> 404 Page Not Found: /index
ERROR - 2022-04-03 21:23:24 --> 404 Page Not Found: /index
ERROR - 2022-04-03 21:24:49 --> 404 Page Not Found: /index
ERROR - 2022-04-03 21:27:17 --> 404 Page Not Found: /index
ERROR - 2022-04-03 21:28:52 --> 404 Page Not Found: /index
ERROR - 2022-04-03 21:28:56 --> 404 Page Not Found: /index
ERROR - 2022-04-03 21:31:55 --> 404 Page Not Found: /index
ERROR - 2022-04-03 21:35:59 --> 404 Page Not Found: /index
ERROR - 2022-04-03 21:37:03 --> 404 Page Not Found: /index
ERROR - 2022-04-03 21:39:04 --> 404 Page Not Found: /index
ERROR - 2022-04-03 21:39:24 --> 404 Page Not Found: /index
ERROR - 2022-04-03 21:39:42 --> 404 Page Not Found: /index
ERROR - 2022-04-03 21:40:16 --> 404 Page Not Found: /index
ERROR - 2022-04-03 21:41:00 --> 404 Page Not Found: /index
ERROR - 2022-04-03 21:42:15 --> 404 Page Not Found: /index
ERROR - 2022-04-03 21:44:59 --> 404 Page Not Found: /index
ERROR - 2022-04-03 21:49:16 --> 404 Page Not Found: /index
ERROR - 2022-04-03 21:56:15 --> 404 Page Not Found: /index
ERROR - 2022-04-03 21:56:31 --> 404 Page Not Found: /index
ERROR - 2022-04-03 21:57:08 --> 404 Page Not Found: /index
ERROR - 2022-04-03 21:57:59 --> 404 Page Not Found: /index
ERROR - 2022-04-03 21:58:00 --> 404 Page Not Found: /index
ERROR - 2022-04-03 21:58:28 --> 404 Page Not Found: /index
ERROR - 2022-04-03 22:05:32 --> 404 Page Not Found: /index
ERROR - 2022-04-03 22:05:33 --> 404 Page Not Found: /index
ERROR - 2022-04-03 22:05:40 --> 404 Page Not Found: /index
ERROR - 2022-04-03 22:06:03 --> 404 Page Not Found: /index
ERROR - 2022-04-03 22:06:57 --> 404 Page Not Found: /index
ERROR - 2022-04-03 22:08:33 --> 404 Page Not Found: /index
ERROR - 2022-04-03 22:11:32 --> 404 Page Not Found: /index
ERROR - 2022-04-03 22:12:29 --> 404 Page Not Found: /index
ERROR - 2022-04-03 22:13:54 --> 404 Page Not Found: /index
ERROR - 2022-04-03 22:14:26 --> 404 Page Not Found: /index
ERROR - 2022-04-03 22:16:28 --> 404 Page Not Found: /index
ERROR - 2022-04-03 22:18:32 --> 404 Page Not Found: /index
ERROR - 2022-04-03 22:18:37 --> 404 Page Not Found: /index
ERROR - 2022-04-03 22:18:52 --> 404 Page Not Found: /index
ERROR - 2022-04-03 22:18:58 --> 404 Page Not Found: /index
ERROR - 2022-04-03 22:19:13 --> 404 Page Not Found: /index
ERROR - 2022-04-03 22:20:21 --> 404 Page Not Found: /index
ERROR - 2022-04-03 22:21:30 --> 404 Page Not Found: /index
ERROR - 2022-04-03 22:21:53 --> 404 Page Not Found: /index
ERROR - 2022-04-03 22:22:20 --> 404 Page Not Found: /index
ERROR - 2022-04-03 22:23:54 --> 404 Page Not Found: /index
ERROR - 2022-04-03 22:25:06 --> 404 Page Not Found: /index
ERROR - 2022-04-03 22:30:33 --> 404 Page Not Found: /index
ERROR - 2022-04-03 22:33:17 --> 404 Page Not Found: /index
ERROR - 2022-04-03 22:33:39 --> 404 Page Not Found: /index
ERROR - 2022-04-03 22:34:33 --> 404 Page Not Found: /index
ERROR - 2022-04-03 22:34:42 --> 404 Page Not Found: /index
ERROR - 2022-04-03 22:35:04 --> 404 Page Not Found: /index
ERROR - 2022-04-03 22:35:07 --> 404 Page Not Found: /index
ERROR - 2022-04-03 22:35:34 --> 404 Page Not Found: /index
ERROR - 2022-04-03 22:37:24 --> 404 Page Not Found: /index
ERROR - 2022-04-03 22:38:07 --> 404 Page Not Found: /index
ERROR - 2022-04-03 22:38:30 --> 404 Page Not Found: /index
ERROR - 2022-04-03 22:40:33 --> 404 Page Not Found: /index
ERROR - 2022-04-03 22:40:51 --> 404 Page Not Found: /index
ERROR - 2022-04-03 22:41:39 --> 404 Page Not Found: /index
ERROR - 2022-04-03 22:41:49 --> 404 Page Not Found: /index
ERROR - 2022-04-03 22:42:13 --> 404 Page Not Found: /index
ERROR - 2022-04-03 22:43:15 --> 404 Page Not Found: /index
ERROR - 2022-04-03 22:43:56 --> 404 Page Not Found: /index
ERROR - 2022-04-03 22:44:05 --> 404 Page Not Found: /index
ERROR - 2022-04-03 22:46:11 --> 404 Page Not Found: /index
ERROR - 2022-04-03 22:49:55 --> 404 Page Not Found: /index
ERROR - 2022-04-03 22:50:53 --> To Id is not available for User - 2345
ERROR - 2022-04-03 22:50:59 --> To Id is not available for User - 2206
ERROR - 2022-04-03 22:51:06 --> To Id is not available for User - 2185
ERROR - 2022-04-03 22:54:50 --> 404 Page Not Found: /index
ERROR - 2022-04-03 22:55:16 --> 404 Page Not Found: /index
ERROR - 2022-04-03 22:55:50 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-04-03 22:55:50')
ERROR - 2022-04-03 22:56:54 --> 404 Page Not Found: /index
ERROR - 2022-04-03 23:00:37 --> 404 Page Not Found: /index
ERROR - 2022-04-03 23:01:23 --> 404 Page Not Found: /index
ERROR - 2022-04-03 23:05:01 --> 404 Page Not Found: /index
ERROR - 2022-04-03 23:05:10 --> 404 Page Not Found: /index
ERROR - 2022-04-03 23:05:46 --> 404 Page Not Found: /index
ERROR - 2022-04-03 23:06:02 --> 404 Page Not Found: /index
ERROR - 2022-04-03 23:06:19 --> 404 Page Not Found: /index
ERROR - 2022-04-03 23:06:20 --> 404 Page Not Found: /index
ERROR - 2022-04-03 23:06:30 --> 404 Page Not Found: /index
ERROR - 2022-04-03 23:07:33 --> 404 Page Not Found: /index
ERROR - 2022-04-03 23:07:43 --> 404 Page Not Found: /index
ERROR - 2022-04-03 23:09:11 --> 404 Page Not Found: /index
ERROR - 2022-04-03 23:14:33 --> 404 Page Not Found: /index
ERROR - 2022-04-03 23:15:16 --> 404 Page Not Found: /index
ERROR - 2022-04-03 23:15:34 --> 404 Page Not Found: /index
ERROR - 2022-04-03 23:18:52 --> 404 Page Not Found: /index
ERROR - 2022-04-03 23:18:52 --> 404 Page Not Found: /index
ERROR - 2022-04-03 23:18:52 --> 404 Page Not Found: /index
ERROR - 2022-04-03 23:19:14 --> 404 Page Not Found: /index
ERROR - 2022-04-03 23:19:14 --> 404 Page Not Found: /index
ERROR - 2022-04-03 23:19:14 --> 404 Page Not Found: /index
ERROR - 2022-04-03 23:20:20 --> 404 Page Not Found: /index
ERROR - 2022-04-03 23:20:38 --> 404 Page Not Found: /index
ERROR - 2022-04-03 23:20:50 --> 404 Page Not Found: /index
ERROR - 2022-04-03 23:21:44 --> 404 Page Not Found: /index
ERROR - 2022-04-03 23:21:47 --> 404 Page Not Found: /index
ERROR - 2022-04-03 23:22:08 --> 404 Page Not Found: /index
ERROR - 2022-04-03 23:22:35 --> 404 Page Not Found: /index
ERROR - 2022-04-03 23:22:57 --> 404 Page Not Found: /index
ERROR - 2022-04-03 23:22:57 --> 404 Page Not Found: /index
ERROR - 2022-04-03 23:22:57 --> 404 Page Not Found: /index
ERROR - 2022-04-03 23:24:01 --> 404 Page Not Found: /index
ERROR - 2022-04-03 23:24:20 --> 404 Page Not Found: /index
ERROR - 2022-04-03 23:24:49 --> 404 Page Not Found: /index
ERROR - 2022-04-03 23:25:49 --> 404 Page Not Found: /index
ERROR - 2022-04-03 23:25:55 --> 404 Page Not Found: /index
ERROR - 2022-04-03 23:26:04 --> 404 Page Not Found: /index
ERROR - 2022-04-03 23:26:33 --> 404 Page Not Found: /index
ERROR - 2022-04-03 23:30:36 --> 404 Page Not Found: /index
ERROR - 2022-04-03 23:31:44 --> 404 Page Not Found: /index
ERROR - 2022-04-03 23:32:58 --> 404 Page Not Found: /index
ERROR - 2022-04-03 23:33:50 --> 404 Page Not Found: /index
ERROR - 2022-04-03 23:33:58 --> 404 Page Not Found: /index
ERROR - 2022-04-03 23:34:24 --> 404 Page Not Found: /index
ERROR - 2022-04-03 23:35:02 --> 404 Page Not Found: /index
ERROR - 2022-04-03 23:36:03 --> 404 Page Not Found: /index
ERROR - 2022-04-03 23:36:56 --> 404 Page Not Found: /index
ERROR - 2022-04-03 23:37:10 --> 404 Page Not Found: /index
ERROR - 2022-04-03 23:38:13 --> 404 Page Not Found: /index
ERROR - 2022-04-03 23:38:13 --> 404 Page Not Found: /index
ERROR - 2022-04-03 23:38:26 --> 404 Page Not Found: /index
ERROR - 2022-04-03 23:39:44 --> 404 Page Not Found: /index
ERROR - 2022-04-03 23:40:31 --> 404 Page Not Found: /index
ERROR - 2022-04-03 23:41:11 --> 404 Page Not Found: /index
ERROR - 2022-04-03 23:43:27 --> 404 Page Not Found: /index
ERROR - 2022-04-03 23:45:09 --> 404 Page Not Found: /index
ERROR - 2022-04-03 23:45:14 --> 404 Page Not Found: /index
ERROR - 2022-04-03 23:53:17 --> 404 Page Not Found: /index
ERROR - 2022-04-03 23:54:04 --> 404 Page Not Found: /index
ERROR - 2022-04-03 23:54:50 --> 404 Page Not Found: /index
ERROR - 2022-04-03 23:57:23 --> 404 Page Not Found: /index
ERROR - 2022-04-03 23:58:31 --> 404 Page Not Found: /index
