<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-06-26 13:15:21 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user 'cowcdrmy_kammavri'@'localhost' (using password: YES) /home/kammavaari1/public_html/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2022-06-26 13:15:21 --> Severity: error --> Exception: Unable to connect to the database. /home/kammavaari1/public_html/system/database/DB_driver.php 433
