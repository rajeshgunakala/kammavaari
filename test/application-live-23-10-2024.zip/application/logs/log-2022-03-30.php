<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-30 00:03:03 --> 404 Page Not Found: /index
ERROR - 2022-03-30 00:05:50 --> 404 Page Not Found: /index
ERROR - 2022-03-30 00:06:30 --> 404 Page Not Found: /index
ERROR - 2022-03-30 00:07:35 --> 404 Page Not Found: /index
ERROR - 2022-03-30 00:16:48 --> 404 Page Not Found: /index
ERROR - 2022-03-30 00:26:12 --> 404 Page Not Found: /index
ERROR - 2022-03-30 00:36:57 --> 404 Page Not Found: /index
ERROR - 2022-03-30 00:36:59 --> 404 Page Not Found: /index
ERROR - 2022-03-30 00:41:43 --> 404 Page Not Found: /index
ERROR - 2022-03-30 00:41:51 --> 404 Page Not Found: /index
ERROR - 2022-03-30 00:42:48 --> 404 Page Not Found: /index
ERROR - 2022-03-30 00:42:48 --> 404 Page Not Found: /index
ERROR - 2022-03-30 00:42:49 --> 404 Page Not Found: /index
ERROR - 2022-03-30 00:42:49 --> 404 Page Not Found: /index
ERROR - 2022-03-30 00:42:50 --> 404 Page Not Found: /index
ERROR - 2022-03-30 00:42:50 --> 404 Page Not Found: /index
ERROR - 2022-03-30 00:42:51 --> 404 Page Not Found: /index
ERROR - 2022-03-30 00:42:51 --> 404 Page Not Found: /index
ERROR - 2022-03-30 00:47:50 --> 404 Page Not Found: /index
ERROR - 2022-03-30 00:52:44 --> 404 Page Not Found: /index
ERROR - 2022-03-30 01:02:29 --> 404 Page Not Found: /index
ERROR - 2022-03-30 01:10:05 --> 404 Page Not Found: /index
ERROR - 2022-03-30 01:11:43 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-30 01:11:43')
ERROR - 2022-03-30 01:14:45 --> 404 Page Not Found: /index
ERROR - 2022-03-30 01:15:52 --> 404 Page Not Found: /index
ERROR - 2022-03-30 01:23:44 --> 404 Page Not Found: /index
ERROR - 2022-03-30 01:24:37 --> 404 Page Not Found: /index
ERROR - 2022-03-30 01:26:58 --> 404 Page Not Found: /index
ERROR - 2022-03-30 01:31:00 --> 404 Page Not Found: /index
ERROR - 2022-03-30 01:32:12 --> 404 Page Not Found: /index
ERROR - 2022-03-30 01:35:29 --> 404 Page Not Found: /index
ERROR - 2022-03-30 01:37:59 --> 404 Page Not Found: /index
ERROR - 2022-03-30 01:50:30 --> 404 Page Not Found: /index
ERROR - 2022-03-30 01:54:20 --> 404 Page Not Found: /index
ERROR - 2022-03-30 02:08:41 --> 404 Page Not Found: /index
ERROR - 2022-03-30 02:09:37 --> 404 Page Not Found: /index
ERROR - 2022-03-30 02:09:42 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-30 02:09:42')
ERROR - 2022-03-30 02:10:05 --> 404 Page Not Found: /index
ERROR - 2022-03-30 02:25:15 --> 404 Page Not Found: /index
ERROR - 2022-03-30 02:32:27 --> 404 Page Not Found: /index
ERROR - 2022-03-30 02:44:42 --> 404 Page Not Found: /index
ERROR - 2022-03-30 02:45:59 --> To Id is not available for User - 4051
ERROR - 2022-03-30 02:46:00 --> 404 Page Not Found: /index
ERROR - 2022-03-30 02:46:01 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
GROUP BY `profileowner`' at line 3 - Invalid query: SELECT *
FROM `ms_profilesetting`
WHERE `ms_id` in()
GROUP BY `profileowner`
ERROR - 2022-03-30 02:46:35 --> To Id is not available for User - 4051
ERROR - 2022-03-30 02:46:59 --> 404 Page Not Found: /index
ERROR - 2022-03-30 02:50:12 --> Query error: Column 'to_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES ('3872', NULL, 1, '2022-03-30 02:50:12')
ERROR - 2022-03-30 02:53:39 --> 404 Page Not Found: /index
ERROR - 2022-03-30 03:02:43 --> Severity: error --> Exception: Call to undefined method My_account_model::from() /home4/cowcdrmy/public_html/application/modules/dashboard/models/My_account_model.php 849
ERROR - 2022-03-30 03:09:10 --> 404 Page Not Found: /index
ERROR - 2022-03-30 03:09:58 --> 404 Page Not Found: /index
ERROR - 2022-03-30 03:10:52 --> 404 Page Not Found: /index
ERROR - 2022-03-30 03:12:06 --> To Id is not available for User - 4051
ERROR - 2022-03-30 03:17:32 --> 404 Page Not Found: /index
ERROR - 2022-03-30 03:19:57 --> 404 Page Not Found: /index
ERROR - 2022-03-30 03:24:15 --> 404 Page Not Found: /index
ERROR - 2022-03-30 03:36:55 --> 404 Page Not Found: /index
ERROR - 2022-03-30 03:37:46 --> 404 Page Not Found: /index
ERROR - 2022-03-30 03:37:46 --> 404 Page Not Found: /index
ERROR - 2022-03-30 03:57:47 --> 404 Page Not Found: /index
ERROR - 2022-03-30 04:08:56 --> 404 Page Not Found: /index
ERROR - 2022-03-30 04:19:53 --> 404 Page Not Found: /index
ERROR - 2022-03-30 04:40:59 --> 404 Page Not Found: /index
ERROR - 2022-03-30 04:42:14 --> 404 Page Not Found: /index
ERROR - 2022-03-30 04:42:24 --> 404 Page Not Found: /index
ERROR - 2022-03-30 04:44:23 --> 404 Page Not Found: /index
ERROR - 2022-03-30 04:44:31 --> Query error: Table 'cowcdrmy_kammamarriage.ms_shortlist_viewedd_ignored' doesn't exist - Invalid query: SELECT `v`.*, `p`.`gender`, `p`.`id`, `p`.`status`, `p`.`age`, `p`.`living_in`, `p`.`profile_id`, `p`.`first_name`, `last_name`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `s`.*
FROM `kv_profileview` as `v`
LEFT JOIN `tbl_primary_info` as `p` ON `v`.`kv_profileview_on` = `p`.`id`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`ms_id`
INNER JOIN `ms_profilesetting` as `s` ON `p`.`id`=`s`.`ms_id`
WHERE `s`.`elite` = 'no'
AND `p`.`status` = 1
AND `v`.`kv_userfkid` = '3581'
AND `u`.`ismain` = 1
AND  `p`.`id` not in(select kv_msi_interested_on from kv_mysideinterests where kv_msi_profilefkid="3581")
AND  p.id not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid = "3581" AND `shortlist_status` = 1)
AND  `p`.`id` not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid="3581"AND ignore_status=1)
ORDER BY `v`.`kv_profileview_created_date` DESC
 LIMIT 10
ERROR - 2022-03-30 04:46:55 --> 404 Page Not Found: /index
ERROR - 2022-03-30 04:48:31 --> 404 Page Not Found: /index
ERROR - 2022-03-30 04:49:27 --> 404 Page Not Found: /index
ERROR - 2022-03-30 04:50:37 --> 404 Page Not Found: /index
ERROR - 2022-03-30 04:50:37 --> 404 Page Not Found: /index
ERROR - 2022-03-30 04:50:38 --> 404 Page Not Found: /index
ERROR - 2022-03-30 04:50:38 --> 404 Page Not Found: /index
ERROR - 2022-03-30 04:50:39 --> 404 Page Not Found: /index
ERROR - 2022-03-30 04:50:39 --> 404 Page Not Found: /index
ERROR - 2022-03-30 04:50:39 --> 404 Page Not Found: /index
ERROR - 2022-03-30 04:50:40 --> 404 Page Not Found: /index
ERROR - 2022-03-30 04:50:40 --> 404 Page Not Found: /index
ERROR - 2022-03-30 04:50:40 --> 404 Page Not Found: /index
ERROR - 2022-03-30 04:51:17 --> 404 Page Not Found: /index
ERROR - 2022-03-30 04:57:45 --> 404 Page Not Found: /index
ERROR - 2022-03-30 05:07:48 --> 404 Page Not Found: /index
ERROR - 2022-03-30 05:15:53 --> 404 Page Not Found: /index
ERROR - 2022-03-30 05:18:10 --> 404 Page Not Found: /index
ERROR - 2022-03-30 05:18:47 --> 404 Page Not Found: /index
ERROR - 2022-03-30 05:21:23 --> 404 Page Not Found: /index
ERROR - 2022-03-30 05:24:26 --> 404 Page Not Found: /index
ERROR - 2022-03-30 05:26:49 --> 404 Page Not Found: /index
ERROR - 2022-03-30 05:29:19 --> 404 Page Not Found: /index
ERROR - 2022-03-30 05:35:05 --> 404 Page Not Found: /index
ERROR - 2022-03-30 05:41:29 --> 404 Page Not Found: /index
ERROR - 2022-03-30 05:43:38 --> 404 Page Not Found: /index
ERROR - 2022-03-30 05:44:44 --> 404 Page Not Found: /index
ERROR - 2022-03-30 05:47:56 --> 404 Page Not Found: /index
ERROR - 2022-03-30 05:50:35 --> 404 Page Not Found: /index
ERROR - 2022-03-30 05:51:10 --> 404 Page Not Found: /index
ERROR - 2022-03-30 05:57:07 --> 404 Page Not Found: /index
ERROR - 2022-03-30 06:00:47 --> 404 Page Not Found: /index
ERROR - 2022-03-30 06:03:45 --> 404 Page Not Found: /index
ERROR - 2022-03-30 06:04:09 --> 404 Page Not Found: /index
ERROR - 2022-03-30 06:05:07 --> 404 Page Not Found: /index
ERROR - 2022-03-30 06:05:18 --> 404 Page Not Found: /index
ERROR - 2022-03-30 06:05:40 --> 404 Page Not Found: /index
ERROR - 2022-03-30 06:06:49 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-30 06:06:49')
ERROR - 2022-03-30 06:11:10 --> 404 Page Not Found: /index
ERROR - 2022-03-30 06:15:23 --> 404 Page Not Found: /index
ERROR - 2022-03-30 06:17:32 --> 404 Page Not Found: /index
ERROR - 2022-03-30 06:20:50 --> 404 Page Not Found: /index
ERROR - 2022-03-30 06:24:39 --> 404 Page Not Found: /index
ERROR - 2022-03-30 06:25:02 --> 404 Page Not Found: /index
ERROR - 2022-03-30 06:26:01 --> 404 Page Not Found: /index
ERROR - 2022-03-30 06:26:23 --> 404 Page Not Found: /index
ERROR - 2022-03-30 06:27:38 --> 404 Page Not Found: /index
ERROR - 2022-03-30 06:28:14 --> 404 Page Not Found: /index
ERROR - 2022-03-30 06:30:34 --> 404 Page Not Found: /index
ERROR - 2022-03-30 06:30:54 --> 404 Page Not Found: /index
ERROR - 2022-03-30 06:34:19 --> 404 Page Not Found: /index
ERROR - 2022-03-30 06:35:48 --> 404 Page Not Found: /index
ERROR - 2022-03-30 06:36:53 --> 404 Page Not Found: /index
ERROR - 2022-03-30 06:42:30 --> 404 Page Not Found: /index
ERROR - 2022-03-30 06:45:14 --> 404 Page Not Found: /index
ERROR - 2022-03-30 06:45:34 --> 404 Page Not Found: /index
ERROR - 2022-03-30 06:45:47 --> 404 Page Not Found: /index
ERROR - 2022-03-30 06:47:20 --> 404 Page Not Found: /index
ERROR - 2022-03-30 06:49:00 --> 404 Page Not Found: /index
ERROR - 2022-03-30 06:58:15 --> 404 Page Not Found: /index
ERROR - 2022-03-30 06:58:45 --> 404 Page Not Found: /index
ERROR - 2022-03-30 07:01:04 --> 404 Page Not Found: /index
ERROR - 2022-03-30 07:02:08 --> 404 Page Not Found: /index
ERROR - 2022-03-30 07:03:17 --> 404 Page Not Found: /index
ERROR - 2022-03-30 07:04:58 --> 404 Page Not Found: /index
ERROR - 2022-03-30 07:06:07 --> 404 Page Not Found: /index
ERROR - 2022-03-30 07:09:06 --> 404 Page Not Found: /index
ERROR - 2022-03-30 07:09:23 --> 404 Page Not Found: /index
ERROR - 2022-03-30 07:17:18 --> 404 Page Not Found: /index
ERROR - 2022-03-30 07:20:56 --> 404 Page Not Found: /index
ERROR - 2022-03-30 07:24:55 --> 404 Page Not Found: /index
ERROR - 2022-03-30 07:25:04 --> 404 Page Not Found: /index
ERROR - 2022-03-30 07:25:09 --> 404 Page Not Found: /index
ERROR - 2022-03-30 07:28:52 --> 404 Page Not Found: /index
ERROR - 2022-03-30 07:33:38 --> 404 Page Not Found: /index
ERROR - 2022-03-30 07:37:42 --> 404 Page Not Found: /index
ERROR - 2022-03-30 07:37:42 --> 404 Page Not Found: /index
ERROR - 2022-03-30 07:38:16 --> 404 Page Not Found: /index
ERROR - 2022-03-30 07:43:00 --> 404 Page Not Found: /index
ERROR - 2022-03-30 07:44:32 --> 404 Page Not Found: /index
ERROR - 2022-03-30 07:48:00 --> 404 Page Not Found: /index
ERROR - 2022-03-30 07:48:37 --> 404 Page Not Found: /index
ERROR - 2022-03-30 07:48:37 --> 404 Page Not Found: /index
ERROR - 2022-03-30 07:48:38 --> 404 Page Not Found: /index
ERROR - 2022-03-30 07:49:35 --> 404 Page Not Found: /index
ERROR - 2022-03-30 07:50:42 --> 404 Page Not Found: /index
ERROR - 2022-03-30 07:50:51 --> 404 Page Not Found: /index
ERROR - 2022-03-30 07:52:06 --> 404 Page Not Found: /index
ERROR - 2022-03-30 07:52:19 --> 404 Page Not Found: /index
ERROR - 2022-03-30 07:55:57 --> 404 Page Not Found: /index
ERROR - 2022-03-30 07:57:35 --> 404 Page Not Found: /index
ERROR - 2022-03-30 08:00:28 --> 404 Page Not Found: /index
ERROR - 2022-03-30 08:01:22 --> 404 Page Not Found: /index
ERROR - 2022-03-30 08:02:09 --> 404 Page Not Found: /index
ERROR - 2022-03-30 08:03:36 --> 404 Page Not Found: /index
ERROR - 2022-03-30 08:03:58 --> 404 Page Not Found: /index
ERROR - 2022-03-30 08:07:38 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-30 08:07:38')
ERROR - 2022-03-30 08:08:07 --> 404 Page Not Found: /index
ERROR - 2022-03-30 08:08:53 --> 404 Page Not Found: /index
ERROR - 2022-03-30 08:08:55 --> 404 Page Not Found: /index
ERROR - 2022-03-30 08:12:27 --> 404 Page Not Found: /index
ERROR - 2022-03-30 08:13:04 --> 404 Page Not Found: /index
ERROR - 2022-03-30 08:14:00 --> 404 Page Not Found: /index
ERROR - 2022-03-30 08:14:34 --> 404 Page Not Found: /index
ERROR - 2022-03-30 08:15:37 --> 404 Page Not Found: /index
ERROR - 2022-03-30 08:17:08 --> 404 Page Not Found: /index
ERROR - 2022-03-30 08:17:16 --> 404 Page Not Found: /index
ERROR - 2022-03-30 08:17:59 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-30 08:17:59')
ERROR - 2022-03-30 08:18:03 --> 404 Page Not Found: /index
ERROR - 2022-03-30 08:18:49 --> 404 Page Not Found: /index
ERROR - 2022-03-30 08:19:23 --> 404 Page Not Found: /index
ERROR - 2022-03-30 08:19:25 --> 404 Page Not Found: /index
ERROR - 2022-03-30 08:23:25 --> 404 Page Not Found: /index
ERROR - 2022-03-30 08:24:59 --> 404 Page Not Found: /index
ERROR - 2022-03-30 08:26:10 --> 404 Page Not Found: /index
ERROR - 2022-03-30 08:27:15 --> 404 Page Not Found: /index
ERROR - 2022-03-30 08:27:48 --> 404 Page Not Found: /index
ERROR - 2022-03-30 08:28:38 --> 404 Page Not Found: /index
ERROR - 2022-03-30 08:28:55 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-30 08:28:55')
ERROR - 2022-03-30 08:29:18 --> 404 Page Not Found: /index
ERROR - 2022-03-30 08:33:19 --> 404 Page Not Found: /index
ERROR - 2022-03-30 08:35:18 --> 404 Page Not Found: /index
ERROR - 2022-03-30 08:36:45 --> 404 Page Not Found: /index
ERROR - 2022-03-30 08:37:08 --> 404 Page Not Found: /index
ERROR - 2022-03-30 08:40:29 --> 404 Page Not Found: /index
ERROR - 2022-03-30 08:40:57 --> 404 Page Not Found: /index
ERROR - 2022-03-30 08:41:05 --> 404 Page Not Found: /index
ERROR - 2022-03-30 08:41:13 --> 404 Page Not Found: /index
ERROR - 2022-03-30 08:43:58 --> 404 Page Not Found: /index
ERROR - 2022-03-30 08:44:34 --> 404 Page Not Found: /index
ERROR - 2022-03-30 08:45:03 --> 404 Page Not Found: /index
ERROR - 2022-03-30 08:47:14 --> 404 Page Not Found: /index
ERROR - 2022-03-30 08:48:58 --> 404 Page Not Found: /index
ERROR - 2022-03-30 08:52:45 --> 404 Page Not Found: /index
ERROR - 2022-03-30 08:55:30 --> To Id is not available for User - 3740
ERROR - 2022-03-30 08:56:55 --> 404 Page Not Found: /index
ERROR - 2022-03-30 08:57:20 --> 404 Page Not Found: /index
ERROR - 2022-03-30 08:59:12 --> 404 Page Not Found: /index
ERROR - 2022-03-30 09:01:38 --> 404 Page Not Found: /index
ERROR - 2022-03-30 09:02:00 --> 404 Page Not Found: /index
ERROR - 2022-03-30 09:02:41 --> 404 Page Not Found: /index
ERROR - 2022-03-30 09:02:53 --> 404 Page Not Found: /index
ERROR - 2022-03-30 09:03:36 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-30 09:04:10 --> 404 Page Not Found: /index
ERROR - 2022-03-30 09:04:20 --> 404 Page Not Found: /index
ERROR - 2022-03-30 09:07:38 --> 404 Page Not Found: /index
ERROR - 2022-03-30 09:09:02 --> 404 Page Not Found: /index
ERROR - 2022-03-30 09:09:13 --> 404 Page Not Found: /index
ERROR - 2022-03-30 09:09:45 --> 404 Page Not Found: /index
ERROR - 2022-03-30 09:11:38 --> 404 Page Not Found: /index
ERROR - 2022-03-30 09:14:02 --> 404 Page Not Found: /index
ERROR - 2022-03-30 09:15:02 --> 404 Page Not Found: /index
ERROR - 2022-03-30 09:15:06 --> 404 Page Not Found: /index
ERROR - 2022-03-30 09:15:08 --> 404 Page Not Found: /index
ERROR - 2022-03-30 09:16:00 --> 404 Page Not Found: /index
ERROR - 2022-03-30 09:16:30 --> 404 Page Not Found: /index
ERROR - 2022-03-30 09:16:36 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-30 09:18:06 --> 404 Page Not Found: /index
ERROR - 2022-03-30 09:18:20 --> 404 Page Not Found: /index
ERROR - 2022-03-30 09:18:48 --> 404 Page Not Found: /index
ERROR - 2022-03-30 09:19:11 --> 404 Page Not Found: /index
ERROR - 2022-03-30 09:19:21 --> 404 Page Not Found: /index
ERROR - 2022-03-30 09:19:30 --> 404 Page Not Found: /index
ERROR - 2022-03-30 09:20:46 --> 404 Page Not Found: /index
ERROR - 2022-03-30 09:21:29 --> 404 Page Not Found: /index
ERROR - 2022-03-30 09:22:08 --> 404 Page Not Found: /index
ERROR - 2022-03-30 09:23:31 --> 404 Page Not Found: /index
ERROR - 2022-03-30 09:23:56 --> 404 Page Not Found: /index
ERROR - 2022-03-30 09:26:16 --> 404 Page Not Found: /index
ERROR - 2022-03-30 09:27:07 --> 404 Page Not Found: /index
ERROR - 2022-03-30 09:27:12 --> 404 Page Not Found: /index
ERROR - 2022-03-30 09:27:16 --> 404 Page Not Found: /index
ERROR - 2022-03-30 09:27:52 --> 404 Page Not Found: /index
ERROR - 2022-03-30 09:29:40 --> 404 Page Not Found: /index
ERROR - 2022-03-30 09:30:55 --> 404 Page Not Found: /index
ERROR - 2022-03-30 09:31:07 --> 404 Page Not Found: /index
ERROR - 2022-03-30 09:32:06 --> 404 Page Not Found: /index
ERROR - 2022-03-30 09:32:08 --> 404 Page Not Found: /index
ERROR - 2022-03-30 09:32:13 --> 404 Page Not Found: /index
ERROR - 2022-03-30 09:33:13 --> 404 Page Not Found: /index
ERROR - 2022-03-30 09:34:09 --> 404 Page Not Found: /index
ERROR - 2022-03-30 09:34:17 --> 404 Page Not Found: /index
ERROR - 2022-03-30 09:34:26 --> 404 Page Not Found: /index
ERROR - 2022-03-30 09:35:50 --> 404 Page Not Found: /index
ERROR - 2022-03-30 09:36:26 --> 404 Page Not Found: /index
ERROR - 2022-03-30 09:37:19 --> 404 Page Not Found: /index
ERROR - 2022-03-30 09:37:19 --> 404 Page Not Found: /index
ERROR - 2022-03-30 09:37:19 --> 404 Page Not Found: /index
ERROR - 2022-03-30 09:37:27 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-30 09:37:42 --> 404 Page Not Found: /index
ERROR - 2022-03-30 09:37:42 --> 404 Page Not Found: /index
ERROR - 2022-03-30 09:38:19 --> 404 Page Not Found: /index
ERROR - 2022-03-30 09:38:36 --> 404 Page Not Found: /index
ERROR - 2022-03-30 09:39:00 --> 404 Page Not Found: /index
ERROR - 2022-03-30 09:42:42 --> 404 Page Not Found: /index
ERROR - 2022-03-30 09:42:54 --> 404 Page Not Found: /index
ERROR - 2022-03-30 09:42:55 --> 404 Page Not Found: /index
ERROR - 2022-03-30 09:43:46 --> 404 Page Not Found: /index
ERROR - 2022-03-30 09:44:10 --> 404 Page Not Found: /index
ERROR - 2022-03-30 09:44:28 --> 404 Page Not Found: /index
ERROR - 2022-03-30 09:47:17 --> 404 Page Not Found: /index
ERROR - 2022-03-30 09:49:15 --> 404 Page Not Found: /index
ERROR - 2022-03-30 09:49:55 --> 404 Page Not Found: /index
ERROR - 2022-03-30 09:50:53 --> 404 Page Not Found: /index
ERROR - 2022-03-30 09:51:07 --> 404 Page Not Found: /index
ERROR - 2022-03-30 09:51:28 --> 404 Page Not Found: /index
ERROR - 2022-03-30 09:52:02 --> 404 Page Not Found: /index
ERROR - 2022-03-30 09:53:12 --> 404 Page Not Found: /index
ERROR - 2022-03-30 09:53:43 --> 404 Page Not Found: /index
ERROR - 2022-03-30 09:54:21 --> 404 Page Not Found: /index
ERROR - 2022-03-30 09:55:06 --> 404 Page Not Found: /index
ERROR - 2022-03-30 09:55:53 --> 404 Page Not Found: /index
ERROR - 2022-03-30 09:57:09 --> 404 Page Not Found: /index
ERROR - 2022-03-30 09:57:19 --> 404 Page Not Found: /index
ERROR - 2022-03-30 09:57:23 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-30 09:57:39 --> 404 Page Not Found: /index
ERROR - 2022-03-30 09:58:01 --> 404 Page Not Found: /index
ERROR - 2022-03-30 09:58:46 --> 404 Page Not Found: /index
ERROR - 2022-03-30 09:58:52 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:00:07 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:00:27 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:00:30 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:00:41 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-30 10:00:45 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-30 10:02:12 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:02:29 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:02:55 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:03:23 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:03:34 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:04:09 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-30 10:05:50 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:06:21 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:07:34 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:07:46 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:08:59 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:09:23 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-30 10:09:46 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-30 10:09:48 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:10:02 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-30 10:10:13 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-30 10:11:02 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:11:02 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:11:30 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-30 10:11:36 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:11:39 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:13:02 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:13:47 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:14:09 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:14:45 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:15:46 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:16:16 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:16:43 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:16:57 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:17:29 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:17:58 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:18:02 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:18:38 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:19:14 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:21:03 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:21:23 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:21:41 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:21:41 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:21:41 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:21:42 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:21:42 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:21:42 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:21:42 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:21:54 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:21:54 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:22:04 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:23:10 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-30 10:23:38 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:23:59 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:24:58 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:25:30 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-30 10:25:32 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-30 10:26:25 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:26:32 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:26:56 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:26:58 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:27:12 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:27:28 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:27:55 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:28:22 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:28:31 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:29:08 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:29:19 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:29:29 --> To Id is not available for User - 3046
ERROR - 2022-03-30 10:29:38 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:29:38 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:30:38 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:30:44 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-30 10:30:44')
ERROR - 2022-03-30 10:31:27 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:31:33 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:31:43 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:32:08 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:32:46 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:32:48 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:33:12 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:33:13 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:33:30 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:34:25 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:34:43 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:34:52 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:36:10 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:36:15 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:36:33 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-30 10:36:40 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-30 10:36:56 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-30 10:36:58 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-30 10:37:28 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:37:51 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:38:00 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:38:05 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:38:22 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:41:25 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:42:26 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:44:51 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:44:56 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:45:05 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:45:22 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:45:43 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:46:29 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:46:40 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:46:41 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:46:48 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:46:48 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:47:10 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:50:47 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:51:11 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:53:15 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:54:30 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:54:31 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:55:49 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:55:49 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:56:10 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:56:18 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:56:24 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:58:05 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:58:05 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:59:15 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:59:33 --> 404 Page Not Found: /index
ERROR - 2022-03-30 10:59:53 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-30 10:59:53')
ERROR - 2022-03-30 11:00:34 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:01:08 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:01:17 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:01:28 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:01:55 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:02:11 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:02:55 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:03:04 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:04:36 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:04:58 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:05:10 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:05:38 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:06:03 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:07:18 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:07:21 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:07:23 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:08:17 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:08:46 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:08:47 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:10:13 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:10:32 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:11:32 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:11:38 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:13:20 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:13:52 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:14:10 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:14:10 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:14:10 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:14:10 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:14:10 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:14:10 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:14:56 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:16:38 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:17:04 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:17:43 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:18:14 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:18:50 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:18:51 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:18:55 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:19:27 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:21:14 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:21:24 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:21:26 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:21:39 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:23:17 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:23:43 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-30 11:24:09 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:25:22 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-30 11:26:03 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:26:38 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:26:42 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:26:46 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:27:50 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:27:53 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:27:54 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:27:57 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:27:59 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:28:00 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:28:02 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:28:03 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:28:04 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:28:07 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:28:16 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:28:16 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:28:25 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:28:35 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:28:37 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:29:23 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:29:24 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:29:26 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:29:27 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:30:05 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:31:04 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:31:20 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:31:38 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:31:38 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:31:49 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:31:49 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:31:49 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:31:53 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:33:49 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:34:00 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:34:51 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:35:16 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:35:56 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:36:02 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:36:18 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:36:29 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:37:28 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:37:54 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:38:32 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:38:33 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:42:16 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:43:03 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:43:05 --> To Id is not available for User - 2454
ERROR - 2022-03-30 11:43:06 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:43:19 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:43:28 --> To Id is not available for User - 2454
ERROR - 2022-03-30 11:44:34 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:44:56 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:44:56 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:44:56 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:45:12 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:45:40 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:45:59 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
GROUP BY `profileowner`' at line 3 - Invalid query: SELECT *
FROM `ms_profilesetting`
WHERE `ms_id` in()
GROUP BY `profileowner`
ERROR - 2022-03-30 11:45:59 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ')
GROUP BY `profileowner`' at line 3 - Invalid query: SELECT *
FROM `ms_profilesetting`
WHERE `ms_id` in()
GROUP BY `profileowner`
ERROR - 2022-03-30 11:46:03 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-30 11:46:03')
ERROR - 2022-03-30 11:46:10 --> To Id is not available for User - 2454
ERROR - 2022-03-30 11:47:14 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:47:39 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:47:47 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:49:20 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:51:29 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:54:38 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:55:35 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:56:09 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:57:01 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:57:17 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:57:33 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:58:06 --> 404 Page Not Found: /index
ERROR - 2022-03-30 11:58:12 --> 404 Page Not Found: /index
ERROR - 2022-03-30 12:00:56 --> 404 Page Not Found: /index
ERROR - 2022-03-30 12:03:27 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-30 12:05:19 --> 404 Page Not Found: /index
ERROR - 2022-03-30 12:05:20 --> 404 Page Not Found: /index
ERROR - 2022-03-30 12:05:28 --> 404 Page Not Found: /index
ERROR - 2022-03-30 12:05:32 --> 404 Page Not Found: /index
ERROR - 2022-03-30 12:06:34 --> 404 Page Not Found: /index
ERROR - 2022-03-30 12:07:12 --> 404 Page Not Found: /index
ERROR - 2022-03-30 12:07:43 --> 404 Page Not Found: /index
ERROR - 2022-03-30 12:07:55 --> 404 Page Not Found: /index
ERROR - 2022-03-30 12:08:29 --> 404 Page Not Found: /index
ERROR - 2022-03-30 12:08:35 --> 404 Page Not Found: /index
ERROR - 2022-03-30 12:09:07 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-30 12:09:07')
ERROR - 2022-03-30 12:09:20 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-30 12:09:20')
ERROR - 2022-03-30 12:09:20 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-30 12:09:20')
ERROR - 2022-03-30 12:09:26 --> 404 Page Not Found: /index
ERROR - 2022-03-30 12:09:43 --> 404 Page Not Found: /index
ERROR - 2022-03-30 12:10:18 --> 404 Page Not Found: /index
ERROR - 2022-03-30 12:10:25 --> 404 Page Not Found: /index
ERROR - 2022-03-30 12:12:27 --> 404 Page Not Found: /index
ERROR - 2022-03-30 12:13:06 --> 404 Page Not Found: /index
ERROR - 2022-03-30 12:13:07 --> 404 Page Not Found: /index
ERROR - 2022-03-30 12:13:16 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-30 12:13:53 --> Query error: Column 'user_id' cannot be null - Invalid query: INSERT INTO `tbl_professional_info` (`user_id`, `employee_in`, `occupation`, `currency`, `annual_income`, `company`, `about_profession`, `country`, `state`, `city`, `visatype`, `residing-since`, `arrival-date`, `departure-date`, `status`, `created_time`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 1, '2022-03-30 12:13:53')
ERROR - 2022-03-30 12:13:58 --> Query error: Column 'user_id' cannot be null - Invalid query: INSERT INTO `tbl_brother_info` (`user_id`, `brother_type`, `brother_name`, `brother_education`, `brother_profession`, `brother_joblocation`, `brother_mobile`, `brother_email`, `married_type`, `wife_name`, `wife_education`, `wife_profession_category`, `brother_wife_designation`, `wife_joblocation`, `wife_father_contact`, `wife_father_nativeplace`, `created_at`, `created_by`, `status`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2022-03-30 12:13:58', 'Baby rani', 1)
ERROR - 2022-03-30 12:14:16 --> 404 Page Not Found: /index
ERROR - 2022-03-30 12:14:42 --> 404 Page Not Found: /index
ERROR - 2022-03-30 12:14:47 --> 404 Page Not Found: /index
ERROR - 2022-03-30 12:15:08 --> 404 Page Not Found: /index
ERROR - 2022-03-30 12:15:43 --> 404 Page Not Found: /index
ERROR - 2022-03-30 12:16:22 --> 404 Page Not Found: /index
ERROR - 2022-03-30 12:17:32 --> 404 Page Not Found: /index
ERROR - 2022-03-30 12:17:35 --> 404 Page Not Found: /index
ERROR - 2022-03-30 12:17:44 --> 404 Page Not Found: /index
ERROR - 2022-03-30 12:17:44 --> 404 Page Not Found: /index
ERROR - 2022-03-30 12:19:12 --> 404 Page Not Found: /index
ERROR - 2022-03-30 12:21:13 --> 404 Page Not Found: /index
ERROR - 2022-03-30 12:24:53 --> 404 Page Not Found: /index
ERROR - 2022-03-30 12:25:52 --> 404 Page Not Found: /index
ERROR - 2022-03-30 12:26:34 --> 404 Page Not Found: /index
ERROR - 2022-03-30 12:27:26 --> 404 Page Not Found: /index
ERROR - 2022-03-30 12:28:08 --> 404 Page Not Found: /index
ERROR - 2022-03-30 12:28:30 --> 404 Page Not Found: /index
ERROR - 2022-03-30 12:28:35 --> 404 Page Not Found: /index
ERROR - 2022-03-30 12:31:01 --> 404 Page Not Found: /index
ERROR - 2022-03-30 12:32:36 --> 404 Page Not Found: /index
ERROR - 2022-03-30 12:32:59 --> 404 Page Not Found: /index
ERROR - 2022-03-30 12:33:57 --> 404 Page Not Found: /index
ERROR - 2022-03-30 12:34:04 --> 404 Page Not Found: /index
ERROR - 2022-03-30 12:36:20 --> 404 Page Not Found: /index
ERROR - 2022-03-30 12:37:31 --> 404 Page Not Found: /index
ERROR - 2022-03-30 12:37:53 --> 404 Page Not Found: /index
ERROR - 2022-03-30 12:37:54 --> 404 Page Not Found: /index
ERROR - 2022-03-30 12:38:23 --> 404 Page Not Found: /index
ERROR - 2022-03-30 12:38:37 --> 404 Page Not Found: /index
ERROR - 2022-03-30 12:38:37 --> 404 Page Not Found: /index
ERROR - 2022-03-30 12:41:45 --> 404 Page Not Found: /index
ERROR - 2022-03-30 12:41:45 --> 404 Page Not Found: /index
ERROR - 2022-03-30 12:42:06 --> 404 Page Not Found: /index
ERROR - 2022-03-30 12:42:21 --> 404 Page Not Found: /index
ERROR - 2022-03-30 12:42:51 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-30 12:42:52 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-30 12:42:53 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-30 12:43:10 --> 404 Page Not Found: /index
ERROR - 2022-03-30 12:43:17 --> 404 Page Not Found: /index
ERROR - 2022-03-30 12:44:29 --> 404 Page Not Found: /index
ERROR - 2022-03-30 12:46:33 --> 404 Page Not Found: /index
ERROR - 2022-03-30 12:47:33 --> 404 Page Not Found: /index
ERROR - 2022-03-30 12:47:33 --> 404 Page Not Found: /index
ERROR - 2022-03-30 12:47:33 --> 404 Page Not Found: /index
ERROR - 2022-03-30 12:48:29 --> 404 Page Not Found: /index
ERROR - 2022-03-30 12:49:30 --> 404 Page Not Found: /index
ERROR - 2022-03-30 12:49:58 --> Query error: Column 'education_degree' cannot be null - Invalid query: INSERT INTO `tbl_professional_info` (`user_id`, `heighst_education`, `education_degree`, `specialization`, `university`, `college`, `education_description`, `employee_in`, `occupation`, `currency`, `annual_income`, `company`, `about_profession`, `country`, `state`, `city`, `about_me`, `visatype`, `residing-since`, `arrival-date`, `departure-date`, `status`, `created_time`) VALUES (4450, 'Masters in Engineering', NULL, NULL, '', 'S.I.U.C,  In USA', '', 'Private', 'Engineer', 'US', '', '', 'Software Engineer ', 'USA', '', 'CISCO', '', '', '', '', '', 1, '2022-03-30 12:49:58')
ERROR - 2022-03-30 12:50:09 --> Query error: Column 'education_degree' cannot be null - Invalid query: INSERT INTO `tbl_professional_info` (`user_id`, `heighst_education`, `education_degree`, `specialization`, `university`, `college`, `education_description`, `employee_in`, `occupation`, `currency`, `annual_income`, `company`, `about_profession`, `country`, `state`, `city`, `about_me`, `visatype`, `residing-since`, `arrival-date`, `departure-date`, `status`, `created_time`) VALUES (4450, 'Masters in Engineering', NULL, NULL, '', 'S.I.U.C,  In USA', '', 'Private', 'Engineer', 'US', '', '', 'Software Engineer ', 'USA', '', 'CISCO', '', '', '', '', '', 1, '2022-03-30 12:50:09')
ERROR - 2022-03-30 12:50:15 --> Query error: Column 'education_degree' cannot be null - Invalid query: INSERT INTO `tbl_professional_info` (`user_id`, `heighst_education`, `education_degree`, `specialization`, `university`, `college`, `education_description`, `employee_in`, `occupation`, `currency`, `annual_income`, `company`, `about_profession`, `country`, `state`, `city`, `about_me`, `visatype`, `residing-since`, `arrival-date`, `departure-date`, `status`, `created_time`) VALUES (4450, 'Masters in Engineering', NULL, NULL, '', 'S.I.U.C,  In USA', '', 'Private', 'Engineer', 'US', '', '', 'Software Engineer ', 'USA', '', 'CISCO', '', '', '', '', '', 1, '2022-03-30 12:50:15')
ERROR - 2022-03-30 12:50:21 --> Query error: Column 'education_degree' cannot be null - Invalid query: INSERT INTO `tbl_professional_info` (`user_id`, `heighst_education`, `education_degree`, `specialization`, `university`, `college`, `education_description`, `employee_in`, `occupation`, `currency`, `annual_income`, `company`, `about_profession`, `country`, `state`, `city`, `about_me`, `visatype`, `residing-since`, `arrival-date`, `departure-date`, `status`, `created_time`) VALUES (4450, 'Masters in Engineering', NULL, NULL, '', 'S.I.U.C,  In USA', '', 'Private', 'Engineer', 'US', '', '', 'Software Engineer ', 'USA', '', 'CISCO', '', '', '', '', '', 1, '2022-03-30 12:50:21')
ERROR - 2022-03-30 12:50:29 --> 404 Page Not Found: /index
ERROR - 2022-03-30 12:50:53 --> 404 Page Not Found: /index
ERROR - 2022-03-30 12:51:24 --> 404 Page Not Found: /index
ERROR - 2022-03-30 12:52:26 --> 404 Page Not Found: /index
ERROR - 2022-03-30 12:52:33 --> 404 Page Not Found: /index
ERROR - 2022-03-30 12:52:33 --> 404 Page Not Found: /index
ERROR - 2022-03-30 12:53:53 --> 404 Page Not Found: /index
ERROR - 2022-03-30 12:54:14 --> 404 Page Not Found: /index
ERROR - 2022-03-30 12:55:55 --> 404 Page Not Found: /index
ERROR - 2022-03-30 12:56:01 --> 404 Page Not Found: /index
ERROR - 2022-03-30 12:56:32 --> 404 Page Not Found: /index
ERROR - 2022-03-30 12:56:42 --> 404 Page Not Found: /index
ERROR - 2022-03-30 12:57:19 --> 404 Page Not Found: /index
ERROR - 2022-03-30 12:57:45 --> 404 Page Not Found: /index
ERROR - 2022-03-30 12:57:57 --> 404 Page Not Found: /index
ERROR - 2022-03-30 12:58:25 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:00:08 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:00:23 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:01:53 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:02:05 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:02:28 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:02:41 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:02:57 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:03:20 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:04:37 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:05:12 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:05:56 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:07:03 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:08:46 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:10:26 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:10:54 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:11:12 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:11:18 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:11:42 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:11:45 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:12:12 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:12:12 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:12:12 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:12:43 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:12:56 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:13:42 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:13:56 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:14:21 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:15:19 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:16:51 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:17:33 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:17:53 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:17:56 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:18:55 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:19:30 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:19:31 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:19:31 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:19:41 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:21:07 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:21:28 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:22:15 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:23:00 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:23:21 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:23:48 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:24:42 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:25:24 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:25:56 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:26:50 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:27:04 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:27:32 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:27:32 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:28:16 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:28:16 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:28:16 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:28:26 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:28:34 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:28:34 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:29:45 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-30 13:29:46 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-30 13:29:54 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:31:04 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:31:16 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:33:16 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:33:23 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:33:25 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:33:26 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:34:35 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:34:39 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-30 13:34:39')
ERROR - 2022-03-30 13:35:26 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:36:19 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:36:57 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:37:50 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:38:14 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:38:23 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '<script>alert("xssvuln")</script> AND <script>alert("xssvuln") < `/script>`
AND ' at line 8 - Invalid query: SELECT `p`.`gender`, `p`.`id`, `p`.`status`, `p`.`age`, `p`.`living_in`, `p`.`profile_id`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`
FROM `tbl_primary_info` as `p`
INNER JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`MS_id`
INNER JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
INNER JOIN `ms_profilesetting` as `s` ON `p`.`id`=`s`.`ms_id`
WHERE `p`.`gender` = '<script>alert(\"xssvuln\")</script>'
AND `p`.`age` BETWEEN <script>alert("xssvuln")</script> AND <script>alert("xssvuln") < `/script>`
AND `r`.`religion` = '<script>alert(\"xssvuln\")</script>'
AND `r`.`mother_tounge` = '<script>alert(\"xssvuln\")</script>'
AND `p`.`status` = 1
AND `s`.`elite` = 'no'
AND `s`.`ms_usertype` = 'regular'
AND `u`.`ismain` = 1
AND `u`.`photoname` != ''
AND `u`.`applicationphotopath` != ''
GROUP BY `u`.`MS_id`
ORDER BY `registered_on` DESC
 LIMIT 8
ERROR - 2022-03-30 13:38:36 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:38:52 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-30 13:39:06 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:39:33 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:41:30 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:43:10 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:43:55 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:45:04 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:45:31 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:47:02 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:47:07 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:47:09 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:48:04 --> To Id is not available for User - 3046
ERROR - 2022-03-30 13:48:06 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:48:09 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:48:29 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:48:52 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:48:58 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:50:18 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:50:49 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:51:27 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:53:24 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:53:38 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:53:50 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:53:51 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:53:51 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:54:04 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:54:13 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:54:30 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:54:32 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:55:01 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:55:55 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:56:55 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:57:20 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:57:26 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:58:12 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:58:13 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:58:48 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:59:04 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:59:22 --> 404 Page Not Found: /index
ERROR - 2022-03-30 13:59:36 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:00:19 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:01:51 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:02:29 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:02:33 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:03:53 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:04:56 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:05:14 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:05:28 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:05:35 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:05:58 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:06:18 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:06:31 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:07:06 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:08:05 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:08:34 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:09:11 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:09:57 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:09:58 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:09:58 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:12:44 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:12:52 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:13:43 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:13:55 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:13:57 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:14:42 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:15:36 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:15:47 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:15:47 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:17:02 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:17:29 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:17:50 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:17:58 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:18:05 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:18:40 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:19:52 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:21:37 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:21:41 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:22:26 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:22:37 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:22:54 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:22:57 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:23:06 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:23:24 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:24:01 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:24:07 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:24:20 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:25:14 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:26:12 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:26:16 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:26:18 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:28:02 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:28:41 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:29:42 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:29:49 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:31:15 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:31:45 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:32:26 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-30 14:32:26')
ERROR - 2022-03-30 14:32:29 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:32:43 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:33:38 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:34:08 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:34:08 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:34:35 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:34:38 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:35:17 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:35:18 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:35:23 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:35:23 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:35:34 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:35:46 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:36:25 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:36:26 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:36:48 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:38:17 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-30 14:38:17')
ERROR - 2022-03-30 14:38:20 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:38:41 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:41:35 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:42:01 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:42:02 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:42:03 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:42:12 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:42:19 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-30 14:42:19')
ERROR - 2022-03-30 14:42:21 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:44:07 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:44:28 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:46:54 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:47:43 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:47:54 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:48:34 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:49:03 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-30 14:49:08 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-30 14:49:21 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:50:17 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-30 14:50:55 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:51:03 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-30 14:51:06 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:51:16 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:51:22 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:51:23 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:51:23 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:51:35 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:51:36 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:52:00 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:52:28 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-30 14:52:34 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:52:46 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:52:54 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-30 14:52:54')
ERROR - 2022-03-30 14:53:06 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-30 14:53:19 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:53:46 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:54:01 --> To Id is not available for User - 85
ERROR - 2022-03-30 14:54:12 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:54:20 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:55:26 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:56:20 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:56:32 --> Severity: error --> Exception: Invalid address:  (to):  /home4/cowcdrmy/public_html/application/third_party/phpmailer/src/PHPMailer.php 1092
ERROR - 2022-03-30 14:57:40 --> 404 Page Not Found: /index
ERROR - 2022-03-30 14:59:04 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:00:39 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:01:34 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:01:46 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-30 15:02:55 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:04:02 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:06:37 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:06:42 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:07:15 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:08:07 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:08:27 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:08:33 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:09:59 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:10:27 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-30 15:10:27')
ERROR - 2022-03-30 15:11:39 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:11:54 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:12:50 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:12:50 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:13:40 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:14:16 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:14:37 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:14:37 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:14:39 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:14:58 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:15:02 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:15:23 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:15:40 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:15:41 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:15:43 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:15:46 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:15:59 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:17:08 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:17:09 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:17:23 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:17:23 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:17:23 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:17:33 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:17:33 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:17:53 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:17:54 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:18:05 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:18:14 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:18:14 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:19:37 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:19:53 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:20:00 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:20:01 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:21:02 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:22:17 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:22:35 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:23:30 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:24:07 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:25:23 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:25:24 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:25:25 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:26:58 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-30 15:27:49 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:27:50 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:27:52 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:27:52 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:29:15 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:29:22 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:31:18 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:31:37 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:32:43 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:32:46 --> Severity: error --> Exception: Invalid address:  (to):  /home4/cowcdrmy/public_html/application/third_party/phpmailer/src/PHPMailer.php 1092
ERROR - 2022-03-30 15:32:47 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:33:58 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:34:43 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:34:58 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:35:51 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:36:07 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:36:10 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:36:10 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:36:13 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:36:25 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:36:43 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:38:01 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:38:23 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:38:42 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:39:54 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:40:02 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:40:02 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:40:03 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:40:25 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:40:25 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:40:25 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:41:10 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:41:40 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:41:48 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:41:48 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:41:55 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:42:12 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:42:32 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:42:33 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:42:34 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:43:22 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:43:22 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:43:23 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:43:43 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:44:15 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:44:22 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:44:37 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:45:03 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:47:16 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:48:01 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:48:38 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:50:30 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:51:21 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:51:48 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:51:58 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:52:26 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:53:25 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:54:13 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:54:28 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:54:35 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:55:05 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:55:12 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:55:26 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:55:58 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:55:59 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:56:27 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:58:00 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:58:23 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:58:24 --> 404 Page Not Found: /index
ERROR - 2022-03-30 15:59:08 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:00:08 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:00:09 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:01:30 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:01:30 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:01:30 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:03:08 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:03:13 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:03:21 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:03:27 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:03:35 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:04:18 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:05:42 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:06:03 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:06:22 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:07:48 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:09:27 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:09:58 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:10:52 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:11:29 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:11:45 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:15:43 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:17:01 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:17:16 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:17:37 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:18:16 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:18:47 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:19:23 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:19:35 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:21:12 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:21:15 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:21:44 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:22:37 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:22:54 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:23:32 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:23:59 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:23:59 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:24:13 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:24:28 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:24:46 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:24:53 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:25:09 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:25:17 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:25:22 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:25:34 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:27:31 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:27:42 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:27:47 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:27:54 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:28:12 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:28:14 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:28:31 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:28:32 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:29:27 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:30:34 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:31:03 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:31:10 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:31:16 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:31:26 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:31:56 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:32:19 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:32:19 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:32:54 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-30 16:33:34 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:34:10 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:34:28 --> Severity: error --> Exception: Invalid address:  (to): Gogineni @gmail.com /home4/cowcdrmy/public_html/application/third_party/phpmailer/src/PHPMailer.php 1157
ERROR - 2022-03-30 16:35:06 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:35:42 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:36:09 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:36:14 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:36:20 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:36:27 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:37:08 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:37:49 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:38:58 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:40:16 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:40:53 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:42:29 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:42:36 --> To Id is not available for User - 2006
ERROR - 2022-03-30 16:43:03 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:43:28 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-30 16:43:31 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-30 16:43:36 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-30 16:44:59 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:45:21 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:45:42 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:46:51 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:47:00 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:47:27 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:47:31 --> Severity: error --> Exception: Invalid address:  (to):  /home4/cowcdrmy/public_html/application/third_party/phpmailer/src/PHPMailer.php 1092
ERROR - 2022-03-30 16:48:07 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:48:23 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:48:49 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:49:21 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:49:21 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:50:40 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:51:51 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:51:53 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:52:39 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:53:24 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:53:39 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:54:02 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:54:43 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:55:37 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:55:42 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:56:41 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:56:55 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:57:33 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:57:33 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:57:37 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:57:54 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:59:22 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:59:41 --> 404 Page Not Found: /index
ERROR - 2022-03-30 16:59:42 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:00:34 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT `p`.*, `r`.`caste`, `r`.`height`, `r`.`star`, `r`.`time_of_birth`, `r`.`raasi`, `prp`.`property_value`, `e`.`occupation`, `e`.`education_degree`, `e`.`visatype`, `e`.`city`, `e`.`country`, `e`.`annual_income`, `pfs`.`payment_status`, `pfs`.`profilesetting_id` as `pfs_id`, `pfs`.`last_call_updated`, `adm`.`username` as `profile_owner`
FROM `tbl_primary_info` as `p`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `ms_property_info` as `prp` ON `p`.`id`=`prp`.`ms_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `ms_profilesetting` as `pfs` ON `p`.`id`=`pfs`.`ms_id`
LEFT JOIN `tbl_admin_data` as `adm` ON `pfs`.`profileowner`=`adm`.`id`
WHERE `p`.`gender` = 'female'
AND `p`.`status` = '1'
AND `r`.`caste` = `Array`
AND `adm`.`id` = '15'
GROUP BY `p`.`id`
ERROR - 2022-03-30 17:00:36 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT `p`.*, `r`.`caste`, `r`.`height`, `r`.`star`, `r`.`time_of_birth`, `r`.`raasi`, `prp`.`property_value`, `e`.`occupation`, `e`.`education_degree`, `e`.`visatype`, `e`.`city`, `e`.`country`, `e`.`annual_income`, `pfs`.`payment_status`, `pfs`.`profilesetting_id` as `pfs_id`, `pfs`.`last_call_updated`, `adm`.`username` as `profile_owner`
FROM `tbl_primary_info` as `p`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `ms_property_info` as `prp` ON `p`.`id`=`prp`.`ms_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `ms_profilesetting` as `pfs` ON `p`.`id`=`pfs`.`ms_id`
LEFT JOIN `tbl_admin_data` as `adm` ON `pfs`.`profileowner`=`adm`.`id`
WHERE `p`.`gender` = 'female'
AND `p`.`status` = '1'
AND `r`.`caste` = `Array`
AND `adm`.`id` = '15'
GROUP BY `p`.`id`
ERROR - 2022-03-30 17:00:38 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT `p`.*, `r`.`caste`, `r`.`height`, `r`.`star`, `r`.`time_of_birth`, `r`.`raasi`, `prp`.`property_value`, `e`.`occupation`, `e`.`education_degree`, `e`.`visatype`, `e`.`city`, `e`.`country`, `e`.`annual_income`, `pfs`.`payment_status`, `pfs`.`profilesetting_id` as `pfs_id`, `pfs`.`last_call_updated`, `adm`.`username` as `profile_owner`
FROM `tbl_primary_info` as `p`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `ms_property_info` as `prp` ON `p`.`id`=`prp`.`ms_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `ms_profilesetting` as `pfs` ON `p`.`id`=`pfs`.`ms_id`
LEFT JOIN `tbl_admin_data` as `adm` ON `pfs`.`profileowner`=`adm`.`id`
WHERE `p`.`gender` = 'female'
AND `p`.`status` = '1'
AND `r`.`caste` = `Array`
AND `adm`.`id` = '15'
GROUP BY `p`.`id`
ERROR - 2022-03-30 17:00:43 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:01:51 --> Severity: error --> Exception: Call to undefined method My_account_model::from() /home4/cowcdrmy/public_html/application/modules/dashboard/models/My_account_model.php 849
ERROR - 2022-03-30 17:01:52 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:01:55 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:02:18 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:03:15 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:04:33 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:04:33 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:04:34 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:05:12 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:06:12 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:06:37 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:06:44 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:07:39 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:08:46 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:09:44 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:10:05 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:10:14 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:11:14 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:12:21 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:12:31 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:13:40 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-30 17:13:40')
ERROR - 2022-03-30 17:14:43 --> To Id is not available for User - 1326
ERROR - 2022-03-30 17:15:34 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:16:45 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:16:49 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:17:22 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:18:20 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:18:59 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:19:19 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:19:49 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:19:58 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:20:10 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:20:48 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:20:54 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:21:04 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:21:22 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:21:52 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:22:07 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:23:39 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:23:44 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:24:23 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:24:37 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:25:04 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:25:07 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:25:52 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:25:58 --> To Id is not available for User - 4051
ERROR - 2022-03-30 17:26:01 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:27:43 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:27:51 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:28:06 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:28:09 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:28:10 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:28:29 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:29:09 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:29:19 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:29:26 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:29:27 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:29:37 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:29:43 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:30:06 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:30:49 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:31:19 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:31:47 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:31:59 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:32:39 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:33:05 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:33:40 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:33:50 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:34:49 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:35:22 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:36:59 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:37:36 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:42:02 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:43:01 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:43:03 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:43:15 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:44:20 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:46:03 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:46:52 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:48:54 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:49:24 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:49:28 --> Severity: error --> Exception: Invalid address:  (to):  /home4/cowcdrmy/public_html/application/third_party/phpmailer/src/PHPMailer.php 1092
ERROR - 2022-03-30 17:49:31 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:50:13 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:50:26 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:51:03 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-30 17:51:03')
ERROR - 2022-03-30 17:51:10 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:52:11 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:53:08 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:53:14 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:53:46 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:55:20 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:55:44 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:55:44 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:57:00 --> 404 Page Not Found: /index
ERROR - 2022-03-30 17:59:30 --> 404 Page Not Found: /index
ERROR - 2022-03-30 18:01:58 --> Severity: error --> Exception: Invalid address:  (to):  /home4/cowcdrmy/public_html/application/third_party/phpmailer/src/PHPMailer.php 1092
ERROR - 2022-03-30 18:02:33 --> 404 Page Not Found: /index
ERROR - 2022-03-30 18:02:48 --> 404 Page Not Found: /index
ERROR - 2022-03-30 18:02:49 --> 404 Page Not Found: /index
ERROR - 2022-03-30 18:02:49 --> 404 Page Not Found: /index
ERROR - 2022-03-30 18:05:38 --> To Id is not available for User - 3046
ERROR - 2022-03-30 18:05:42 --> 404 Page Not Found: /index
ERROR - 2022-03-30 18:09:35 --> 404 Page Not Found: /index
ERROR - 2022-03-30 18:10:13 --> 404 Page Not Found: /index
ERROR - 2022-03-30 18:12:04 --> To Id is not available for User - 4361
ERROR - 2022-03-30 18:12:59 --> To Id is not available for User - 4352
ERROR - 2022-03-30 18:13:00 --> 404 Page Not Found: /index
ERROR - 2022-03-30 18:14:02 --> 404 Page Not Found: /index
ERROR - 2022-03-30 18:14:12 --> 404 Page Not Found: /index
ERROR - 2022-03-30 18:14:57 --> 404 Page Not Found: /index
ERROR - 2022-03-30 18:15:35 --> To Id is not available for User - 4253
ERROR - 2022-03-30 18:16:41 --> To Id is not available for User - 4215
ERROR - 2022-03-30 18:17:52 --> 404 Page Not Found: /index
ERROR - 2022-03-30 18:20:07 --> 404 Page Not Found: /index
ERROR - 2022-03-30 18:20:07 --> 404 Page Not Found: /index
ERROR - 2022-03-30 18:20:07 --> 404 Page Not Found: /index
ERROR - 2022-03-30 18:20:09 --> 404 Page Not Found: /index
ERROR - 2022-03-30 18:20:10 --> 404 Page Not Found: /index
ERROR - 2022-03-30 18:20:10 --> 404 Page Not Found: /index
ERROR - 2022-03-30 18:20:11 --> 404 Page Not Found: /index
ERROR - 2022-03-30 18:20:47 --> 404 Page Not Found: /index
ERROR - 2022-03-30 18:21:50 --> 404 Page Not Found: /index
ERROR - 2022-03-30 18:21:50 --> 404 Page Not Found: /index
ERROR - 2022-03-30 18:21:50 --> 404 Page Not Found: /index
ERROR - 2022-03-30 18:21:52 --> 404 Page Not Found: /index
ERROR - 2022-03-30 18:21:53 --> 404 Page Not Found: /index
ERROR - 2022-03-30 18:21:53 --> 404 Page Not Found: /index
ERROR - 2022-03-30 18:24:09 --> 404 Page Not Found: /index
ERROR - 2022-03-30 18:24:10 --> 404 Page Not Found: /index
ERROR - 2022-03-30 18:25:07 --> 404 Page Not Found: /index
ERROR - 2022-03-30 18:25:07 --> 404 Page Not Found: /index
ERROR - 2022-03-30 18:25:14 --> 404 Page Not Found: /index
ERROR - 2022-03-30 18:26:32 --> 404 Page Not Found: /index
ERROR - 2022-03-30 18:27:44 --> To Id is not available for User - 4361
ERROR - 2022-03-30 18:27:47 --> 404 Page Not Found: /index
ERROR - 2022-03-30 18:28:02 --> To Id is not available for User - 4352
ERROR - 2022-03-30 18:28:11 --> To Id is not available for User - 4253
ERROR - 2022-03-30 18:28:22 --> To Id is not available for User - 4215
ERROR - 2022-03-30 18:30:31 --> 404 Page Not Found: /index
ERROR - 2022-03-30 18:30:42 --> 404 Page Not Found: /index
ERROR - 2022-03-30 18:30:50 --> 404 Page Not Found: /index
ERROR - 2022-03-30 18:31:36 --> 404 Page Not Found: /index
ERROR - 2022-03-30 18:31:40 --> 404 Page Not Found: /index
ERROR - 2022-03-30 18:31:42 --> 404 Page Not Found: /index
ERROR - 2022-03-30 18:31:42 --> 404 Page Not Found: /index
ERROR - 2022-03-30 18:31:42 --> 404 Page Not Found: /index
ERROR - 2022-03-30 18:31:43 --> 404 Page Not Found: /index
ERROR - 2022-03-30 18:31:43 --> 404 Page Not Found: /index
ERROR - 2022-03-30 18:31:43 --> 404 Page Not Found: /index
ERROR - 2022-03-30 18:31:44 --> 404 Page Not Found: /index
ERROR - 2022-03-30 18:31:44 --> 404 Page Not Found: /index
ERROR - 2022-03-30 18:31:44 --> 404 Page Not Found: /index
ERROR - 2022-03-30 18:31:44 --> 404 Page Not Found: /index
ERROR - 2022-03-30 18:31:45 --> 404 Page Not Found: /index
ERROR - 2022-03-30 18:31:45 --> 404 Page Not Found: /index
ERROR - 2022-03-30 18:33:42 --> 404 Page Not Found: /index
ERROR - 2022-03-30 18:34:10 --> 404 Page Not Found: /index
ERROR - 2022-03-30 18:34:23 --> 404 Page Not Found: /index
ERROR - 2022-03-30 18:34:32 --> 404 Page Not Found: /index
ERROR - 2022-03-30 18:34:37 --> 404 Page Not Found: /index
ERROR - 2022-03-30 18:35:06 --> 404 Page Not Found: /index
ERROR - 2022-03-30 18:35:49 --> 404 Page Not Found: /index
ERROR - 2022-03-30 18:36:42 --> 404 Page Not Found: /index
ERROR - 2022-03-30 18:36:59 --> 404 Page Not Found: /index
ERROR - 2022-03-30 18:38:14 --> 404 Page Not Found: /index
ERROR - 2022-03-30 18:41:22 --> 404 Page Not Found: /index
ERROR - 2022-03-30 18:41:29 --> 404 Page Not Found: /index
ERROR - 2022-03-30 18:43:58 --> 404 Page Not Found: /index
ERROR - 2022-03-30 18:43:59 --> 404 Page Not Found: /index
ERROR - 2022-03-30 18:44:01 --> 404 Page Not Found: /index
ERROR - 2022-03-30 18:46:17 --> 404 Page Not Found: /index
ERROR - 2022-03-30 18:46:37 --> 404 Page Not Found: /index
ERROR - 2022-03-30 18:47:15 --> 404 Page Not Found: /index
ERROR - 2022-03-30 18:50:28 --> 404 Page Not Found: /index
ERROR - 2022-03-30 18:52:49 --> 404 Page Not Found: /index
ERROR - 2022-03-30 18:54:30 --> 404 Page Not Found: /index
ERROR - 2022-03-30 18:54:39 --> 404 Page Not Found: /index
ERROR - 2022-03-30 18:55:23 --> 404 Page Not Found: /index
ERROR - 2022-03-30 18:55:30 --> 404 Page Not Found: /index
ERROR - 2022-03-30 18:55:36 --> 404 Page Not Found: /index
ERROR - 2022-03-30 18:55:50 --> 404 Page Not Found: /index
ERROR - 2022-03-30 18:57:10 --> To Id is not available for User - 3046
ERROR - 2022-03-30 18:57:14 --> 404 Page Not Found: /index
ERROR - 2022-03-30 18:59:00 --> 404 Page Not Found: /index
ERROR - 2022-03-30 19:00:15 --> 404 Page Not Found: /index
ERROR - 2022-03-30 19:04:11 --> 404 Page Not Found: /index
ERROR - 2022-03-30 19:06:57 --> 404 Page Not Found: /index
ERROR - 2022-03-30 19:07:22 --> 404 Page Not Found: /index
ERROR - 2022-03-30 19:07:52 --> 404 Page Not Found: /index
ERROR - 2022-03-30 19:08:13 --> 404 Page Not Found: /index
ERROR - 2022-03-30 19:10:13 --> 404 Page Not Found: /index
ERROR - 2022-03-30 19:10:16 --> 404 Page Not Found: /index
ERROR - 2022-03-30 19:11:09 --> 404 Page Not Found: /index
ERROR - 2022-03-30 19:11:11 --> 404 Page Not Found: /index
ERROR - 2022-03-30 19:11:12 --> 404 Page Not Found: /index
ERROR - 2022-03-30 19:11:26 --> 404 Page Not Found: /index
ERROR - 2022-03-30 19:11:57 --> 404 Page Not Found: /index
ERROR - 2022-03-30 19:12:26 --> 404 Page Not Found: /index
ERROR - 2022-03-30 19:16:36 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: select SUM(IFNULL(`basicdetails`, 0) + IFNULL(`religion`, 0) + IFNULL(`edu_prof`, 0) + IFNULL(`parents`, 0) + IFNULL(`Siblings`, 0) + IFNULL(`photo`, 0)) as total,photo,basicdetails,religion,edu_prof,parents,Siblings from tbl_profilebattery where user_id=
ERROR - 2022-03-30 19:16:37 --> 404 Page Not Found: /index
ERROR - 2022-03-30 19:16:37 --> 404 Page Not Found: /index
ERROR - 2022-03-30 19:16:38 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: select SUM(IFNULL(`basicdetails`, 0) + IFNULL(`religion`, 0) + IFNULL(`edu_prof`, 0) + IFNULL(`parents`, 0) + IFNULL(`Siblings`, 0) + IFNULL(`photo`, 0)) as total,photo,basicdetails,religion,edu_prof,parents,Siblings from tbl_profilebattery where user_id=
ERROR - 2022-03-30 19:16:55 --> 404 Page Not Found: ../modules/admin/controllers/Admin_ap/confidentialprofiles
ERROR - 2022-03-30 19:17:13 --> 404 Page Not Found: /index
ERROR - 2022-03-30 19:17:35 --> Query error: Table 'cowcdrmy_kammamarriage.ms_shortlist_viewedd_ignored' doesn't exist - Invalid query: SELECT `v`.*, `p`.`gender`, `p`.`id`, `p`.`status`, `p`.`age`, `p`.`living_in`, `p`.`profile_id`, `p`.`first_name`, `last_name`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `s`.*
FROM `kv_profileview` as `v`
LEFT JOIN `tbl_primary_info` as `p` ON `v`.`kv_profileview_on` = `p`.`id`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`ms_id`
INNER JOIN `ms_profilesetting` as `s` ON `p`.`id`=`s`.`ms_id`
WHERE `s`.`elite` = 'no'
AND `p`.`status` = 1
AND `v`.`kv_userfkid` = '3581'
AND `u`.`ismain` = 1
AND  `p`.`id` not in(select kv_msi_interested_on from kv_mysideinterests where kv_msi_profilefkid="3581")
AND  p.id not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid = "3581" AND `shortlist_status` = 1)
AND  `p`.`id` not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid="3581"AND ignore_status=1)
ORDER BY `v`.`kv_profileview_created_date` DESC
 LIMIT 10
ERROR - 2022-03-30 19:17:54 --> 404 Page Not Found: /index
ERROR - 2022-03-30 19:19:15 --> 404 Page Not Found: /index
ERROR - 2022-03-30 19:20:13 --> 404 Page Not Found: /index
ERROR - 2022-03-30 19:20:14 --> 404 Page Not Found: /index
ERROR - 2022-03-30 19:20:14 --> 404 Page Not Found: /index
ERROR - 2022-03-30 19:20:14 --> 404 Page Not Found: /index
ERROR - 2022-03-30 19:20:15 --> 404 Page Not Found: /index
ERROR - 2022-03-30 19:20:15 --> 404 Page Not Found: /index
ERROR - 2022-03-30 19:20:15 --> 404 Page Not Found: /index
ERROR - 2022-03-30 19:20:16 --> 404 Page Not Found: /index
ERROR - 2022-03-30 19:20:16 --> 404 Page Not Found: /index
ERROR - 2022-03-30 19:20:17 --> 404 Page Not Found: /index
ERROR - 2022-03-30 19:21:05 --> 404 Page Not Found: /index
ERROR - 2022-03-30 19:25:22 --> 404 Page Not Found: /index
ERROR - 2022-03-30 19:27:25 --> 404 Page Not Found: /index
ERROR - 2022-03-30 19:29:26 --> 404 Page Not Found: /index
ERROR - 2022-03-30 19:30:03 --> 404 Page Not Found: /index
ERROR - 2022-03-30 19:33:19 --> 404 Page Not Found: /index
ERROR - 2022-03-30 19:33:19 --> 404 Page Not Found: /index
ERROR - 2022-03-30 19:33:21 --> 404 Page Not Found: /index
ERROR - 2022-03-30 19:35:15 --> 404 Page Not Found: /index
ERROR - 2022-03-30 19:36:48 --> 404 Page Not Found: /index
ERROR - 2022-03-30 19:37:34 --> 404 Page Not Found: /index
ERROR - 2022-03-30 19:40:12 --> To Id is not available for User - 2006
ERROR - 2022-03-30 19:41:21 --> 404 Page Not Found: /index
ERROR - 2022-03-30 19:41:39 --> To Id is not available for User - 2006
ERROR - 2022-03-30 19:42:46 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-30 19:42:46')
ERROR - 2022-03-30 19:45:01 --> 404 Page Not Found: /index
ERROR - 2022-03-30 19:45:04 --> 404 Page Not Found: /index
ERROR - 2022-03-30 19:45:35 --> 404 Page Not Found: /index
ERROR - 2022-03-30 19:47:06 --> 404 Page Not Found: /index
ERROR - 2022-03-30 19:49:05 --> 404 Page Not Found: /index
ERROR - 2022-03-30 19:52:57 --> 404 Page Not Found: /index
ERROR - 2022-03-30 19:53:58 --> 404 Page Not Found: /index
ERROR - 2022-03-30 19:54:31 --> To Id is not available for User - 4051
ERROR - 2022-03-30 19:55:12 --> 404 Page Not Found: /index
ERROR - 2022-03-30 19:56:14 --> 404 Page Not Found: /index
ERROR - 2022-03-30 19:56:37 --> To Id is not available for User - 4051
ERROR - 2022-03-30 19:56:39 --> 404 Page Not Found: /index
ERROR - 2022-03-30 20:00:13 --> 404 Page Not Found: /index
ERROR - 2022-03-30 20:00:54 --> 404 Page Not Found: /index
ERROR - 2022-03-30 20:02:45 --> 404 Page Not Found: /index
ERROR - 2022-03-30 20:05:08 --> 404 Page Not Found: /index
ERROR - 2022-03-30 20:06:32 --> 404 Page Not Found: /index
ERROR - 2022-03-30 20:07:14 --> 404 Page Not Found: /index
ERROR - 2022-03-30 20:07:43 --> 404 Page Not Found: /index
ERROR - 2022-03-30 20:07:51 --> 404 Page Not Found: /index
ERROR - 2022-03-30 20:07:53 --> 404 Page Not Found: /index
ERROR - 2022-03-30 20:08:12 --> 404 Page Not Found: /index
ERROR - 2022-03-30 20:09:52 --> 404 Page Not Found: /index
ERROR - 2022-03-30 20:14:18 --> 404 Page Not Found: /index
ERROR - 2022-03-30 20:16:09 --> 404 Page Not Found: /index
ERROR - 2022-03-30 20:16:41 --> 404 Page Not Found: /index
ERROR - 2022-03-30 20:18:21 --> 404 Page Not Found: /index
ERROR - 2022-03-30 20:20:53 --> 404 Page Not Found: /index
ERROR - 2022-03-30 20:20:53 --> 404 Page Not Found: /index
ERROR - 2022-03-30 20:20:53 --> 404 Page Not Found: /index
ERROR - 2022-03-30 20:20:54 --> 404 Page Not Found: /index
ERROR - 2022-03-30 20:20:54 --> 404 Page Not Found: /index
ERROR - 2022-03-30 20:20:55 --> 404 Page Not Found: /index
ERROR - 2022-03-30 20:20:55 --> 404 Page Not Found: /index
ERROR - 2022-03-30 20:20:55 --> 404 Page Not Found: /index
ERROR - 2022-03-30 20:20:56 --> 404 Page Not Found: /index
ERROR - 2022-03-30 20:20:56 --> 404 Page Not Found: /index
ERROR - 2022-03-30 20:21:46 --> 404 Page Not Found: /index
ERROR - 2022-03-30 20:22:29 --> 404 Page Not Found: /index
ERROR - 2022-03-30 20:23:22 --> 404 Page Not Found: /index
ERROR - 2022-03-30 20:29:45 --> 404 Page Not Found: /index
ERROR - 2022-03-30 20:35:37 --> 404 Page Not Found: /index
ERROR - 2022-03-30 20:42:55 --> 404 Page Not Found: /index
ERROR - 2022-03-30 20:43:06 --> 404 Page Not Found: /index
ERROR - 2022-03-30 20:51:58 --> 404 Page Not Found: /index
ERROR - 2022-03-30 20:52:40 --> 404 Page Not Found: /index
ERROR - 2022-03-30 20:53:41 --> 404 Page Not Found: /index
ERROR - 2022-03-30 20:55:10 --> 404 Page Not Found: /index
ERROR - 2022-03-30 20:56:45 --> 404 Page Not Found: /index
ERROR - 2022-03-30 20:57:39 --> 404 Page Not Found: /index
ERROR - 2022-03-30 20:58:01 --> 404 Page Not Found: /index
ERROR - 2022-03-30 20:59:15 --> 404 Page Not Found: /index
ERROR - 2022-03-30 20:59:22 --> 404 Page Not Found: /index
ERROR - 2022-03-30 21:00:47 --> 404 Page Not Found: /index
ERROR - 2022-03-30 21:00:47 --> 404 Page Not Found: /index
ERROR - 2022-03-30 21:00:48 --> 404 Page Not Found: /index
ERROR - 2022-03-30 21:00:48 --> 404 Page Not Found: /index
ERROR - 2022-03-30 21:00:48 --> 404 Page Not Found: /index
ERROR - 2022-03-30 21:00:49 --> 404 Page Not Found: /index
ERROR - 2022-03-30 21:00:49 --> 404 Page Not Found: /index
ERROR - 2022-03-30 21:00:50 --> 404 Page Not Found: /index
ERROR - 2022-03-30 21:00:50 --> 404 Page Not Found: /index
ERROR - 2022-03-30 21:00:51 --> 404 Page Not Found: /index
ERROR - 2022-03-30 21:01:46 --> 404 Page Not Found: /index
ERROR - 2022-03-30 21:02:50 --> 404 Page Not Found: /index
ERROR - 2022-03-30 21:03:52 --> 404 Page Not Found: /index
ERROR - 2022-03-30 21:04:29 --> 404 Page Not Found: /index
ERROR - 2022-03-30 21:04:42 --> 404 Page Not Found: /index
ERROR - 2022-03-30 21:05:18 --> 404 Page Not Found: /index
ERROR - 2022-03-30 21:06:41 --> 404 Page Not Found: /index
ERROR - 2022-03-30 21:06:56 --> 404 Page Not Found: /index
ERROR - 2022-03-30 21:07:07 --> 404 Page Not Found: /index
ERROR - 2022-03-30 21:08:00 --> 404 Page Not Found: /index
ERROR - 2022-03-30 21:08:14 --> 404 Page Not Found: /index
ERROR - 2022-03-30 21:08:21 --> 404 Page Not Found: /index
ERROR - 2022-03-30 21:09:06 --> 404 Page Not Found: /index
ERROR - 2022-03-30 21:09:15 --> 404 Page Not Found: /index
ERROR - 2022-03-30 21:09:49 --> 404 Page Not Found: /index
ERROR - 2022-03-30 21:10:03 --> 404 Page Not Found: /index
ERROR - 2022-03-30 21:10:08 --> 404 Page Not Found: /index
ERROR - 2022-03-30 21:10:20 --> 404 Page Not Found: /index
ERROR - 2022-03-30 21:11:00 --> 404 Page Not Found: /index
ERROR - 2022-03-30 21:12:30 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-30 21:12:34 --> 404 Page Not Found: /index
ERROR - 2022-03-30 21:13:20 --> 404 Page Not Found: /index
ERROR - 2022-03-30 21:15:15 --> 404 Page Not Found: /index
ERROR - 2022-03-30 21:16:11 --> 404 Page Not Found: /index
ERROR - 2022-03-30 21:16:52 --> 404 Page Not Found: /index
ERROR - 2022-03-30 21:17:42 --> 404 Page Not Found: /index
ERROR - 2022-03-30 21:18:03 --> 404 Page Not Found: /index
ERROR - 2022-03-30 21:18:16 --> 404 Page Not Found: /index
ERROR - 2022-03-30 21:24:08 --> 404 Page Not Found: /index
ERROR - 2022-03-30 21:24:20 --> 404 Page Not Found: /index
ERROR - 2022-03-30 21:28:19 --> 404 Page Not Found: /index
ERROR - 2022-03-30 21:28:57 --> 404 Page Not Found: /index
ERROR - 2022-03-30 21:31:48 --> 404 Page Not Found: /index
ERROR - 2022-03-30 21:34:29 --> 404 Page Not Found: /index
ERROR - 2022-03-30 21:35:37 --> 404 Page Not Found: /index
ERROR - 2022-03-30 21:36:37 --> To Id is not available for User - 4213
ERROR - 2022-03-30 21:36:41 --> 404 Page Not Found: /index
ERROR - 2022-03-30 21:40:08 --> 404 Page Not Found: /index
ERROR - 2022-03-30 21:43:35 --> 404 Page Not Found: /index
ERROR - 2022-03-30 21:43:52 --> 404 Page Not Found: /index
ERROR - 2022-03-30 21:43:53 --> 404 Page Not Found: /index
ERROR - 2022-03-30 21:44:54 --> 404 Page Not Found: /index
ERROR - 2022-03-30 21:46:32 --> 404 Page Not Found: /index
ERROR - 2022-03-30 21:47:36 --> 404 Page Not Found: /index
ERROR - 2022-03-30 21:48:17 --> 404 Page Not Found: /index
ERROR - 2022-03-30 21:49:56 --> 404 Page Not Found: /index
ERROR - 2022-03-30 21:50:02 --> 404 Page Not Found: /index
ERROR - 2022-03-30 21:50:24 --> 404 Page Not Found: /index
ERROR - 2022-03-30 21:53:42 --> 404 Page Not Found: /index
ERROR - 2022-03-30 21:54:19 --> 404 Page Not Found: /index
ERROR - 2022-03-30 21:54:38 --> 404 Page Not Found: /index
ERROR - 2022-03-30 21:55:18 --> 404 Page Not Found: /index
ERROR - 2022-03-30 21:56:53 --> 404 Page Not Found: /index
ERROR - 2022-03-30 21:56:54 --> 404 Page Not Found: /index
ERROR - 2022-03-30 21:57:25 --> 404 Page Not Found: /index
ERROR - 2022-03-30 21:57:48 --> 404 Page Not Found: /index
ERROR - 2022-03-30 21:58:11 --> 404 Page Not Found: /index
ERROR - 2022-03-30 21:59:01 --> 404 Page Not Found: /index
ERROR - 2022-03-30 21:59:50 --> 404 Page Not Found: /index
ERROR - 2022-03-30 22:00:34 --> 404 Page Not Found: /index
ERROR - 2022-03-30 22:03:16 --> 404 Page Not Found: /index
ERROR - 2022-03-30 22:04:31 --> 404 Page Not Found: /index
ERROR - 2022-03-30 22:04:32 --> 404 Page Not Found: /index
ERROR - 2022-03-30 22:04:39 --> 404 Page Not Found: /index
ERROR - 2022-03-30 22:04:45 --> 404 Page Not Found: /index
ERROR - 2022-03-30 22:06:12 --> 404 Page Not Found: /index
ERROR - 2022-03-30 22:08:30 --> 404 Page Not Found: /index
ERROR - 2022-03-30 22:08:30 --> 404 Page Not Found: /index
ERROR - 2022-03-30 22:11:27 --> 404 Page Not Found: /index
ERROR - 2022-03-30 22:12:00 --> 404 Page Not Found: /index
ERROR - 2022-03-30 22:12:10 --> 404 Page Not Found: /index
ERROR - 2022-03-30 22:13:07 --> 404 Page Not Found: /index
ERROR - 2022-03-30 22:13:49 --> 404 Page Not Found: /index
ERROR - 2022-03-30 22:16:30 --> 404 Page Not Found: /index
ERROR - 2022-03-30 22:16:44 --> 404 Page Not Found: /index
ERROR - 2022-03-30 22:17:32 --> 404 Page Not Found: /index
ERROR - 2022-03-30 22:17:38 --> 404 Page Not Found: /index
ERROR - 2022-03-30 22:18:30 --> 404 Page Not Found: /index
ERROR - 2022-03-30 22:20:16 --> 404 Page Not Found: /index
ERROR - 2022-03-30 22:22:30 --> 404 Page Not Found: /index
ERROR - 2022-03-30 22:23:11 --> 404 Page Not Found: /index
ERROR - 2022-03-30 22:23:46 --> 404 Page Not Found: /index
ERROR - 2022-03-30 22:24:07 --> 404 Page Not Found: /index
ERROR - 2022-03-30 22:24:08 --> Severity: error --> Exception: Invalid address:  (to):  /home4/cowcdrmy/public_html/application/third_party/phpmailer/src/PHPMailer.php 1092
ERROR - 2022-03-30 22:26:27 --> 404 Page Not Found: /index
ERROR - 2022-03-30 22:29:40 --> 404 Page Not Found: /index
ERROR - 2022-03-30 22:29:45 --> 404 Page Not Found: /index
ERROR - 2022-03-30 22:30:48 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-30 22:30:48')
ERROR - 2022-03-30 22:43:14 --> 404 Page Not Found: /index
ERROR - 2022-03-30 22:43:33 --> 404 Page Not Found: /index
ERROR - 2022-03-30 22:45:46 --> 404 Page Not Found: /index
ERROR - 2022-03-30 22:49:27 --> 404 Page Not Found: /index
ERROR - 2022-03-30 22:49:36 --> 404 Page Not Found: /index
ERROR - 2022-03-30 22:57:14 --> 404 Page Not Found: /index
ERROR - 2022-03-30 22:57:43 --> 404 Page Not Found: /index
ERROR - 2022-03-30 22:57:57 --> 404 Page Not Found: /index
ERROR - 2022-03-30 22:58:03 --> 404 Page Not Found: /index
ERROR - 2022-03-30 22:58:04 --> 404 Page Not Found: /index
ERROR - 2022-03-30 22:58:21 --> 404 Page Not Found: /index
ERROR - 2022-03-30 22:59:05 --> 404 Page Not Found: /index
ERROR - 2022-03-30 23:00:14 --> 404 Page Not Found: /index
ERROR - 2022-03-30 23:10:58 --> 404 Page Not Found: /index
ERROR - 2022-03-30 23:21:18 --> 404 Page Not Found: /index
ERROR - 2022-03-30 23:21:31 --> 404 Page Not Found: /index
ERROR - 2022-03-30 23:21:42 --> 404 Page Not Found: /index
ERROR - 2022-03-30 23:40:42 --> 404 Page Not Found: /index
ERROR - 2022-03-30 23:40:42 --> 404 Page Not Found: /index
ERROR - 2022-03-30 23:40:43 --> 404 Page Not Found: /index
ERROR - 2022-03-30 23:40:43 --> 404 Page Not Found: /index
ERROR - 2022-03-30 23:40:44 --> 404 Page Not Found: /index
ERROR - 2022-03-30 23:40:44 --> 404 Page Not Found: /index
ERROR - 2022-03-30 23:40:45 --> 404 Page Not Found: /index
ERROR - 2022-03-30 23:43:20 --> 404 Page Not Found: /index
ERROR - 2022-03-30 23:43:35 --> 404 Page Not Found: /index
ERROR - 2022-03-30 23:43:53 --> 404 Page Not Found: /index
ERROR - 2022-03-30 23:48:20 --> 404 Page Not Found: /index
ERROR - 2022-03-30 23:49:04 --> 404 Page Not Found: /index
ERROR - 2022-03-30 23:57:00 --> 404 Page Not Found: /index
ERROR - 2022-03-30 23:58:04 --> 404 Page Not Found: /index
ERROR - 2022-03-30 23:58:40 --> 404 Page Not Found: /index
