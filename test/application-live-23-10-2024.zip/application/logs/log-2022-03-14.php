ERROR - 2022-03-14 07:54:41 --> 404 Page Not Found: /index
ERROR - 2022-03-14 07:54:41 --> 404 Page Not Found: /index
ERROR - 2022-03-14 07:54:41 --> 404 Page Not Found: /index
ERROR - 2022-03-14 07:54:41 --> 404 Page Not Found: /index
ERROR - 2022-03-14 07:54:41 --> 404 Page Not Found: /index
ERROR - 2022-03-14 07:54:42 --> 404 Page Not Found: /index
ERROR - 2022-03-14 07:54:42 --> 404 Page Not Found: /index
ERROR - 2022-03-14 07:54:42 --> 404 Page Not Found: /index
ERROR - 2022-03-14 07:54:42 --> 404 Page Not Found: /index
ERROR - 2022-03-14 07:54:42 --> 404 Page Not Found: /index
ERROR - 2022-03-14 07:54:42 --> 404 Page Not Found: /index
ERROR - 2022-03-14 07:54:42 --> 404 Page Not Found: /index
ERROR - 2022-03-14 07:54:42 --> 404 Page Not Found: /index
ERROR - 2022-03-14 07:54:43 --> 404 Page Not Found: /index
ERROR - 2022-03-14 07:54:43 --> 404 Page Not Found: /index
ERROR - 2022-03-14 07:54:44 --> 404 Page Not Found: /index
ERROR - 2022-03-14 07:54:44 --> 404 Page Not Found: /index
ERROR - 2022-03-14 07:56:26 --> 404 Page Not Found: /index
ERROR - 2022-03-14 07:56:50 --> 404 Page Not Found: /index
ERROR - 2022-03-14 07:56:58 --> 404 Page Not Found: ../modules/customerregistration/controllers//index
ERROR - 2022-03-14 07:57:22 --> 404 Page Not Found: /index
ERROR - 2022-03-14 07:58:17 --> 404 Page Not Found: /index
ERROR - 2022-03-14 07:59:09 --> 404 Page Not Found: /index
ERROR - 2022-03-14 07:59:28 --> 404 Page Not Found: ../modules/customerregistration/controllers//index
ERROR - 2022-03-14 08:00:35 --> 404 Page Not Found: /index
ERROR - 2022-03-14 08:01:12 --> 404 Page Not Found: /index
ERROR - 2022-03-14 08:01:31 --> 404 Page Not Found: /index
ERROR - 2022-03-14 08:01:40 --> 404 Page Not Found: /index
ERROR - 2022-03-14 08:02:14 --> 404 Page Not Found: /index
ERROR - 2022-03-14 08:02:15 --> 404 Page Not Found: /index
ERROR - 2022-03-14 08:02:38 --> 404 Page Not Found: /index
ERROR - 2022-03-14 08:02:39 --> 404 Page Not Found: /index
ERROR - 2022-03-14 08:02:43 --> 404 Page Not Found: /index
ERROR - 2022-03-14 08:03:18 --> 404 Page Not Found: /index
ERROR - 2022-03-14 08:03:33 --> 404 Page Not Found: /index
ERROR - 2022-03-14 08:04:15 --> 404 Page Not Found: /index
ERROR - 2022-03-14 08:04:45 --> 404 Page Not Found: /index
ERROR - 2022-03-14 08:04:45 --> 404 Page Not Found: /index
ERROR - 2022-03-14 08:04:45 --> 404 Page Not Found: /index
ERROR - 2022-03-14 08:05:49 --> 404 Page Not Found: /index
ERROR - 2022-03-14 08:06:33 --> 404 Page Not Found: /index
ERROR - 2022-03-14 08:09:39 --> 404 Page Not Found: /index
ERROR - 2022-03-14 08:10:36 --> 404 Page Not Found: /index
ERROR - 2022-03-14 08:11:44 --> 404 Page Not Found: ../modules/login/controllers/Login/forgetPassword
ERROR - 2022-03-14 08:12:21 --> 404 Page Not Found: /index
ERROR - 2022-03-14 08:13:56 --> 404 Page Not Found: /index
ERROR - 2022-03-14 08:14:04 --> 404 Page Not Found: ../modules/customerregistration/controllers//index
ERROR - 2022-03-14 08:14:17 --> 404 Page Not Found: /index
ERROR - 2022-03-14 08:14:24 --> 404 Page Not Found: ../modules/customerregistration/controllers//index
ERROR - 2022-03-14 08:14:35 --> 404 Page Not Found: ../modules/customerregistration/controllers//index
ERROR - 2022-03-14 08:14:38 --> 404 Page Not Found: ../modules/customerregistration/controllers//index
ERROR - 2022-03-14 08:14:39 --> 404 Page Not Found: ../modules/customerregistration/controllers//index
ERROR - 2022-03-14 08:14:42 --> 404 Page Not Found: /index
ERROR - 2022-03-14 08:14:58 --> 404 Page Not Found: ../modules/customerregistration/controllers//index
ERROR - 2022-03-14 08:15:55 --> 404 Page Not Found: /index
ERROR - 2022-03-14 08:15:58 --> 404 Page Not Found: /index
ERROR - 2022-03-14 08:16:16 --> 404 Page Not Found: /index
ERROR - 2022-03-14 08:16:26 --> 404 Page Not Found: ../modules/customerregistration/controllers//index
ERROR - 2022-03-14 08:17:11 --> 404 Page Not Found: /index
ERROR - 2022-03-14 08:18:10 --> 404 Page Not Found: /index
ERROR - 2022-03-14 08:18:57 --> Query error: Table 'cowcdrmy_kammamarriage.ms_shortlist_viewedd_ignored' doesn't exist - Invalid query: SELECT `to_msid`
FROM `ms_shortlist_viewedd_ignored`
WHERE `from_msid` = '3903'
AND `ignore_status` = '1'
ERROR - 2022-03-14 08:19:21 --> 404 Page Not Found: /index
ERROR - 2022-03-14 08:19:35 --> 404 Page Not Found: /index
ERROR - 2022-03-14 08:19:44 --> 404 Page Not Found: /index
ERROR - 2022-03-14 08:19:58 --> 404 Page Not Found: /index
ERROR - 2022-03-14 08:20:35 --> 404 Page Not Found: /index
ERROR - 2022-03-14 08:20:59 --> 404 Page Not Found: /index
ERROR - 2022-03-14 08:21:54 --> 404 Page Not Found: /index
ERROR - 2022-03-14 08:22:35 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-14 08:22:35')
ERROR - 2022-03-14 08:22:55 --> 404 Page Not Found: /index
ERROR - 2022-03-14 08:23:00 --> 404 Page Not Found: /index
ERROR - 2022-03-14 08:23:02 --> 404 Page Not Found: /index
ERROR - 2022-03-14 08:23:06 --> 404 Page Not Found: /index
ERROR - 2022-03-14 08:23:50 --> 404 Page Not Found: /index
ERROR - 2022-03-14 08:24:15 --> 404 Page Not Found: /index
ERROR - 2022-03-14 08:24:57 --> 404 Page Not Found: ../modules/admin/controllers/Admin_ap/eliteprofiles
ERROR - 2022-03-14 08:25:30 --> 404 Page Not Found: /index
ERROR - 2022-03-14 08:26:27 --> 404 Page Not Found: /index
ERROR - 2022-03-14 08:26:29 --> 404 Page Not Found: /index
ERROR - 2022-03-14 08:27:02 --> 404 Page Not Found: /index
ERROR - 2022-03-14 08:29:01 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-14 08:29:29 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-14 08:29:33 --> 404 Page Not Found: /index
ERROR - 2022-03-14 08:30:52 --> 404 Page Not Found: /index
ERROR - 2022-03-14 08:31:04 --> 404 Page Not Found: /index
ERROR - 2022-03-14 08:31:16 --> 404 Page Not Found: /index
ERROR - 2022-03-14 08:31:25 --> 404 Page Not Found: /index
ERROR - 2022-03-14 08:33:58 --> 404 Page Not Found: /index
ERROR - 2022-03-14 08:34:28 --> 404 Page Not Found: /index
ERROR - 2022-03-14 08:37:01 --> 404 Page Not Found: /index
ERROR - 2022-03-14 08:37:16 --> 404 Page Not Found: /index
ERROR - 2022-03-14 08:38:32 --> 404 Page Not Found: /index
ERROR - 2022-03-14 08:39:04 --> 404 Page Not Found: /index
ERROR - 2022-03-14 08:39:44 --> 404 Page Not Found: /index
ERROR - 2022-03-14 08:40:01 --> 404 Page Not Found: /index
ERROR - 2022-03-14 08:40:33 --> 404 Page Not Found: /index
ERROR - 2022-03-14 08:40:42 --> 404 Page Not Found: /index
ERROR - 2022-03-14 08:40:48 --> 404 Page Not Found: ../modules/customerregistration/controllers//index
ERROR - 2022-03-14 08:41:38 --> 404 Page Not Found: /index
ERROR - 2022-03-14 08:41:52 --> 404 Page Not Found: ../modules/customerregistration/controllers//index
ERROR - 2022-03-14 08:47:33 --> 404 Page Not Found: /index
ERROR - 2022-03-14 08:47:38 --> 404 Page Not Found: /index
ERROR - 2022-03-14 08:47:56 --> 404 Page Not Found: /index
ERROR - 2022-03-14 08:48:22 --> 404 Page Not Found: /index
ERROR - 2022-03-14 08:48:30 --> 404 Page Not Found: /index
ERROR - 2022-03-14 08:49:22 --> 404 Page Not Found: /index
ERROR - 2022-03-14 08:50:36 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-14 08:50:36')
ERROR - 2022-03-14 08:50:44 --> 404 Page Not Found: /index
ERROR - 2022-03-14 08:50:44 --> 404 Page Not Found: /index
ERROR - 2022-03-14 08:51:45 --> 404 Page Not Found: /index
ERROR - 2022-03-14 08:51:58 --> 404 Page Not Found: /index
ERROR - 2022-03-14 08:52:01 --> 404 Page Not Found: /index
ERROR - 2022-03-14 08:52:09 --> 404 Page Not Found: /index
ERROR - 2022-03-14 08:52:28 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-14 08:52:28')
ERROR - 2022-03-14 08:58:44 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:01:44 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:02:04 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:03:19 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:04:30 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:05:08 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-14 09:05:08')
ERROR - 2022-03-14 09:05:13 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:06:00 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:07:39 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:07:43 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:08:18 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:08:40 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:09:13 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:11:14 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:11:23 --> 404 Page Not Found: ../modules/admin/controllers/Admin_ap/eliteprofiles
ERROR - 2022-03-14 09:13:12 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:13:20 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:13:27 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:13:32 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:13:39 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:16:07 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:17:51 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:18:15 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:18:44 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:18:51 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:20:56 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:20:58 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:20:59 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:20:59 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:21:02 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:21:04 --> 404 Page Not Found: ../modules/customerregistration/controllers//index
ERROR - 2022-03-14 09:21:06 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:21:10 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:21:17 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:21:20 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:21:20 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:22:34 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:22:34 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:22:36 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:22:41 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:24:12 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:25:13 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:25:21 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:25:21 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:26:03 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:26:06 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:26:32 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:30:26 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:30:53 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:30:53 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:32:06 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:32:43 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:32:44 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:33:48 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:33:49 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:34:00 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:34:05 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:34:06 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:34:53 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:35:00 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:35:00 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:35:00 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:35:00 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:35:01 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:35:01 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:35:01 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:35:01 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:35:02 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:35:02 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:35:25 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:35:26 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:36:24 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:37:29 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:38:50 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:39:25 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:39:35 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:40:11 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:42:49 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:43:17 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:43:44 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:44:17 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:44:21 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:45:36 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:46:03 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:47:24 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:47:24 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:47:41 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:49:45 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:49:57 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:50:07 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:54:31 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:54:32 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:54:46 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:54:46 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:55:06 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:55:58 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:56:00 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:56:00 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:56:15 --> 404 Page Not Found: ../modules/admin/controllers/Admin_ap/eliteprofiles
ERROR - 2022-03-14 09:57:06 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:57:45 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:57:45 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:58:03 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:58:04 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:58:20 --> 404 Page Not Found: /index
ERROR - 2022-03-14 09:59:23 --> 404 Page Not Found: /index
ERROR - 2022-03-14 10:01:45 --> 404 Page Not Found: /index
ERROR - 2022-03-14 10:01:52 --> 404 Page Not Found: /index
ERROR - 2022-03-14 10:01:59 --> 404 Page Not Found: /index
ERROR - 2022-03-14 10:03:48 --> 404 Page Not Found: /index
ERROR - 2022-03-14 10:03:53 --> 404 Page Not Found: /index
ERROR - 2022-03-14 10:04:00 --> 404 Page Not Found: /index
ERROR - 2022-03-14 10:05:50 --> 404 Page Not Found: /index
ERROR - 2022-03-14 10:08:03 --> 404 Page Not Found: ../modules/admin/controllers/Admin_ap/eliteprofiles
ERROR - 2022-03-14 10:08:10 --> 404 Page Not Found: ../modules/admin/controllers/Admin_ap/confidentialprofiles
ERROR - 2022-03-14 10:08:22 --> 404 Page Not Found: /index
ERROR - 2022-03-14 10:09:21 --> 404 Page Not Found: /index
ERROR - 2022-03-14 10:10:31 --> 404 Page Not Found: /index
ERROR - 2022-03-14 10:10:43 --> 404 Page Not Found: /index
ERROR - 2022-03-14 10:11:12 --> 404 Page Not Found: /index
ERROR - 2022-03-14 10:11:17 --> 404 Page Not Found: /index
ERROR - 2022-03-14 10:11:31 --> 404 Page Not Found: /index
ERROR - 2022-03-14 10:11:40 --> 404 Page Not Found: /index
ERROR - 2022-03-14 10:11:45 --> 404 Page Not Found: /index
ERROR - 2022-03-14 10:12:11 --> 404 Page Not Found: /index
ERROR - 2022-03-14 10:12:27 --> 404 Page Not Found: /index
ERROR - 2022-03-14 10:14:06 --> 404 Page Not Found: /index
ERROR - 2022-03-14 10:16:22 --> 404 Page Not Found: /index
ERROR - 2022-03-14 10:17:46 --> 404 Page Not Found: /index
ERROR - 2022-03-14 10:18:30 --> 404 Page Not Found: /index
ERROR - 2022-03-14 10:18:53 --> 404 Page Not Found: /index
ERROR - 2022-03-14 10:19:39 --> 404 Page Not Found: /index
ERROR - 2022-03-14 10:20:27 --> 404 Page Not Found: /index
ERROR - 2022-03-14 10:21:22 --> 404 Page Not Found: /index
ERROR - 2022-03-14 10:22:18 --> 404 Page Not Found: /index
ERROR - 2022-03-14 10:25:05 --> 404 Page Not Found: /index
ERROR - 2022-03-14 10:26:05 --> 404 Page Not Found: /index
ERROR - 2022-03-14 10:26:44 --> 404 Page Not Found: /index
ERROR - 2022-03-14 10:29:08 --> 404 Page Not Found: /index
ERROR - 2022-03-14 10:29:44 --> 404 Page Not Found: /index
ERROR - 2022-03-14 10:29:55 --> Query error: Unknown column 'activation_code' in 'field list' - Invalid query: INSERT INTO `tbl_primary_info` (`email`, `password`, `mobile`, `first_name`, `last_name`, `gender`, `date`, `month`, `year`, `profile_id`, `living_in`, `age`, `status`, `registered_on`, `activation_code`) VALUES ('pavuluri.sneha97@gmail.com', '552642bd82cc3eabd6452a189252532c', '9052034999', 'Sneha', 'Pavuluri', 'female', '5', 'Apr', '1997', 'KV974074', 'India', 25, 1, '2022-03-14 10:29:55', 'MonFKNvz3HBG')
ERROR - 2022-03-14 10:30:22 --> 404 Page Not Found: /index
ERROR - 2022-03-14 10:30:26 --> 404 Page Not Found: /index
ERROR - 2022-03-14 10:30:51 --> 404 Page Not Found: /index
ERROR - 2022-03-14 10:31:03 --> 404 Page Not Found: /index
ERROR - 2022-03-14 10:31:12 --> 404 Page Not Found: /index
ERROR - 2022-03-14 10:33:00 --> 404 Page Not Found: /index
ERROR - 2022-03-14 10:33:50 --> 404 Page Not Found: /index
ERROR - 2022-03-14 10:34:04 --> 404 Page Not Found: /index
ERROR - 2022-03-14 10:34:45 --> 404 Page Not Found: /index
ERROR - 2022-03-14 10:34:46 --> Query error: Unknown column 'activation_code' in 'field list' - Invalid query: INSERT INTO `tbl_primary_info` (`email`, `password`, `mobile`, `first_name`, `last_name`, `gender`, `date`, `month`, `year`, `profile_id`, `living_in`, `age`, `status`, `registered_on`, `activation_code`) VALUES ('pavuluri.sneha97@gmail.com', '552642bd82cc3eabd6452a189252532c', '9052034999', 'Sneha', 'Pavuluri', 'female', '5', 'Apr', '1997', 'KV974074', 'India', 25, 1, '2022-03-14 10:34:46', 'CF3stAyZModX')
ERROR - 2022-03-14 10:34:54 --> 404 Page Not Found: /index
ERROR - 2022-03-14 10:35:01 --> 404 Page Not Found: /index
ERROR - 2022-03-14 10:36:25 --> 404 Page Not Found: /index
ERROR - 2022-03-14 10:36:42 --> 404 Page Not Found: /index
ERROR - 2022-03-14 10:36:49 --> 404 Page Not Found: /index
ERROR - 2022-03-14 10:37:27 --> 404 Page Not Found: /index
ERROR - 2022-03-14 10:37:45 --> 404 Page Not Found: /index
ERROR - 2022-03-14 10:37:48 --> 404 Page Not Found: /index
ERROR - 2022-03-14 10:38:06 --> 404 Page Not Found: /index
ERROR - 2022-03-14 10:39:37 --> 404 Page Not Found: /index
ERROR - 2022-03-14 10:40:12 --> 404 Page Not Found: /index
ERROR - 2022-03-14 10:40:21 --> 404 Page Not Found: /index
ERROR - 2022-03-14 10:40:36 --> 404 Page Not Found: /index
ERROR - 2022-03-14 10:40:48 --> 404 Page Not Found: /index
ERROR - 2022-03-14 10:40:54 --> 404 Page Not Found: /index
ERROR - 2022-03-14 10:41:33 --> Query error: Unknown column 'activation_code' in 'field list' - Invalid query: INSERT INTO `tbl_primary_info` (`email`, `password`, `mobile`, `first_name`, `last_name`, `gender`, `date`, `month`, `year`, `profile_id`, `living_in`, `age`, `status`, `registered_on`, `activation_code`) VALUES ('kishore@gmail.com', '69b42c3db4d4fab732bdf55c201d05ae', '9491972400', 'Kishore', 'Simhadri', 'male', '17', 'Jul', '1995', 'KV954074', 'India', 27, 1, '2022-03-14 10:41:33', 'K19NA4QRIc2B')
ERROR - 2022-03-14 10:42:18 --> 404 Page Not Found: /index
ERROR - 2022-03-14 10:43:15 --> 404 Page Not Found: /index
ERROR - 2022-03-14 10:43:18 --> Query error: Unknown column 'activation_code' in 'field list' - Invalid query: INSERT INTO `tbl_primary_info` (`email`, `password`, `mobile`, `first_name`, `last_name`, `gender`, `date`, `month`, `year`, `profile_id`, `living_in`, `age`, `status`, `registered_on`, `activation_code`) VALUES ('kishore@gmail.com', '69b42c3db4d4fab732bdf55c201d05ae', '9491972400', 'Kishore', 'Simhadri', 'male', '17', 'Jul', '1995', 'KV954074', 'India', 27, 1, '2022-03-14 10:43:18', 'bhvGskLW98q4')
ERROR - 2022-03-14 10:43:26 --> 404 Page Not Found: /index
ERROR - 2022-03-14 10:45:49 --> 404 Page Not Found: /index
ERROR - 2022-03-14 10:46:06 --> 404 Page Not Found: /index
ERROR - 2022-03-14 10:46:06 --> Query error: Unknown column 'activation_code' in 'field list' - Invalid query: INSERT INTO `tbl_primary_info` (`email`, `password`, `mobile`, `first_name`, `last_name`, `gender`, `date`, `month`, `year`, `profile_id`, `living_in`, `age`, `status`, `registered_on`, `activation_code`) VALUES ('kishoresimhadri@gmail.com', '69b42c3db4d4fab732bdf55c201d05ae', '9491972400', 'Kishore', 'Simhadri', 'male', '17', 'Jul', '1995', 'KV954074', 'India', 27, 1, '2022-03-14 10:46:06', 'sVwY2AFlUdOp')
ERROR - 2022-03-14 10:46:14 --> 404 Page Not Found: /index
ERROR - 2022-03-14 10:46:16 --> 404 Page Not Found: /index
ERROR - 2022-03-14 10:46:33 --> 404 Page Not Found: /index
ERROR - 2022-03-14 10:47:34 --> 404 Page Not Found: /index
ERROR - 2022-03-14 10:47:56 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT `p`.*, `r`.`caste`, `r`.`height`, `r`.`star`, `r`.`time_of_birth`, `r`.`raasi`, `prp`.`property_value`, `e`.`occupation`, `e`.`education_degree`, `e`.`visatype`, `e`.`city`, `e`.`country`, `e`.`annual_income`, `pi`.`fathers_father_native_place`, `pi`.`mothers_father_native_place`, `pi`.`father_mobile`, `pfs`.`payment_status`, `pfs`.`profilesetting_id` as `pfs_id`, `pfs`.`last_call_updated`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `adm`.`username` as `profile_owner`
FROM `tbl_primary_info` as `p`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `ms_property_info` as `prp` ON `p`.`id`=`prp`.`ms_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `tbl_parents_info` as `pi` ON `p`.`id`=`pi`.`user_id`
LEFT JOIN `ms_profilesetting` as `pfs` ON `p`.`id`=`pfs`.`ms_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`MS_id` AND `u`.`ismain`="1" AND `u`.`isactive`="1"
LEFT JOIN `tbl_admin_data` as `adm` ON `pfs`.`profileowner`=`adm`.`id`
WHERE `p`.`gender` = 'male'
AND  `p`.`profile_id` LIKE '%KV914071%' ESCAPE '!'
AND `p`.`status` = '1'
AND `r`.`caste` = `Array`
AND `adm`.`id` = '15'
GROUP BY `p`.`id`
ERROR - 2022-03-14 10:48:33 --> 404 Page Not Found: /index
ERROR - 2022-03-14 10:51:10 --> 404 Page Not Found: /index
ERROR - 2022-03-14 10:51:15 --> 404 Page Not Found: /index
ERROR - 2022-03-14 10:52:29 --> 404 Page Not Found: /index
ERROR - 2022-03-14 10:52:33 --> 404 Page Not Found: /index
ERROR - 2022-03-14 10:52:35 --> 404 Page Not Found: /index
ERROR - 2022-03-14 10:52:36 --> 404 Page Not Found: /index
ERROR - 2022-03-14 10:52:50 --> 404 Page Not Found: /index
ERROR - 2022-03-14 10:54:31 --> 404 Page Not Found: /index
ERROR - 2022-03-14 10:55:51 --> 404 Page Not Found: /index
ERROR - 2022-03-14 10:55:55 --> 404 Page Not Found: /index
ERROR - 2022-03-14 10:56:35 --> 404 Page Not Found: /index
ERROR - 2022-03-14 10:57:02 --> 404 Page Not Found: /index
ERROR - 2022-03-14 10:58:05 --> 404 Page Not Found: /index
ERROR - 2022-03-14 10:58:08 --> 404 Page Not Found: /index
ERROR - 2022-03-14 10:58:23 --> 404 Page Not Found: /index
ERROR - 2022-03-14 11:00:05 --> 404 Page Not Found: /index
ERROR - 2022-03-14 11:00:07 --> 404 Page Not Found: /index
ERROR - 2022-03-14 11:01:02 --> 404 Page Not Found: /index
ERROR - 2022-03-14 11:01:36 --> 404 Page Not Found: /index
ERROR - 2022-03-14 11:01:54 --> 404 Page Not Found: /index
ERROR - 2022-03-14 11:03:26 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-14 11:03:26')
ERROR - 2022-03-14 11:03:31 --> 404 Page Not Found: /index
ERROR - 2022-03-14 11:03:50 --> 404 Page Not Found: /index
ERROR - 2022-03-14 11:07:22 --> 404 Page Not Found: /index
ERROR - 2022-03-14 11:07:49 --> 404 Page Not Found: /index
ERROR - 2022-03-14 11:08:34 --> 404 Page Not Found: /index
ERROR - 2022-03-14 11:09:51 --> 404 Page Not Found: /index
ERROR - 2022-03-14 11:12:13 --> 404 Page Not Found: /index
ERROR - 2022-03-14 11:12:15 --> 404 Page Not Found: /index
ERROR - 2022-03-14 11:12:45 --> 404 Page Not Found: /index
ERROR - 2022-03-14 11:12:55 --> 404 Page Not Found: /index
ERROR - 2022-03-14 11:13:34 --> 404 Page Not Found: /index
ERROR - 2022-03-14 11:14:00 --> 404 Page Not Found: /index
ERROR - 2022-03-14 11:15:27 --> 404 Page Not Found: /index
ERROR - 2022-03-14 11:17:15 --> 404 Page Not Found: /index
ERROR - 2022-03-14 11:18:08 --> Query error: Unknown column 'activation_code' in 'field list' - Invalid query: INSERT INTO `tbl_primary_info` (`email`, `password`, `mobile`, `first_name`, `last_name`, `gender`, `date`, `month`, `year`, `profile_id`, `living_in`, `age`, `status`, `registered_on`, `activation_code`) VALUES ('kishoresimhadri@gmail.com', '9ee3483b51708afc481f50307d6fa6c9', '9491972400', 'Kishore', 'Simhadri', 'male', '17', 'Jul', '1995', 'KV954074', 'India', 27, 1, '2022-03-14 11:18:08', 'YOBMojg1r8ek')
ERROR - 2022-03-14 11:18:39 --> 404 Page Not Found: /index
ERROR - 2022-03-14 11:19:44 --> Query error: Unknown column 'activation_code' in 'field list' - Invalid query: INSERT INTO `tbl_primary_info` (`email`, `password`, `mobile`, `first_name`, `last_name`, `gender`, `date`, `month`, `year`, `profile_id`, `living_in`, `age`, `status`, `registered_on`, `activation_code`) VALUES ('pavuluri.sneha97@gmail.com', '552642bd82cc3eabd6452a189252532c', '9052034999', 'Sneha', 'pavuluri', 'female', '5', 'Apr', '1997', 'KV974074', 'India', 25, 1, '2022-03-14 11:19:44', 'dtGW9bLfKvQn')
ERROR - 2022-03-14 11:19:55 --> Query error: Unknown column 'activation_code' in 'field list' - Invalid query: INSERT INTO `tbl_primary_info` (`email`, `password`, `mobile`, `first_name`, `last_name`, `gender`, `date`, `month`, `year`, `profile_id`, `living_in`, `age`, `status`, `registered_on`, `activation_code`) VALUES ('9491972400k@gmal.com', '69b42c3db4d4fab732bdf55c201d05ae', '9491972400', 'Kishore', 'Simhadri', 'male', '17', 'Jul', '1995', 'KV954074', 'India', 27, 1, '2022-03-14 11:19:55', 'lPOLbmx3fYua')
ERROR - 2022-03-14 11:20:12 --> 404 Page Not Found: /index
ERROR - 2022-03-14 11:20:38 --> 404 Page Not Found: /index
ERROR - 2022-03-14 11:20:47 --> 404 Page Not Found: /index
ERROR - 2022-03-14 11:21:18 --> 404 Page Not Found: ../modules/admin/controllers/Admin_ap/confidentialprofiles
ERROR - 2022-03-14 11:21:33 --> 404 Page Not Found: ../modules/admin/controllers/Admin_ap/confidentialprofiles
ERROR - 2022-03-14 11:22:01 --> 404 Page Not Found: /index
ERROR - 2022-03-14 11:22:54 --> 404 Page Not Found: /index
ERROR - 2022-03-14 11:23:14 --> 404 Page Not Found: /index
ERROR - 2022-03-14 11:24:48 --> 404 Page Not Found: /index
ERROR - 2022-03-14 11:25:10 --> 404 Page Not Found: /index
ERROR - 2022-03-14 11:26:36 --> 404 Page Not Found: /index
ERROR - 2022-03-14 11:27:00 --> 404 Page Not Found: /index
ERROR - 2022-03-14 11:27:12 --> 404 Page Not Found: /index
ERROR - 2022-03-14 11:27:12 --> 404 Page Not Found: /index
ERROR - 2022-03-14 11:28:05 --> 404 Page Not Found: /index
ERROR - 2022-03-14 11:30:02 --> 404 Page Not Found: /index
ERROR - 2022-03-14 11:30:13 --> 404 Page Not Found: /index
ERROR - 2022-03-14 11:31:58 --> 404 Page Not Found: /index
ERROR - 2022-03-14 11:33:23 --> 404 Page Not Found: /index
ERROR - 2022-03-14 11:33:34 --> 404 Page Not Found: /index
ERROR - 2022-03-14 11:34:28 --> 404 Page Not Found: /index
ERROR - 2022-03-14 11:34:53 --> 404 Page Not Found: /index
ERROR - 2022-03-14 11:35:12 --> 404 Page Not Found: /index
ERROR - 2022-03-14 11:35:33 --> 404 Page Not Found: /index
ERROR - 2022-03-14 11:35:36 --> 404 Page Not Found: /index
ERROR - 2022-03-14 11:35:37 --> 404 Page Not Found: /index
ERROR - 2022-03-14 11:35:58 --> 404 Page Not Found: /index
ERROR - 2022-03-14 11:36:19 --> 404 Page Not Found: /index
ERROR - 2022-03-14 11:36:37 --> 404 Page Not Found: /index
ERROR - 2022-03-14 11:37:15 --> 404 Page Not Found: /index
ERROR - 2022-03-14 11:37:32 --> 404 Page Not Found: /index
ERROR - 2022-03-14 11:37:54 --> 404 Page Not Found: /index
ERROR - 2022-03-14 11:38:16 --> 404 Page Not Found: /index
ERROR - 2022-03-14 11:38:32 --> 404 Page Not Found: /index
ERROR - 2022-03-14 11:39:03 --> 404 Page Not Found: /index
ERROR - 2022-03-14 11:40:06 --> 404 Page Not Found: /index
ERROR - 2022-03-14 11:40:07 --> 404 Page Not Found: /index
ERROR - 2022-03-14 11:40:13 --> 404 Page Not Found: /index
ERROR - 2022-03-14 11:42:21 --> 404 Page Not Found: /index
ERROR - 2022-03-14 11:43:42 --> 404 Page Not Found: /index
ERROR - 2022-03-14 11:43:48 --> Query error: Unknown column 'activation_code' in 'field list' - Invalid query: INSERT INTO `tbl_primary_info` (`email`, `password`, `mobile`, `first_name`, `last_name`, `gender`, `date`, `month`, `year`, `profile_id`, `living_in`, `age`, `status`, `registered_on`, `activation_code`) VALUES ('pavuluri.sneha97@gmail.com', '809e67e8b07095844c2a60c060670918', '9052034999', 'Sneha', 'pavuluri', 'female', '5', 'Apr', '1997', 'KV974076', 'India', 25, 1, '2022-03-14 11:43:48', 'izkvo6mYWA9H')
ERROR - 2022-03-14 11:44:18 --> 404 Page Not Found: /index
ERROR - 2022-03-14 11:45:48 --> Query error: Unknown column 'activation_code' in 'field list' - Invalid query: INSERT INTO `tbl_primary_info` (`email`, `password`, `mobile`, `first_name`, `last_name`, `gender`, `date`, `month`, `year`, `profile_id`, `living_in`, `age`, `status`, `registered_on`, `activation_code`) VALUES ('vetukuri@gmail.com', '09c0ab27ba6f5398d95e1559d04d4ddf', '9246999148', 'Mohan Chowdary', 'Vetukuri', 'male', '25', 'Sep', '1992', 'KV924076', 'India', 30, 1, '2022-03-14 11:45:48', 'uPLmgq2SfoEO')
ERROR - 2022-03-14 11:45:58 --> 404 Page Not Found: /index
ERROR - 2022-03-14 11:48:03 --> 404 Page Not Found: /index
ERROR - 2022-03-14 11:48:05 --> 404 Page Not Found: /index
ERROR - 2022-03-14 11:48:21 --> 404 Page Not Found: /index
ERROR - 2022-03-14 11:48:59 --> 404 Page Not Found: /index
ERROR - 2022-03-14 11:49:43 --> 404 Page Not Found: /index
ERROR - 2022-03-14 11:49:47 --> 404 Page Not Found: /index
ERROR - 2022-03-14 11:50:02 --> 404 Page Not Found: /index
ERROR - 2022-03-14 11:50:38 --> 404 Page Not Found: /index
ERROR - 2022-03-14 11:50:47 --> 404 Page Not Found: /index
ERROR - 2022-03-14 11:51:05 --> 404 Page Not Found: /index
ERROR - 2022-03-14 11:51:06 --> 404 Page Not Found: /index
ERROR - 2022-03-14 11:51:36 --> 404 Page Not Found: /index
ERROR - 2022-03-14 11:52:07 --> 404 Page Not Found: /index
ERROR - 2022-03-14 11:53:07 --> 404 Page Not Found: /index
ERROR - 2022-03-14 11:54:20 --> Query error: Unknown column 'activation_code' in 'field list' - Invalid query: INSERT INTO `tbl_primary_info` (`email`, `password`, `mobile`, `first_name`, `last_name`, `gender`, `date`, `month`, `year`, `profile_id`, `living_in`, `age`, `status`, `registered_on`, `activation_code`) VALUES ('9491975400@s@gmail.com', '3f96ac7c2bfa7bee77f3d94a5e083ddb', '9491975400', 'Kishore ', 'Simhadri', 'male', '17', 'Jul', '1995', 'KV954076', 'India', 27, 1, '2022-03-14 11:54:20', 'YexKwGTuVn8b')
ERROR - 2022-03-14 11:54:27 --> 404 Page Not Found: /index
ERROR - 2022-03-14 11:55:18 --> 404 Page Not Found: /index
ERROR - 2022-03-14 11:55:20 --> 404 Page Not Found: /index
ERROR - 2022-03-14 11:55:30 --> 404 Page Not Found: /index
ERROR - 2022-03-14 11:56:27 --> 404 Page Not Found: /index
ERROR - 2022-03-14 11:56:41 --> 404 Page Not Found: /index
ERROR - 2022-03-14 11:57:04 --> 404 Page Not Found: /index
ERROR - 2022-03-14 11:57:19 --> 404 Page Not Found: /index
ERROR - 2022-03-14 11:59:02 --> 404 Page Not Found: /index
ERROR - 2022-03-14 11:59:24 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:00:14 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:00:14 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:00:22 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:00:25 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT `p`.*, `r`.`caste`, `r`.`height`, `r`.`star`, `r`.`time_of_birth`, `r`.`raasi`, `prp`.`property_value`, `e`.`occupation`, `e`.`education_degree`, `e`.`visatype`, `e`.`city`, `e`.`country`, `e`.`annual_income`, `pi`.`fathers_father_native_place`, `pi`.`mothers_father_native_place`, `pi`.`father_mobile`, `pfs`.`payment_status`, `pfs`.`profilesetting_id` as `pfs_id`, `pfs`.`last_call_updated`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `adm`.`username` as `profile_owner`
FROM `tbl_primary_info` as `p`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `ms_property_info` as `prp` ON `p`.`id`=`prp`.`ms_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `tbl_parents_info` as `pi` ON `p`.`id`=`pi`.`user_id`
LEFT JOIN `ms_profilesetting` as `pfs` ON `p`.`id`=`pfs`.`ms_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`MS_id` AND `u`.`ismain`="1" AND `u`.`isactive`="1"
LEFT JOIN `tbl_admin_data` as `adm` ON `pfs`.`profileowner`=`adm`.`id`
WHERE `p`.`gender` = 'female'
AND `p`.`status` = '1'
AND `r`.`caste` = `Array`
AND `pfs`.`profileowner` = '12'
AND `adm`.`id` = '12'
GROUP BY `p`.`id`
ERROR - 2022-03-14 12:00:25 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:00:52 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:01:01 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:02:22 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:04:51 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:04:51 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:05:42 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:05:51 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:08:11 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:08:26 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:08:29 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:08:29 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:09:18 --> 404 Page Not Found: ../modules/admin/controllers/Admin_ap/confidentialprofiles
ERROR - 2022-03-14 12:09:23 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:09:27 --> 404 Page Not Found: ../modules/admin/controllers/Admin_ap/confidentialprofiles
ERROR - 2022-03-14 12:09:30 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:10:40 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:12:00 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:14:43 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:16:55 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:17:06 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:17:16 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:17:27 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:17:34 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:17:57 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:18:26 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:18:26 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:21:27 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:22:55 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:22:55 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:23:45 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT `p`.*, `r`.`caste`, `r`.`height`, `r`.`star`, `r`.`time_of_birth`, `r`.`raasi`, `prp`.`property_value`, `e`.`occupation`, `e`.`education_degree`, `e`.`visatype`, `e`.`city`, `e`.`country`, `e`.`annual_income`, `pi`.`fathers_father_native_place`, `pi`.`mothers_father_native_place`, `pi`.`father_mobile`, `pfs`.`payment_status`, `pfs`.`profilesetting_id` as `pfs_id`, `pfs`.`last_call_updated`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `adm`.`username` as `profile_owner`
FROM `tbl_primary_info` as `p`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `ms_property_info` as `prp` ON `p`.`id`=`prp`.`ms_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `tbl_parents_info` as `pi` ON `p`.`id`=`pi`.`user_id`
LEFT JOIN `ms_profilesetting` as `pfs` ON `p`.`id`=`pfs`.`ms_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`MS_id` AND `u`.`ismain`="1" AND `u`.`isactive`="1"
LEFT JOIN `tbl_admin_data` as `adm` ON `pfs`.`profileowner`=`adm`.`id`
WHERE `p`.`gender` = 'female'
AND `p`.`status` = '1'
AND `r`.`caste` = `Array`
AND `pfs`.`profileowner` = '12'
AND `adm`.`id` = '12'
GROUP BY `p`.`id`
ERROR - 2022-03-14 12:24:17 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:24:20 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:24:44 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:24:50 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:25:08 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:25:18 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:26:02 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:26:47 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:27:52 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:28:54 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:29:56 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:30:45 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:31:00 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:32:20 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:32:28 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:33:52 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:33:57 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:34:22 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:34:23 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:35:22 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:35:40 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:36:18 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:37:05 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:37:29 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:38:44 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:40:20 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:42:14 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:42:38 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:42:55 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:43:28 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:43:44 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:44:26 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:44:56 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:44:56 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:45:15 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:46:00 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:46:26 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:47:13 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:48:13 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:49:09 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:49:49 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:52:22 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:52:56 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:53:21 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:53:42 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:54:21 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:55:12 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:56:35 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:56:49 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:57:28 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:58:30 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:59:17 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:59:23 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:59:24 --> 404 Page Not Found: /index
ERROR - 2022-03-14 12:59:26 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:00:01 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:00:08 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:00:12 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:01:20 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:01:55 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:01:59 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:02:00 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:02:31 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:03:19 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:03:39 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:03:44 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:04:00 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:04:14 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:04:14 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:04:16 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:04:40 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:05:48 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:06:09 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:07:15 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:08:19 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:08:34 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:09:40 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:09:53 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:10:18 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:10:39 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:10:58 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:10:59 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:11:43 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:13:26 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:13:51 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:14:09 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:16:10 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:16:49 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:20:48 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:22:55 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:24:00 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:24:30 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:26:33 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:27:06 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:27:25 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:27:25 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:28:03 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:29:58 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:29:58 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:30:40 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:30:52 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:31:00 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:31:16 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:31:33 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:31:47 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:32:06 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:32:23 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:32:34 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:32:47 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:35:37 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:36:36 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:37:06 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:37:43 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:37:47 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:38:48 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:40:07 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:40:59 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:41:28 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:41:39 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:41:53 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:41:57 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:42:15 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:43:02 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:43:28 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:44:15 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:44:21 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:44:22 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:44:22 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:44:22 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:44:22 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:44:23 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:44:23 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:44:23 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:44:23 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:44:23 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:45:28 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:47:46 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:48:46 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:49:20 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:49:29 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:51:34 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:52:01 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:52:54 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:53:37 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:55:04 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:55:08 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:55:49 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:55:54 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:55:55 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:56:07 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:56:24 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:58:10 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:58:31 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:59:26 --> 404 Page Not Found: /index
ERROR - 2022-03-14 13:59:43 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:00:50 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:01:07 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:01:42 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:02:45 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:03:01 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:03:48 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:04:24 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:05:10 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:06:24 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:06:53 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:07:05 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:07:45 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:08:29 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:09:37 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:10:05 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:13:24 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:14:17 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:16:07 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:17:13 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:18:11 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:18:17 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:18:18 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:18:47 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:20:59 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:21:33 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:21:35 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:21:44 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:22:51 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:23:18 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:23:44 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:23:58 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:24:37 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:24:50 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:25:47 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:26:06 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:26:33 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:26:40 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:26:47 --> Severity: error --> Exception: Invalid address:  (to):  /home4/cowcdrmy/public_html/application/third_party/phpmailer/src/PHPMailer.php 1092
ERROR - 2022-03-14 14:26:50 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:27:17 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:28:05 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:29:50 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:30:22 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:30:27 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:31:21 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:31:57 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:33:51 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:34:19 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:34:21 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:35:17 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:37:11 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:39:34 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:39:52 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:40:13 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:40:44 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:40:55 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:41:08 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:42:39 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:42:48 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:42:56 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:43:30 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:44:06 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:44:58 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:45:11 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:46:21 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:46:33 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:46:46 --> Query error: Unknown column 'activation_code' in 'field list' - Invalid query: INSERT INTO `tbl_primary_info` (`email`, `password`, `mobile`, `first_name`, `last_name`, `gender`, `date`, `month`, `year`, `profile_id`, `living_in`, `age`, `status`, `registered_on`, `activation_code`) VALUES ('kishoresimhadri@gmail.com', '69b42c3db4d4fab732bdf55c201d05ae', '9491972400', 'Kishore', 'Simhadri', 'male', '17', 'Jul', '1995', 'KV954078', 'India', 27, 1, '2022-03-14 14:46:46', 'E1XP6kClpZIY')
ERROR - 2022-03-14 14:47:15 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:47:56 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:47:57 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:48:03 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:49:44 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:50:04 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:50:14 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:50:27 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:50:40 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:50:53 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:50:54 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:50:55 --> Query error: Unknown column 'activation_code' in 'field list' - Invalid query: INSERT INTO `tbl_primary_info` (`email`, `password`, `mobile`, `first_name`, `last_name`, `gender`, `date`, `month`, `year`, `profile_id`, `living_in`, `age`, `status`, `registered_on`, `activation_code`) VALUES ('kishoresimhadri@gmail.com', '148874e36e82eedd4f7ab9e9855d5746', '9491972400', 'Kishore', 'simhadri', 'male', '17', 'Jul', '1995', 'KV954078', 'India', 27, 1, '2022-03-14 14:50:55', 'wnXNIMfiZvKj')
ERROR - 2022-03-14 14:50:56 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:52:41 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:53:14 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:53:59 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:54:11 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:54:49 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:55:16 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:55:25 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:55:38 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:55:39 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:57:00 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:57:01 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:57:56 --> Query error: Unknown column 'activation_code' in 'field list' - Invalid query: INSERT INTO `tbl_primary_info` (`email`, `password`, `mobile`, `first_name`, `last_name`, `gender`, `date`, `month`, `year`, `profile_id`, `living_in`, `age`, `status`, `registered_on`, `activation_code`) VALUES ('Kishores@gmail.com', 'ccf0ec3a251dd893088058124e697990', '9491972400', 'Kishore', 'Simhadri', 'male', '17', 'Jul', '1995', 'KV954078', 'India', 27, 1, '2022-03-14 14:57:56', 'gktBdJFa5S8X')
ERROR - 2022-03-14 14:58:59 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:59:30 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:59:52 --> 404 Page Not Found: /index
ERROR - 2022-03-14 14:59:58 --> Query error: Unknown column 'activation_code' in 'field list' - Invalid query: INSERT INTO `tbl_primary_info` (`email`, `password`, `mobile`, `first_name`, `last_name`, `gender`, `date`, `month`, `year`, `profile_id`, `living_in`, `age`, `status`, `registered_on`, `activation_code`) VALUES ('mounikak@gmail.com', '3574e48da07e01d291f308e1a6e8eaac', '9573560566', 'Mounika', 'K', 'female', '14', 'May', '1998', 'KV984078', 'India', 24, 1, '2022-03-14 14:59:58', 'cY2CXbA3tdZe')
ERROR - 2022-03-14 14:59:58 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:00:11 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:00:26 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:00:27 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:01:01 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:01:22 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:01:23 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:01:34 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:03:35 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:03:41 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:04:03 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:04:08 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:05:43 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:06:04 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:06:37 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:06:47 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:06:48 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:07:09 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:07:31 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:07:31 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:08:12 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:09:00 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:09:00 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:09:00 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:09:09 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:09:11 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:09:20 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:09:20 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:09:30 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:09:53 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:13:37 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:13:40 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:13:58 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:15:21 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:17:34 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-14 15:17:48 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:18:06 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:18:31 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:20:53 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:21:24 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:21:49 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:21:55 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:22:31 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:22:42 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:23:00 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:23:40 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:27:09 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:27:31 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:28:00 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:28:22 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:29:14 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:29:52 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:31:11 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:31:31 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:31:38 --> 404 Page Not Found: ../modules/admin/controllers/Admin_ap/confidentialprofiles
ERROR - 2022-03-14 15:32:13 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:32:55 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-14 15:32:55')
ERROR - 2022-03-14 15:33:10 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:33:32 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:33:33 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:34:24 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:34:30 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:34:47 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:35:03 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:35:14 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:36:54 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:37:00 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:37:02 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:38:14 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:38:16 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:38:33 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:38:54 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:39:20 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:39:42 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:39:45 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:39:47 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:39:52 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:40:22 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:40:24 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:41:07 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:42:10 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:43:00 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:43:05 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-14 15:43:05')
ERROR - 2022-03-14 15:44:04 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:44:29 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:45:18 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:45:24 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:46:17 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:46:27 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:46:29 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:46:59 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:47:02 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:47:07 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:47:33 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:49:12 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:50:12 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:52:19 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:52:21 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:54:22 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:55:17 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:55:41 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:56:16 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:56:32 --> To Id is not available for User - 4019
ERROR - 2022-03-14 15:56:35 --> To Id is not available for User - 4019
ERROR - 2022-03-14 15:56:37 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:56:40 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:56:51 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:57:24 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:57:45 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:57:54 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:58:15 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:59:15 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:59:22 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:59:38 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:59:38 --> 404 Page Not Found: /index
ERROR - 2022-03-14 15:59:41 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:00:06 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:00:08 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:01:15 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:02:35 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:02:56 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:04:07 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:04:15 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:04:49 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:05:29 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:05:39 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:05:40 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:05:43 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:05:44 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:05:46 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:05:47 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:05:52 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:05:53 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:06:02 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:06:09 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:06:39 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:06:55 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:07:04 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:07:06 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:07:07 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:07:18 --> To Id is not available for User - 2176
ERROR - 2022-03-14 16:07:21 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:08:01 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:09:04 --> To Id is not available for User - 2176
ERROR - 2022-03-14 16:09:41 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:09:49 --> To Id is not available for User - 2243
ERROR - 2022-03-14 16:10:10 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:10:41 --> To Id is not available for User - 2301
ERROR - 2022-03-14 16:11:04 --> To Id is not available for User - 2373
ERROR - 2022-03-14 16:11:05 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:11:23 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:12:11 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:12:51 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:12:54 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:13:04 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:13:30 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:13:40 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:14:30 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:15:08 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT `p`.*, `r`.`caste`, `r`.`height`, `r`.`star`, `r`.`time_of_birth`, `r`.`raasi`, `prp`.`property_value`, `e`.`occupation`, `e`.`education_degree`, `e`.`visatype`, `e`.`city`, `e`.`country`, `e`.`annual_income`, `pi`.`fathers_father_native_place`, `pi`.`mothers_father_native_place`, `pi`.`father_mobile`, `pfs`.`payment_status`, `pfs`.`profilesetting_id` as `pfs_id`, `pfs`.`last_call_updated`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `adm`.`username` as `profile_owner`
FROM `tbl_primary_info` as `p`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `ms_property_info` as `prp` ON `p`.`id`=`prp`.`ms_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `tbl_parents_info` as `pi` ON `p`.`id`=`pi`.`user_id`
LEFT JOIN `ms_profilesetting` as `pfs` ON `p`.`id`=`pfs`.`ms_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`MS_id` AND `u`.`ismain`="1" AND `u`.`isactive`="1"
LEFT JOIN `tbl_admin_data` as `adm` ON `pfs`.`profileowner`=`adm`.`id`
WHERE `p`.`gender` = 'female'
AND `r`.`caste` = `Array`
GROUP BY `p`.`id`
ERROR - 2022-03-14 16:15:39 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:17:10 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:17:12 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:17:13 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:17:14 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:17:16 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:17:27 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:17:30 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:18:04 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:18:40 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:18:43 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:18:57 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:21:12 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:23:02 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:24:19 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:25:12 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:30:34 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:30:48 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:31:28 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:31:32 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:32:54 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:33:32 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:33:44 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:34:14 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:35:41 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:36:06 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:36:06 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:36:06 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:36:06 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:36:16 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:38:21 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:39:37 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:40:40 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:41:14 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:44:57 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:45:00 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:45:01 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:45:16 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:46:51 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:46:58 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:47:01 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:47:58 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:50:06 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:50:18 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:53:03 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:54:19 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:55:44 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:56:20 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:56:35 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:57:53 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:58:54 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:59:02 --> 404 Page Not Found: /index
ERROR - 2022-03-14 16:59:33 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:00:23 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:00:27 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:00:45 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:00:53 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:04:16 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:04:28 --> Query error: Unknown column 'activation_code' in 'field list' - Invalid query: INSERT INTO `tbl_primary_info` (`email`, `password`, `mobile`, `first_name`, `last_name`, `gender`, `date`, `month`, `year`, `profile_id`, `living_in`, `age`, `status`, `registered_on`, `activation_code`) VALUES ('anilgunnam597@gmail.com', 'a5ffdcc9220fc736fb29dc11b58f25ac', '9100049448', 'Gunnam', 'anil Kumar ', 'male', '24', 'Jun', '1985', 'KV854080', 'India', 37, 1, '2022-03-14 17:04:28', 'kKreiM7ExozQ')
ERROR - 2022-03-14 17:04:38 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:04:56 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:05:26 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-14 17:05:26')
ERROR - 2022-03-14 17:05:52 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:05:57 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:06:27 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:07:40 --> Query error: Table 'cowcdrmy_kammamarriage.ms_shortlist_viewedd_ignored' doesn't exist - Invalid query: SELECT `v`.*, `p`.`gender`, `p`.`id`, `p`.`status`, `p`.`age`, `p`.`living_in`, `p`.`profile_id`, `p`.`first_name`, `last_name`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `s`.*
FROM `kv_profileview` as `v`
LEFT JOIN `tbl_primary_info` as `p` ON `v`.`kv_profileview_on` = `p`.`id`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`ms_id`
INNER JOIN `ms_profilesetting` as `s` ON `p`.`id`=`s`.`ms_id`
WHERE `s`.`elite` = 'no'
AND `p`.`status` = 1
AND `v`.`kv_userfkid` = '401'
AND `u`.`ismain` = 1
AND  `p`.`id` not in(select kv_msi_interested_on from kv_mysideinterests where kv_msi_profilefkid="401")
AND  p.id not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid = "401" AND `shortlist_status` = 1)
AND  `p`.`id` not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid="401"AND ignore_status=1)
ORDER BY `v`.`kv_profileview_created_date` DESC
 LIMIT 10
ERROR - 2022-03-14 17:07:45 --> Query error: Table 'cowcdrmy_kammamarriage.ms_shortlist_viewedd_ignored' doesn't exist - Invalid query: SELECT `v`.*, `p`.`gender`, `p`.`id`, `p`.`status`, `p`.`age`, `p`.`living_in`, `p`.`profile_id`, `p`.`first_name`, `last_name`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `s`.*
FROM `kv_profileview` as `v`
LEFT JOIN `tbl_primary_info` as `p` ON `v`.`kv_profileview_on` = `p`.`id`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`ms_id`
INNER JOIN `ms_profilesetting` as `s` ON `p`.`id`=`s`.`ms_id`
WHERE `s`.`elite` = 'no'
AND `p`.`status` = 1
AND `v`.`kv_userfkid` = '401'
AND `u`.`ismain` = 1
AND  `p`.`id` not in(select kv_msi_interested_on from kv_mysideinterests where kv_msi_profilefkid="401")
AND  p.id not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid = "401" AND `shortlist_status` = 1)
AND  `p`.`id` not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid="401"AND ignore_status=1)
ORDER BY `v`.`kv_profileview_created_date` DESC
 LIMIT 10
ERROR - 2022-03-14 17:07:48 --> Severity: error --> Exception: Call to a member function result_array() on null /home4/cowcdrmy/public_html/application/modules/dashboard/models/My_account_model.php 911
ERROR - 2022-03-14 17:08:04 --> Query error: Table 'cowcdrmy_kammamarriage.ms_shortlist_viewedd_ignored' doesn't exist - Invalid query: SELECT `v`.*, `p`.`gender`, `p`.`id`, `p`.`status`, `p`.`age`, `p`.`living_in`, `p`.`profile_id`, `p`.`first_name`, `last_name`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `s`.*
FROM `kv_profileview` as `v`
LEFT JOIN `tbl_primary_info` as `p` ON `v`.`kv_profileview_on` = `p`.`id`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`ms_id`
INNER JOIN `ms_profilesetting` as `s` ON `p`.`id`=`s`.`ms_id`
WHERE `s`.`elite` = 'no'
AND `p`.`status` = 1
AND `v`.`kv_userfkid` = '401'
AND `u`.`ismain` = 1
AND  `p`.`id` not in(select kv_msi_interested_on from kv_mysideinterests where kv_msi_profilefkid="401")
AND  p.id not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid = "401" AND `shortlist_status` = 1)
AND  `p`.`id` not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid="401"AND ignore_status=1)
ORDER BY `v`.`kv_profileview_created_date` DESC
 LIMIT 10
ERROR - 2022-03-14 17:08:08 --> Query error: Table 'cowcdrmy_kammamarriage.ms_shortlist_viewedd_ignored' doesn't exist - Invalid query: SELECT `v`.*, `p`.`gender`, `p`.`id`, `p`.`status`, `p`.`age`, `p`.`living_in`, `p`.`profile_id`, `p`.`first_name`, `last_name`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `s`.*
FROM `kv_profileview` as `v`
LEFT JOIN `tbl_primary_info` as `p` ON `v`.`kv_profileview_on` = `p`.`id`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`ms_id`
INNER JOIN `ms_profilesetting` as `s` ON `p`.`id`=`s`.`ms_id`
WHERE `s`.`elite` = 'no'
AND `p`.`status` = 1
AND `v`.`kv_userfkid` = '401'
AND `u`.`ismain` = 1
AND  `p`.`id` not in(select kv_msi_interested_on from kv_mysideinterests where kv_msi_profilefkid="401")
AND  p.id not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid = "401" AND `shortlist_status` = 1)
AND  `p`.`id` not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid="401"AND ignore_status=1)
ORDER BY `v`.`kv_profileview_created_date` DESC
 LIMIT 10
ERROR - 2022-03-14 17:08:12 --> Query error: Table 'cowcdrmy_kammamarriage.ms_shortlist_viewedd_ignored' doesn't exist - Invalid query: SELECT `v`.*, `p`.`gender`, `p`.`id`, `p`.`status`, `p`.`age`, `p`.`living_in`, `p`.`profile_id`, `p`.`first_name`, `last_name`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `s`.*
FROM `kv_profileview` as `v`
LEFT JOIN `tbl_primary_info` as `p` ON `v`.`kv_profileview_on` = `p`.`id`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`ms_id`
INNER JOIN `ms_profilesetting` as `s` ON `p`.`id`=`s`.`ms_id`
WHERE `s`.`elite` = 'no'
AND `p`.`status` = 1
AND `v`.`kv_userfkid` = '401'
AND `u`.`ismain` = 1
AND  `p`.`id` not in(select kv_msi_interested_on from kv_mysideinterests where kv_msi_profilefkid="401")
AND  p.id not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid = "401" AND `shortlist_status` = 1)
AND  `p`.`id` not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid="401"AND ignore_status=1)
ORDER BY `v`.`kv_profileview_created_date` DESC
 LIMIT 10
ERROR - 2022-03-14 17:10:49 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:13:29 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:13:46 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:17:44 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:18:01 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:18:12 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:18:56 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:19:48 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:22:22 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:22:24 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:23:04 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:23:04 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:23:04 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:23:05 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:23:05 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:23:05 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:23:18 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:23:23 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:23:23 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:23:23 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:23:25 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:23:25 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:23:25 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:23:27 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:23:27 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:23:27 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:23:28 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:23:28 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:23:28 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:23:46 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:23:46 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:23:47 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:23:49 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:23:49 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:23:49 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:23:55 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:23:56 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:23:56 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:23:57 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:23:57 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:23:57 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:23:59 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:23:59 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:23:59 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:24:07 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:24:09 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:24:09 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:24:09 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:24:10 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:24:10 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:24:22 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:24:40 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:25:42 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:27:12 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:28:38 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:29:00 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:29:02 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:30:03 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:30:06 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:30:06 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:30:06 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:30:29 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:31:14 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:34:04 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:35:07 --> 404 Page Not Found: ../modules/admin/controllers/Admin_ap/confidentialprofiles
ERROR - 2022-03-14 17:35:46 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:36:22 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:37:11 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:37:17 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:37:17 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:37:25 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:37:25 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:37:44 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:38:09 --> To Id is not available for User - �
ERROR - 2022-03-14 17:38:09 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:38:10 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:38:17 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:38:23 --> Query error: Table 'cowcdrmy_kammamarriage.ms_shortlist_viewedd_ignored' doesn't exist - Invalid query: SELECT `v`.*, `p`.`gender`, `p`.`id`, `p`.`status`, `p`.`age`, `p`.`living_in`, `p`.`profile_id`, `p`.`first_name`, `last_name`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `s`.*
FROM `kv_profileview` as `v`
LEFT JOIN `tbl_primary_info` as `p` ON `v`.`kv_profileview_on` = `p`.`id`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`ms_id`
INNER JOIN `ms_profilesetting` as `s` ON `p`.`id`=`s`.`ms_id`
WHERE `s`.`elite` = 'no'
AND `p`.`status` = 1
AND `v`.`kv_userfkid` = '401'
AND `u`.`ismain` = 1
AND  `p`.`id` not in(select kv_msi_interested_on from kv_mysideinterests where kv_msi_profilefkid="401")
AND  p.id not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid = "401" AND `shortlist_status` = 1)
AND  `p`.`id` not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid="401"AND ignore_status=1)
ORDER BY `v`.`kv_profileview_created_date` DESC
 LIMIT 10
ERROR - 2022-03-14 17:38:36 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:38:42 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:38:47 --> Severity: error --> Exception: Call to a member function result_array() on null /home4/cowcdrmy/public_html/application/modules/dashboard/models/My_account_model.php 911
ERROR - 2022-03-14 17:38:48 --> Query error: Table 'cowcdrmy_kammamarriage.ms_shortlist_viewedd_ignored' doesn't exist - Invalid query: SELECT `v`.*, `p`.`gender`, `p`.`id`, `p`.`status`, `p`.`age`, `p`.`living_in`, `p`.`profile_id`, `p`.`first_name`, `last_name`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `s`.*
FROM `kv_profileview` as `v`
LEFT JOIN `tbl_primary_info` as `p` ON `v`.`kv_profileview_on` = `p`.`id`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`ms_id`
INNER JOIN `ms_profilesetting` as `s` ON `p`.`id`=`s`.`ms_id`
WHERE `s`.`elite` = 'no'
AND `p`.`status` = 1
AND `v`.`kv_userfkid` = '401'
AND `u`.`ismain` = 1
AND  `p`.`id` not in(select kv_msi_interested_on from kv_mysideinterests where kv_msi_profilefkid="401")
AND  p.id not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid = "401" AND `shortlist_status` = 1)
AND  `p`.`id` not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid="401"AND ignore_status=1)
ORDER BY `v`.`kv_profileview_created_date` DESC
 LIMIT 10
ERROR - 2022-03-14 17:38:50 --> Severity: error --> Exception: Call to a member function result_array() on null /home4/cowcdrmy/public_html/application/modules/dashboard/models/My_account_model.php 911
ERROR - 2022-03-14 17:39:06 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:39:07 --> Query error: Table 'cowcdrmy_kammamarriage.ms_shortlist_viewedd_ignored' doesn't exist - Invalid query: SELECT `v`.*, `p`.`gender`, `p`.`id`, `p`.`status`, `p`.`age`, `p`.`living_in`, `p`.`profile_id`, `p`.`first_name`, `last_name`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `s`.*
FROM `kv_profileview` as `v`
LEFT JOIN `tbl_primary_info` as `p` ON `v`.`kv_profileview_on` = `p`.`id`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`ms_id`
INNER JOIN `ms_profilesetting` as `s` ON `p`.`id`=`s`.`ms_id`
WHERE `s`.`elite` = 'no'
AND `p`.`status` = 1
AND `v`.`kv_userfkid` = '401'
AND `u`.`ismain` = 1
AND  `p`.`id` not in(select kv_msi_interested_on from kv_mysideinterests where kv_msi_profilefkid="401")
AND  p.id not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid = "401" AND `shortlist_status` = 1)
AND  `p`.`id` not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid="401"AND ignore_status=1)
ORDER BY `v`.`kv_profileview_created_date` DESC
 LIMIT 10
ERROR - 2022-03-14 17:39:14 --> Severity: error --> Exception: Call to a member function result_array() on null /home4/cowcdrmy/public_html/application/modules/dashboard/models/My_account_model.php 911
ERROR - 2022-03-14 17:39:18 --> Severity: error --> Exception: Call to a member function result_array() on null /home4/cowcdrmy/public_html/application/modules/dashboard/models/My_account_model.php 911
ERROR - 2022-03-14 17:39:20 --> Severity: error --> Exception: Call to a member function result_array() on null /home4/cowcdrmy/public_html/application/modules/dashboard/models/My_account_model.php 911
ERROR - 2022-03-14 17:39:29 --> Severity: error --> Exception: Call to a member function result_array() on null /home4/cowcdrmy/public_html/application/modules/dashboard/models/My_account_model.php 911
ERROR - 2022-03-14 17:39:41 --> Severity: error --> Exception: Call to a member function result_array() on null /home4/cowcdrmy/public_html/application/modules/dashboard/models/My_account_model.php 911
ERROR - 2022-03-14 17:40:51 --> Severity: error --> Exception: Call to a member function result_array() on null /home4/cowcdrmy/public_html/application/modules/dashboard/models/My_account_model.php 911
ERROR - 2022-03-14 17:41:07 --> Severity: error --> Exception: Call to undefined method My_account_model::from() /home4/cowcdrmy/public_html/application/modules/dashboard/models/My_account_model.php 849
ERROR - 2022-03-14 17:42:45 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:42:53 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:44:04 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:44:14 --> Query error: Unknown column 'activation_code' in 'field list' - Invalid query: INSERT INTO `tbl_primary_info` (`email`, `password`, `mobile`, `first_name`, `last_name`, `gender`, `date`, `month`, `year`, `profile_id`, `living_in`, `age`, `status`, `registered_on`, `activation_code`) VALUES ('taruntammineni9@gmail.com', '40fe36bfd9fe2b1fe4def2dd9cd254b0', '8886884997', 'Tarun', 'Tammineni', 'male', '16', 'May', '1992', 'KV924080', 'India', 30, 1, '2022-03-14 17:44:14', 'w7jOdHYgqWG6')
ERROR - 2022-03-14 17:45:41 --> Query error: Unknown column 'activation_code' in 'field list' - Invalid query: INSERT INTO `tbl_primary_info` (`email`, `password`, `mobile`, `first_name`, `last_name`, `gender`, `date`, `month`, `year`, `profile_id`, `living_in`, `age`, `status`, `registered_on`, `activation_code`) VALUES ('Bandarupalli1@gmail.com', 'c4f0f2b31f96ad43c0223cf8f8d97bae', '9392568273', 'Kishore', 'Bandarupalli', 'male', '3', 'Nov', '1993', 'KV934080', 'USA', 29, 1, '2022-03-14 17:45:41', 'sZVWrPwGbnH4')
ERROR - 2022-03-14 17:46:22 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:47:52 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:48:10 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:48:28 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:48:32 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:48:54 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:50:04 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:50:30 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:51:03 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:51:27 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:51:33 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:52:03 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:53:12 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:53:24 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:55:48 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:55:52 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:58:32 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:58:56 --> 404 Page Not Found: /index
ERROR - 2022-03-14 17:59:30 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE ms.profileowner IS NULL' at line 7 - Invalid query: SELECT cs.caste,  pinfo.father_mobile, ms.*, prm.profile_id as ms_profile_id, CONCAT( prm.last_name,' ' ,prm.first_name) as ms_user_name 
        from ms_profilesetting as ms 
        JOIN tbl_primary_info as prm ON prm.id = ms.ms_id  
        JOIN tbl_parents_info as pinfo on pinfo.user_id = ms.ms_id  
        JOIN tbl_religion_info as cs ON cs.user_id = ms.ms_id   
        WHERE prm.status = 0
        WHERE ms.profileowner IS NULL 
ERROR - 2022-03-14 17:59:38 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:00:06 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:00:06 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE ms.profileowner IS NULL' at line 7 - Invalid query: SELECT cs.caste,  pinfo.father_mobile, ms.*, prm.profile_id as ms_profile_id, CONCAT( prm.last_name,' ' ,prm.first_name) as ms_user_name 
        from ms_profilesetting as ms 
        JOIN tbl_primary_info as prm ON prm.id = ms.ms_id  
        JOIN tbl_parents_info as pinfo on pinfo.user_id = ms.ms_id  
        JOIN tbl_religion_info as cs ON cs.user_id = ms.ms_id   
        WHERE prm.status = 0 AND
        WHERE ms.profileowner IS NULL 
ERROR - 2022-03-14 18:00:08 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near 'WHERE ms.profileowner IS NULL' at line 7 - Invalid query: SELECT cs.caste,  pinfo.father_mobile, ms.*, prm.profile_id as ms_profile_id, CONCAT( prm.last_name,' ' ,prm.first_name) as ms_user_name 
        from ms_profilesetting as ms 
        JOIN tbl_primary_info as prm ON prm.id = ms.ms_id  
        JOIN tbl_parents_info as pinfo on pinfo.user_id = ms.ms_id  
        JOIN tbl_religion_info as cs ON cs.user_id = ms.ms_id   
        WHERE prm.status = 0 AND
        WHERE ms.profileowner IS NULL 
ERROR - 2022-03-14 18:00:13 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:00:13 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:00:13 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:00:50 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:05:23 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:06:42 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:07:39 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:08:23 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:08:23 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:08:23 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:08:24 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:08:24 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:08:24 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:08:24 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:08:35 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:08:35 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:08:35 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:08:36 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:08:36 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:08:36 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:08:38 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:08:38 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:08:38 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:08:38 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:08:38 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:08:38 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:09:11 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:10:58 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:12:33 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:12:47 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:16:24 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:16:34 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:20:03 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:20:03 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:20:18 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:20:28 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:21:16 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:21:28 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:22:27 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:22:58 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:25:32 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:26:05 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:26:06 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:27:07 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:27:14 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:28:06 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:28:43 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-14 18:28:51 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-14 18:29:02 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:29:02 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:29:03 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:29:03 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:30:31 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:32:05 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:32:08 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:32:28 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:33:04 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:33:07 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:33:08 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:34:26 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:34:36 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:34:46 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:35:00 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:35:48 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:36:08 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:36:38 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:37:06 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:37:07 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:37:15 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:37:43 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:37:43 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:37:50 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:41:33 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:42:23 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:43:05 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:43:22 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:43:33 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-14 18:43:33')
ERROR - 2022-03-14 18:43:35 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:45:33 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:47:21 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:47:54 --> To Id is not available for User - 2069
ERROR - 2022-03-14 18:47:57 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:48:39 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:48:47 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:49:13 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:49:27 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:51:03 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:51:42 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:51:54 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:54:39 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:56:02 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:56:31 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:57:01 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:57:34 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:58:16 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:58:26 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:58:27 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:58:27 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:58:28 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:58:29 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:58:29 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:58:30 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:58:31 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:58:31 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:58:32 --> 404 Page Not Found: /index
ERROR - 2022-03-14 18:59:56 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:00:08 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:00:13 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:03:05 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:03:14 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:03:17 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:03:25 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:03:31 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:05:11 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:05:17 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:06:20 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:07:08 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:07:09 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:07:09 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:07:35 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:08:03 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:08:12 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:08:34 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:08:44 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:08:46 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:08:52 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:08:55 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-14 19:09:02 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-14 19:09:25 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:09:27 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:09:38 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:09:44 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:09:44 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:09:44 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:09:45 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:09:45 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:09:45 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:09:47 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:09:47 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:09:47 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:09:47 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:09:47 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:09:47 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:09:47 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:09:47 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:09:47 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:09:53 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:10:05 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:10:07 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:10:14 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:10:52 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:10:53 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:11:27 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:12:27 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:13:09 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:13:11 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:13:26 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:13:34 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:13:39 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:14:46 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:15:07 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:15:40 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:15:57 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:17:21 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:17:25 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:17:28 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:17:34 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:17:52 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:18:05 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:18:20 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:19:41 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:20:18 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:20:51 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:22:44 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:23:35 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:25:06 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:25:07 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:25:07 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:25:07 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:25:07 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:25:07 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:25:08 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:25:08 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:25:08 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:25:08 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:25:37 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:27:42 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:28:21 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:29:03 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:29:03 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:29:57 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:30:55 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:31:57 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:31:58 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:32:25 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:32:51 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:33:58 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:34:15 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:34:30 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:34:50 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:35:24 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:36:43 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:37:08 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:37:23 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:38:22 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:39:20 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:39:35 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:39:41 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:40:04 --> To Id is not available for User - 1887
ERROR - 2022-03-14 19:40:05 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:40:45 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:40:50 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:41:22 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:43:53 --> To Id is not available for User - 1319
ERROR - 2022-03-14 19:45:56 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:46:10 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:47:43 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:47:45 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:47:58 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:49:10 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:49:18 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:49:44 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:51:30 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:53:06 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:55:10 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:56:17 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:56:21 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:57:25 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:58:24 --> 404 Page Not Found: /index
ERROR - 2022-03-14 19:59:49 --> 404 Page Not Found: /index
ERROR - 2022-03-14 20:01:14 --> 404 Page Not Found: /index
ERROR - 2022-03-14 20:01:49 --> 404 Page Not Found: /index
ERROR - 2022-03-14 20:05:46 --> 404 Page Not Found: /index
ERROR - 2022-03-14 20:06:08 --> 404 Page Not Found: /index
ERROR - 2022-03-14 20:07:50 --> 404 Page Not Found: /index
ERROR - 2022-03-14 20:07:50 --> 404 Page Not Found: /index
ERROR - 2022-03-14 20:11:33 --> 404 Page Not Found: /index
ERROR - 2022-03-14 20:12:38 --> 404 Page Not Found: /index
ERROR - 2022-03-14 20:14:58 --> 404 Page Not Found: /index
ERROR - 2022-03-14 20:15:55 --> 404 Page Not Found: /index
ERROR - 2022-03-14 20:16:00 --> 404 Page Not Found: /index
ERROR - 2022-03-14 20:16:07 --> 404 Page Not Found: /index
ERROR - 2022-03-14 20:17:04 --> 404 Page Not Found: /index
ERROR - 2022-03-14 20:17:05 --> 404 Page Not Found: /index
ERROR - 2022-03-14 20:17:22 --> 404 Page Not Found: /index
ERROR - 2022-03-14 20:18:27 --> 404 Page Not Found: /index
ERROR - 2022-03-14 20:18:29 --> 404 Page Not Found: /index
ERROR - 2022-03-14 20:18:35 --> 404 Page Not Found: /index
ERROR - 2022-03-14 20:18:39 --> 404 Page Not Found: /index
ERROR - 2022-03-14 20:19:34 --> 404 Page Not Found: /index
ERROR - 2022-03-14 20:20:11 --> 404 Page Not Found: /index
ERROR - 2022-03-14 20:21:06 --> 404 Page Not Found: /index
ERROR - 2022-03-14 20:21:06 --> 404 Page Not Found: /index
ERROR - 2022-03-14 20:22:28 --> 404 Page Not Found: /index
ERROR - 2022-03-14 20:24:27 --> 404 Page Not Found: /index
ERROR - 2022-03-14 20:30:13 --> 404 Page Not Found: /index
ERROR - 2022-03-14 20:31:39 --> 404 Page Not Found: /index
ERROR - 2022-03-14 20:31:40 --> 404 Page Not Found: /index
ERROR - 2022-03-14 20:31:59 --> 404 Page Not Found: /index
ERROR - 2022-03-14 20:32:14 --> 404 Page Not Found: /index
ERROR - 2022-03-14 20:33:56 --> 404 Page Not Found: /index
ERROR - 2022-03-14 20:34:18 --> 404 Page Not Found: /index
ERROR - 2022-03-14 20:36:45 --> 404 Page Not Found: /index
ERROR - 2022-03-14 20:38:13 --> 404 Page Not Found: /index
ERROR - 2022-03-14 20:38:25 --> 404 Page Not Found: /index
ERROR - 2022-03-14 20:38:44 --> 404 Page Not Found: /index
ERROR - 2022-03-14 20:39:15 --> 404 Page Not Found: /index
ERROR - 2022-03-14 20:39:24 --> 404 Page Not Found: /index
ERROR - 2022-03-14 20:39:30 --> 404 Page Not Found: ../modules/admin/controllers/Admin_ap/eliteprofiles
ERROR - 2022-03-14 20:40:22 --> 404 Page Not Found: /index
ERROR - 2022-03-14 20:40:29 --> 404 Page Not Found: /index
ERROR - 2022-03-14 20:40:43 --> 404 Page Not Found: /index
ERROR - 2022-03-14 20:41:09 --> 404 Page Not Found: /index
ERROR - 2022-03-14 20:41:53 --> 404 Page Not Found: /index
ERROR - 2022-03-14 20:44:22 --> 404 Page Not Found: /index
ERROR - 2022-03-14 20:48:39 --> 404 Page Not Found: /index
ERROR - 2022-03-14 20:49:36 --> 404 Page Not Found: /index
ERROR - 2022-03-14 20:50:02 --> 404 Page Not Found: /index
ERROR - 2022-03-14 20:50:39 --> 404 Page Not Found: /index
ERROR - 2022-03-14 20:51:54 --> 404 Page Not Found: /index
ERROR - 2022-03-14 20:52:38 --> 404 Page Not Found: /index
ERROR - 2022-03-14 20:54:25 --> 404 Page Not Found: /index
ERROR - 2022-03-14 20:55:14 --> 404 Page Not Found: /index
ERROR - 2022-03-14 20:57:51 --> 404 Page Not Found: /index
ERROR - 2022-03-14 20:59:17 --> 404 Page Not Found: /index
ERROR - 2022-03-14 21:00:22 --> 404 Page Not Found: /index
ERROR - 2022-03-14 21:01:18 --> 404 Page Not Found: /index
ERROR - 2022-03-14 21:01:29 --> 404 Page Not Found: /index
ERROR - 2022-03-14 21:01:30 --> 404 Page Not Found: /index
ERROR - 2022-03-14 21:03:43 --> 404 Page Not Found: /index
ERROR - 2022-03-14 21:04:05 --> 404 Page Not Found: /index
ERROR - 2022-03-14 21:04:46 --> 404 Page Not Found: /index
ERROR - 2022-03-14 21:05:59 --> 404 Page Not Found: /index
ERROR - 2022-03-14 21:07:41 --> 404 Page Not Found: /index
ERROR - 2022-03-14 21:08:31 --> 404 Page Not Found: /index
ERROR - 2022-03-14 21:09:30 --> 404 Page Not Found: /index
ERROR - 2022-03-14 21:10:14 --> 404 Page Not Found: /index
ERROR - 2022-03-14 21:11:31 --> 404 Page Not Found: /index
ERROR - 2022-03-14 21:11:45 --> 404 Page Not Found: /index
ERROR - 2022-03-14 21:11:48 --> 404 Page Not Found: /index
ERROR - 2022-03-14 21:12:00 --> 404 Page Not Found: /index
ERROR - 2022-03-14 21:12:04 --> 404 Page Not Found: /index
ERROR - 2022-03-14 21:12:35 --> 404 Page Not Found: /index
ERROR - 2022-03-14 21:13:06 --> 404 Page Not Found: /index
ERROR - 2022-03-14 21:13:16 --> 404 Page Not Found: /index
ERROR - 2022-03-14 21:14:02 --> 404 Page Not Found: /index
ERROR - 2022-03-14 21:16:29 --> 404 Page Not Found: /index
ERROR - 2022-03-14 21:17:19 --> 404 Page Not Found: /index
ERROR - 2022-03-14 21:17:20 --> 404 Page Not Found: /index
ERROR - 2022-03-14 21:17:49 --> 404 Page Not Found: /index
ERROR - 2022-03-14 21:18:00 --> 404 Page Not Found: /index
ERROR - 2022-03-14 21:18:27 --> 404 Page Not Found: /index
ERROR - 2022-03-14 21:18:48 --> 404 Page Not Found: /index
ERROR - 2022-03-14 21:19:47 --> 404 Page Not Found: /index
ERROR - 2022-03-14 21:20:26 --> 404 Page Not Found: /index
ERROR - 2022-03-14 21:22:05 --> To Id is not available for User - 2437
ERROR - 2022-03-14 21:22:22 --> 404 Page Not Found: /index
ERROR - 2022-03-14 21:22:24 --> 404 Page Not Found: /index
ERROR - 2022-03-14 21:23:54 --> 404 Page Not Found: /index
ERROR - 2022-03-14 21:26:11 --> 404 Page Not Found: /index
ERROR - 2022-03-14 21:26:13 --> 404 Page Not Found: /index
ERROR - 2022-03-14 21:26:15 --> 404 Page Not Found: /index
ERROR - 2022-03-14 21:26:22 --> 404 Page Not Found: /index
ERROR - 2022-03-14 21:27:05 --> 404 Page Not Found: /index
ERROR - 2022-03-14 21:30:06 --> 404 Page Not Found: /index
ERROR - 2022-03-14 21:30:10 --> 404 Page Not Found: /index
ERROR - 2022-03-14 21:30:33 --> 404 Page Not Found: /index
ERROR - 2022-03-14 21:30:57 --> 404 Page Not Found: /index
ERROR - 2022-03-14 21:33:03 --> 404 Page Not Found: /index
ERROR - 2022-03-14 21:35:38 --> 404 Page Not Found: /index
ERROR - 2022-03-14 21:37:22 --> 404 Page Not Found: /index
ERROR - 2022-03-14 21:38:29 --> 404 Page Not Found: /index
ERROR - 2022-03-14 21:39:35 --> 404 Page Not Found: /index
ERROR - 2022-03-14 21:43:02 --> 404 Page Not Found: /index
ERROR - 2022-03-14 21:43:22 --> 404 Page Not Found: /index
ERROR - 2022-03-14 21:43:22 --> 404 Page Not Found: /index
ERROR - 2022-03-14 21:43:22 --> 404 Page Not Found: /index
ERROR - 2022-03-14 21:43:22 --> 404 Page Not Found: /index
ERROR - 2022-03-14 21:43:22 --> 404 Page Not Found: /index
ERROR - 2022-03-14 21:43:27 --> 404 Page Not Found: /index
ERROR - 2022-03-14 21:43:45 --> 404 Page Not Found: /index
ERROR - 2022-03-14 21:43:56 --> 404 Page Not Found: /index
ERROR - 2022-03-14 21:43:56 --> 404 Page Not Found: /index
ERROR - 2022-03-14 21:43:58 --> 404 Page Not Found: /index
ERROR - 2022-03-14 21:44:37 --> 404 Page Not Found: /index
ERROR - 2022-03-14 21:44:37 --> 404 Page Not Found: /index
ERROR - 2022-03-14 21:45:09 --> 404 Page Not Found: /index
ERROR - 2022-03-14 21:45:43 --> 404 Page Not Found: /index
ERROR - 2022-03-14 21:45:52 --> 404 Page Not Found: /index
ERROR - 2022-03-14 21:47:56 --> 404 Page Not Found: /index
ERROR - 2022-03-14 21:49:06 --> 404 Page Not Found: /index
ERROR - 2022-03-14 21:51:03 --> 404 Page Not Found: /index
ERROR - 2022-03-14 21:51:25 --> 404 Page Not Found: /index
ERROR - 2022-03-14 21:52:39 --> 404 Page Not Found: /index
ERROR - 2022-03-14 21:52:59 --> 404 Page Not Found: /index
ERROR - 2022-03-14 21:52:59 --> 404 Page Not Found: /index
ERROR - 2022-03-14 21:53:25 --> 404 Page Not Found: /index
ERROR - 2022-03-14 21:53:31 --> 404 Page Not Found: /index
ERROR - 2022-03-14 21:54:54 --> 404 Page Not Found: /index
ERROR - 2022-03-14 21:56:50 --> 404 Page Not Found: /index
ERROR - 2022-03-14 21:57:13 --> 404 Page Not Found: /index
ERROR - 2022-03-14 21:57:25 --> 404 Page Not Found: /index
ERROR - 2022-03-14 21:58:12 --> 404 Page Not Found: /index
ERROR - 2022-03-14 22:00:05 --> 404 Page Not Found: /index
ERROR - 2022-03-14 22:01:21 --> 404 Page Not Found: /index
ERROR - 2022-03-14 22:04:24 --> 404 Page Not Found: /index
ERROR - 2022-03-14 22:04:26 --> 404 Page Not Found: /index
ERROR - 2022-03-14 22:06:18 --> 404 Page Not Found: /index
ERROR - 2022-03-14 22:06:47 --> 404 Page Not Found: /index
ERROR - 2022-03-14 22:08:08 --> 404 Page Not Found: /index
ERROR - 2022-03-14 22:08:49 --> 404 Page Not Found: /index
ERROR - 2022-03-14 22:11:58 --> 404 Page Not Found: /index
ERROR - 2022-03-14 22:12:06 --> 404 Page Not Found: /index
ERROR - 2022-03-14 22:15:55 --> 404 Page Not Found: /index
ERROR - 2022-03-14 22:16:17 --> 404 Page Not Found: /index
ERROR - 2022-03-14 22:16:20 --> 404 Page Not Found: /index
ERROR - 2022-03-14 22:17:07 --> 404 Page Not Found: /index
ERROR - 2022-03-14 22:17:25 --> 404 Page Not Found: /index
ERROR - 2022-03-14 22:17:36 --> 404 Page Not Found: /index
ERROR - 2022-03-14 22:17:45 --> 404 Page Not Found: /index
ERROR - 2022-03-14 22:18:50 --> 404 Page Not Found: /index
ERROR - 2022-03-14 22:18:58 --> 404 Page Not Found: /index
ERROR - 2022-03-14 22:19:03 --> 404 Page Not Found: /index
ERROR - 2022-03-14 22:19:03 --> 404 Page Not Found: /index
ERROR - 2022-03-14 22:19:03 --> 404 Page Not Found: /index
ERROR - 2022-03-14 22:19:27 --> 404 Page Not Found: /index
ERROR - 2022-03-14 22:20:31 --> 404 Page Not Found: /index
ERROR - 2022-03-14 22:20:38 --> 404 Page Not Found: /index
ERROR - 2022-03-14 22:20:44 --> 404 Page Not Found: /index
ERROR - 2022-03-14 22:21:04 --> 404 Page Not Found: /index
ERROR - 2022-03-14 22:21:24 --> 404 Page Not Found: /index
ERROR - 2022-03-14 22:21:42 --> 404 Page Not Found: /index
ERROR - 2022-03-14 22:22:08 --> 404 Page Not Found: /index
ERROR - 2022-03-14 22:23:41 --> 404 Page Not Found: /index
ERROR - 2022-03-14 22:23:53 --> 404 Page Not Found: /index
ERROR - 2022-03-14 22:27:48 --> 404 Page Not Found: /index
ERROR - 2022-03-14 22:29:28 --> 404 Page Not Found: /index
ERROR - 2022-03-14 22:30:00 --> 404 Page Not Found: /index
ERROR - 2022-03-14 22:30:14 --> 404 Page Not Found: /index
ERROR - 2022-03-14 22:30:19 --> 404 Page Not Found: /index
ERROR - 2022-03-14 22:31:24 --> 404 Page Not Found: /index
ERROR - 2022-03-14 22:31:42 --> 404 Page Not Found: ../modules/home/controllers/Home/searc
ERROR - 2022-03-14 22:32:52 --> 404 Page Not Found: /index
ERROR - 2022-03-14 22:37:30 --> 404 Page Not Found: /index
ERROR - 2022-03-14 22:37:40 --> 404 Page Not Found: /index
ERROR - 2022-03-14 22:38:55 --> 404 Page Not Found: /index
ERROR - 2022-03-14 22:39:18 --> 404 Page Not Found: /index
ERROR - 2022-03-14 22:40:21 --> 404 Page Not Found: /index
ERROR - 2022-03-14 22:40:33 --> 404 Page Not Found: /index
ERROR - 2022-03-14 22:42:14 --> 404 Page Not Found: /index
ERROR - 2022-03-14 22:43:40 --> 404 Page Not Found: /index
ERROR - 2022-03-14 22:43:40 --> 404 Page Not Found: /index
ERROR - 2022-03-14 22:45:54 --> 404 Page Not Found: /index
ERROR - 2022-03-14 22:46:01 --> 404 Page Not Found: /index
ERROR - 2022-03-14 22:47:04 --> 404 Page Not Found: /index
ERROR - 2022-03-14 22:47:10 --> 404 Page Not Found: /index
ERROR - 2022-03-14 22:48:18 --> 404 Page Not Found: /index
ERROR - 2022-03-14 22:49:04 --> 404 Page Not Found: /index
ERROR - 2022-03-14 22:49:15 --> 404 Page Not Found: /index
ERROR - 2022-03-14 22:49:18 --> 404 Page Not Found: /index
ERROR - 2022-03-14 22:51:06 --> 404 Page Not Found: /index
ERROR - 2022-03-14 22:51:33 --> 404 Page Not Found: /index
ERROR - 2022-03-14 22:53:30 --> 404 Page Not Found: /index
ERROR - 2022-03-14 22:53:45 --> 404 Page Not Found: /index
ERROR - 2022-03-14 22:54:39 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-14 22:54:39')
ERROR - 2022-03-14 22:56:33 --> 404 Page Not Found: /index
ERROR - 2022-03-14 22:56:36 --> 404 Page Not Found: /index
ERROR - 2022-03-14 22:56:56 --> 404 Page Not Found: /index
ERROR - 2022-03-14 22:59:12 --> 404 Page Not Found: /index
ERROR - 2022-03-14 23:00:04 --> 404 Page Not Found: /index
ERROR - 2022-03-14 23:01:10 --> 404 Page Not Found: /index
ERROR - 2022-03-14 23:02:53 --> 404 Page Not Found: /index
ERROR - 2022-03-14 23:02:57 --> 404 Page Not Found: /index
ERROR - 2022-03-14 23:04:48 --> 404 Page Not Found: /index
ERROR - 2022-03-14 23:06:08 --> 404 Page Not Found: /index
ERROR - 2022-03-14 23:06:56 --> 404 Page Not Found: /index
ERROR - 2022-03-14 23:07:31 --> 404 Page Not Found: /index
ERROR - 2022-03-14 23:10:45 --> 404 Page Not Found: /index
ERROR - 2022-03-14 23:11:08 --> 404 Page Not Found: /index
ERROR - 2022-03-14 23:11:09 --> Query error: Table 'cowcdrmy_kammamarriage.ms_shortlist_viewedd_ignored' doesn't exist - Invalid query: SELECT `v`.*, `p`.`gender`, `p`.`id`, `p`.`status`, `p`.`age`, `p`.`living_in`, `p`.`profile_id`, `p`.`first_name`, `last_name`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `s`.*
FROM `kv_profileview` as `v`
LEFT JOIN `tbl_primary_info` as `p` ON `v`.`kv_profileview_on` = `p`.`id`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`ms_id`
INNER JOIN `ms_profilesetting` as `s` ON `p`.`id`=`s`.`ms_id`
WHERE `s`.`elite` = 'no'
AND `p`.`status` = 1
AND `v`.`kv_userfkid` = '3737'
AND `u`.`ismain` = 1
AND  `p`.`id` not in(select kv_msi_interested_on from kv_mysideinterests where kv_msi_profilefkid="3737")
AND  p.id not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid = "3737" AND `shortlist_status` = 1)
AND  `p`.`id` not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid="3737"AND ignore_status=1)
ORDER BY `v`.`kv_profileview_created_date` DESC
 LIMIT 10
ERROR - 2022-03-14 23:13:39 --> 404 Page Not Found: /index
ERROR - 2022-03-14 23:14:19 --> 404 Page Not Found: /index
ERROR - 2022-03-14 23:14:48 --> 404 Page Not Found: /index
ERROR - 2022-03-14 23:15:54 --> 404 Page Not Found: /index
ERROR - 2022-03-14 23:16:13 --> 404 Page Not Found: /index
ERROR - 2022-03-14 23:17:08 --> 404 Page Not Found: /index
ERROR - 2022-03-14 23:21:02 --> 404 Page Not Found: /index
ERROR - 2022-03-14 23:21:50 --> 404 Page Not Found: /index
ERROR - 2022-03-14 23:22:52 --> 404 Page Not Found: /index
ERROR - 2022-03-14 23:23:48 --> 404 Page Not Found: /index
ERROR - 2022-03-14 23:24:57 --> 404 Page Not Found: /index
ERROR - 2022-03-14 23:24:58 --> 404 Page Not Found: /index
ERROR - 2022-03-14 23:34:34 --> 404 Page Not Found: /index
ERROR - 2022-03-14 23:38:46 --> 404 Page Not Found: /index
ERROR - 2022-03-14 23:39:55 --> 404 Page Not Found: /index
ERROR - 2022-03-14 23:40:29 --> 404 Page Not Found: /index
ERROR - 2022-03-14 23:46:14 --> 404 Page Not Found: /index
ERROR - 2022-03-14 23:47:33 --> 404 Page Not Found: /index
ERROR - 2022-03-14 23:47:39 --> 404 Page Not Found: /index
ERROR - 2022-03-14 23:52:40 --> 404 Page Not Found: /index
ERROR - 2022-03-14 23:52:55 --> 404 Page Not Found: /index
ERROR - 2022-03-14 23:53:39 --> 404 Page Not Found: /index
ERROR - 2022-03-14 23:56:43 --> 404 Page Not Found: /index
