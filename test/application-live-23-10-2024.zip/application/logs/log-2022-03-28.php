<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-03-28 00:02:05 --> 404 Page Not Found: /index
ERROR - 2022-03-28 00:02:23 --> 404 Page Not Found: /index
ERROR - 2022-03-28 00:04:59 --> 404 Page Not Found: /index
ERROR - 2022-03-28 00:10:43 --> 404 Page Not Found: /index
ERROR - 2022-03-28 00:10:53 --> 404 Page Not Found: /index
ERROR - 2022-03-28 00:12:23 --> 404 Page Not Found: /index
ERROR - 2022-03-28 00:20:51 --> 404 Page Not Found: /index
ERROR - 2022-03-28 00:24:26 --> 404 Page Not Found: /index
ERROR - 2022-03-28 00:35:33 --> 404 Page Not Found: /index
ERROR - 2022-03-28 00:40:24 --> 404 Page Not Found: /index
ERROR - 2022-03-28 00:44:48 --> 404 Page Not Found: /index
ERROR - 2022-03-28 00:50:23 --> 404 Page Not Found: /index
ERROR - 2022-03-28 01:08:05 --> 404 Page Not Found: /index
ERROR - 2022-03-28 01:09:50 --> 404 Page Not Found: /index
ERROR - 2022-03-28 01:28:47 --> 404 Page Not Found: /index
ERROR - 2022-03-28 01:42:43 --> 404 Page Not Found: /index
ERROR - 2022-03-28 02:06:28 --> 404 Page Not Found: /index
ERROR - 2022-03-28 02:08:46 --> 404 Page Not Found: /index
ERROR - 2022-03-28 02:20:48 --> 404 Page Not Found: /index
ERROR - 2022-03-28 02:26:18 --> 404 Page Not Found: /index
ERROR - 2022-03-28 02:29:40 --> 404 Page Not Found: /index
ERROR - 2022-03-28 02:53:22 --> 404 Page Not Found: /index
ERROR - 2022-03-28 03:00:16 --> 404 Page Not Found: /index
ERROR - 2022-03-28 03:00:49 --> 404 Page Not Found: /index
ERROR - 2022-03-28 03:03:42 --> 404 Page Not Found: /index
ERROR - 2022-03-28 03:10:23 --> 404 Page Not Found: /index
ERROR - 2022-03-28 03:18:31 --> 404 Page Not Found: /index
ERROR - 2022-03-28 03:22:17 --> 404 Page Not Found: /index
ERROR - 2022-03-28 03:22:17 --> 404 Page Not Found: /index
ERROR - 2022-03-28 03:22:18 --> 404 Page Not Found: /index
ERROR - 2022-03-28 03:26:52 --> 404 Page Not Found: /index
ERROR - 2022-03-28 03:34:19 --> 404 Page Not Found: /index
ERROR - 2022-03-28 03:48:50 --> 404 Page Not Found: /index
ERROR - 2022-03-28 04:02:41 --> 404 Page Not Found: /index
ERROR - 2022-03-28 04:03:18 --> 404 Page Not Found: /index
ERROR - 2022-03-28 04:03:18 --> 404 Page Not Found: /index
ERROR - 2022-03-28 04:03:19 --> 404 Page Not Found: /index
ERROR - 2022-03-28 04:03:19 --> 404 Page Not Found: /index
ERROR - 2022-03-28 04:03:20 --> 404 Page Not Found: /index
ERROR - 2022-03-28 04:03:20 --> 404 Page Not Found: /index
ERROR - 2022-03-28 04:03:21 --> 404 Page Not Found: /index
ERROR - 2022-03-28 04:03:22 --> 404 Page Not Found: /index
ERROR - 2022-03-28 04:03:22 --> 404 Page Not Found: /index
ERROR - 2022-03-28 04:03:23 --> 404 Page Not Found: /index
ERROR - 2022-03-28 04:11:21 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: select SUM(IFNULL(`basicdetails`, 0) + IFNULL(`religion`, 0) + IFNULL(`edu_prof`, 0) + IFNULL(`parents`, 0) + IFNULL(`Siblings`, 0) + IFNULL(`photo`, 0)) as total,photo,basicdetails,religion,edu_prof,parents,Siblings from tbl_profilebattery where user_id=
ERROR - 2022-03-28 04:28:16 --> 404 Page Not Found: /index
ERROR - 2022-03-28 04:33:49 --> 404 Page Not Found: /index
ERROR - 2022-03-28 04:33:56 --> 404 Page Not Found: /index
ERROR - 2022-03-28 04:40:15 --> 404 Page Not Found: /index
ERROR - 2022-03-28 04:43:30 --> 404 Page Not Found: /index
ERROR - 2022-03-28 04:46:34 --> 404 Page Not Found: /index
ERROR - 2022-03-28 04:55:27 --> 404 Page Not Found: /index
ERROR - 2022-03-28 04:56:54 --> 404 Page Not Found: /index
ERROR - 2022-03-28 04:58:25 --> 404 Page Not Found: /index
ERROR - 2022-03-28 05:01:06 --> 404 Page Not Found: /index
ERROR - 2022-03-28 05:05:25 --> 404 Page Not Found: /index
ERROR - 2022-03-28 05:22:37 --> 404 Page Not Found: /index
ERROR - 2022-03-28 05:23:21 --> 404 Page Not Found: /index
ERROR - 2022-03-28 05:30:31 --> 404 Page Not Found: /index
ERROR - 2022-03-28 05:34:39 --> 404 Page Not Found: /index
ERROR - 2022-03-28 05:35:25 --> 404 Page Not Found: /index
ERROR - 2022-03-28 05:35:25 --> 404 Page Not Found: /index
ERROR - 2022-03-28 05:35:26 --> 404 Page Not Found: /index
ERROR - 2022-03-28 05:35:26 --> 404 Page Not Found: /index
ERROR - 2022-03-28 05:35:27 --> 404 Page Not Found: /index
ERROR - 2022-03-28 05:35:28 --> 404 Page Not Found: /index
ERROR - 2022-03-28 05:35:28 --> 404 Page Not Found: /index
ERROR - 2022-03-28 05:35:29 --> 404 Page Not Found: /index
ERROR - 2022-03-28 05:35:30 --> 404 Page Not Found: /index
ERROR - 2022-03-28 05:35:30 --> 404 Page Not Found: /index
ERROR - 2022-03-28 05:40:58 --> 404 Page Not Found: /index
ERROR - 2022-03-28 05:42:50 --> 404 Page Not Found: /index
ERROR - 2022-03-28 05:49:58 --> 404 Page Not Found: /index
ERROR - 2022-03-28 06:03:41 --> 404 Page Not Found: /index
ERROR - 2022-03-28 06:06:15 --> 404 Page Not Found: /index
ERROR - 2022-03-28 06:07:48 --> 404 Page Not Found: /index
ERROR - 2022-03-28 06:09:04 --> 404 Page Not Found: /index
ERROR - 2022-03-28 06:11:21 --> 404 Page Not Found: /index
ERROR - 2022-03-28 06:16:12 --> 404 Page Not Found: /index
ERROR - 2022-03-28 06:19:26 --> 404 Page Not Found: /index
ERROR - 2022-03-28 06:24:27 --> 404 Page Not Found: /index
ERROR - 2022-03-28 06:25:02 --> 404 Page Not Found: /index
ERROR - 2022-03-28 06:30:56 --> 404 Page Not Found: /index
ERROR - 2022-03-28 06:32:24 --> 404 Page Not Found: /index
ERROR - 2022-03-28 06:33:28 --> 404 Page Not Found: /index
ERROR - 2022-03-28 06:36:54 --> 404 Page Not Found: /index
ERROR - 2022-03-28 06:39:06 --> 404 Page Not Found: /index
ERROR - 2022-03-28 06:43:28 --> 404 Page Not Found: /index
ERROR - 2022-03-28 06:46:08 --> 404 Page Not Found: /index
ERROR - 2022-03-28 06:51:08 --> 404 Page Not Found: /index
ERROR - 2022-03-28 06:53:13 --> 404 Page Not Found: /index
ERROR - 2022-03-28 07:05:20 --> 404 Page Not Found: /index
ERROR - 2022-03-28 07:05:36 --> 404 Page Not Found: /index
ERROR - 2022-03-28 07:05:39 --> 404 Page Not Found: /index
ERROR - 2022-03-28 07:08:21 --> 404 Page Not Found: /index
ERROR - 2022-03-28 07:10:10 --> 404 Page Not Found: /index
ERROR - 2022-03-28 07:11:23 --> 404 Page Not Found: /index
ERROR - 2022-03-28 07:12:29 --> 404 Page Not Found: /index
ERROR - 2022-03-28 07:12:33 --> 404 Page Not Found: /index
ERROR - 2022-03-28 07:17:17 --> 404 Page Not Found: /index
ERROR - 2022-03-28 07:18:52 --> 404 Page Not Found: /index
ERROR - 2022-03-28 07:20:22 --> 404 Page Not Found: /index
ERROR - 2022-03-28 07:20:37 --> 404 Page Not Found: /index
ERROR - 2022-03-28 07:22:32 --> 404 Page Not Found: /index
ERROR - 2022-03-28 07:23:16 --> 404 Page Not Found: /index
ERROR - 2022-03-28 07:24:42 --> 404 Page Not Found: /index
ERROR - 2022-03-28 07:26:27 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-28 07:26:27')
ERROR - 2022-03-28 07:26:37 --> 404 Page Not Found: /index
ERROR - 2022-03-28 07:27:14 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-28 07:27:14')
ERROR - 2022-03-28 07:27:45 --> 404 Page Not Found: /index
ERROR - 2022-03-28 07:30:39 --> 404 Page Not Found: /index
ERROR - 2022-03-28 07:30:52 --> 404 Page Not Found: /index
ERROR - 2022-03-28 07:32:17 --> 404 Page Not Found: /index
ERROR - 2022-03-28 07:32:20 --> 404 Page Not Found: /index
ERROR - 2022-03-28 07:33:16 --> 404 Page Not Found: /index
ERROR - 2022-03-28 07:36:11 --> 404 Page Not Found: /index
ERROR - 2022-03-28 07:36:50 --> 404 Page Not Found: /index
ERROR - 2022-03-28 07:37:50 --> 404 Page Not Found: /index
ERROR - 2022-03-28 07:40:43 --> 404 Page Not Found: /index
ERROR - 2022-03-28 07:45:09 --> 404 Page Not Found: /index
ERROR - 2022-03-28 07:46:29 --> 404 Page Not Found: /index
ERROR - 2022-03-28 07:46:29 --> 404 Page Not Found: /index
ERROR - 2022-03-28 07:48:46 --> 404 Page Not Found: /index
ERROR - 2022-03-28 07:53:50 --> 404 Page Not Found: /index
ERROR - 2022-03-28 07:58:02 --> 404 Page Not Found: /index
ERROR - 2022-03-28 08:00:11 --> 404 Page Not Found: /index
ERROR - 2022-03-28 08:06:55 --> 404 Page Not Found: /index
ERROR - 2022-03-28 08:06:55 --> 404 Page Not Found: /index
ERROR - 2022-03-28 08:07:07 --> 404 Page Not Found: /index
ERROR - 2022-03-28 08:07:16 --> 404 Page Not Found: /index
ERROR - 2022-03-28 08:08:22 --> 404 Page Not Found: /index
ERROR - 2022-03-28 08:10:14 --> 404 Page Not Found: /index
ERROR - 2022-03-28 08:10:36 --> 404 Page Not Found: /index
ERROR - 2022-03-28 08:11:43 --> 404 Page Not Found: /index
ERROR - 2022-03-28 08:12:13 --> 404 Page Not Found: /index
ERROR - 2022-03-28 08:14:27 --> 404 Page Not Found: /index
ERROR - 2022-03-28 08:17:46 --> 404 Page Not Found: /index
ERROR - 2022-03-28 08:18:50 --> 404 Page Not Found: /index
ERROR - 2022-03-28 08:19:20 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-28 08:19:20')
ERROR - 2022-03-28 08:19:25 --> 404 Page Not Found: /index
ERROR - 2022-03-28 08:23:35 --> 404 Page Not Found: /index
ERROR - 2022-03-28 08:24:36 --> 404 Page Not Found: /index
ERROR - 2022-03-28 08:24:37 --> 404 Page Not Found: /index
ERROR - 2022-03-28 08:26:51 --> 404 Page Not Found: /index
ERROR - 2022-03-28 08:26:57 --> 404 Page Not Found: /index
ERROR - 2022-03-28 08:28:36 --> 404 Page Not Found: /index
ERROR - 2022-03-28 08:29:21 --> 404 Page Not Found: /index
ERROR - 2022-03-28 08:31:02 --> 404 Page Not Found: /index
ERROR - 2022-03-28 08:33:36 --> 404 Page Not Found: /index
ERROR - 2022-03-28 08:34:28 --> 404 Page Not Found: /index
ERROR - 2022-03-28 08:35:27 --> 404 Page Not Found: /index
ERROR - 2022-03-28 08:41:53 --> 404 Page Not Found: /index
ERROR - 2022-03-28 08:42:13 --> 404 Page Not Found: /index
ERROR - 2022-03-28 08:42:15 --> To Id is not available for User - 1499
ERROR - 2022-03-28 08:44:56 --> 404 Page Not Found: /index
ERROR - 2022-03-28 08:49:46 --> 404 Page Not Found: /index
ERROR - 2022-03-28 08:49:54 --> 404 Page Not Found: /index
ERROR - 2022-03-28 08:52:04 --> 404 Page Not Found: /index
ERROR - 2022-03-28 08:53:32 --> 404 Page Not Found: /index
ERROR - 2022-03-28 08:53:38 --> 404 Page Not Found: /index
ERROR - 2022-03-28 08:53:56 --> 404 Page Not Found: /index
ERROR - 2022-03-28 08:56:31 --> 404 Page Not Found: /index
ERROR - 2022-03-28 08:57:12 --> 404 Page Not Found: /index
ERROR - 2022-03-28 09:00:49 --> 404 Page Not Found: /index
ERROR - 2022-03-28 09:03:36 --> 404 Page Not Found: /index
ERROR - 2022-03-28 09:04:30 --> 404 Page Not Found: /index
ERROR - 2022-03-28 09:04:53 --> 404 Page Not Found: /index
ERROR - 2022-03-28 09:06:13 --> 404 Page Not Found: /index
ERROR - 2022-03-28 09:06:17 --> 404 Page Not Found: /index
ERROR - 2022-03-28 09:06:30 --> 404 Page Not Found: /index
ERROR - 2022-03-28 09:06:32 --> 404 Page Not Found: /index
ERROR - 2022-03-28 09:07:02 --> 404 Page Not Found: /index
ERROR - 2022-03-28 09:07:24 --> 404 Page Not Found: /index
ERROR - 2022-03-28 09:07:24 --> 404 Page Not Found: /index
ERROR - 2022-03-28 09:07:35 --> 404 Page Not Found: /index
ERROR - 2022-03-28 09:08:34 --> 404 Page Not Found: /index
ERROR - 2022-03-28 09:10:11 --> 404 Page Not Found: /index
ERROR - 2022-03-28 09:12:55 --> 404 Page Not Found: /index
ERROR - 2022-03-28 09:13:16 --> 404 Page Not Found: /index
ERROR - 2022-03-28 09:14:56 --> 404 Page Not Found: /index
ERROR - 2022-03-28 09:15:07 --> 404 Page Not Found: /index
ERROR - 2022-03-28 09:15:25 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 09:15:35 --> 404 Page Not Found: /index
ERROR - 2022-03-28 09:15:42 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 09:16:27 --> 404 Page Not Found: /index
ERROR - 2022-03-28 09:16:50 --> 404 Page Not Found: /index
ERROR - 2022-03-28 09:17:31 --> 404 Page Not Found: /index
ERROR - 2022-03-28 09:17:42 --> 404 Page Not Found: /index
ERROR - 2022-03-28 09:18:50 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 09:19:40 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 09:19:57 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 09:20:02 --> 404 Page Not Found: /index
ERROR - 2022-03-28 09:22:23 --> 404 Page Not Found: /index
ERROR - 2022-03-28 09:23:17 --> 404 Page Not Found: /index
ERROR - 2022-03-28 09:24:42 --> 404 Page Not Found: /index
ERROR - 2022-03-28 09:25:05 --> 404 Page Not Found: /index
ERROR - 2022-03-28 09:27:05 --> 404 Page Not Found: /index
ERROR - 2022-03-28 09:27:06 --> 404 Page Not Found: /index
ERROR - 2022-03-28 09:27:34 --> 404 Page Not Found: /index
ERROR - 2022-03-28 09:27:42 --> 404 Page Not Found: /index
ERROR - 2022-03-28 09:28:31 --> 404 Page Not Found: /index
ERROR - 2022-03-28 09:28:59 --> 404 Page Not Found: /index
ERROR - 2022-03-28 09:30:02 --> 404 Page Not Found: /index
ERROR - 2022-03-28 09:30:28 --> 404 Page Not Found: /index
ERROR - 2022-03-28 09:30:37 --> 404 Page Not Found: /index
ERROR - 2022-03-28 09:31:59 --> 404 Page Not Found: /index
ERROR - 2022-03-28 09:32:02 --> 404 Page Not Found: /index
ERROR - 2022-03-28 09:34:00 --> 404 Page Not Found: /index
ERROR - 2022-03-28 09:35:14 --> 404 Page Not Found: /index
ERROR - 2022-03-28 09:36:41 --> 404 Page Not Found: /index
ERROR - 2022-03-28 09:38:22 --> 404 Page Not Found: /index
ERROR - 2022-03-28 09:38:26 --> 404 Page Not Found: /index
ERROR - 2022-03-28 09:38:33 --> 404 Page Not Found: /index
ERROR - 2022-03-28 09:39:17 --> 404 Page Not Found: /index
ERROR - 2022-03-28 09:39:46 --> 404 Page Not Found: /index
ERROR - 2022-03-28 09:40:03 --> 404 Page Not Found: /index
ERROR - 2022-03-28 09:40:28 --> 404 Page Not Found: /index
ERROR - 2022-03-28 09:41:26 --> 404 Page Not Found: /index
ERROR - 2022-03-28 09:43:01 --> 404 Page Not Found: /index
ERROR - 2022-03-28 09:43:26 --> 404 Page Not Found: /index
ERROR - 2022-03-28 09:45:47 --> To Id is not available for User - 2548
ERROR - 2022-03-28 09:45:49 --> 404 Page Not Found: /index
ERROR - 2022-03-28 09:46:45 --> 404 Page Not Found: /index
ERROR - 2022-03-28 09:48:01 --> 404 Page Not Found: /index
ERROR - 2022-03-28 09:49:16 --> 404 Page Not Found: /index
ERROR - 2022-03-28 09:50:08 --> 404 Page Not Found: /index
ERROR - 2022-03-28 09:50:11 --> 404 Page Not Found: /index
ERROR - 2022-03-28 09:51:27 --> 404 Page Not Found: /index
ERROR - 2022-03-28 09:51:52 --> 404 Page Not Found: /index
ERROR - 2022-03-28 09:52:03 --> 404 Page Not Found: /index
ERROR - 2022-03-28 09:52:11 --> 404 Page Not Found: /index
ERROR - 2022-03-28 09:52:22 --> 404 Page Not Found: /index
ERROR - 2022-03-28 09:52:27 --> 404 Page Not Found: /index
ERROR - 2022-03-28 09:54:00 --> 404 Page Not Found: /index
ERROR - 2022-03-28 09:55:16 --> 404 Page Not Found: /index
ERROR - 2022-03-28 09:56:22 --> 404 Page Not Found: /index
ERROR - 2022-03-28 09:57:06 --> 404 Page Not Found: /index
ERROR - 2022-03-28 09:59:29 --> 404 Page Not Found: /index
ERROR - 2022-03-28 09:59:42 --> 404 Page Not Found: /index
ERROR - 2022-03-28 09:59:46 --> 404 Page Not Found: /index
ERROR - 2022-03-28 09:59:59 --> 404 Page Not Found: /index
ERROR - 2022-03-28 10:00:11 --> 404 Page Not Found: /index
ERROR - 2022-03-28 10:00:13 --> 404 Page Not Found: /index
ERROR - 2022-03-28 10:00:28 --> 404 Page Not Found: /index
ERROR - 2022-03-28 10:01:32 --> 404 Page Not Found: /index
ERROR - 2022-03-28 10:01:55 --> 404 Page Not Found: /index
ERROR - 2022-03-28 10:04:01 --> 404 Page Not Found: /index
ERROR - 2022-03-28 10:04:01 --> 404 Page Not Found: /index
ERROR - 2022-03-28 10:04:28 --> 404 Page Not Found: /index
ERROR - 2022-03-28 10:04:34 --> 404 Page Not Found: /index
ERROR - 2022-03-28 10:06:58 --> 404 Page Not Found: /index
ERROR - 2022-03-28 10:07:22 --> 404 Page Not Found: /index
ERROR - 2022-03-28 10:08:20 --> 404 Page Not Found: /index
ERROR - 2022-03-28 10:08:27 --> 404 Page Not Found: /index
ERROR - 2022-03-28 10:09:28 --> 404 Page Not Found: /index
ERROR - 2022-03-28 10:09:37 --> 404 Page Not Found: /index
ERROR - 2022-03-28 10:11:12 --> 404 Page Not Found: /index
ERROR - 2022-03-28 10:11:50 --> 404 Page Not Found: /index
ERROR - 2022-03-28 10:13:07 --> 404 Page Not Found: /index
ERROR - 2022-03-28 10:13:50 --> 404 Page Not Found: /index
ERROR - 2022-03-28 10:14:05 --> 404 Page Not Found: /index
ERROR - 2022-03-28 10:14:14 --> 404 Page Not Found: /index
ERROR - 2022-03-28 10:15:01 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 10:15:02 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 10:15:04 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 10:15:07 --> 404 Page Not Found: /index
ERROR - 2022-03-28 10:15:31 --> 404 Page Not Found: /index
ERROR - 2022-03-28 10:15:56 --> 404 Page Not Found: /index
ERROR - 2022-03-28 10:19:31 --> 404 Page Not Found: /index
ERROR - 2022-03-28 10:20:05 --> 404 Page Not Found: /index
ERROR - 2022-03-28 10:20:05 --> 404 Page Not Found: /index
ERROR - 2022-03-28 10:22:42 --> 404 Page Not Found: /index
ERROR - 2022-03-28 10:22:42 --> 404 Page Not Found: /index
ERROR - 2022-03-28 10:25:28 --> 404 Page Not Found: /index
ERROR - 2022-03-28 10:25:30 --> 404 Page Not Found: /index
ERROR - 2022-03-28 10:26:24 --> 404 Page Not Found: /index
ERROR - 2022-03-28 10:26:50 --> 404 Page Not Found: /index
ERROR - 2022-03-28 10:27:10 --> 404 Page Not Found: /index
ERROR - 2022-03-28 10:27:46 --> 404 Page Not Found: /index
ERROR - 2022-03-28 10:28:58 --> 404 Page Not Found: /index
ERROR - 2022-03-28 10:30:23 --> 404 Page Not Found: /index
ERROR - 2022-03-28 10:32:21 --> 404 Page Not Found: /index
ERROR - 2022-03-28 10:34:08 --> 404 Page Not Found: /index
ERROR - 2022-03-28 10:34:10 --> 404 Page Not Found: /index
ERROR - 2022-03-28 10:34:19 --> 404 Page Not Found: /index
ERROR - 2022-03-28 10:34:25 --> 404 Page Not Found: /index
ERROR - 2022-03-28 10:35:27 --> 404 Page Not Found: /index
ERROR - 2022-03-28 10:35:27 --> 404 Page Not Found: /index
ERROR - 2022-03-28 10:36:53 --> 404 Page Not Found: /index
ERROR - 2022-03-28 10:36:56 --> 404 Page Not Found: /index
ERROR - 2022-03-28 10:37:31 --> 404 Page Not Found: /index
ERROR - 2022-03-28 10:37:34 --> 404 Page Not Found: /index
ERROR - 2022-03-28 10:37:38 --> 404 Page Not Found: /index
ERROR - 2022-03-28 10:37:48 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 10:37:51 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 10:38:00 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 10:38:02 --> 404 Page Not Found: /index
ERROR - 2022-03-28 10:38:05 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 10:43:29 --> 404 Page Not Found: /index
ERROR - 2022-03-28 10:45:10 --> 404 Page Not Found: /index
ERROR - 2022-03-28 10:45:13 --> 404 Page Not Found: /index
ERROR - 2022-03-28 10:45:23 --> 404 Page Not Found: /index
ERROR - 2022-03-28 10:47:34 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT `p`.*, `r`.`caste`, `r`.`height`, `r`.`star`, `r`.`time_of_birth`, `r`.`raasi`, `prp`.`property_value`, `e`.`occupation`, `e`.`education_degree`, `e`.`visatype`, `e`.`city`, `e`.`country`, `e`.`annual_income`, `pfs`.`payment_status`, `pfs`.`profilesetting_id` as `pfs_id`, `pfs`.`last_call_updated`, `adm`.`username` as `profile_owner`
FROM `tbl_primary_info` as `p`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `ms_property_info` as `prp` ON `p`.`id`=`prp`.`ms_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `ms_profilesetting` as `pfs` ON `p`.`id`=`pfs`.`ms_id`
LEFT JOIN `tbl_admin_data` as `adm` ON `pfs`.`profileowner`=`adm`.`id`
WHERE `p`.`gender` = 'male'
AND `p`.`status` = '1'
AND `r`.`caste` = `Array`
AND `pfs`.`profileowner` = '12'
AND `adm`.`id` = '12'
GROUP BY `p`.`id`
ERROR - 2022-03-28 10:48:34 --> 404 Page Not Found: /index
ERROR - 2022-03-28 10:48:36 --> 404 Page Not Found: /index
ERROR - 2022-03-28 10:48:41 --> 404 Page Not Found: /index
ERROR - 2022-03-28 10:49:00 --> 404 Page Not Found: /index
ERROR - 2022-03-28 10:49:21 --> 404 Page Not Found: /index
ERROR - 2022-03-28 10:49:25 --> 404 Page Not Found: /index
ERROR - 2022-03-28 10:50:04 --> 404 Page Not Found: /index
ERROR - 2022-03-28 10:50:14 --> 404 Page Not Found: /index
ERROR - 2022-03-28 10:50:14 --> 404 Page Not Found: /index
ERROR - 2022-03-28 10:50:14 --> 404 Page Not Found: /index
ERROR - 2022-03-28 10:50:28 --> 404 Page Not Found: /index
ERROR - 2022-03-28 10:50:28 --> 404 Page Not Found: /index
ERROR - 2022-03-28 10:52:14 --> 404 Page Not Found: /index
ERROR - 2022-03-28 10:56:48 --> 404 Page Not Found: /index
ERROR - 2022-03-28 10:57:00 --> 404 Page Not Found: /index
ERROR - 2022-03-28 10:57:11 --> 404 Page Not Found: /index
ERROR - 2022-03-28 10:59:29 --> 404 Page Not Found: /index
ERROR - 2022-03-28 10:59:48 --> 404 Page Not Found: /index
ERROR - 2022-03-28 11:02:31 --> 404 Page Not Found: /index
ERROR - 2022-03-28 11:05:15 --> 404 Page Not Found: /index
ERROR - 2022-03-28 11:07:07 --> 404 Page Not Found: /index
ERROR - 2022-03-28 11:07:10 --> 404 Page Not Found: /index
ERROR - 2022-03-28 11:07:38 --> 404 Page Not Found: /index
ERROR - 2022-03-28 11:12:03 --> 404 Page Not Found: /index
ERROR - 2022-03-28 11:12:39 --> 404 Page Not Found: /index
ERROR - 2022-03-28 11:12:49 --> 404 Page Not Found: /index
ERROR - 2022-03-28 11:13:08 --> 404 Page Not Found: /index
ERROR - 2022-03-28 11:14:36 --> 404 Page Not Found: /index
ERROR - 2022-03-28 11:15:30 --> 404 Page Not Found: /index
ERROR - 2022-03-28 11:16:34 --> 404 Page Not Found: /index
ERROR - 2022-03-28 11:17:50 --> 404 Page Not Found: /index
ERROR - 2022-03-28 11:17:54 --> 404 Page Not Found: /index
ERROR - 2022-03-28 11:18:07 --> 404 Page Not Found: /index
ERROR - 2022-03-28 11:18:17 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-28 11:18:17')
ERROR - 2022-03-28 11:21:47 --> Severity: error --> Exception: Invalid address:  (to): tarun.i @gmail.com /home4/cowcdrmy/public_html/application/third_party/phpmailer/src/PHPMailer.php 1157
ERROR - 2022-03-28 11:22:38 --> 404 Page Not Found: /index
ERROR - 2022-03-28 11:24:17 --> 404 Page Not Found: /index
ERROR - 2022-03-28 11:24:24 --> 404 Page Not Found: /index
ERROR - 2022-03-28 11:25:14 --> 404 Page Not Found: /index
ERROR - 2022-03-28 11:25:53 --> 404 Page Not Found: /index
ERROR - 2022-03-28 11:27:57 --> 404 Page Not Found: /index
ERROR - 2022-03-28 11:28:07 --> 404 Page Not Found: /index
ERROR - 2022-03-28 11:28:07 --> 404 Page Not Found: /index
ERROR - 2022-03-28 11:29:07 --> 404 Page Not Found: /index
ERROR - 2022-03-28 11:29:35 --> 404 Page Not Found: /index
ERROR - 2022-03-28 11:32:15 --> 404 Page Not Found: /index
ERROR - 2022-03-28 11:32:17 --> 404 Page Not Found: /index
ERROR - 2022-03-28 11:32:19 --> 404 Page Not Found: /index
ERROR - 2022-03-28 11:32:40 --> 404 Page Not Found: /index
ERROR - 2022-03-28 11:33:11 --> 404 Page Not Found: /index
ERROR - 2022-03-28 11:33:20 --> 404 Page Not Found: /index
ERROR - 2022-03-28 11:34:53 --> 404 Page Not Found: /index
ERROR - 2022-03-28 11:38:07 --> 404 Page Not Found: /index
ERROR - 2022-03-28 11:38:37 --> 404 Page Not Found: /index
ERROR - 2022-03-28 11:40:05 --> 404 Page Not Found: /index
ERROR - 2022-03-28 11:40:17 --> 404 Page Not Found: /index
ERROR - 2022-03-28 11:40:28 --> 404 Page Not Found: /index
ERROR - 2022-03-28 11:42:07 --> 404 Page Not Found: /index
ERROR - 2022-03-28 11:42:35 --> 404 Page Not Found: /index
ERROR - 2022-03-28 11:43:47 --> 404 Page Not Found: /index
ERROR - 2022-03-28 11:46:56 --> 404 Page Not Found: /index
ERROR - 2022-03-28 11:47:06 --> 404 Page Not Found: /index
ERROR - 2022-03-28 11:47:08 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 11:47:24 --> 404 Page Not Found: /index
ERROR - 2022-03-28 11:47:50 --> 404 Page Not Found: /index
ERROR - 2022-03-28 11:48:49 --> 404 Page Not Found: /index
ERROR - 2022-03-28 11:49:00 --> 404 Page Not Found: /index
ERROR - 2022-03-28 11:49:00 --> 404 Page Not Found: /index
ERROR - 2022-03-28 11:49:43 --> 404 Page Not Found: /index
ERROR - 2022-03-28 11:49:57 --> 404 Page Not Found: /index
ERROR - 2022-03-28 11:50:27 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 11:50:29 --> 404 Page Not Found: /index
ERROR - 2022-03-28 11:50:29 --> 404 Page Not Found: /index
ERROR - 2022-03-28 11:51:40 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 11:52:37 --> 404 Page Not Found: /index
ERROR - 2022-03-28 11:52:41 --> 404 Page Not Found: /index
ERROR - 2022-03-28 11:53:40 --> 404 Page Not Found: /index
ERROR - 2022-03-28 11:54:12 --> 404 Page Not Found: /index
ERROR - 2022-03-28 11:55:05 --> 404 Page Not Found: /index
ERROR - 2022-03-28 11:55:27 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 11:55:27 --> 404 Page Not Found: /index
ERROR - 2022-03-28 11:55:35 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 11:56:19 --> 404 Page Not Found: /index
ERROR - 2022-03-28 11:57:07 --> 404 Page Not Found: /index
ERROR - 2022-03-28 11:57:15 --> 404 Page Not Found: /index
ERROR - 2022-03-28 11:57:41 --> 404 Page Not Found: /index
ERROR - 2022-03-28 11:58:56 --> 404 Page Not Found: /index
ERROR - 2022-03-28 11:59:57 --> 404 Page Not Found: /index
ERROR - 2022-03-28 12:00:41 --> 404 Page Not Found: /index
ERROR - 2022-03-28 12:03:23 --> Severity: error --> Exception: Invalid address:  (to):  /home4/cowcdrmy/public_html/application/third_party/phpmailer/src/PHPMailer.php 1092
ERROR - 2022-03-28 12:04:29 --> 404 Page Not Found: /index
ERROR - 2022-03-28 12:04:58 --> 404 Page Not Found: /index
ERROR - 2022-03-28 12:08:43 --> 404 Page Not Found: /index
ERROR - 2022-03-28 12:10:48 --> 404 Page Not Found: /index
ERROR - 2022-03-28 12:10:49 --> 404 Page Not Found: /index
ERROR - 2022-03-28 12:14:17 --> 404 Page Not Found: /index
ERROR - 2022-03-28 12:15:14 --> 404 Page Not Found: /index
ERROR - 2022-03-28 12:15:23 --> Query error: Column 'user_id' cannot be null - Invalid query: INSERT INTO `parents_brother_details` (`user_id`, `brother_of`, `brother_type`, `brother_name`, `brother_education`, `brother_profession`, `brother_mobile`, `current_location`, `created_at`, `created_by`, `status`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2022-03-28 12:15:23', 'Sailaja', 1)
ERROR - 2022-03-28 12:15:24 --> Query error: Column 'user_id' cannot be null - Invalid query: INSERT INTO `parents_brother_details` (`user_id`, `brother_of`, `brother_type`, `brother_name`, `brother_education`, `brother_profession`, `brother_mobile`, `current_location`, `created_at`, `created_by`, `status`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2022-03-28 12:15:24', 'Sailaja', 1)
ERROR - 2022-03-28 12:15:29 --> Query error: Column 'user_id' cannot be null - Invalid query: INSERT INTO `parents_brother_details` (`user_id`, `brother_of`, `brother_type`, `brother_name`, `brother_education`, `brother_profession`, `brother_mobile`, `current_location`, `created_at`, `created_by`, `status`) VALUES (NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2022-03-28 12:15:29', 'Sailaja', 1)
ERROR - 2022-03-28 12:16:04 --> 404 Page Not Found: /index
ERROR - 2022-03-28 12:16:25 --> 404 Page Not Found: /index
ERROR - 2022-03-28 12:17:26 --> 404 Page Not Found: /index
ERROR - 2022-03-28 12:18:08 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 12:18:10 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 12:18:12 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 12:21:24 --> 404 Page Not Found: /index
ERROR - 2022-03-28 12:22:54 --> 404 Page Not Found: /index
ERROR - 2022-03-28 12:24:12 --> 404 Page Not Found: /index
ERROR - 2022-03-28 12:24:28 --> 404 Page Not Found: /index
ERROR - 2022-03-28 12:24:47 --> 404 Page Not Found: /index
ERROR - 2022-03-28 12:24:52 --> 404 Page Not Found: /index
ERROR - 2022-03-28 12:24:58 --> 404 Page Not Found: /index
ERROR - 2022-03-28 12:24:59 --> 404 Page Not Found: /index
ERROR - 2022-03-28 12:25:56 --> 404 Page Not Found: /index
ERROR - 2022-03-28 12:26:06 --> 404 Page Not Found: /index
ERROR - 2022-03-28 12:26:34 --> 404 Page Not Found: /index
ERROR - 2022-03-28 12:27:09 --> 404 Page Not Found: /index
ERROR - 2022-03-28 12:29:27 --> To Id is not available for User - 1765
ERROR - 2022-03-28 12:29:30 --> 404 Page Not Found: /index
ERROR - 2022-03-28 12:30:22 --> 404 Page Not Found: /index
ERROR - 2022-03-28 12:31:21 --> To Id is not available for User - 1832
ERROR - 2022-03-28 12:31:52 --> 404 Page Not Found: /index
ERROR - 2022-03-28 12:32:06 --> 404 Page Not Found: /index
ERROR - 2022-03-28 12:32:14 --> 404 Page Not Found: /index
ERROR - 2022-03-28 12:32:22 --> 404 Page Not Found: /index
ERROR - 2022-03-28 12:32:26 --> To Id is not available for User - 1765
ERROR - 2022-03-28 12:32:37 --> 404 Page Not Found: /index
ERROR - 2022-03-28 12:33:55 --> 404 Page Not Found: /index
ERROR - 2022-03-28 12:34:58 --> 404 Page Not Found: /index
ERROR - 2022-03-28 12:36:58 --> 404 Page Not Found: /index
ERROR - 2022-03-28 12:37:22 --> 404 Page Not Found: /index
ERROR - 2022-03-28 12:39:50 --> 404 Page Not Found: /index
ERROR - 2022-03-28 12:40:18 --> 404 Page Not Found: /index
ERROR - 2022-03-28 12:40:26 --> 404 Page Not Found: /index
ERROR - 2022-03-28 12:41:16 --> 404 Page Not Found: /index
ERROR - 2022-03-28 12:41:17 --> 404 Page Not Found: /index
ERROR - 2022-03-28 12:43:19 --> 404 Page Not Found: /index
ERROR - 2022-03-28 12:44:37 --> 404 Page Not Found: /index
ERROR - 2022-03-28 12:44:46 --> 404 Page Not Found: /index
ERROR - 2022-03-28 12:45:05 --> 404 Page Not Found: /index
ERROR - 2022-03-28 12:45:29 --> 404 Page Not Found: /index
ERROR - 2022-03-28 12:45:29 --> 404 Page Not Found: /index
ERROR - 2022-03-28 12:46:03 --> 404 Page Not Found: /index
ERROR - 2022-03-28 12:46:18 --> 404 Page Not Found: /index
ERROR - 2022-03-28 12:46:33 --> 404 Page Not Found: /index
ERROR - 2022-03-28 12:47:12 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-28 12:47:12')
ERROR - 2022-03-28 12:50:33 --> 404 Page Not Found: /index
ERROR - 2022-03-28 12:51:56 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 12:54:03 --> 404 Page Not Found: /index
ERROR - 2022-03-28 12:54:30 --> 404 Page Not Found: /index
ERROR - 2022-03-28 12:56:10 --> 404 Page Not Found: /index
ERROR - 2022-03-28 12:56:33 --> 404 Page Not Found: /index
ERROR - 2022-03-28 12:56:33 --> 404 Page Not Found: /index
ERROR - 2022-03-28 12:56:41 --> 404 Page Not Found: /index
ERROR - 2022-03-28 12:57:15 --> 404 Page Not Found: /index
ERROR - 2022-03-28 12:58:17 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:00:47 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:01:57 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:02:26 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:03:31 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:03:40 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:04:19 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:04:23 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:05:30 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:05:30 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:05:35 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:06:54 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:08:09 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:08:30 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:09:51 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 13:10:30 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:10:41 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:10:49 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:10:51 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:11:28 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:11:53 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:12:03 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:12:10 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:12:23 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:12:32 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:13:09 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:13:35 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:14:32 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:14:55 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:15:08 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:15:12 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:15:46 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:15:54 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:17:00 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:18:31 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:19:10 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 13:19:58 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:21:53 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:22:31 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:23:12 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:23:21 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 13:23:22 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 13:23:22 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:23:22 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 13:23:28 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 13:23:30 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:23:31 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 13:23:32 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 13:23:33 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 13:25:11 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:25:43 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:27:11 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:27:13 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 13:27:14 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 13:27:18 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 13:27:20 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 13:27:21 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 13:27:22 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 13:27:29 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 13:27:32 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:27:33 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:28:33 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 13:28:34 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 13:28:37 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 13:29:15 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:30:28 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:31:42 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:32:20 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:32:55 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:32:59 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:33:16 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:33:52 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '<script>alert("xssvuln")</script> AND <script>alert("xssvuln") < `/script>`
AND ' at line 8 - Invalid query: SELECT `p`.`gender`, `p`.`id`, `p`.`status`, `p`.`age`, `p`.`living_in`, `p`.`profile_id`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`
FROM `tbl_primary_info` as `p`
INNER JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`MS_id`
INNER JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
INNER JOIN `ms_profilesetting` as `s` ON `p`.`id`=`s`.`ms_id`
WHERE `p`.`gender` = '<script>alert(\"xssvuln\")</script>'
AND `p`.`age` BETWEEN <script>alert("xssvuln")</script> AND <script>alert("xssvuln") < `/script>`
AND `r`.`religion` = '<script>alert(\"xssvuln\")</script>'
AND `r`.`mother_tounge` = '<script>alert(\"xssvuln\")</script>'
AND `p`.`status` = 1
AND `s`.`elite` = 'no'
AND `s`.`ms_usertype` = 'regular'
AND `u`.`ismain` = 1
AND `u`.`photoname` != ''
AND `u`.`applicationphotopath` != ''
GROUP BY `u`.`MS_id`
ORDER BY `registered_on` DESC
 LIMIT 8
ERROR - 2022-03-28 13:35:01 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:35:09 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:35:45 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:35:46 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:37:39 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:38:04 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 13:38:08 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 13:38:10 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 13:38:12 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 13:38:17 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:38:23 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:39:34 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:40:34 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:40:54 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:41:08 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:41:45 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:42:20 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:42:45 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:44:09 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:44:10 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:46:00 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:46:17 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:46:56 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:46:59 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:47:27 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:49:27 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:50:09 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:50:51 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:51:02 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:51:06 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:51:28 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:53:48 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:54:00 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:54:41 --> To Id is not available for User - 1765
ERROR - 2022-03-28 13:54:56 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:55:26 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:55:34 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:55:56 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 13:56:00 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 13:57:26 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:57:57 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:58:14 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:58:19 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:59:06 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:59:32 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:59:40 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:59:40 --> 404 Page Not Found: /index
ERROR - 2022-03-28 13:59:52 --> 404 Page Not Found: /index
ERROR - 2022-03-28 14:00:54 --> 404 Page Not Found: /index
ERROR - 2022-03-28 14:01:10 --> 404 Page Not Found: /index
ERROR - 2022-03-28 14:01:22 --> 404 Page Not Found: /index
ERROR - 2022-03-28 14:02:23 --> 404 Page Not Found: /index
ERROR - 2022-03-28 14:02:51 --> 404 Page Not Found: /index
ERROR - 2022-03-28 14:04:06 --> 404 Page Not Found: /index
ERROR - 2022-03-28 14:05:05 --> 404 Page Not Found: /index
ERROR - 2022-03-28 14:05:27 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-28 14:05:27')
ERROR - 2022-03-28 14:06:13 --> 404 Page Not Found: /index
ERROR - 2022-03-28 14:06:15 --> 404 Page Not Found: /index
ERROR - 2022-03-28 14:07:38 --> 404 Page Not Found: /index
ERROR - 2022-03-28 14:07:39 --> 404 Page Not Found: /index
ERROR - 2022-03-28 14:09:20 --> 404 Page Not Found: /index
ERROR - 2022-03-28 14:09:31 --> 404 Page Not Found: /index
ERROR - 2022-03-28 14:12:06 --> 404 Page Not Found: /index
ERROR - 2022-03-28 14:13:16 --> 404 Page Not Found: /index
ERROR - 2022-03-28 14:13:18 --> 404 Page Not Found: /index
ERROR - 2022-03-28 14:14:40 --> 404 Page Not Found: /index
ERROR - 2022-03-28 14:16:02 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 14:16:19 --> 404 Page Not Found: /index
ERROR - 2022-03-28 14:18:12 --> 404 Page Not Found: /index
ERROR - 2022-03-28 14:18:57 --> 404 Page Not Found: /index
ERROR - 2022-03-28 14:18:57 --> 404 Page Not Found: /index
ERROR - 2022-03-28 14:19:24 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 14:19:38 --> 404 Page Not Found: /index
ERROR - 2022-03-28 14:20:11 --> 404 Page Not Found: /index
ERROR - 2022-03-28 14:21:44 --> 404 Page Not Found: /index
ERROR - 2022-03-28 14:23:57 --> 404 Page Not Found: /index
ERROR - 2022-03-28 14:24:23 --> 404 Page Not Found: /index
ERROR - 2022-03-28 14:24:36 --> 404 Page Not Found: /index
ERROR - 2022-03-28 14:25:33 --> 404 Page Not Found: /index
ERROR - 2022-03-28 14:25:55 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 14:25:58 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 14:26:08 --> 404 Page Not Found: /index
ERROR - 2022-03-28 14:26:44 --> 404 Page Not Found: /index
ERROR - 2022-03-28 14:27:04 --> 404 Page Not Found: /index
ERROR - 2022-03-28 14:27:16 --> 404 Page Not Found: /index
ERROR - 2022-03-28 14:29:24 --> 404 Page Not Found: /index
ERROR - 2022-03-28 14:29:47 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 14:29:54 --> 404 Page Not Found: /index
ERROR - 2022-03-28 14:30:23 --> 404 Page Not Found: /index
ERROR - 2022-03-28 14:31:02 --> 404 Page Not Found: /index
ERROR - 2022-03-28 14:31:49 --> 404 Page Not Found: /index
ERROR - 2022-03-28 14:32:03 --> 404 Page Not Found: /index
ERROR - 2022-03-28 14:32:07 --> 404 Page Not Found: /index
ERROR - 2022-03-28 14:32:46 --> 404 Page Not Found: /index
ERROR - 2022-03-28 14:34:21 --> 404 Page Not Found: /index
ERROR - 2022-03-28 14:35:14 --> 404 Page Not Found: /index
ERROR - 2022-03-28 14:35:15 --> 404 Page Not Found: /index
ERROR - 2022-03-28 14:36:17 --> 404 Page Not Found: /index
ERROR - 2022-03-28 14:36:58 --> 404 Page Not Found: /index
ERROR - 2022-03-28 14:37:53 --> 404 Page Not Found: /index
ERROR - 2022-03-28 14:37:59 --> 404 Page Not Found: /index
ERROR - 2022-03-28 14:38:18 --> 404 Page Not Found: /index
ERROR - 2022-03-28 14:39:13 --> 404 Page Not Found: /index
ERROR - 2022-03-28 14:40:05 --> 404 Page Not Found: /index
ERROR - 2022-03-28 14:40:55 --> 404 Page Not Found: /index
ERROR - 2022-03-28 14:40:57 --> 404 Page Not Found: /index
ERROR - 2022-03-28 14:41:32 --> 404 Page Not Found: /index
ERROR - 2022-03-28 14:42:09 --> 404 Page Not Found: /index
ERROR - 2022-03-28 14:42:32 --> 404 Page Not Found: /index
ERROR - 2022-03-28 14:47:32 --> 404 Page Not Found: /index
ERROR - 2022-03-28 14:47:39 --> 404 Page Not Found: /index
ERROR - 2022-03-28 14:48:56 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 14:48:59 --> 404 Page Not Found: /index
ERROR - 2022-03-28 14:49:01 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 14:49:08 --> 404 Page Not Found: /index
ERROR - 2022-03-28 14:49:21 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 14:49:29 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 14:49:50 --> 404 Page Not Found: /index
ERROR - 2022-03-28 14:49:50 --> 404 Page Not Found: /index
ERROR - 2022-03-28 14:50:16 --> 404 Page Not Found: /index
ERROR - 2022-03-28 14:52:16 --> 404 Page Not Found: /index
ERROR - 2022-03-28 14:55:37 --> 404 Page Not Found: /index
ERROR - 2022-03-28 14:56:17 --> 404 Page Not Found: /index
ERROR - 2022-03-28 14:57:21 --> 404 Page Not Found: /index
ERROR - 2022-03-28 14:57:53 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 14:58:45 --> 404 Page Not Found: /index
ERROR - 2022-03-28 14:59:12 --> 404 Page Not Found: /index
ERROR - 2022-03-28 14:59:16 --> 404 Page Not Found: /index
ERROR - 2022-03-28 15:00:57 --> 404 Page Not Found: /index
ERROR - 2022-03-28 15:00:57 --> 404 Page Not Found: /index
ERROR - 2022-03-28 15:01:26 --> 404 Page Not Found: /index
ERROR - 2022-03-28 15:01:34 --> 404 Page Not Found: /index
ERROR - 2022-03-28 15:01:54 --> 404 Page Not Found: /index
ERROR - 2022-03-28 15:01:59 --> 404 Page Not Found: /index
ERROR - 2022-03-28 15:02:01 --> 404 Page Not Found: /index
ERROR - 2022-03-28 15:02:05 --> 404 Page Not Found: /index
ERROR - 2022-03-28 15:02:12 --> 404 Page Not Found: /index
ERROR - 2022-03-28 15:02:30 --> 404 Page Not Found: /index
ERROR - 2022-03-28 15:02:30 --> 404 Page Not Found: /index
ERROR - 2022-03-28 15:02:36 --> 404 Page Not Found: /index
ERROR - 2022-03-28 15:03:31 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 15:04:22 --> To Id is not available for User - 3046
ERROR - 2022-03-28 15:05:11 --> 404 Page Not Found: /index
ERROR - 2022-03-28 15:06:58 --> 404 Page Not Found: /index
ERROR - 2022-03-28 15:08:51 --> 404 Page Not Found: /index
ERROR - 2022-03-28 15:09:02 --> 404 Page Not Found: /index
ERROR - 2022-03-28 15:09:04 --> 404 Page Not Found: /index
ERROR - 2022-03-28 15:09:50 --> 404 Page Not Found: /index
ERROR - 2022-03-28 15:10:19 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-28 15:10:19')
ERROR - 2022-03-28 15:10:55 --> 404 Page Not Found: /index
ERROR - 2022-03-28 15:11:01 --> To Id is not available for User - 3046
ERROR - 2022-03-28 15:11:03 --> 404 Page Not Found: /index
ERROR - 2022-03-28 15:11:04 --> To Id is not available for User - 3046
ERROR - 2022-03-28 15:11:15 --> 404 Page Not Found: /index
ERROR - 2022-03-28 15:11:25 --> 404 Page Not Found: /index
ERROR - 2022-03-28 15:11:56 --> 404 Page Not Found: /index
ERROR - 2022-03-28 15:13:22 --> 404 Page Not Found: /index
ERROR - 2022-03-28 15:13:43 --> 404 Page Not Found: /index
ERROR - 2022-03-28 15:14:20 --> 404 Page Not Found: /index
ERROR - 2022-03-28 15:14:28 --> 404 Page Not Found: /index
ERROR - 2022-03-28 15:14:31 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-28 15:14:31')
ERROR - 2022-03-28 15:14:43 --> 404 Page Not Found: /index
ERROR - 2022-03-28 15:14:53 --> 404 Page Not Found: /index
ERROR - 2022-03-28 15:15:01 --> 404 Page Not Found: /index
ERROR - 2022-03-28 15:15:53 --> 404 Page Not Found: /index
ERROR - 2022-03-28 15:16:08 --> 404 Page Not Found: /index
ERROR - 2022-03-28 15:17:13 --> 404 Page Not Found: /index
ERROR - 2022-03-28 15:17:18 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-28 15:17:18')
ERROR - 2022-03-28 15:17:26 --> 404 Page Not Found: /index
ERROR - 2022-03-28 15:18:13 --> 404 Page Not Found: /index
ERROR - 2022-03-28 15:19:20 --> To Id is not available for User - 3046
ERROR - 2022-03-28 15:19:42 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 15:19:44 --> 404 Page Not Found: /index
ERROR - 2022-03-28 15:20:50 --> 404 Page Not Found: /index
ERROR - 2022-03-28 15:21:27 --> 404 Page Not Found: /index
ERROR - 2022-03-28 15:21:31 --> 404 Page Not Found: /index
ERROR - 2022-03-28 15:22:06 --> 404 Page Not Found: /index
ERROR - 2022-03-28 15:23:48 --> 404 Page Not Found: /index
ERROR - 2022-03-28 15:24:11 --> 404 Page Not Found: /index
ERROR - 2022-03-28 15:24:14 --> 404 Page Not Found: /index
ERROR - 2022-03-28 15:24:14 --> 404 Page Not Found: /index
ERROR - 2022-03-28 15:25:36 --> 404 Page Not Found: /index
ERROR - 2022-03-28 15:28:13 --> 404 Page Not Found: /index
ERROR - 2022-03-28 15:28:53 --> 404 Page Not Found: /index
ERROR - 2022-03-28 15:29:43 --> 404 Page Not Found: /index
ERROR - 2022-03-28 15:30:11 --> 404 Page Not Found: /index
ERROR - 2022-03-28 15:30:49 --> 404 Page Not Found: /index
ERROR - 2022-03-28 15:31:17 --> 404 Page Not Found: /index
ERROR - 2022-03-28 15:32:02 --> 404 Page Not Found: /index
ERROR - 2022-03-28 15:32:55 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 15:33:27 --> To Id is not available for User - 3046
ERROR - 2022-03-28 15:33:30 --> 404 Page Not Found: /index
ERROR - 2022-03-28 15:33:50 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 15:34:04 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 15:34:10 --> 404 Page Not Found: /index
ERROR - 2022-03-28 15:34:13 --> 404 Page Not Found: /index
ERROR - 2022-03-28 15:34:39 --> 404 Page Not Found: /index
ERROR - 2022-03-28 15:35:34 --> 404 Page Not Found: /index
ERROR - 2022-03-28 15:37:11 --> 404 Page Not Found: /index
ERROR - 2022-03-28 15:38:16 --> 404 Page Not Found: /index
ERROR - 2022-03-28 15:38:22 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 15:38:30 --> 404 Page Not Found: /index
ERROR - 2022-03-28 15:38:39 --> 404 Page Not Found: /index
ERROR - 2022-03-28 15:38:59 --> 404 Page Not Found: /index
ERROR - 2022-03-28 15:39:28 --> 404 Page Not Found: /index
ERROR - 2022-03-28 15:41:30 --> 404 Page Not Found: /index
ERROR - 2022-03-28 15:41:50 --> 404 Page Not Found: /index
ERROR - 2022-03-28 15:42:34 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 15:42:34 --> 404 Page Not Found: /index
ERROR - 2022-03-28 15:42:48 --> 404 Page Not Found: /index
ERROR - 2022-03-28 15:43:29 --> 404 Page Not Found: /index
ERROR - 2022-03-28 15:44:01 --> 404 Page Not Found: /index
ERROR - 2022-03-28 15:44:11 --> 404 Page Not Found: /index
ERROR - 2022-03-28 15:44:20 --> 404 Page Not Found: /index
ERROR - 2022-03-28 15:47:42 --> 404 Page Not Found: /index
ERROR - 2022-03-28 15:53:20 --> To Id is not available for User - 3046
ERROR - 2022-03-28 15:53:22 --> 404 Page Not Found: /index
ERROR - 2022-03-28 15:54:06 --> 404 Page Not Found: /index
ERROR - 2022-03-28 15:54:33 --> 404 Page Not Found: /index
ERROR - 2022-03-28 15:54:47 --> 404 Page Not Found: /index
ERROR - 2022-03-28 15:55:24 --> 404 Page Not Found: /index
ERROR - 2022-03-28 15:56:18 --> To Id is not available for User - 3046
ERROR - 2022-03-28 15:56:21 --> 404 Page Not Found: /index
ERROR - 2022-03-28 15:57:24 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-28 15:57:24')
ERROR - 2022-03-28 15:57:28 --> 404 Page Not Found: /index
ERROR - 2022-03-28 15:57:58 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:00:03 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:02:23 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:02:29 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:02:35 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:03:47 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:04:10 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:04:46 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:05:14 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:05:46 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:05:52 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 16:05:55 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 16:06:16 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:06:30 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:06:55 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:08:05 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:08:11 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:08:25 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:08:41 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:08:54 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:09:20 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:09:26 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:09:46 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:10:06 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:10:09 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:10:12 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:10:24 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:10:43 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:10:55 --> To Id is not available for User - 3046
ERROR - 2022-03-28 16:10:56 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:11:00 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:11:32 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:11:33 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:11:52 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 16:11:56 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:12:00 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:12:03 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:12:29 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:12:38 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:12:40 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:13:44 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:14:20 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:15:12 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:15:18 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:15:50 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:16:21 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:16:33 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 16:16:37 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 16:16:50 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:16:54 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:17:09 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:17:09 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:17:09 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:17:59 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:18:00 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:18:20 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:19:08 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:19:08 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:19:24 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:19:50 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:20:07 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:20:08 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:20:30 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:21:43 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:21:47 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:22:27 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:23:00 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:24:37 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:26:15 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:26:43 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:26:48 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:26:57 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:27:26 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:27:30 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:27:40 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:28:33 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:29:45 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:31:46 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:31:47 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:32:02 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:32:53 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:34:07 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:34:31 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:34:37 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:35:37 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:35:55 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:36:53 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:36:58 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:37:34 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:38:52 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:39:25 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:39:40 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:40:56 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:42:04 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:42:32 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:44:07 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:44:40 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:46:22 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:46:36 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:46:39 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:47:32 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:47:45 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:47:57 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:48:17 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:48:34 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:49:43 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:51:22 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:51:29 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:51:59 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:52:56 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:53:06 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:53:45 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:53:54 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:55:24 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:56:20 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:56:21 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:57:50 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:58:00 --> 404 Page Not Found: /index
ERROR - 2022-03-28 16:58:48 --> 404 Page Not Found: /index
ERROR - 2022-03-28 17:01:12 --> 404 Page Not Found: /index
ERROR - 2022-03-28 17:01:40 --> 404 Page Not Found: /index
ERROR - 2022-03-28 17:03:53 --> 404 Page Not Found: /index
ERROR - 2022-03-28 17:03:56 --> 404 Page Not Found: /index
ERROR - 2022-03-28 17:04:33 --> 404 Page Not Found: /index
ERROR - 2022-03-28 17:05:39 --> To Id is not available for User - 3046
ERROR - 2022-03-28 17:05:43 --> 404 Page Not Found: /index
ERROR - 2022-03-28 17:05:50 --> 404 Page Not Found: /index
ERROR - 2022-03-28 17:05:50 --> 404 Page Not Found: /index
ERROR - 2022-03-28 17:05:51 --> 404 Page Not Found: /index
ERROR - 2022-03-28 17:05:53 --> 404 Page Not Found: /index
ERROR - 2022-03-28 17:06:21 --> 404 Page Not Found: /index
ERROR - 2022-03-28 17:06:51 --> 404 Page Not Found: /index
ERROR - 2022-03-28 17:06:54 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 17:06:55 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 17:06:55 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 17:06:56 --> 404 Page Not Found: /index
ERROR - 2022-03-28 17:07:00 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 17:07:01 --> 404 Page Not Found: /index
ERROR - 2022-03-28 17:07:12 --> 404 Page Not Found: /index
ERROR - 2022-03-28 17:08:42 --> 404 Page Not Found: /index
ERROR - 2022-03-28 17:08:51 --> 404 Page Not Found: /index
ERROR - 2022-03-28 17:11:05 --> 404 Page Not Found: /index
ERROR - 2022-03-28 17:11:05 --> 404 Page Not Found: /index
ERROR - 2022-03-28 17:13:00 --> 404 Page Not Found: /index
ERROR - 2022-03-28 17:13:04 --> 404 Page Not Found: /index
ERROR - 2022-03-28 17:13:20 --> 404 Page Not Found: /index
ERROR - 2022-03-28 17:14:26 --> 404 Page Not Found: /index
ERROR - 2022-03-28 17:15:25 --> 404 Page Not Found: /index
ERROR - 2022-03-28 17:15:44 --> 404 Page Not Found: /index
ERROR - 2022-03-28 17:17:22 --> 404 Page Not Found: /index
ERROR - 2022-03-28 17:17:44 --> 404 Page Not Found: /index
ERROR - 2022-03-28 17:19:59 --> 404 Page Not Found: /index
ERROR - 2022-03-28 17:20:31 --> 404 Page Not Found: /index
ERROR - 2022-03-28 17:20:36 --> 404 Page Not Found: /index
ERROR - 2022-03-28 17:21:08 --> 404 Page Not Found: /index
ERROR - 2022-03-28 17:24:10 --> 404 Page Not Found: /index
ERROR - 2022-03-28 17:24:11 --> 404 Page Not Found: /index
ERROR - 2022-03-28 17:24:32 --> 404 Page Not Found: /index
ERROR - 2022-03-28 17:26:30 --> 404 Page Not Found: /index
ERROR - 2022-03-28 17:26:41 --> 404 Page Not Found: /index
ERROR - 2022-03-28 17:27:07 --> 404 Page Not Found: /index
ERROR - 2022-03-28 17:27:17 --> 404 Page Not Found: /index
ERROR - 2022-03-28 17:27:19 --> 404 Page Not Found: /index
ERROR - 2022-03-28 17:30:51 --> 404 Page Not Found: /index
ERROR - 2022-03-28 17:31:26 --> 404 Page Not Found: /index
ERROR - 2022-03-28 17:31:43 --> 404 Page Not Found: /index
ERROR - 2022-03-28 17:33:27 --> 404 Page Not Found: /index
ERROR - 2022-03-28 17:33:40 --> 404 Page Not Found: /index
ERROR - 2022-03-28 17:33:59 --> 404 Page Not Found: /index
ERROR - 2022-03-28 17:34:00 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 17:34:01 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 17:34:01 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 17:34:07 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 17:34:10 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 17:34:15 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 17:34:27 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 17:34:31 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 17:34:34 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 17:34:49 --> 404 Page Not Found: /index
ERROR - 2022-03-28 17:35:12 --> 404 Page Not Found: /index
ERROR - 2022-03-28 17:35:32 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 17:35:37 --> 404 Page Not Found: /index
ERROR - 2022-03-28 17:35:55 --> 404 Page Not Found: /index
ERROR - 2022-03-28 17:36:05 --> 404 Page Not Found: /index
ERROR - 2022-03-28 17:36:27 --> 404 Page Not Found: /index
ERROR - 2022-03-28 17:36:27 --> 404 Page Not Found: /index
ERROR - 2022-03-28 17:36:45 --> 404 Page Not Found: /index
ERROR - 2022-03-28 17:36:45 --> 404 Page Not Found: /index
ERROR - 2022-03-28 17:36:47 --> 404 Page Not Found: /index
ERROR - 2022-03-28 17:36:47 --> 404 Page Not Found: /index
ERROR - 2022-03-28 17:37:04 --> 404 Page Not Found: /index
ERROR - 2022-03-28 17:37:53 --> 404 Page Not Found: /index
ERROR - 2022-03-28 17:38:41 --> 404 Page Not Found: /index
ERROR - 2022-03-28 17:41:11 --> 404 Page Not Found: /index
ERROR - 2022-03-28 17:41:48 --> 404 Page Not Found: /index
ERROR - 2022-03-28 17:43:12 --> 404 Page Not Found: /index
ERROR - 2022-03-28 17:43:59 --> 404 Page Not Found: /index
ERROR - 2022-03-28 17:44:01 --> 404 Page Not Found: /index
ERROR - 2022-03-28 17:44:06 --> 404 Page Not Found: /index
ERROR - 2022-03-28 17:44:15 --> 404 Page Not Found: /index
ERROR - 2022-03-28 17:44:19 --> 404 Page Not Found: /index
ERROR - 2022-03-28 17:45:06 --> 404 Page Not Found: /index
ERROR - 2022-03-28 17:45:39 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 17:45:41 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 17:45:42 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 17:46:25 --> 404 Page Not Found: /index
ERROR - 2022-03-28 17:48:36 --> 404 Page Not Found: /index
ERROR - 2022-03-28 17:48:47 --> 404 Page Not Found: /index
ERROR - 2022-03-28 17:49:09 --> 404 Page Not Found: /index
ERROR - 2022-03-28 17:51:13 --> 404 Page Not Found: /index
ERROR - 2022-03-28 17:52:29 --> 404 Page Not Found: /index
ERROR - 2022-03-28 17:53:20 --> 404 Page Not Found: /index
ERROR - 2022-03-28 17:55:02 --> 404 Page Not Found: /index
ERROR - 2022-03-28 17:56:19 --> 404 Page Not Found: /index
ERROR - 2022-03-28 17:57:59 --> 404 Page Not Found: /index
ERROR - 2022-03-28 17:58:14 --> 404 Page Not Found: /index
ERROR - 2022-03-28 17:58:30 --> 404 Page Not Found: /index
ERROR - 2022-03-28 17:58:34 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:00:00 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:00:42 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:01:36 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:03:58 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:04:22 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:06:39 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:06:52 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:07:16 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:09:51 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:10:32 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:12:48 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:13:27 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:13:27 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:14:28 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:14:46 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:15:11 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:16:24 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:16:35 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:16:37 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:16:43 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:16:47 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:17:50 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:18:14 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:19:32 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:20:18 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:21:28 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:21:28 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:24:04 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:24:24 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:26:01 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:26:05 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:26:13 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:26:36 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:26:39 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:28:09 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:29:18 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:30:05 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:30:28 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:30:37 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:31:44 --> To Id is not available for User - 3046
ERROR - 2022-03-28 18:31:44 --> To Id is not available for User - 3046
ERROR - 2022-03-28 18:31:49 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:31:56 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:31:58 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:32:06 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:32:31 --> To Id is not available for User - 3046
ERROR - 2022-03-28 18:32:34 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:32:43 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:33:42 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:33:46 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:34:45 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:35:40 --> To Id is not available for User - 3046
ERROR - 2022-03-28 18:36:30 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:36:39 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:37:05 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:38:03 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:39:57 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:40:32 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:41:07 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:41:23 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:41:23 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:41:24 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:41:24 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:41:25 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:41:25 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:41:26 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:41:26 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:41:27 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:41:27 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:41:56 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:41:56 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:43:10 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:43:10 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:43:20 --> To Id is not available for User - 3046
ERROR - 2022-03-28 18:43:21 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:43:24 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:43:40 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:45:04 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:45:38 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:45:52 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:47:45 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:47:52 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:51:23 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:52:28 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:53:10 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:53:34 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:54:00 --> To Id is not available for User - 3046
ERROR - 2022-03-28 18:54:00 --> To Id is not available for User - 3046
ERROR - 2022-03-28 18:54:07 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:54:07 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:54:33 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:54:46 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:55:37 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:56:33 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:57:25 --> To Id is not available for User - 3046
ERROR - 2022-03-28 18:57:28 --> 404 Page Not Found: /index
ERROR - 2022-03-28 18:58:24 --> 404 Page Not Found: /index
ERROR - 2022-03-28 19:01:05 --> 404 Page Not Found: /index
ERROR - 2022-03-28 19:08:46 --> 404 Page Not Found: /index
ERROR - 2022-03-28 19:10:20 --> 404 Page Not Found: /index
ERROR - 2022-03-28 19:10:45 --> 404 Page Not Found: /index
ERROR - 2022-03-28 19:10:53 --> 404 Page Not Found: /index
ERROR - 2022-03-28 19:11:32 --> 404 Page Not Found: /index
ERROR - 2022-03-28 19:13:49 --> 404 Page Not Found: /index
ERROR - 2022-03-28 19:14:38 --> 404 Page Not Found: /index
ERROR - 2022-03-28 19:15:51 --> 404 Page Not Found: /index
ERROR - 2022-03-28 19:16:53 --> 404 Page Not Found: /index
ERROR - 2022-03-28 19:18:02 --> 404 Page Not Found: /index
ERROR - 2022-03-28 19:23:25 --> 404 Page Not Found: /index
ERROR - 2022-03-28 19:28:06 --> To Id is not available for User - 3046
ERROR - 2022-03-28 19:28:07 --> 404 Page Not Found: /index
ERROR - 2022-03-28 19:28:31 --> 404 Page Not Found: /index
ERROR - 2022-03-28 19:30:40 --> 404 Page Not Found: /index
ERROR - 2022-03-28 19:34:40 --> 404 Page Not Found: /index
ERROR - 2022-03-28 19:34:40 --> 404 Page Not Found: /index
ERROR - 2022-03-28 19:35:04 --> 404 Page Not Found: /index
ERROR - 2022-03-28 19:35:33 --> 404 Page Not Found: /index
ERROR - 2022-03-28 19:35:35 --> 404 Page Not Found: /index
ERROR - 2022-03-28 19:35:38 --> 404 Page Not Found: /index
ERROR - 2022-03-28 19:35:46 --> 404 Page Not Found: /index
ERROR - 2022-03-28 19:36:36 --> 404 Page Not Found: /index
ERROR - 2022-03-28 19:38:43 --> 404 Page Not Found: /index
ERROR - 2022-03-28 19:42:05 --> 404 Page Not Found: /index
ERROR - 2022-03-28 19:42:21 --> 404 Page Not Found: /index
ERROR - 2022-03-28 19:42:22 --> 404 Page Not Found: /index
ERROR - 2022-03-28 19:43:45 --> 404 Page Not Found: /index
ERROR - 2022-03-28 19:47:23 --> 404 Page Not Found: /index
ERROR - 2022-03-28 19:48:41 --> 404 Page Not Found: /index
ERROR - 2022-03-28 19:50:25 --> 404 Page Not Found: /index
ERROR - 2022-03-28 19:52:38 --> 404 Page Not Found: /index
ERROR - 2022-03-28 19:53:51 --> 404 Page Not Found: /index
ERROR - 2022-03-28 19:54:25 --> 404 Page Not Found: /index
ERROR - 2022-03-28 19:54:57 --> 404 Page Not Found: /index
ERROR - 2022-03-28 19:56:02 --> 404 Page Not Found: /index
ERROR - 2022-03-28 19:56:19 --> 404 Page Not Found: /index
ERROR - 2022-03-28 19:57:04 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:00:59 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:01:55 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:02:20 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:02:42 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:06:11 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:06:59 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:07:06 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:07:26 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:07:26 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:08:26 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:08:35 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:11:35 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:12:31 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:12:31 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:12:32 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:13:51 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:13:57 --> Query error: Table 'cowcdrmy_kammamarriage.ms_shortlist_viewedd_ignored' doesn't exist - Invalid query: SELECT `v`.*, `p`.`gender`, `p`.`id`, `p`.`status`, `p`.`age`, `p`.`living_in`, `p`.`profile_id`, `p`.`first_name`, `last_name`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `s`.*
FROM `kv_profileview` as `v`
LEFT JOIN `tbl_primary_info` as `p` ON `v`.`kv_profileview_on` = `p`.`id`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`ms_id`
INNER JOIN `ms_profilesetting` as `s` ON `p`.`id`=`s`.`ms_id`
WHERE `s`.`elite` = 'no'
AND `p`.`status` = 1
AND `v`.`kv_userfkid` = '3581'
AND `u`.`ismain` = 1
AND  `p`.`id` not in(select kv_msi_interested_on from kv_mysideinterests where kv_msi_profilefkid="3581")
AND  p.id not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid = "3581" AND `shortlist_status` = 1)
AND  `p`.`id` not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid="3581"AND ignore_status=1)
ORDER BY `v`.`kv_profileview_created_date` DESC
 LIMIT 10
ERROR - 2022-03-28 20:14:14 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:14:14 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:14:40 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:14:40 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:14:42 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:14:42 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:14:45 --> Query error: Table 'cowcdrmy_kammamarriage.ms_shortlist_viewedd_ignored' doesn't exist - Invalid query: SELECT `v`.*, `p`.`gender`, `p`.`id`, `p`.`status`, `p`.`age`, `p`.`living_in`, `p`.`profile_id`, `p`.`first_name`, `last_name`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `s`.*
FROM `kv_profileview` as `v`
LEFT JOIN `tbl_primary_info` as `p` ON `v`.`kv_profileview_on` = `p`.`id`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`ms_id`
INNER JOIN `ms_profilesetting` as `s` ON `p`.`id`=`s`.`ms_id`
WHERE `s`.`elite` = 'no'
AND `p`.`status` = 1
AND `v`.`kv_userfkid` = '3581'
AND `u`.`ismain` = 1
AND  `p`.`id` not in(select kv_msi_interested_on from kv_mysideinterests where kv_msi_profilefkid="3581")
AND  p.id not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid = "3581" AND `shortlist_status` = 1)
AND  `p`.`id` not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid="3581"AND ignore_status=1)
ORDER BY `v`.`kv_profileview_created_date` DESC
 LIMIT 10
ERROR - 2022-03-28 20:18:30 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:18:48 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:19:05 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:19:39 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:20:52 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:20:59 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:22:31 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:22:42 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:23:22 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:23:22 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:23:42 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-03-28 20:23:42')
ERROR - 2022-03-28 20:25:32 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:25:40 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:25:40 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:25:51 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:26:26 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:26:47 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:28:07 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:28:28 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:28:35 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:28:58 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:29:21 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:31:18 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:32:31 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:33:28 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:33:55 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:36:01 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:36:22 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:36:32 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:37:36 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:38:03 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:41:29 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:42:06 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:43:55 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:45:26 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:45:26 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:46:40 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:47:04 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:47:04 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:47:04 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:47:05 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:47:06 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:47:07 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:47:21 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:47:22 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:47:23 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:47:24 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:47:25 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:47:27 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:47:28 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:47:29 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:47:30 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:47:31 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:47:33 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:47:34 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:47:35 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:47:36 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:47:37 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:47:38 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:47:39 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:47:41 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:47:41 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:47:42 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:47:43 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:47:44 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:47:45 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:47:46 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:47:48 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:47:49 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:47:51 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:47:52 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:47:53 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:47:54 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:47:56 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:47:57 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:47:58 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:47:59 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:48:00 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:48:01 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:48:02 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:48:03 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:48:04 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:48:05 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:48:06 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:48:07 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:48:08 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:48:09 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:48:11 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:48:12 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:48:12 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:48:14 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:48:32 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:49:15 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:50:02 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:50:38 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:50:40 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:52:19 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:52:51 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:52:58 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:53:02 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:54:27 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:56:58 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:57:39 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:58:59 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:59:54 --> 404 Page Not Found: /index
ERROR - 2022-03-28 20:59:54 --> 404 Page Not Found: /index
ERROR - 2022-03-28 21:02:31 --> 404 Page Not Found: /index
ERROR - 2022-03-28 21:03:43 --> 404 Page Not Found: /index
ERROR - 2022-03-28 21:04:04 --> 404 Page Not Found: /index
ERROR - 2022-03-28 21:04:40 --> 404 Page Not Found: /index
ERROR - 2022-03-28 21:05:14 --> 404 Page Not Found: /index
ERROR - 2022-03-28 21:05:32 --> 404 Page Not Found: /index
ERROR - 2022-03-28 21:05:36 --> 404 Page Not Found: /index
ERROR - 2022-03-28 21:05:38 --> 404 Page Not Found: /index
ERROR - 2022-03-28 21:05:45 --> To Id is not available for User - 2542
ERROR - 2022-03-28 21:08:09 --> 404 Page Not Found: /index
ERROR - 2022-03-28 21:08:12 --> 404 Page Not Found: /index
ERROR - 2022-03-28 21:08:27 --> 404 Page Not Found: /index
ERROR - 2022-03-28 21:14:48 --> 404 Page Not Found: /index
ERROR - 2022-03-28 21:15:09 --> 404 Page Not Found: /index
ERROR - 2022-03-28 21:15:53 --> 404 Page Not Found: /index
ERROR - 2022-03-28 21:16:33 --> 404 Page Not Found: /index
ERROR - 2022-03-28 21:17:07 --> 404 Page Not Found: /index
ERROR - 2022-03-28 21:18:49 --> 404 Page Not Found: /index
ERROR - 2022-03-28 21:19:00 --> 404 Page Not Found: /index
ERROR - 2022-03-28 21:21:20 --> 404 Page Not Found: /index
ERROR - 2022-03-28 21:22:48 --> 404 Page Not Found: /index
ERROR - 2022-03-28 21:22:48 --> 404 Page Not Found: /index
ERROR - 2022-03-28 21:23:10 --> 404 Page Not Found: /index
ERROR - 2022-03-28 21:23:30 --> 404 Page Not Found: /index
ERROR - 2022-03-28 21:23:53 --> 404 Page Not Found: /index
ERROR - 2022-03-28 21:24:10 --> 404 Page Not Found: /index
ERROR - 2022-03-28 21:24:13 --> 404 Page Not Found: /index
ERROR - 2022-03-28 21:25:24 --> 404 Page Not Found: /index
ERROR - 2022-03-28 21:25:27 --> 404 Page Not Found: /index
ERROR - 2022-03-28 21:25:31 --> 404 Page Not Found: /index
ERROR - 2022-03-28 21:25:34 --> 404 Page Not Found: /index
ERROR - 2022-03-28 21:27:01 --> 404 Page Not Found: /index
ERROR - 2022-03-28 21:28:12 --> 404 Page Not Found: /index
ERROR - 2022-03-28 21:28:17 --> 404 Page Not Found: /index
ERROR - 2022-03-28 21:29:53 --> 404 Page Not Found: /index
ERROR - 2022-03-28 21:31:04 --> 404 Page Not Found: /index
ERROR - 2022-03-28 21:32:30 --> 404 Page Not Found: /index
ERROR - 2022-03-28 21:32:41 --> 404 Page Not Found: /index
ERROR - 2022-03-28 21:33:23 --> 404 Page Not Found: /index
ERROR - 2022-03-28 21:33:38 --> 404 Page Not Found: /index
ERROR - 2022-03-28 21:34:25 --> 404 Page Not Found: /index
ERROR - 2022-03-28 21:34:50 --> 404 Page Not Found: /index
ERROR - 2022-03-28 21:36:53 --> 404 Page Not Found: /index
ERROR - 2022-03-28 21:38:07 --> 404 Page Not Found: /index
ERROR - 2022-03-28 21:38:21 --> 404 Page Not Found: /index
ERROR - 2022-03-28 21:38:29 --> 404 Page Not Found: /index
ERROR - 2022-03-28 21:39:02 --> 404 Page Not Found: /index
ERROR - 2022-03-28 21:41:14 --> 404 Page Not Found: /index
ERROR - 2022-03-28 21:42:29 --> 404 Page Not Found: /index
ERROR - 2022-03-28 21:43:39 --> 404 Page Not Found: /index
ERROR - 2022-03-28 21:45:13 --> 404 Page Not Found: /index
ERROR - 2022-03-28 21:45:19 --> 404 Page Not Found: /index
ERROR - 2022-03-28 21:45:45 --> 404 Page Not Found: /index
ERROR - 2022-03-28 21:45:52 --> 404 Page Not Found: /index
ERROR - 2022-03-28 21:45:52 --> 404 Page Not Found: /index
ERROR - 2022-03-28 21:46:09 --> 404 Page Not Found: /index
ERROR - 2022-03-28 21:47:29 --> 404 Page Not Found: /index
ERROR - 2022-03-28 21:47:29 --> 404 Page Not Found: /index
ERROR - 2022-03-28 21:48:13 --> 404 Page Not Found: /index
ERROR - 2022-03-28 21:48:41 --> To Id is not available for User - 1765
ERROR - 2022-03-28 21:49:20 --> 404 Page Not Found: /index
ERROR - 2022-03-28 21:49:20 --> 404 Page Not Found: /index
ERROR - 2022-03-28 21:49:55 --> 404 Page Not Found: /index
ERROR - 2022-03-28 21:51:26 --> 404 Page Not Found: /index
ERROR - 2022-03-28 21:51:26 --> 404 Page Not Found: /index
ERROR - 2022-03-28 21:52:11 --> 404 Page Not Found: /index
ERROR - 2022-03-28 21:53:00 --> 404 Page Not Found: /index
ERROR - 2022-03-28 21:53:19 --> 404 Page Not Found: /index
ERROR - 2022-03-28 21:53:19 --> 404 Page Not Found: /index
ERROR - 2022-03-28 21:53:45 --> 404 Page Not Found: /index
ERROR - 2022-03-28 21:55:05 --> 404 Page Not Found: /index
ERROR - 2022-03-28 21:56:21 --> 404 Page Not Found: /index
ERROR - 2022-03-28 21:57:11 --> 404 Page Not Found: /index
ERROR - 2022-03-28 21:57:41 --> 404 Page Not Found: /index
ERROR - 2022-03-28 21:57:46 --> 404 Page Not Found: /index
ERROR - 2022-03-28 21:57:51 --> 404 Page Not Found: /index
ERROR - 2022-03-28 21:58:07 --> 404 Page Not Found: /index
ERROR - 2022-03-28 21:58:07 --> 404 Page Not Found: /index
ERROR - 2022-03-28 21:58:15 --> 404 Page Not Found: /index
ERROR - 2022-03-28 21:58:41 --> 404 Page Not Found: /index
ERROR - 2022-03-28 21:59:32 --> 404 Page Not Found: /index
ERROR - 2022-03-28 21:59:52 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:00:25 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:01:33 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:02:39 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:03:38 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:04:23 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:04:53 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:05:14 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:05:20 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: select SUM(IFNULL(`basicdetails`, 0) + IFNULL(`religion`, 0) + IFNULL(`edu_prof`, 0) + IFNULL(`parents`, 0) + IFNULL(`Siblings`, 0) + IFNULL(`photo`, 0)) as total,photo,basicdetails,religion,edu_prof,parents,Siblings from tbl_profilebattery where user_id=
ERROR - 2022-03-28 22:05:52 --> Query error: Table 'cowcdrmy_kammamarriage.ms_shortlist_viewedd_ignored' doesn't exist - Invalid query: SELECT `v`.*, `p`.`gender`, `p`.`id`, `p`.`status`, `p`.`age`, `p`.`living_in`, `p`.`profile_id`, `p`.`first_name`, `last_name`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `s`.*
FROM `kv_profileview` as `v`
LEFT JOIN `tbl_primary_info` as `p` ON `v`.`kv_profileview_on` = `p`.`id`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`ms_id`
INNER JOIN `ms_profilesetting` as `s` ON `p`.`id`=`s`.`ms_id`
WHERE `s`.`elite` = 'no'
AND `p`.`status` = 1
AND `v`.`kv_userfkid` = '3581'
AND `u`.`ismain` = 1
AND  `p`.`id` not in(select kv_msi_interested_on from kv_mysideinterests where kv_msi_profilefkid="3581")
AND  p.id not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid = "3581" AND `shortlist_status` = 1)
AND  `p`.`id` not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid="3581"AND ignore_status=1)
ORDER BY `v`.`kv_profileview_created_date` DESC
 LIMIT 10
ERROR - 2022-03-28 22:08:32 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:09:18 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:09:31 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:10:04 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:10:45 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:10:45 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:11:38 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:11:38 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:11:39 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:11:39 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:11:39 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:11:39 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:11:39 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:11:40 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:11:40 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:11:40 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:11:51 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:12:19 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:12:53 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:14:19 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:15:17 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:15:27 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:16:33 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:16:41 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:16:41 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:16:49 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:17:51 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:18:20 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:18:38 --> Severity: error --> Exception: Call to a member function result_array() on null /home4/cowcdrmy/public_html/application/modules/dashboard/models/My_account_model.php 911
ERROR - 2022-03-28 22:19:11 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:19:11 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:19:14 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:19:14 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:19:14 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:19:31 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:19:32 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:19:33 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:19:35 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:19:35 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:19:41 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:19:42 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:19:46 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:19:46 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:20:03 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:20:04 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:22:54 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:23:55 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:24:18 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:25:09 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:25:23 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:25:54 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:25:58 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:26:00 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:26:24 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:28:28 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:28:30 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 22:28:31 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 22:28:34 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-03-28 22:28:46 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:30:39 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:33:25 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:33:26 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:33:48 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:34:08 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:35:09 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:37:07 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:37:12 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:37:27 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:37:49 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:39:06 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:39:39 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:39:44 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:39:45 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:39:45 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:40:01 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:40:38 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:41:19 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:41:22 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:42:27 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:42:27 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:42:27 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:42:29 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:42:29 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:42:30 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:42:49 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:42:58 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:43:23 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:43:42 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:43:42 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:44:29 --> Severity: error --> Exception: Call to a member function result_array() on null /home4/cowcdrmy/public_html/application/modules/dashboard/models/My_account_model.php 911
ERROR - 2022-03-28 22:44:57 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:44:59 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:45:06 --> Query error: Table 'cowcdrmy_kammamarriage.ms_shortlist_viewedd_ignored' doesn't exist - Invalid query: SELECT `v`.*, `p`.`gender`, `p`.`id`, `p`.`status`, `p`.`age`, `p`.`living_in`, `p`.`profile_id`, `p`.`first_name`, `last_name`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `s`.*
FROM `kv_profileview` as `v`
LEFT JOIN `tbl_primary_info` as `p` ON `v`.`kv_profileview_on` = `p`.`id`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`ms_id`
INNER JOIN `ms_profilesetting` as `s` ON `p`.`id`=`s`.`ms_id`
WHERE `s`.`elite` = 'no'
AND `p`.`status` = 1
AND `v`.`kv_userfkid` = '3581'
AND `u`.`ismain` = 1
AND  `p`.`id` not in(select kv_msi_interested_on from kv_mysideinterests where kv_msi_profilefkid="3581")
AND  p.id not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid = "3581" AND `shortlist_status` = 1)
AND  `p`.`id` not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid="3581"AND ignore_status=1)
ORDER BY `v`.`kv_profileview_created_date` DESC
 LIMIT 10
ERROR - 2022-03-28 22:45:14 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:46:16 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:46:16 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:46:57 --> Query error: Table 'cowcdrmy_kammamarriage.ms_shortlist_viewedd_ignored' doesn't exist - Invalid query: SELECT `v`.*, `p`.`gender`, `p`.`id`, `p`.`status`, `p`.`age`, `p`.`living_in`, `p`.`profile_id`, `p`.`first_name`, `last_name`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `s`.*
FROM `kv_profileview` as `v`
LEFT JOIN `tbl_primary_info` as `p` ON `v`.`kv_profileview_on` = `p`.`id`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`ms_id`
INNER JOIN `ms_profilesetting` as `s` ON `p`.`id`=`s`.`ms_id`
WHERE `s`.`elite` = 'no'
AND `p`.`status` = 1
AND `v`.`kv_userfkid` = '3581'
AND `u`.`ismain` = 1
AND  `p`.`id` not in(select kv_msi_interested_on from kv_mysideinterests where kv_msi_profilefkid="3581")
AND  p.id not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid = "3581" AND `shortlist_status` = 1)
AND  `p`.`id` not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid="3581"AND ignore_status=1)
ORDER BY `v`.`kv_profileview_created_date` DESC
 LIMIT 10
ERROR - 2022-03-28 22:47:02 --> Query error: Table 'cowcdrmy_kammamarriage.ms_shortlist_viewedd_ignored' doesn't exist - Invalid query: SELECT `v`.*, `p`.`gender`, `p`.`id`, `p`.`status`, `p`.`age`, `p`.`living_in`, `p`.`profile_id`, `p`.`first_name`, `last_name`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `s`.*
FROM `kv_profileview` as `v`
LEFT JOIN `tbl_primary_info` as `p` ON `v`.`kv_profileview_on` = `p`.`id`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`ms_id`
INNER JOIN `ms_profilesetting` as `s` ON `p`.`id`=`s`.`ms_id`
WHERE `s`.`elite` = 'no'
AND `p`.`status` = 1
AND `v`.`kv_userfkid` = '3581'
AND `u`.`ismain` = 1
AND  `p`.`id` not in(select kv_msi_interested_on from kv_mysideinterests where kv_msi_profilefkid="3581")
AND  p.id not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid = "3581" AND `shortlist_status` = 1)
AND  `p`.`id` not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid="3581"AND ignore_status=1)
ORDER BY `v`.`kv_profileview_created_date` DESC
 LIMIT 10
ERROR - 2022-03-28 22:47:17 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:47:31 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:48:00 --> Query error: Table 'cowcdrmy_kammamarriage.ms_shortlist_viewedd_ignored' doesn't exist - Invalid query: SELECT `v`.*, `p`.`gender`, `p`.`id`, `p`.`status`, `p`.`age`, `p`.`living_in`, `p`.`profile_id`, `p`.`first_name`, `last_name`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `s`.*
FROM `kv_profileview` as `v`
LEFT JOIN `tbl_primary_info` as `p` ON `v`.`kv_profileview_on` = `p`.`id`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`ms_id`
INNER JOIN `ms_profilesetting` as `s` ON `p`.`id`=`s`.`ms_id`
WHERE `s`.`elite` = 'no'
AND `p`.`status` = 1
AND `v`.`kv_userfkid` = '3581'
AND `u`.`ismain` = 1
AND  `p`.`id` not in(select kv_msi_interested_on from kv_mysideinterests where kv_msi_profilefkid="3581")
AND  p.id not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid = "3581" AND `shortlist_status` = 1)
AND  `p`.`id` not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid="3581"AND ignore_status=1)
ORDER BY `v`.`kv_profileview_created_date` DESC
 LIMIT 10
ERROR - 2022-03-28 22:49:13 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:49:13 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:49:37 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:49:53 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:50:09 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:50:43 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:50:43 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:52:24 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:53:22 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:53:22 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:53:41 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:57:53 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:57:53 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:58:33 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:58:37 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:58:37 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:58:43 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:58:51 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:59:14 --> 404 Page Not Found: /index
ERROR - 2022-03-28 22:59:26 --> 404 Page Not Found: /index
ERROR - 2022-03-28 23:00:16 --> 404 Page Not Found: /index
ERROR - 2022-03-28 23:00:43 --> 404 Page Not Found: /index
ERROR - 2022-03-28 23:02:31 --> 404 Page Not Found: /index
ERROR - 2022-03-28 23:03:25 --> 404 Page Not Found: /index
ERROR - 2022-03-28 23:04:48 --> 404 Page Not Found: /index
ERROR - 2022-03-28 23:09:33 --> 404 Page Not Found: /index
ERROR - 2022-03-28 23:09:52 --> 404 Page Not Found: /index
ERROR - 2022-03-28 23:09:56 --> 404 Page Not Found: /index
ERROR - 2022-03-28 23:09:56 --> 404 Page Not Found: /index
ERROR - 2022-03-28 23:09:56 --> 404 Page Not Found: /index
ERROR - 2022-03-28 23:09:57 --> 404 Page Not Found: /index
ERROR - 2022-03-28 23:09:57 --> 404 Page Not Found: /index
ERROR - 2022-03-28 23:09:58 --> 404 Page Not Found: /index
ERROR - 2022-03-28 23:09:58 --> 404 Page Not Found: /index
ERROR - 2022-03-28 23:09:59 --> 404 Page Not Found: /index
ERROR - 2022-03-28 23:09:59 --> 404 Page Not Found: /index
ERROR - 2022-03-28 23:10:47 --> 404 Page Not Found: /index
ERROR - 2022-03-28 23:10:57 --> 404 Page Not Found: /index
ERROR - 2022-03-28 23:11:07 --> 404 Page Not Found: /index
ERROR - 2022-03-28 23:12:09 --> 404 Page Not Found: /index
ERROR - 2022-03-28 23:14:36 --> 404 Page Not Found: /index
ERROR - 2022-03-28 23:14:52 --> 404 Page Not Found: /index
ERROR - 2022-03-28 23:15:07 --> 404 Page Not Found: /index
ERROR - 2022-03-28 23:16:06 --> 404 Page Not Found: /index
ERROR - 2022-03-28 23:20:23 --> 404 Page Not Found: /index
ERROR - 2022-03-28 23:22:42 --> 404 Page Not Found: /index
ERROR - 2022-03-28 23:24:13 --> 404 Page Not Found: /index
ERROR - 2022-03-28 23:24:41 --> 404 Page Not Found: /index
ERROR - 2022-03-28 23:26:14 --> 404 Page Not Found: /index
ERROR - 2022-03-28 23:28:07 --> 404 Page Not Found: /index
ERROR - 2022-03-28 23:31:10 --> 404 Page Not Found: /index
ERROR - 2022-03-28 23:35:02 --> 404 Page Not Found: /index
ERROR - 2022-03-28 23:37:04 --> 404 Page Not Found: /index
ERROR - 2022-03-28 23:37:47 --> 404 Page Not Found: /index
ERROR - 2022-03-28 23:39:43 --> 404 Page Not Found: /index
ERROR - 2022-03-28 23:42:48 --> 404 Page Not Found: /index
ERROR - 2022-03-28 23:42:49 --> 404 Page Not Found: /index
ERROR - 2022-03-28 23:47:32 --> 404 Page Not Found: /index
ERROR - 2022-03-28 23:53:10 --> 404 Page Not Found: /index
