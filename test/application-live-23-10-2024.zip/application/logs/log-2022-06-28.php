<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-06-28 00:03:51 --> 404 Page Not Found: /index
ERROR - 2022-06-28 05:36:12 --> 404 Page Not Found: /index
ERROR - 2022-06-28 06:34:05 --> 404 Page Not Found: /index
ERROR - 2022-06-28 07:03:22 --> 404 Page Not Found: /index
ERROR - 2022-06-28 07:55:06 --> 404 Page Not Found: /index
ERROR - 2022-06-28 07:56:30 --> 404 Page Not Found: /index
ERROR - 2022-06-28 07:56:30 --> 404 Page Not Found: /index
ERROR - 2022-06-28 07:56:39 --> 404 Page Not Found: /index
ERROR - 2022-06-28 07:58:28 --> 404 Page Not Found: /index
ERROR - 2022-06-28 07:58:28 --> 404 Page Not Found: /index
ERROR - 2022-06-28 07:58:39 --> 404 Page Not Found: /index
ERROR - 2022-06-28 07:58:41 --> 404 Page Not Found: /index
ERROR - 2022-06-28 07:58:53 --> 404 Page Not Found: /index
ERROR - 2022-06-28 07:58:53 --> 404 Page Not Found: /index
ERROR - 2022-06-28 07:58:58 --> 404 Page Not Found: /index
ERROR - 2022-06-28 07:58:59 --> 404 Page Not Found: /index
ERROR - 2022-06-28 07:59:03 --> 404 Page Not Found: /index
ERROR - 2022-06-28 07:59:03 --> 404 Page Not Found: /index
ERROR - 2022-06-28 07:59:04 --> 404 Page Not Found: /index
ERROR - 2022-06-28 07:59:04 --> 404 Page Not Found: /index
ERROR - 2022-06-28 07:59:13 --> 404 Page Not Found: /index
ERROR - 2022-06-28 09:11:02 --> 404 Page Not Found: /index
ERROR - 2022-06-28 09:11:03 --> 404 Page Not Found: /index
ERROR - 2022-06-28 09:11:06 --> 404 Page Not Found: /index
ERROR - 2022-06-28 09:11:07 --> 404 Page Not Found: /index
ERROR - 2022-06-28 09:30:56 --> 404 Page Not Found: /index
ERROR - 2022-06-28 09:31:02 --> 404 Page Not Found: /index
ERROR - 2022-06-28 09:44:42 --> 404 Page Not Found: /index
ERROR - 2022-06-28 09:47:31 --> 404 Page Not Found: /index
ERROR - 2022-06-28 09:47:32 --> 404 Page Not Found: /index
ERROR - 2022-06-28 09:54:58 --> 404 Page Not Found: /index
ERROR - 2022-06-28 09:55:17 --> 404 Page Not Found: /index
ERROR - 2022-06-28 09:55:59 --> 404 Page Not Found: /index
ERROR - 2022-06-28 09:56:25 --> 404 Page Not Found: /index
ERROR - 2022-06-28 09:58:56 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:00:57 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:01:08 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:01:12 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:02:30 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:03:49 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:06:21 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:06:38 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:06:41 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:07:01 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:07:10 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 118
ERROR - 2022-06-28 10:07:10 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:07:10 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 230
ERROR - 2022-06-28 10:07:10 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:07:10 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:07:34 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:07:39 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:08:02 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/kammavaari/public_html/application/modules/admin/models/Admin_search_model.php 199
ERROR - 2022-06-28 10:08:18 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 118
ERROR - 2022-06-28 10:08:18 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:08:18 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 230
ERROR - 2022-06-28 10:08:18 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:08:19 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 118
ERROR - 2022-06-28 10:08:19 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:08:19 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 230
ERROR - 2022-06-28 10:08:19 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:08:19 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 118
ERROR - 2022-06-28 10:08:19 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:08:19 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 230
ERROR - 2022-06-28 10:08:19 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:08:27 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:08:27 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 118
ERROR - 2022-06-28 10:08:27 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:08:27 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 230
ERROR - 2022-06-28 10:08:27 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:08:29 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 118
ERROR - 2022-06-28 10:08:29 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:08:29 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 230
ERROR - 2022-06-28 10:08:29 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:08:29 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 118
ERROR - 2022-06-28 10:08:29 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:08:29 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 230
ERROR - 2022-06-28 10:08:29 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:08:33 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:08:34 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:08:52 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 118
ERROR - 2022-06-28 10:08:52 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:08:52 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 230
ERROR - 2022-06-28 10:08:52 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:08:58 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 118
ERROR - 2022-06-28 10:08:58 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:08:58 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 230
ERROR - 2022-06-28 10:08:58 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:09:03 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 118
ERROR - 2022-06-28 10:09:03 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:09:03 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 230
ERROR - 2022-06-28 10:09:03 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:09:10 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 118
ERROR - 2022-06-28 10:09:10 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:09:10 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 230
ERROR - 2022-06-28 10:09:10 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:09:19 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 118
ERROR - 2022-06-28 10:09:19 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:09:19 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 230
ERROR - 2022-06-28 10:09:19 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:09:34 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 118
ERROR - 2022-06-28 10:09:34 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:09:34 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 230
ERROR - 2022-06-28 10:09:34 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:09:35 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/kammavaari/public_html/application/modules/admin/models/Admin_search_model.php 199
ERROR - 2022-06-28 10:09:36 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 118
ERROR - 2022-06-28 10:09:36 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:09:36 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 230
ERROR - 2022-06-28 10:09:36 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:09:36 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:09:36 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 118
ERROR - 2022-06-28 10:09:36 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:09:36 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 230
ERROR - 2022-06-28 10:09:36 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:09:46 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:09:53 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 118
ERROR - 2022-06-28 10:09:53 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:09:53 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 230
ERROR - 2022-06-28 10:09:53 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:10:06 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/kammavaari/public_html/application/modules/admin/models/Admin_search_model.php 199
ERROR - 2022-06-28 10:10:16 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 118
ERROR - 2022-06-28 10:10:16 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:10:16 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 230
ERROR - 2022-06-28 10:10:16 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:10:28 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 118
ERROR - 2022-06-28 10:10:28 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:10:28 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 230
ERROR - 2022-06-28 10:10:28 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:10:29 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:10:42 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 118
ERROR - 2022-06-28 10:10:42 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:10:42 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 230
ERROR - 2022-06-28 10:10:42 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:10:44 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 118
ERROR - 2022-06-28 10:10:44 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:10:44 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 230
ERROR - 2022-06-28 10:10:44 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:10:44 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 118
ERROR - 2022-06-28 10:10:44 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:10:44 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 230
ERROR - 2022-06-28 10:10:44 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:11:27 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 118
ERROR - 2022-06-28 10:11:27 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:11:27 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 230
ERROR - 2022-06-28 10:11:27 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:11:31 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:11:31 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 118
ERROR - 2022-06-28 10:11:31 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:11:31 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 230
ERROR - 2022-06-28 10:11:31 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:11:36 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 118
ERROR - 2022-06-28 10:11:36 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:11:36 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 230
ERROR - 2022-06-28 10:11:36 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:11:37 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 118
ERROR - 2022-06-28 10:11:37 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:11:37 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 230
ERROR - 2022-06-28 10:11:37 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:11:37 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:12:00 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:12:14 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:12:30 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:13:10 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/kammavaari/public_html/application/modules/admin/models/Admin_search_model.php 199
ERROR - 2022-06-28 10:13:16 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/kammavaari/public_html/application/modules/admin/models/Admin_search_model.php 199
ERROR - 2022-06-28 10:13:18 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/kammavaari/public_html/application/modules/admin/models/Admin_search_model.php 199
ERROR - 2022-06-28 10:13:27 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/kammavaari/public_html/application/modules/admin/models/Admin_search_model.php 199
ERROR - 2022-06-28 10:13:28 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 118
ERROR - 2022-06-28 10:13:28 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:13:28 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 230
ERROR - 2022-06-28 10:13:28 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:13:36 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 118
ERROR - 2022-06-28 10:13:36 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:13:36 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 230
ERROR - 2022-06-28 10:13:36 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:13:38 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/kammavaari/public_html/application/modules/admin/models/Admin_search_model.php 199
ERROR - 2022-06-28 10:13:42 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 118
ERROR - 2022-06-28 10:13:42 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:13:42 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 230
ERROR - 2022-06-28 10:13:42 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:13:54 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/kammavaari/public_html/application/modules/admin/models/Admin_search_model.php 199
ERROR - 2022-06-28 10:13:57 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/kammavaari/public_html/application/modules/admin/models/Admin_search_model.php 199
ERROR - 2022-06-28 10:14:01 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:14:02 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:14:03 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/kammavaari/public_html/application/modules/admin/models/Admin_search_model.php 199
ERROR - 2022-06-28 10:14:17 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:14:20 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/kammavaari/public_html/application/modules/admin/models/Admin_search_model.php 199
ERROR - 2022-06-28 10:14:30 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/kammavaari/public_html/application/modules/admin/models/Admin_search_model.php 199
ERROR - 2022-06-28 10:14:37 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 118
ERROR - 2022-06-28 10:14:37 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:14:37 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 230
ERROR - 2022-06-28 10:14:37 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:14:39 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 118
ERROR - 2022-06-28 10:14:39 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:14:39 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 230
ERROR - 2022-06-28 10:14:39 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:14:39 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 118
ERROR - 2022-06-28 10:14:39 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:14:39 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 230
ERROR - 2022-06-28 10:14:39 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:14:46 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 118
ERROR - 2022-06-28 10:14:46 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:14:46 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 230
ERROR - 2022-06-28 10:14:46 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:14:56 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/kammavaari/public_html/application/modules/admin/models/Admin_search_model.php 199
ERROR - 2022-06-28 10:15:04 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/kammavaari/public_html/application/modules/admin/models/Admin_search_model.php 199
ERROR - 2022-06-28 10:15:17 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:15:21 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/kammavaari/public_html/application/modules/admin/models/Admin_search_model.php 199
ERROR - 2022-06-28 10:15:47 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 118
ERROR - 2022-06-28 10:15:47 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:15:47 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 230
ERROR - 2022-06-28 10:15:47 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:15:58 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 118
ERROR - 2022-06-28 10:15:58 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:15:58 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 230
ERROR - 2022-06-28 10:15:58 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:16:04 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/kammavaari/public_html/application/modules/admin/models/Admin_search_model.php 199
ERROR - 2022-06-28 10:16:08 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/kammavaari/public_html/application/modules/admin/models/Admin_search_model.php 199
ERROR - 2022-06-28 10:16:10 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/kammavaari/public_html/application/modules/admin/models/Admin_search_model.php 199
ERROR - 2022-06-28 10:16:17 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/kammavaari/public_html/application/modules/admin/models/Admin_search_model.php 199
ERROR - 2022-06-28 10:16:21 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/kammavaari/public_html/application/modules/admin/models/Admin_search_model.php 199
ERROR - 2022-06-28 10:16:27 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 118
ERROR - 2022-06-28 10:16:27 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:16:27 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 230
ERROR - 2022-06-28 10:16:27 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:16:35 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:16:36 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/kammavaari/public_html/application/modules/admin/models/Admin_search_model.php 199
ERROR - 2022-06-28 10:16:43 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:16:48 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:16:49 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 118
ERROR - 2022-06-28 10:16:49 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:16:49 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 230
ERROR - 2022-06-28 10:16:49 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:16:50 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 118
ERROR - 2022-06-28 10:16:50 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:16:50 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 230
ERROR - 2022-06-28 10:16:50 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:16:50 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 118
ERROR - 2022-06-28 10:16:50 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:16:50 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 230
ERROR - 2022-06-28 10:16:50 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:17:00 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:17:11 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 118
ERROR - 2022-06-28 10:17:11 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:17:11 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 230
ERROR - 2022-06-28 10:17:11 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:17:14 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 118
ERROR - 2022-06-28 10:17:14 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:17:14 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 230
ERROR - 2022-06-28 10:17:14 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:17:16 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 118
ERROR - 2022-06-28 10:17:16 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:17:16 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 230
ERROR - 2022-06-28 10:17:16 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:17:16 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 118
ERROR - 2022-06-28 10:17:16 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:17:16 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 230
ERROR - 2022-06-28 10:17:16 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:17:24 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:17:32 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:17:36 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:17:48 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/kammavaari/public_html/application/modules/admin/models/Admin_search_model.php 199
ERROR - 2022-06-28 10:17:55 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:18:12 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 118
ERROR - 2022-06-28 10:18:12 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:18:12 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 230
ERROR - 2022-06-28 10:18:12 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:18:14 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 118
ERROR - 2022-06-28 10:18:14 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:18:14 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 230
ERROR - 2022-06-28 10:18:14 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:18:14 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 118
ERROR - 2022-06-28 10:18:14 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:18:14 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 230
ERROR - 2022-06-28 10:18:14 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:18:29 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/kammavaari/public_html/application/modules/admin/models/Admin_search_model.php 199
ERROR - 2022-06-28 10:18:34 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 118
ERROR - 2022-06-28 10:18:34 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:18:34 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 230
ERROR - 2022-06-28 10:18:34 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:18:38 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 118
ERROR - 2022-06-28 10:18:38 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:18:38 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 230
ERROR - 2022-06-28 10:18:38 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:18:43 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 118
ERROR - 2022-06-28 10:18:43 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:18:43 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 230
ERROR - 2022-06-28 10:18:43 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:18:44 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/kammavaari/public_html/application/modules/admin/models/Admin_search_model.php 199
ERROR - 2022-06-28 10:18:44 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 118
ERROR - 2022-06-28 10:18:44 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:18:44 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 230
ERROR - 2022-06-28 10:18:44 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:18:44 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 118
ERROR - 2022-06-28 10:18:44 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:18:44 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 230
ERROR - 2022-06-28 10:18:44 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:18:52 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/kammavaari/public_html/application/modules/admin/models/Admin_search_model.php 199
ERROR - 2022-06-28 10:19:06 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/kammavaari/public_html/application/modules/admin/models/Admin_search_model.php 199
ERROR - 2022-06-28 10:19:13 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 118
ERROR - 2022-06-28 10:19:13 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:19:13 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 230
ERROR - 2022-06-28 10:19:13 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:19:14 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 118
ERROR - 2022-06-28 10:19:14 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:19:14 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 230
ERROR - 2022-06-28 10:19:14 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:19:14 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 118
ERROR - 2022-06-28 10:19:14 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:19:14 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 230
ERROR - 2022-06-28 10:19:14 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:19:19 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/kammavaari/public_html/application/modules/admin/models/Admin_search_model.php 199
ERROR - 2022-06-28 10:19:25 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 118
ERROR - 2022-06-28 10:19:25 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:19:25 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 230
ERROR - 2022-06-28 10:19:25 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:19:27 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:19:36 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:19:36 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/kammavaari/public_html/application/modules/admin/models/Admin_search_model.php 199
ERROR - 2022-06-28 10:20:06 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 118
ERROR - 2022-06-28 10:20:06 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:20:06 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 230
ERROR - 2022-06-28 10:20:06 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:20:07 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/kammavaari/public_html/application/modules/admin/models/Admin_search_model.php 199
ERROR - 2022-06-28 10:20:46 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:21:02 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:21:03 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:21:04 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/kammavaari/public_html/application/modules/admin/models/Admin_search_model.php 199
ERROR - 2022-06-28 10:21:23 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 118
ERROR - 2022-06-28 10:21:23 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:21:23 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 230
ERROR - 2022-06-28 10:21:23 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:21:42 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 118
ERROR - 2022-06-28 10:21:42 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:21:42 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 230
ERROR - 2022-06-28 10:21:42 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:21:44 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 118
ERROR - 2022-06-28 10:21:44 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:21:44 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 230
ERROR - 2022-06-28 10:21:44 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:21:44 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 118
ERROR - 2022-06-28 10:21:44 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:21:44 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 230
ERROR - 2022-06-28 10:21:44 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:21:58 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 118
ERROR - 2022-06-28 10:21:58 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:21:58 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 230
ERROR - 2022-06-28 10:21:58 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:22:57 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:23:07 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:23:12 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:23:39 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/kammavaari/public_html/application/modules/admin/models/Admin_search_model.php 199
ERROR - 2022-06-28 10:23:42 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/kammavaari/public_html/application/modules/admin/models/Admin_search_model.php 199
ERROR - 2022-06-28 10:23:52 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 118
ERROR - 2022-06-28 10:23:52 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:23:52 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 230
ERROR - 2022-06-28 10:23:52 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:24:09 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:24:12 --> Severity: error --> Exception: array_key_exists(): Argument #2 ($array) must be of type array, null given /home/kammavaari/public_html/application/modules/dashboard/models/My_account_model.php 687
ERROR - 2022-06-28 10:24:17 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/kammavaari/public_html/application/modules/admin/models/Admin_search_model.php 199
ERROR - 2022-06-28 10:24:19 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:24:26 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:24:31 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:24:36 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:24:39 --> Severity: error --> Exception: array_key_exists(): Argument #2 ($array) must be of type array, null given /home/kammavaari/public_html/application/modules/dashboard/models/My_account_model.php 687
ERROR - 2022-06-28 10:24:42 --> Severity: error --> Exception: array_key_exists(): Argument #2 ($array) must be of type array, null given /home/kammavaari/public_html/application/modules/dashboard/models/My_account_model.php 687
ERROR - 2022-06-28 10:24:58 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:25:06 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/kammavaari/public_html/application/modules/admin/models/Admin_search_model.php 199
ERROR - 2022-06-28 10:25:10 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:25:15 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 118
ERROR - 2022-06-28 10:25:15 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:25:15 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 230
ERROR - 2022-06-28 10:25:15 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:25:18 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:25:24 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:25:38 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:25:43 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:25:51 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:25:58 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:26:07 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 118
ERROR - 2022-06-28 10:26:07 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:26:07 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 230
ERROR - 2022-06-28 10:26:07 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:26:09 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 118
ERROR - 2022-06-28 10:26:09 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:26:09 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 230
ERROR - 2022-06-28 10:26:09 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:26:09 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 118
ERROR - 2022-06-28 10:26:09 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:26:09 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 230
ERROR - 2022-06-28 10:26:09 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:26:16 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/kammavaari/public_html/application/modules/admin/models/Admin_search_model.php 199
ERROR - 2022-06-28 10:26:17 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 118
ERROR - 2022-06-28 10:26:17 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:26:17 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 230
ERROR - 2022-06-28 10:26:17 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:26:18 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 118
ERROR - 2022-06-28 10:26:18 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:26:18 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 230
ERROR - 2022-06-28 10:26:18 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:26:18 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 118
ERROR - 2022-06-28 10:26:18 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:26:18 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 230
ERROR - 2022-06-28 10:26:18 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:26:25 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 118
ERROR - 2022-06-28 10:26:25 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:26:25 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 230
ERROR - 2022-06-28 10:26:25 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:26:27 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 118
ERROR - 2022-06-28 10:26:27 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:26:27 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 230
ERROR - 2022-06-28 10:26:27 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:26:27 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 118
ERROR - 2022-06-28 10:26:27 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:26:27 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 230
ERROR - 2022-06-28 10:26:27 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:26:28 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:26:34 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:26:43 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 118
ERROR - 2022-06-28 10:26:43 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:26:43 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 230
ERROR - 2022-06-28 10:26:43 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:26:43 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/kammavaari/public_html/application/modules/admin/models/Admin_search_model.php 199
ERROR - 2022-06-28 10:26:55 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/kammavaari/public_html/application/modules/admin/models/Admin_search_model.php 199
ERROR - 2022-06-28 10:26:57 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/kammavaari/public_html/application/modules/admin/models/Admin_search_model.php 199
ERROR - 2022-06-28 10:27:01 --> Severity: error --> Exception: array_key_exists(): Argument #2 ($array) must be of type array, null given /home/kammavaari/public_html/application/modules/dashboard/models/My_account_model.php 687
ERROR - 2022-06-28 10:27:05 --> Severity: error --> Exception: array_key_exists(): Argument #2 ($array) must be of type array, null given /home/kammavaari/public_html/application/modules/dashboard/models/My_account_model.php 687
ERROR - 2022-06-28 10:27:07 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/kammavaari/public_html/application/modules/admin/models/Admin_search_model.php 199
ERROR - 2022-06-28 10:27:09 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:27:10 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/kammavaari/public_html/application/modules/admin/models/Admin_search_model.php 199
ERROR - 2022-06-28 10:27:10 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/kammavaari/public_html/application/modules/admin/models/Admin_search_model.php 199
ERROR - 2022-06-28 10:27:11 --> Severity: error --> Exception: array_key_exists(): Argument #2 ($array) must be of type array, null given /home/kammavaari/public_html/application/modules/dashboard/models/My_account_model.php 687
ERROR - 2022-06-28 10:27:20 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/kammavaari/public_html/application/modules/admin/models/Admin_search_model.php 199
ERROR - 2022-06-28 10:27:21 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/kammavaari/public_html/application/modules/admin/models/Admin_search_model.php 199
ERROR - 2022-06-28 10:27:30 --> Severity: error --> Exception: array_key_exists(): Argument #2 ($array) must be of type array, null given /home/kammavaari/public_html/application/modules/dashboard/models/My_account_model.php 687
ERROR - 2022-06-28 10:27:31 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:27:51 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/kammavaari/public_html/application/modules/admin/models/Admin_search_model.php 199
ERROR - 2022-06-28 10:27:55 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/kammavaari/public_html/application/modules/admin/models/Admin_search_model.php 199
ERROR - 2022-06-28 10:28:02 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:28:02 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/kammavaari/public_html/application/modules/admin/models/Admin_search_model.php 199
ERROR - 2022-06-28 10:28:19 --> Severity: error --> Exception: array_key_exists(): Argument #2 ($array) must be of type array, null given /home/kammavaari/public_html/application/modules/dashboard/models/My_account_model.php 687
ERROR - 2022-06-28 10:28:19 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/kammavaari/public_html/application/modules/admin/models/Admin_search_model.php 199
ERROR - 2022-06-28 10:28:25 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/kammavaari/public_html/application/modules/admin/models/Admin_search_model.php 199
ERROR - 2022-06-28 10:28:48 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/kammavaari/public_html/application/modules/admin/models/Admin_search_model.php 199
ERROR - 2022-06-28 10:28:49 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/kammavaari/public_html/application/modules/admin/models/Admin_search_model.php 199
ERROR - 2022-06-28 10:28:52 --> Severity: error --> Exception: count(): Argument #1 ($value) must be of type Countable|array, null given /home/kammavaari/public_html/application/modules/admin/models/Admin_search_model.php 199
ERROR - 2022-06-28 10:29:09 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 118
ERROR - 2022-06-28 10:29:09 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:29:09 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 230
ERROR - 2022-06-28 10:29:09 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:29:16 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 118
ERROR - 2022-06-28 10:29:16 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:29:16 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 230
ERROR - 2022-06-28 10:29:16 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:29:18 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 118
ERROR - 2022-06-28 10:29:18 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:29:18 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 230
ERROR - 2022-06-28 10:29:18 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:29:18 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 118
ERROR - 2022-06-28 10:29:18 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:29:18 --> Severity: 8192 --> Required parameter $limit follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 230
ERROR - 2022-06-28 10:29:18 --> Severity: 8192 --> Required parameter $offset follows optional parameter $fortyeighthours /home/kammavaari/public_html/application/modules/admin/models/Employee_model.php 0
ERROR - 2022-06-28 10:29:25 --> Severity: error --> Exception: array_key_exists(): Argument #2 ($array) must be of type array, null given /home/kammavaari/public_html/application/modules/dashboard/models/My_account_model.php 687
ERROR - 2022-06-28 10:29:56 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:30:56 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:31:31 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:32:06 --> To Id is not available for User - 4945
ERROR - 2022-06-28 10:32:07 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:32:08 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:34:07 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:34:25 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:38:21 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:38:47 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:38:53 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:39:21 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:39:40 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:39:43 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:39:49 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:39:54 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:39:56 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:39:59 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:41:18 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:41:36 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:41:37 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:41:40 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:41:43 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:41:57 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:42:04 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:42:15 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:42:20 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:42:26 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:42:29 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:42:39 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:42:53 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:43:24 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:43:56 --> To Id is not available for User - 1793
ERROR - 2022-06-28 10:43:57 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:44:13 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:45:26 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:45:28 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:46:29 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:47:57 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:47:57 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:48:00 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:48:04 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:48:11 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:48:41 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:49:33 --> To Id is not available for User - 1499
ERROR - 2022-06-28 10:49:34 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:49:40 --> To Id is not available for User - 1540
ERROR - 2022-06-28 10:49:41 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:49:44 --> To Id is not available for User - 1555
ERROR - 2022-06-28 10:49:45 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:49:48 --> To Id is not available for User - 2217
ERROR - 2022-06-28 10:49:49 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:50:04 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:50:23 --> To Id is not available for User - 2306
ERROR - 2022-06-28 10:50:24 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:50:27 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:51:26 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:51:43 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:52:00 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:52:28 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:52:32 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:52:49 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:53:15 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:53:25 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:53:31 --> To Id is not available for User - 476
ERROR - 2022-06-28 10:53:36 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:53:41 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:54:04 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:54:08 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:54:17 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:54:23 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:54:34 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:54:55 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:55:00 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:55:11 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:56:32 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:56:49 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:58:18 --> 404 Page Not Found: /index
ERROR - 2022-06-28 10:59:06 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:01:05 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:01:21 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:01:39 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:04:32 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:05:52 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:05:56 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:06:01 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:06:13 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:06:21 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:06:28 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:07:09 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:07:11 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:07:18 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:07:55 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:08:00 --> To Id is not available for User - �
ERROR - 2022-06-28 11:08:01 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:08:07 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:08:20 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:08:31 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:08:42 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:09:30 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:09:50 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:09:53 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:10:48 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:11:03 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:11:33 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:11:46 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:11:56 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:12:26 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:13:54 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:14:02 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:14:40 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:14:49 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:14:50 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:15:12 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:15:19 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:15:44 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:16:06 --> To Id is not available for User - 401
ERROR - 2022-06-28 11:16:10 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:16:13 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:16:29 --> To Id is not available for User - 401
ERROR - 2022-06-28 11:16:47 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:17:18 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:18:17 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:18:41 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:19:16 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:19:31 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:19:52 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:19:54 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:20:04 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:20:09 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:20:16 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:20:21 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:20:25 --> To Id is not available for User - 401
ERROR - 2022-06-28 11:20:38 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:20:45 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:20:56 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:20:59 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:21:12 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:21:19 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:21:45 --> To Id is not available for User - 401
ERROR - 2022-06-28 11:22:07 --> To Id is not available for User - 401
ERROR - 2022-06-28 11:22:52 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:24:44 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:25:52 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:26:20 --> 404 Page Not Found: ../modules/home/controllers/Home/dashboard
ERROR - 2022-06-28 11:26:21 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:27:04 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:27:26 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:27:37 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:28:12 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:28:39 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:29:03 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:29:08 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:29:09 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:29:22 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:29:31 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:29:32 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:30:04 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:30:13 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:30:56 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:31:34 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:33:22 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:33:23 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:33:23 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:33:24 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:33:25 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:33:26 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:33:27 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:33:29 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:33:30 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:33:49 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:33:53 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:33:55 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:34:02 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:34:05 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:34:19 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:34:47 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:38:02 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:38:05 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:38:57 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:39:14 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:41:14 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:42:01 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:43:17 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:43:21 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:43:47 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:43:51 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:43:56 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:44:01 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:44:13 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:44:33 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:44:52 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:45:09 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:46:16 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:47:42 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:47:46 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:47:49 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:47:52 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:47:56 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:49:10 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:49:39 --> To Id is not available for User - 401
ERROR - 2022-06-28 11:52:24 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:52:53 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:54:00 --> To Id is not available for User - 401
ERROR - 2022-06-28 11:55:41 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:56:09 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:56:16 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:56:21 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:56:30 --> To Id is not available for User - 401
ERROR - 2022-06-28 11:56:32 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:56:36 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:57:05 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:57:08 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:57:19 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:57:58 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:58:14 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:58:16 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:58:30 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:58:38 --> 404 Page Not Found: /index
ERROR - 2022-06-28 11:58:43 --> To Id is not available for User - 401
ERROR - 2022-06-28 11:59:16 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:00:11 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:00:13 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:01:23 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:01:32 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:01:43 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:02:03 --> To Id is not available for User - 401
ERROR - 2022-06-28 12:02:33 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:02:37 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:03:02 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:03:49 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:03:51 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:04:17 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:04:31 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:04:44 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:05:16 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:05:24 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:05:27 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:05:41 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:06:19 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:06:30 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:07:06 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:07:27 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:07:30 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:08:01 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:08:02 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:08:15 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:08:22 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:08:40 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:08:44 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:09:00 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:09:06 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:09:10 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:09:14 --> To Id is not available for User - 401
ERROR - 2022-06-28 12:09:28 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:09:46 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:09:46 --> To Id is not available for User - 401
ERROR - 2022-06-28 12:09:49 --> To Id is not available for User - 401
ERROR - 2022-06-28 12:09:54 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:10:00 --> To Id is not available for User - 401
ERROR - 2022-06-28 12:10:06 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:10:20 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:10:25 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:10:26 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:10:41 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:10:44 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:10:57 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:11:00 --> To Id is not available for User - 401
ERROR - 2022-06-28 12:11:22 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:11:39 --> To Id is not available for User - 401
ERROR - 2022-06-28 12:11:43 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:13:10 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:13:28 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:13:40 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:13:59 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:14:05 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:14:07 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:14:08 --> To Id is not available for User - 401
ERROR - 2022-06-28 12:14:53 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:17:50 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:18:53 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:19:03 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:19:10 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:19:13 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:19:16 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:19:22 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:20:38 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:24:04 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:24:39 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:25:36 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:25:48 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:26:38 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:26:44 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:27:50 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:28:35 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:31:14 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:31:36 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:31:40 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:32:20 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:32:25 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:32:28 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:33:35 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-06-28 12:33:38 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:33:45 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:34:47 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:34:58 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:35:17 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:35:43 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:35:52 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:35:58 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:36:04 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:36:14 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:36:22 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:38:28 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:38:52 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:38:55 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:39:09 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:39:55 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:40:24 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:40:50 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:41:10 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:41:24 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:41:35 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:41:48 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:42:05 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:42:49 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:44:17 --> Severity: error --> Exception: SMTP Error: Could not authenticate. /home/kammavaari/public_html/application/third_party/phpmailer/src/PHPMailer.php 2154
ERROR - 2022-06-28 12:44:23 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:44:33 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:45:30 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:45:41 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:45:58 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:46:00 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:46:16 --> Severity: error --> Exception: SMTP Error: Could not authenticate. /home/kammavaari/public_html/application/third_party/phpmailer/src/PHPMailer.php 2154
ERROR - 2022-06-28 12:46:59 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:47:06 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:47:12 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:47:23 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:47:47 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:48:21 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:48:56 --> Severity: error --> Exception: SMTP Error: Could not authenticate. /home/kammavaari/public_html/application/third_party/phpmailer/src/PHPMailer.php 2154
ERROR - 2022-06-28 12:49:09 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:49:42 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:50:12 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:51:48 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:51:51 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:52:12 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:52:17 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:52:26 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:52:42 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:52:58 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:53:47 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:53:59 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:54:00 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:54:10 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:54:33 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:55:11 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:55:12 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:55:16 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:55:34 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:55:35 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:55:52 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:55:56 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:56:28 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:56:37 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:58:39 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:58:41 --> 404 Page Not Found: /index
ERROR - 2022-06-28 12:59:34 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:00:01 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:00:33 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:00:50 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:00:55 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:01:01 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:01:20 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:01:44 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:01:48 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:01:50 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:01:54 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:02:03 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:02:19 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:02:21 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:02:24 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:03:04 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:03:31 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:04:05 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:05:34 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:05:59 --> To Id is not available for User - 4832
ERROR - 2022-06-28 13:06:05 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:06:28 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:06:29 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:06:41 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:07:09 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:07:14 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:07:34 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:08:07 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:08:19 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:08:33 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:08:52 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:08:58 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:09:05 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:09:32 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:09:49 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:10:38 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:11:03 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:11:57 --> Severity: error --> Exception: SMTP Error: Could not authenticate. /home/kammavaari/public_html/application/third_party/phpmailer/src/PHPMailer.php 2154
ERROR - 2022-06-28 13:12:09 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:12:10 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:12:16 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:12:36 --> Severity: error --> Exception: SMTP Error: Could not authenticate. /home/kammavaari/public_html/application/third_party/phpmailer/src/PHPMailer.php 2154
ERROR - 2022-06-28 13:13:00 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:13:07 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:13:25 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:13:32 --> Severity: error --> Exception: SMTP Error: Could not authenticate. /home/kammavaari/public_html/application/third_party/phpmailer/src/PHPMailer.php 2154
ERROR - 2022-06-28 13:13:41 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:14:05 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:14:09 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:15:34 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:15:55 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:16:21 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:17:31 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:21:29 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:22:09 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:22:30 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:22:42 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:22:48 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:23:49 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:23:51 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:24:45 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:24:50 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:24:51 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:25:45 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:25:56 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:27:59 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:28:01 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:28:03 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:28:04 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:28:07 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:28:11 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:28:13 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:28:38 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:28:43 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:29:25 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:29:36 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:29:49 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:30:16 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:30:55 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:31:11 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:31:18 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:31:42 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:33:34 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:33:36 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:34:24 --> Query error: Expression #1 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'kammavaari_marriage.v.kv_msi_id' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `v`.*, `p`.`gender`, `p`.`id`, `p`.`status`, `p`.`age`, `p`.`living_in`, `p`.`profile_id`, `p`.`first_name`, `last_name`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`
FROM `kv_mysideinterests` as `v`
LEFT JOIN `tbl_primary_info` as `p` ON `p`.`id`=`v`.`kv_msi_interested_on`
LEFT JOIN `tbl_religion_info` as `r` ON `v`.`kv_msi_interested_on`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `v`.`kv_msi_interested_on`=`e`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`MS_id`
INNER JOIN `ms_profilesetting` as `s` ON `p`.`id`=`s`.`ms_id`
WHERE `p`.`status` = 1
AND `v`.`kv_msi_profilefkid` = '3417'
AND `u`.`ismain` = 1
AND `kv_msi_onresstatus` = 'oneside_accepted'
GROUP BY `v`.`kv_msi_interested_on`
ORDER BY `v`.`kv_msi_created_date` DESC
ERROR - 2022-06-28 13:34:30 --> Query error: In aggregated query without GROUP BY, expression #2 of SELECT list contains nonaggregated column 'kammavaari_marriage.tbl_profilebattery.photo'; this is incompatible with sql_mode=only_full_group_by - Invalid query: select SUM(IFNULL(`basicdetails`, 0) + IFNULL(`religion`, 0) + IFNULL(`edu_prof`, 0) + IFNULL(`parents`, 0) + IFNULL(`Siblings`, 0) + IFNULL(`photo`, 0)) as total,photo,basicdetails,religion,edu_prof,parents,Siblings from tbl_profilebattery where user_id='4251'
ERROR - 2022-06-28 13:34:40 --> Query error: Expression #1 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'kammavaari_marriage.v.kv_msi_id' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `v`.*, `p`.`gender`, `p`.`id`, `p`.`status`, `p`.`age`, `p`.`living_in`, `p`.`profile_id`, `p`.`first_name`, `last_name`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`
FROM `kv_mysideinterests` as `v`
LEFT JOIN `tbl_primary_info` as `p` ON `p`.`id`=`v`.`kv_msi_interested_on`
LEFT JOIN `tbl_religion_info` as `r` ON `v`.`kv_msi_interested_on`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `v`.`kv_msi_interested_on`=`e`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`MS_id`
INNER JOIN `ms_profilesetting` as `s` ON `p`.`id`=`s`.`ms_id`
WHERE `p`.`status` = 1
AND `v`.`kv_msi_profilefkid` = '3417'
AND `u`.`ismain` = 1
AND `kv_msi_onresstatus` = 'oneside_accepted'
GROUP BY `v`.`kv_msi_interested_on`
ORDER BY `v`.`kv_msi_created_date` DESC
ERROR - 2022-06-28 13:34:43 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:34:47 --> Query error: Expression #1 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'kammavaari_marriage.v.kv_msi_id' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `v`.*, `p`.`gender`, `p`.`id`, `p`.`status`, `p`.`age`, `p`.`living_in`, `p`.`profile_id`, `p`.`first_name`, `last_name`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`
FROM `kv_mysideinterests` as `v`
LEFT JOIN `tbl_primary_info` as `p` ON `p`.`id`=`v`.`kv_msi_interested_on`
LEFT JOIN `tbl_religion_info` as `r` ON `v`.`kv_msi_interested_on`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `v`.`kv_msi_interested_on`=`e`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`MS_id`
INNER JOIN `ms_profilesetting` as `s` ON `p`.`id`=`s`.`ms_id`
WHERE `p`.`status` = 1
AND `v`.`kv_msi_profilefkid` = '3417'
AND `u`.`ismain` = 1
AND `kv_msi_onresstatus` = 'oneside_accepted'
GROUP BY `v`.`kv_msi_interested_on`
ORDER BY `v`.`kv_msi_created_date` DESC
ERROR - 2022-06-28 13:34:48 --> Query error: Expression #12 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'kammavaari_marriage.r.height' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `p`.`first_name`, `p`.`last_name`, `p`.`gender`, `p`.`id`, `p`.`status`, DATE_FORMAT(FROM_DAYS(DATEDIFF(now(), p.dob)), '%Y')+0 as cur_age, `p`.`living_in`, `p`.`profile_id`, `p`.`date`, `p`.`month`, `p`.`year`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `r`.`time_of_birth`, `r`.`place_of_birth`, `r`.`gothram`, `r`.`star`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `e`.`country`, `pa`.`fathers_father_district`, `pa`.`mothers_father_district`, `pa`.`father_mobile`, `pa`.`mother_mobile`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `payment_status`, `elite`, `profileowner`, `ms_usertype`, `pr`.`property_value`, `pr`.`property_type`, `pr`.`property_Desc`
FROM `tbl_primary_info` as `p`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `tbl_parents_info` as `pa` ON `p`.`id`=`pa`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`MS_id`
LEFT JOIN `ms_profilesetting` as `mprosetting` ON `p`.`id`=`mprosetting`.`MS_id`
LEFT JOIN `ms_property_info` as `pr` ON `p`.`id`=`pr`.`ms_id`
WHERE `p`.`gender` = 'female'
AND `r`.`height_cm` >= '152'
AND `r`.`height_cm` <= '160'
AND (YEAR(CURDATE()) - CAST(p.year AS UNSIGNED)) >= '18'
AND (YEAR(CURDATE()) - CAST(p.year AS UNSIGNED)) <= '27'
AND `r`.`marital_status` IN('never_married')
AND `r`.`religion` IN('Hindu')
AND `r`.`mother_tounge` IN('Telugu')
AND `r`.`caste` IN('Kamma')
AND `e`.`country` IN('India')
AND CAST(pr.property_value AS DECIMAL(8, 2)) >= '10'
AND `p`.`status` IN('1')
AND `u`.`ismain` = 1 AND `u`.`isactive` = 1
AND `mprosetting`.`profileowner` >0
AND `mprosetting`.`ms_usertype` != 'elite'
AND `mprosetting`.`ms_usertype` IN('regular', 'confidential', 'superconfidential', 'elite')
AND `p`.`status` = 1
GROUP BY `p`.`id`
ORDER BY `p`.`registered_on` DESC
ERROR - 2022-06-28 13:34:49 --> Query error: Expression #1 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'kammavaari_marriage.v.kv_msi_id' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `v`.*, `p`.`gender`, `p`.`id`, `p`.`status`, `p`.`age`, `p`.`living_in`, `p`.`profile_id`, `p`.`first_name`, `last_name`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`
FROM `kv_mysideinterests` as `v`
LEFT JOIN `tbl_primary_info` as `p` ON `p`.`id`=`v`.`kv_msi_interested_on`
LEFT JOIN `tbl_religion_info` as `r` ON `v`.`kv_msi_interested_on`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `v`.`kv_msi_interested_on`=`e`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`MS_id`
INNER JOIN `ms_profilesetting` as `s` ON `p`.`id`=`s`.`ms_id`
WHERE `p`.`status` = 1
AND `v`.`kv_msi_profilefkid` = '3417'
AND `u`.`ismain` = 1
AND `kv_msi_onresstatus` = 'oneside_accepted'
GROUP BY `v`.`kv_msi_interested_on`
ORDER BY `v`.`kv_msi_created_date` DESC
ERROR - 2022-06-28 13:34:54 --> Query error: Expression #12 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'kammavaari_marriage.r.height' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `p`.`first_name`, `p`.`last_name`, `p`.`gender`, `p`.`id`, `p`.`status`, DATE_FORMAT(FROM_DAYS(DATEDIFF(now(), p.dob)), '%Y')+0 as cur_age, `p`.`living_in`, `p`.`profile_id`, `p`.`date`, `p`.`month`, `p`.`year`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `r`.`time_of_birth`, `r`.`place_of_birth`, `r`.`gothram`, `r`.`star`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `e`.`country`, `pa`.`fathers_father_district`, `pa`.`mothers_father_district`, `pa`.`father_mobile`, `pa`.`mother_mobile`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `payment_status`, `elite`, `profileowner`, `ms_usertype`, `pr`.`property_value`, `pr`.`property_type`, `pr`.`property_Desc`
FROM `tbl_primary_info` as `p`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `tbl_parents_info` as `pa` ON `p`.`id`=`pa`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`MS_id`
LEFT JOIN `ms_profilesetting` as `mprosetting` ON `p`.`id`=`mprosetting`.`MS_id`
LEFT JOIN `ms_property_info` as `pr` ON `p`.`id`=`pr`.`ms_id`
WHERE `p`.`gender` = 'female'
AND `r`.`height_cm` >= '152'
AND `r`.`height_cm` <= '160'
AND (YEAR(CURDATE()) - CAST(p.year AS UNSIGNED)) >= '18'
AND (YEAR(CURDATE()) - CAST(p.year AS UNSIGNED)) <= '27'
AND `r`.`marital_status` IN('never_married')
AND `r`.`religion` IN('Hindu')
AND `r`.`mother_tounge` IN('Telugu')
AND `r`.`caste` IN('Kamma')
AND `e`.`country` IN('India')
AND CAST(pr.property_value AS DECIMAL(8, 2)) >= '10'
AND `p`.`status` IN('1')
AND `u`.`ismain` = 1 AND `u`.`isactive` = 1
AND `mprosetting`.`profileowner` >0
AND `mprosetting`.`ms_usertype` != 'elite'
AND `mprosetting`.`ms_usertype` IN('regular', 'confidential', 'superconfidential', 'elite')
AND `p`.`status` = 1
GROUP BY `p`.`id`
ORDER BY `p`.`registered_on` DESC
ERROR - 2022-06-28 13:35:02 --> Query error: Expression #12 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'kammavaari_marriage.r.height' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `p`.`first_name`, `p`.`last_name`, `p`.`gender`, `p`.`id`, `p`.`status`, DATE_FORMAT(FROM_DAYS(DATEDIFF(now(), p.dob)), '%Y')+0 as cur_age, `p`.`living_in`, `p`.`profile_id`, `p`.`date`, `p`.`month`, `p`.`year`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `r`.`time_of_birth`, `r`.`place_of_birth`, `r`.`gothram`, `r`.`star`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `e`.`country`, `pa`.`fathers_father_district`, `pa`.`mothers_father_district`, `pa`.`father_mobile`, `pa`.`mother_mobile`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `payment_status`, `elite`, `profileowner`, `ms_usertype`, `pr`.`property_value`, `pr`.`property_type`, `pr`.`property_Desc`
FROM `tbl_primary_info` as `p`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `tbl_parents_info` as `pa` ON `p`.`id`=`pa`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`MS_id`
LEFT JOIN `ms_profilesetting` as `mprosetting` ON `p`.`id`=`mprosetting`.`MS_id`
LEFT JOIN `ms_property_info` as `pr` ON `p`.`id`=`pr`.`ms_id`
WHERE `p`.`gender` = 'female'
AND `r`.`height_cm` >= '152'
AND `r`.`height_cm` <= '160'
AND (YEAR(CURDATE()) - CAST(p.year AS UNSIGNED)) >= '18'
AND (YEAR(CURDATE()) - CAST(p.year AS UNSIGNED)) <= '27'
AND `r`.`marital_status` IN('never_married')
AND `r`.`religion` IN('Hindu')
AND `r`.`mother_tounge` IN('Telugu')
AND `r`.`caste` IN('Kamma')
AND `e`.`country` IN('India')
AND CAST(pr.property_value AS DECIMAL(8, 2)) >= '10'
AND `p`.`status` IN('1')
AND `u`.`ismain` = 1 AND `u`.`isactive` = 1
AND `mprosetting`.`profileowner` >0
AND `mprosetting`.`ms_usertype` != 'elite'
AND `mprosetting`.`ms_usertype` IN('regular', 'confidential', 'superconfidential', 'elite')
AND `p`.`status` = 1
GROUP BY `p`.`id`
ORDER BY `p`.`registered_on` DESC
ERROR - 2022-06-28 13:35:55 --> Query error: Expression #12 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'kammavaari_marriage.r.height' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `p`.`first_name`, `p`.`last_name`, `p`.`gender`, `p`.`id`, `p`.`status`, DATE_FORMAT(FROM_DAYS(DATEDIFF(now(), p.dob)), '%Y')+0 as cur_age, `p`.`living_in`, `p`.`profile_id`, `p`.`date`, `p`.`month`, `p`.`year`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `r`.`time_of_birth`, `r`.`place_of_birth`, `r`.`gothram`, `r`.`star`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `e`.`country`, `pa`.`fathers_father_district`, `pa`.`mothers_father_district`, `pa`.`father_mobile`, `pa`.`mother_mobile`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `payment_status`, `elite`, `profileowner`, `ms_usertype`, `pr`.`property_value`, `pr`.`property_type`, `pr`.`property_Desc`
FROM `tbl_primary_info` as `p`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `tbl_parents_info` as `pa` ON `p`.`id`=`pa`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`MS_id`
LEFT JOIN `ms_profilesetting` as `mprosetting` ON `p`.`id`=`mprosetting`.`MS_id`
LEFT JOIN `ms_property_info` as `pr` ON `p`.`id`=`pr`.`ms_id`
WHERE `p`.`gender` = 'male'
AND `r`.`height_cm` >= '152'
AND `r`.`height_cm` <= '160'
AND (YEAR(CURDATE()) - CAST(p.year AS UNSIGNED)) >= '22'
AND (YEAR(CURDATE()) - CAST(p.year AS UNSIGNED)) <= '27'
AND `r`.`marital_status` IN('never_married')
AND `r`.`religion` IN('Hindu')
AND `r`.`mother_tounge` IN('Telugu')
AND `r`.`caste` IN('Kamma')
AND `e`.`country` IN('USA')
AND CAST(pr.property_value AS DECIMAL(8, 2)) >= '10'
AND `p`.`status` IN('1')
AND `u`.`ismain` = 1 AND `u`.`isactive` = 1
AND `mprosetting`.`profileowner` >0
AND `mprosetting`.`ms_usertype` != 'elite'
AND `mprosetting`.`ms_usertype` IN('regular', 'confidential', 'superconfidential', 'elite')
AND `p`.`status` = 1
GROUP BY `p`.`id`
ORDER BY `p`.`registered_on` DESC
ERROR - 2022-06-28 13:36:19 --> To Id is not available for User - 401
ERROR - 2022-06-28 13:36:21 --> Query error: Expression #12 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'kammavaari_marriage.r.height' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `p`.`first_name`, `p`.`last_name`, `p`.`gender`, `p`.`id`, `p`.`status`, DATE_FORMAT(FROM_DAYS(DATEDIFF(now(), p.dob)), '%Y')+0 as cur_age, `p`.`living_in`, `p`.`profile_id`, `p`.`date`, `p`.`month`, `p`.`year`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `r`.`time_of_birth`, `r`.`place_of_birth`, `r`.`gothram`, `r`.`star`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `e`.`country`, `pa`.`fathers_father_district`, `pa`.`mothers_father_district`, `pa`.`father_mobile`, `pa`.`mother_mobile`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `payment_status`, `elite`, `profileowner`, `ms_usertype`, `pr`.`property_value`, `pr`.`property_type`, `pr`.`property_Desc`
FROM `tbl_primary_info` as `p`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `tbl_parents_info` as `pa` ON `p`.`id`=`pa`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`MS_id`
LEFT JOIN `ms_profilesetting` as `mprosetting` ON `p`.`id`=`mprosetting`.`MS_id`
LEFT JOIN `ms_property_info` as `pr` ON `p`.`id`=`pr`.`ms_id`
WHERE `p`.`gender` = 'female'
AND `r`.`height_cm` >= '152'
AND `r`.`height_cm` <= '183'
AND (YEAR(CURDATE()) - CAST(p.year AS UNSIGNED)) >= '18'
AND (YEAR(CURDATE()) - CAST(p.year AS UNSIGNED)) <= '40'
AND `r`.`marital_status` IN('never_married')
AND `r`.`religion` IN('Hindu')
AND `r`.`mother_tounge` IN('Telugu')
AND `r`.`caste` IN('Kamma')
AND `e`.`country` IN('India')
AND `p`.`status` IN('1')
AND `u`.`ismain` = 1 AND `u`.`isactive` = 1
AND `mprosetting`.`profileowner` >0
AND `mprosetting`.`ms_usertype` != 'elite'
AND `mprosetting`.`ms_usertype` IN('regular', 'confidential', 'superconfidential')
AND `p`.`status` = 1
GROUP BY `p`.`id`
ORDER BY `p`.`registered_on` DESC
ERROR - 2022-06-28 13:36:21 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:36:30 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:37:36 --> Query error: Expression #12 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'kammavaari_marriage.r.height' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `p`.`first_name`, `p`.`last_name`, `p`.`gender`, `p`.`id`, `p`.`status`, DATE_FORMAT(FROM_DAYS(DATEDIFF(now(), p.dob)), '%Y')+0 as cur_age, `p`.`living_in`, `p`.`profile_id`, `p`.`date`, `p`.`month`, `p`.`year`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `r`.`time_of_birth`, `r`.`place_of_birth`, `r`.`gothram`, `r`.`star`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `e`.`country`, `pa`.`fathers_father_district`, `pa`.`mothers_father_district`, `pa`.`father_mobile`, `pa`.`mother_mobile`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `payment_status`, `elite`, `profileowner`, `ms_usertype`, `pr`.`property_value`, `pr`.`property_type`, `pr`.`property_Desc`
FROM `tbl_primary_info` as `p`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `tbl_parents_info` as `pa` ON `p`.`id`=`pa`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`MS_id`
LEFT JOIN `ms_profilesetting` as `mprosetting` ON `p`.`id`=`mprosetting`.`MS_id`
LEFT JOIN `ms_property_info` as `pr` ON `p`.`id`=`pr`.`ms_id`
WHERE `p`.`gender` = 'male'
AND `r`.`height_cm` >= '152'
AND `r`.`height_cm` <= '183'
AND (YEAR(CURDATE()) - CAST(p.year AS UNSIGNED)) >= '18'
AND (YEAR(CURDATE()) - CAST(p.year AS UNSIGNED)) <= '40'
AND `r`.`marital_status` IN('never_married')
AND `r`.`religion` IN('Hindu')
AND `r`.`mother_tounge` IN('Telugu')
AND `r`.`caste` IN('Kamma')
AND `e`.`country` IN('USA')
AND `p`.`status` IN('1')
AND `u`.`ismain` = 1 AND `u`.`isactive` = 1
AND `mprosetting`.`profileowner` >0
AND `mprosetting`.`ms_usertype` != 'elite'
AND `mprosetting`.`ms_usertype` IN('regular', 'confidential', 'superconfidential', 'elite')
AND `p`.`status` = 1
GROUP BY `p`.`id`
ORDER BY `p`.`registered_on` DESC
ERROR - 2022-06-28 13:37:49 --> Query error: Expression #12 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'kammavaari_marriage.r.height' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `p`.`first_name`, `p`.`last_name`, `p`.`gender`, `p`.`id`, `p`.`status`, DATE_FORMAT(FROM_DAYS(DATEDIFF(now(), p.dob)), '%Y')+0 as cur_age, `p`.`living_in`, `p`.`profile_id`, `p`.`date`, `p`.`month`, `p`.`year`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `r`.`time_of_birth`, `r`.`place_of_birth`, `r`.`gothram`, `r`.`star`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `e`.`country`, `pa`.`fathers_father_district`, `pa`.`mothers_father_district`, `pa`.`father_mobile`, `pa`.`mother_mobile`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `payment_status`, `elite`, `profileowner`, `ms_usertype`, `pr`.`property_value`, `pr`.`property_type`, `pr`.`property_Desc`
FROM `tbl_primary_info` as `p`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `tbl_parents_info` as `pa` ON `p`.`id`=`pa`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`MS_id`
LEFT JOIN `ms_profilesetting` as `mprosetting` ON `p`.`id`=`mprosetting`.`MS_id`
LEFT JOIN `ms_property_info` as `pr` ON `p`.`id`=`pr`.`ms_id`
WHERE `p`.`gender` = 'female'
AND `r`.`height_cm` >= '160'
AND `r`.`height_cm` <= '183'
AND (YEAR(CURDATE()) - CAST(p.year AS UNSIGNED)) >= '25'
AND (YEAR(CURDATE()) - CAST(p.year AS UNSIGNED)) <= '29'
AND `r`.`marital_status` IN('never_married')
AND `r`.`religion` IN('Hindu')
AND `r`.`mother_tounge` IN('Telugu')
AND `r`.`caste` IN('Kamma')
AND `e`.`country` IN('India')
AND CAST(pr.property_value AS DECIMAL(8, 2)) >= '5'
AND `p`.`status` IN('1')
AND `u`.`ismain` = 1 AND `u`.`isactive` = 1
AND `mprosetting`.`profileowner` >0
AND `mprosetting`.`ms_usertype` != 'elite'
AND `mprosetting`.`ms_usertype` IN('regular', 'confidential', 'superconfidential', 'elite')
AND `p`.`status` = 1
GROUP BY `p`.`id`
ORDER BY `p`.`registered_on` DESC
ERROR - 2022-06-28 13:38:09 --> Query error: Expression #12 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'kammavaari_marriage.r.height' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `p`.`first_name`, `p`.`last_name`, `p`.`gender`, `p`.`id`, `p`.`status`, DATE_FORMAT(FROM_DAYS(DATEDIFF(now(), p.dob)), '%Y')+0 as cur_age, `p`.`living_in`, `p`.`profile_id`, `p`.`date`, `p`.`month`, `p`.`year`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `r`.`time_of_birth`, `r`.`place_of_birth`, `r`.`gothram`, `r`.`star`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `e`.`country`, `pa`.`fathers_father_district`, `pa`.`mothers_father_district`, `pa`.`father_mobile`, `pa`.`mother_mobile`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `payment_status`, `elite`, `profileowner`, `ms_usertype`, `pr`.`property_value`, `pr`.`property_type`, `pr`.`property_Desc`
FROM `tbl_primary_info` as `p`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `tbl_parents_info` as `pa` ON `p`.`id`=`pa`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`MS_id`
LEFT JOIN `ms_profilesetting` as `mprosetting` ON `p`.`id`=`mprosetting`.`MS_id`
LEFT JOIN `ms_property_info` as `pr` ON `p`.`id`=`pr`.`ms_id`
WHERE `p`.`gender` = 'female'
AND `r`.`height_cm` >= '152'
AND `r`.`height_cm` <= '183'
AND (YEAR(CURDATE()) - CAST(p.year AS UNSIGNED)) >= '18'
AND (YEAR(CURDATE()) - CAST(p.year AS UNSIGNED)) <= '40'
AND `r`.`marital_status` IN('never_married')
AND `r`.`religion` IN('Hindu')
AND `r`.`mother_tounge` IN('Telugu')
AND `r`.`caste` IN('Kamma')
AND `e`.`country` IN('India')
AND `p`.`status` IN('1')
AND `u`.`ismain` = 1 AND `u`.`isactive` = 1
AND `mprosetting`.`profileowner` >0
AND `mprosetting`.`ms_usertype` != 'elite'
AND `mprosetting`.`ms_usertype` IN('regular', 'confidential', 'superconfidential')
AND `p`.`status` = 1
GROUP BY `p`.`id`
ORDER BY `p`.`registered_on` DESC
ERROR - 2022-06-28 13:38:18 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:38:21 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:38:26 --> Query error: Expression #12 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'kammavaari_marriage.r.height' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `p`.`first_name`, `p`.`last_name`, `p`.`gender`, `p`.`id`, `p`.`status`, DATE_FORMAT(FROM_DAYS(DATEDIFF(now(), p.dob)), '%Y')+0 as cur_age, `p`.`living_in`, `p`.`profile_id`, `p`.`date`, `p`.`month`, `p`.`year`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `r`.`time_of_birth`, `r`.`place_of_birth`, `r`.`gothram`, `r`.`star`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `e`.`country`, `pa`.`fathers_father_district`, `pa`.`mothers_father_district`, `pa`.`father_mobile`, `pa`.`mother_mobile`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `payment_status`, `elite`, `profileowner`, `ms_usertype`, `pr`.`property_value`, `pr`.`property_type`, `pr`.`property_Desc`
FROM `tbl_primary_info` as `p`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `tbl_parents_info` as `pa` ON `p`.`id`=`pa`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`MS_id`
LEFT JOIN `ms_profilesetting` as `mprosetting` ON `p`.`id`=`mprosetting`.`MS_id`
LEFT JOIN `ms_property_info` as `pr` ON `p`.`id`=`pr`.`ms_id`
WHERE `p`.`gender` = 'female'
AND `r`.`height_cm` >= '152'
AND `r`.`height_cm` <= '183'
AND (YEAR(CURDATE()) - CAST(p.year AS UNSIGNED)) >= '29'
AND (YEAR(CURDATE()) - CAST(p.year AS UNSIGNED)) <= '40'
AND `r`.`marital_status` IN('never_married')
AND `r`.`religion` IN('Hindu')
AND `r`.`mother_tounge` IN('Telugu')
AND `r`.`caste` IN('Kamma')
AND `e`.`country` IN('India')
AND `p`.`status` IN('1')
AND `u`.`ismain` = 1 AND `u`.`isactive` = 1
AND `mprosetting`.`profileowner` >0
AND `mprosetting`.`ms_usertype` != 'elite'
AND `mprosetting`.`ms_usertype` IN('regular', 'confidential', 'superconfidential')
AND `p`.`status` = 1
GROUP BY `p`.`id`
ORDER BY `p`.`registered_on` DESC
ERROR - 2022-06-28 13:38:49 --> Query error: In aggregated query without GROUP BY, expression #2 of SELECT list contains nonaggregated column 'kammavaari_marriage.tbl_profilebattery.photo'; this is incompatible with sql_mode=only_full_group_by - Invalid query: select SUM(IFNULL(`basicdetails`, 0) + IFNULL(`religion`, 0) + IFNULL(`edu_prof`, 0) + IFNULL(`parents`, 0) + IFNULL(`Siblings`, 0) + IFNULL(`photo`, 0)) as total,photo,basicdetails,religion,edu_prof,parents,Siblings from tbl_profilebattery where user_id='2726'
ERROR - 2022-06-28 13:38:49 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:38:53 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:39:03 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:39:19 --> Query error: In aggregated query without GROUP BY, expression #2 of SELECT list contains nonaggregated column 'kammavaari_marriage.tbl_profilebattery.photo'; this is incompatible with sql_mode=only_full_group_by - Invalid query: select SUM(IFNULL(`basicdetails`, 0) + IFNULL(`religion`, 0) + IFNULL(`edu_prof`, 0) + IFNULL(`parents`, 0) + IFNULL(`Siblings`, 0) + IFNULL(`photo`, 0)) as total,photo,basicdetails,religion,edu_prof,parents,Siblings from tbl_profilebattery where user_id='2726'
ERROR - 2022-06-28 13:39:29 --> Query error: In aggregated query without GROUP BY, expression #2 of SELECT list contains nonaggregated column 'kammavaari_marriage.tbl_profilebattery.photo'; this is incompatible with sql_mode=only_full_group_by - Invalid query: select SUM(IFNULL(`basicdetails`, 0) + IFNULL(`religion`, 0) + IFNULL(`edu_prof`, 0) + IFNULL(`parents`, 0) + IFNULL(`Siblings`, 0) + IFNULL(`photo`, 0)) as total,photo,basicdetails,religion,edu_prof,parents,Siblings from tbl_profilebattery where user_id='2726'
ERROR - 2022-06-28 13:39:34 --> Query error: Expression #1 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'kammavaari_marriage.kv_mysideinterests.kv_msi_client_rmid' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `kv_msi_client_rmid`, `kv_msi_interested_rmid`, `kv_msi_profilefkid`, `kv_msi_interested_on`, `kv_msi_rmstatus`, `kv_msi_id`, `kv_msi_modified_date`, `sd`.`username`, `sd`.`phone_no`, `sd`.`id` as "staffid", `piinton`.`first_name` as "intonclientfname", `piinton`.`last_name` as "intonclientlname", `piclient`.`first_name` as "clientfname", `piclient`.`last_name` as "clientlname", `kv_msi_created_date`, `piclient`.`profile_id` as "clientprofileid", `piinton`.`profile_id` as "intonclientprofileid"
FROM `kv_mysideinterests`
JOIN `tbl_admin_data` as `sd` ON `sd`.`id`=`kv_msi_interested_rmid`
JOIN `tbl_primary_info` as `piinton` ON `piinton`.`id`=`kv_msi_interested_on`
JOIN `tbl_primary_info` as `piclient` ON `piclient`.`id`=`kv_msi_profilefkid`
WHERE `kv_msi_status` = 'sentinterested'
AND `kv_msi_onresstatus` = 'accepted'
AND `kv_msi_rmstatus` = 'mms'
GROUP BY `kv_msi_profilefkid`, `kv_msi_interested_on`
ORDER BY `kv_msi_created_date` DESC
ERROR - 2022-06-28 13:39:36 --> Query error: Expression #1 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'kammavaari_marriage.v.kv_msi_id' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `v`.*, `p`.`gender`, `p`.`id`, `p`.`status`, `p`.`age`, `p`.`living_in`, `p`.`profile_id`, `p`.`first_name`, `last_name`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`
FROM `kv_mysideinterests` as `v`
LEFT JOIN `tbl_primary_info` as `p` ON `p`.`id`=`v`.`kv_msi_interested_on`
LEFT JOIN `tbl_religion_info` as `r` ON `v`.`kv_msi_interested_on`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `v`.`kv_msi_interested_on`=`e`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`MS_id`
INNER JOIN `ms_profilesetting` as `s` ON `p`.`id`=`s`.`ms_id`
WHERE `p`.`status` = 1
AND `v`.`kv_msi_profilefkid` = '2726'
AND `u`.`ismain` = 1
AND `kv_msi_onresstatus` = 'oneside_accepted'
GROUP BY `v`.`kv_msi_interested_on`
ORDER BY `v`.`kv_msi_created_date` DESC
ERROR - 2022-06-28 13:39:55 --> Query error: Expression #12 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'kammavaari_marriage.r.height' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `p`.`first_name`, `p`.`last_name`, `p`.`gender`, `p`.`id`, `p`.`status`, DATE_FORMAT(FROM_DAYS(DATEDIFF(now(), p.dob)), '%Y')+0 as cur_age, `p`.`living_in`, `p`.`profile_id`, `p`.`date`, `p`.`month`, `p`.`year`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `r`.`time_of_birth`, `r`.`place_of_birth`, `r`.`gothram`, `r`.`star`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `e`.`country`, `pa`.`fathers_father_district`, `pa`.`mothers_father_district`, `pa`.`father_mobile`, `pa`.`mother_mobile`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `payment_status`, `elite`, `profileowner`, `ms_usertype`, `pr`.`property_value`, `pr`.`property_type`, `pr`.`property_Desc`
FROM `tbl_primary_info` as `p`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `tbl_parents_info` as `pa` ON `p`.`id`=`pa`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`MS_id`
LEFT JOIN `ms_profilesetting` as `mprosetting` ON `p`.`id`=`mprosetting`.`MS_id`
LEFT JOIN `ms_property_info` as `pr` ON `p`.`id`=`pr`.`ms_id`
WHERE `p`.`gender` = 'female'
AND `r`.`height_cm` >= '152'
AND `r`.`height_cm` <= '183'
AND (YEAR(CURDATE()) - CAST(p.year AS UNSIGNED)) >= '18'
AND (YEAR(CURDATE()) - CAST(p.year AS UNSIGNED)) <= '40'
AND `r`.`marital_status` IN('never_married')
AND `r`.`religion` IN('Hindu')
AND `r`.`mother_tounge` IN('Telugu')
AND `r`.`caste` IN('Kamma')
AND `e`.`country` IN('India')
AND `p`.`status` IN('1')
AND `u`.`ismain` = 1 AND `u`.`isactive` = 1
AND `mprosetting`.`profileowner` >0
AND `mprosetting`.`ms_usertype` != 'elite'
AND `mprosetting`.`ms_usertype` IN('regular', 'confidential', 'superconfidential')
AND `p`.`status` = 1
GROUP BY `p`.`id`
ORDER BY `p`.`registered_on` DESC
ERROR - 2022-06-28 13:39:58 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:40:06 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:40:10 --> Query error: Expression #12 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'kammavaari_marriage.r.height' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `p`.`first_name`, `p`.`last_name`, `p`.`gender`, `p`.`id`, `p`.`status`, DATE_FORMAT(FROM_DAYS(DATEDIFF(now(), p.dob)), '%Y')+0 as cur_age, `p`.`living_in`, `p`.`profile_id`, `p`.`date`, `p`.`month`, `p`.`year`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `r`.`time_of_birth`, `r`.`place_of_birth`, `r`.`gothram`, `r`.`star`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `e`.`country`, `pa`.`fathers_father_district`, `pa`.`mothers_father_district`, `pa`.`father_mobile`, `pa`.`mother_mobile`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `payment_status`, `elite`, `profileowner`, `ms_usertype`, `pr`.`property_value`, `pr`.`property_type`, `pr`.`property_Desc`
FROM `tbl_primary_info` as `p`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `tbl_parents_info` as `pa` ON `p`.`id`=`pa`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`MS_id`
LEFT JOIN `ms_profilesetting` as `mprosetting` ON `p`.`id`=`mprosetting`.`MS_id`
LEFT JOIN `ms_property_info` as `pr` ON `p`.`id`=`pr`.`ms_id`
WHERE `p`.`profile_id` LIKE '%KV964784%' ESCAPE '!'
AND `u`.`ismain` = 1 AND `u`.`isactive` = 1
AND `mprosetting`.`profileowner` >0
AND `mprosetting`.`ms_usertype` != 'elite'
AND `mprosetting`.`ms_usertype` IN('regular', 'confidential', 'superconfidential', 'elite')
AND `p`.`status` = 1
GROUP BY `p`.`id`
ORDER BY `p`.`registered_on` DESC
ERROR - 2022-06-28 13:40:18 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:40:35 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:40:55 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:40:56 --> Query error: Expression #12 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'kammavaari_marriage.r.height' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `p`.`first_name`, `p`.`last_name`, `p`.`gender`, `p`.`id`, `p`.`status`, DATE_FORMAT(FROM_DAYS(DATEDIFF(now(), p.dob)), '%Y')+0 as cur_age, `p`.`living_in`, `p`.`profile_id`, `p`.`date`, `p`.`month`, `p`.`year`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `r`.`time_of_birth`, `r`.`place_of_birth`, `r`.`gothram`, `r`.`star`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `e`.`country`, `pa`.`fathers_father_district`, `pa`.`mothers_father_district`, `pa`.`father_mobile`, `pa`.`mother_mobile`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `payment_status`, `elite`, `profileowner`, `ms_usertype`, `pr`.`property_value`, `pr`.`property_type`, `pr`.`property_Desc`
FROM `tbl_primary_info` as `p`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `tbl_parents_info` as `pa` ON `p`.`id`=`pa`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`MS_id`
LEFT JOIN `ms_profilesetting` as `mprosetting` ON `p`.`id`=`mprosetting`.`MS_id`
LEFT JOIN `ms_property_info` as `pr` ON `p`.`id`=`pr`.`ms_id`
WHERE `p`.`profile_id` LIKE '%KV964784%' ESCAPE '!'
AND `u`.`ismain` = 1 AND `u`.`isactive` = 1
AND `mprosetting`.`profileowner` >0
AND `mprosetting`.`ms_usertype` != 'elite'
AND `mprosetting`.`ms_usertype` IN('regular', 'confidential', 'superconfidential', 'elite')
AND `p`.`status` = 1
GROUP BY `p`.`id`
ORDER BY `p`.`registered_on` DESC
ERROR - 2022-06-28 13:41:04 --> Query error: Expression #12 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'kammavaari_marriage.r.height' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `p`.`first_name`, `p`.`last_name`, `p`.`gender`, `p`.`id`, `p`.`status`, DATE_FORMAT(FROM_DAYS(DATEDIFF(now(), p.dob)), '%Y')+0 as cur_age, `p`.`living_in`, `p`.`profile_id`, `p`.`date`, `p`.`month`, `p`.`year`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `r`.`time_of_birth`, `r`.`place_of_birth`, `r`.`gothram`, `r`.`star`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `e`.`country`, `pa`.`fathers_father_district`, `pa`.`mothers_father_district`, `pa`.`father_mobile`, `pa`.`mother_mobile`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `payment_status`, `elite`, `profileowner`, `ms_usertype`, `pr`.`property_value`, `pr`.`property_type`, `pr`.`property_Desc`
FROM `tbl_primary_info` as `p`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `tbl_parents_info` as `pa` ON `p`.`id`=`pa`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`MS_id`
LEFT JOIN `ms_profilesetting` as `mprosetting` ON `p`.`id`=`mprosetting`.`MS_id`
LEFT JOIN `ms_property_info` as `pr` ON `p`.`id`=`pr`.`ms_id`
WHERE `p`.`gender` = 'female'
AND `p`.`mobile` = '9160516777'
AND `r`.`height_cm` >= '160'
AND `r`.`height_cm` <= '183'
AND (YEAR(CURDATE()) - CAST(p.year AS UNSIGNED)) >= '25'
AND (YEAR(CURDATE()) - CAST(p.year AS UNSIGNED)) <= '29'
AND `r`.`marital_status` IN('never_married')
AND `r`.`religion` IN('Hindu')
AND `r`.`mother_tounge` IN('Telugu')
AND `r`.`caste` IN('Kamma')
AND `e`.`country` IN('India')
AND CAST(pr.property_value AS DECIMAL(8, 2)) >= '5'
AND `p`.`status` IN('1')
AND `u`.`ismain` = 1 AND `u`.`isactive` = 1
AND `mprosetting`.`profileowner` >0
AND `mprosetting`.`ms_usertype` != 'elite'
AND `mprosetting`.`ms_usertype` IN('regular', 'confidential', 'superconfidential', 'elite')
AND `p`.`status` = 1
GROUP BY `p`.`id`
ORDER BY `p`.`registered_on` DESC
ERROR - 2022-06-28 13:42:56 --> To Id is not available for User - 401
ERROR - 2022-06-28 13:42:59 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:43:09 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:43:24 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:43:42 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:43:50 --> Query error: Expression #1 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'kammavaari_marriage.kv_mysideinterests.kv_msi_client_rmid' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `kv_msi_client_rmid`, `kv_msi_interested_rmid`, `kv_msi_profilefkid`, `kv_msi_interested_on`, `kv_msi_rmstatus`, `kv_msi_id`, `kv_msi_modified_date`, `sd`.`username`, `sd`.`phone_no`, `sd`.`id` as "staffid", `piinton`.`first_name` as "intonclientfname", `piinton`.`last_name` as "intonclientlname", `piclient`.`first_name` as "clientfname", `piclient`.`last_name` as "clientlname", `kv_msi_created_date`, `piclient`.`profile_id` as "clientprofileid", `piinton`.`profile_id` as "intonclientprofileid"
FROM `kv_mysideinterests`
JOIN `tbl_admin_data` as `sd` ON `sd`.`id`=`kv_msi_interested_rmid`
JOIN `tbl_primary_info` as `piinton` ON `piinton`.`id`=`kv_msi_interested_on`
JOIN `tbl_primary_info` as `piclient` ON `piclient`.`id`=`kv_msi_profilefkid`
WHERE `kv_msi_status` = 'sentinterested'
AND `kv_msi_onresstatus` = 'accepted'
AND `kv_msi_rmstatus` = 'mms'
GROUP BY `kv_msi_profilefkid`, `kv_msi_interested_on`
ORDER BY `kv_msi_created_date` DESC
ERROR - 2022-06-28 13:44:18 --> Query error: Expression #12 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'kammavaari_marriage.r.height' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `p`.`first_name`, `p`.`last_name`, `p`.`gender`, `p`.`id`, `p`.`status`, DATE_FORMAT(FROM_DAYS(DATEDIFF(now(), p.dob)), '%Y')+0 as cur_age, `p`.`living_in`, `p`.`profile_id`, `p`.`date`, `p`.`month`, `p`.`year`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `r`.`time_of_birth`, `r`.`place_of_birth`, `r`.`gothram`, `r`.`star`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `e`.`country`, `pa`.`fathers_father_district`, `pa`.`mothers_father_district`, `pa`.`father_mobile`, `pa`.`mother_mobile`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `payment_status`, `elite`, `profileowner`, `ms_usertype`, `pr`.`property_value`, `pr`.`property_type`, `pr`.`property_Desc`
FROM `tbl_primary_info` as `p`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `tbl_parents_info` as `pa` ON `p`.`id`=`pa`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`MS_id`
LEFT JOIN `ms_profilesetting` as `mprosetting` ON `p`.`id`=`mprosetting`.`MS_id`
LEFT JOIN `ms_property_info` as `pr` ON `p`.`id`=`pr`.`ms_id`
WHERE `p`.`gender` = 'female'
AND `r`.`height_cm` >= '152'
AND `r`.`height_cm` <= '183'
AND (YEAR(CURDATE()) - CAST(p.year AS UNSIGNED)) >= '18'
AND (YEAR(CURDATE()) - CAST(p.year AS UNSIGNED)) <= '27'
AND `r`.`marital_status` IN('never_married')
AND `r`.`religion` IN('Hindu')
AND `r`.`mother_tounge` IN('Telugu')
AND `r`.`caste` IN('Kamma')
AND `e`.`country` IN('USA')
AND `p`.`status` IN('1')
AND `u`.`ismain` = 1 AND `u`.`isactive` = 1
AND `mprosetting`.`profileowner` >0
AND `mprosetting`.`ms_usertype` != 'elite'
AND `mprosetting`.`ms_usertype` IN('regular', 'confidential', 'superconfidential', 'elite')
AND `p`.`status` = 1
GROUP BY `p`.`id`
ORDER BY `p`.`registered_on` DESC
ERROR - 2022-06-28 13:44:42 --> Query error: Expression #1 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'kammavaari_marriage.kv_mysideinterests.kv_msi_client_rmid' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `kv_msi_client_rmid`, `kv_msi_interested_rmid`, `kv_msi_profilefkid`, `kv_msi_interested_on`, `kv_msi_rmstatus`, `kv_msi_id`, `kv_msi_modified_date`, `sd`.`username`, `sd`.`phone_no`, `sd`.`id` as "staffid", `piinton`.`first_name` as "intonclientfname", `piinton`.`last_name` as "intonclientlname", `piclient`.`first_name` as "clientfname", `piclient`.`last_name` as "clientlname", `kv_msi_created_date`, `piclient`.`profile_id` as "clientprofileid", `piinton`.`profile_id` as "intonclientprofileid"
FROM `kv_mysideinterests`
JOIN `tbl_admin_data` as `sd` ON `sd`.`id`=`kv_msi_interested_rmid`
JOIN `tbl_primary_info` as `piinton` ON `piinton`.`id`=`kv_msi_interested_on`
JOIN `tbl_primary_info` as `piclient` ON `piclient`.`id`=`kv_msi_profilefkid`
WHERE `kv_msi_status` = 'sentinterested'
AND `kv_msi_onresstatus` = 'accepted'
AND `kv_msi_rmstatus` = 'mms'
GROUP BY `kv_msi_profilefkid`, `kv_msi_interested_on`
ORDER BY `kv_msi_created_date` DESC
ERROR - 2022-06-28 13:45:27 --> Query error: Expression #1 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'kammavaari_marriage.kv_mysideinterests.kv_msi_client_rmid' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `kv_msi_client_rmid`, `kv_msi_interested_rmid`, `kv_msi_profilefkid`, `kv_msi_interested_on`, `kv_msi_rmstatus`, `kv_msi_id`, `kv_msi_modified_date`, `sd`.`username`, `sd`.`phone_no`, `sd`.`id` as "staffid", `piinton`.`first_name` as "intonclientfname", `piinton`.`last_name` as "intonclientlname", `piclient`.`first_name` as "clientfname", `piclient`.`last_name` as "clientlname", `kv_msi_created_date`, `piclient`.`profile_id` as "clientprofileid", `piinton`.`profile_id` as "intonclientprofileid"
FROM `kv_mysideinterests`
JOIN `tbl_admin_data` as `sd` ON `sd`.`id`=`kv_msi_interested_rmid`
JOIN `tbl_primary_info` as `piinton` ON `piinton`.`id`=`kv_msi_interested_on`
JOIN `tbl_primary_info` as `piclient` ON `piclient`.`id`=`kv_msi_profilefkid`
WHERE `kv_msi_status` = 'sentinterested'
AND `kv_msi_onresstatus` = 'accepted'
AND `kv_msi_rmstatus` = 'mms'
GROUP BY `kv_msi_profilefkid`, `kv_msi_interested_on`
ORDER BY `kv_msi_created_date` DESC
ERROR - 2022-06-28 13:45:29 --> Query error: Expression #12 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'kammavaari_marriage.r.height' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `p`.`first_name`, `p`.`last_name`, `p`.`gender`, `p`.`id`, `p`.`status`, DATE_FORMAT(FROM_DAYS(DATEDIFF(now(), p.dob)), '%Y')+0 as cur_age, `p`.`living_in`, `p`.`profile_id`, `p`.`date`, `p`.`month`, `p`.`year`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `r`.`time_of_birth`, `r`.`place_of_birth`, `r`.`gothram`, `r`.`star`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `e`.`country`, `pa`.`fathers_father_district`, `pa`.`mothers_father_district`, `pa`.`father_mobile`, `pa`.`mother_mobile`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `payment_status`, `elite`, `profileowner`, `ms_usertype`, `pr`.`property_value`, `pr`.`property_type`, `pr`.`property_Desc`
FROM `tbl_primary_info` as `p`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `tbl_parents_info` as `pa` ON `p`.`id`=`pa`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`MS_id`
LEFT JOIN `ms_profilesetting` as `mprosetting` ON `p`.`id`=`mprosetting`.`MS_id`
LEFT JOIN `ms_property_info` as `pr` ON `p`.`id`=`pr`.`ms_id`
WHERE `p`.`gender` = 'female'
AND `r`.`height_cm` >= '152'
AND `r`.`height_cm` <= '183'
AND (YEAR(CURDATE()) - CAST(p.year AS UNSIGNED)) >= '18'
AND (YEAR(CURDATE()) - CAST(p.year AS UNSIGNED)) <= '27'
AND `r`.`marital_status` IN('never_married')
AND `r`.`religion` IN('Hindu')
AND `r`.`mother_tounge` IN('Telugu')
AND `r`.`caste` IN('Kamma')
AND `e`.`country` IN('USA')
AND `p`.`status` IN('1')
AND `u`.`ismain` = 1 AND `u`.`isactive` = 1
AND `mprosetting`.`profileowner` >0
AND `mprosetting`.`ms_usertype` != 'elite'
AND `mprosetting`.`ms_usertype` IN('regular', 'confidential', 'superconfidential', 'elite')
AND `p`.`status` = 1
GROUP BY `p`.`id`
ORDER BY `p`.`registered_on` DESC
ERROR - 2022-06-28 13:45:32 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:45:50 --> Query error: Expression #1 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'kammavaari_marriage.kv_mysideinterests.kv_msi_client_rmid' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `kv_msi_client_rmid`, `kv_msi_interested_rmid`, `kv_msi_profilefkid`, `kv_msi_interested_on`, `kv_msi_rmstatus`, `kv_msi_id`, `kv_msi_modified_date`, `sd`.`username`, `sd`.`phone_no`, `sd`.`id` as "staffid", `piinton`.`first_name` as "intonclientfname", `piinton`.`last_name` as "intonclientlname", `piclient`.`first_name` as "clientfname", `piclient`.`last_name` as "clientlname", `kv_msi_created_date`, `piclient`.`profile_id` as "clientprofileid", `piinton`.`profile_id` as "intonclientprofileid"
FROM `kv_mysideinterests`
JOIN `tbl_admin_data` as `sd` ON `sd`.`id`=`kv_msi_interested_rmid`
JOIN `tbl_primary_info` as `piinton` ON `piinton`.`id`=`kv_msi_interested_on`
JOIN `tbl_primary_info` as `piclient` ON `piclient`.`id`=`kv_msi_profilefkid`
WHERE `kv_msi_status` = 'sentinterested'
AND `kv_msi_onresstatus` = 'accepted'
AND `kv_msi_rmstatus` = 'mms'
GROUP BY `kv_msi_profilefkid`, `kv_msi_interested_on`
ORDER BY `kv_msi_created_date` DESC
ERROR - 2022-06-28 13:45:59 --> Query error: Expression #1 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'kammavaari_marriage.kv_mysideinterests.kv_msi_client_rmid' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `kv_msi_client_rmid`, `kv_msi_interested_rmid`, `kv_msi_profilefkid`, `kv_msi_interested_on`, `kv_msi_rmstatus`, `kv_msi_id`, `kv_msi_modified_date`, `sd`.`username`, `sd`.`phone_no`, `sd`.`id` as "staffid", `piinton`.`first_name` as "intonclientfname", `piinton`.`last_name` as "intonclientlname", `piclient`.`first_name` as "clientfname", `piclient`.`last_name` as "clientlname", `kv_msi_created_date`, `piclient`.`profile_id` as "clientprofileid", `piinton`.`profile_id` as "intonclientprofileid"
FROM `kv_mysideinterests`
JOIN `tbl_admin_data` as `sd` ON `sd`.`id`=`kv_msi_interested_rmid`
JOIN `tbl_primary_info` as `piinton` ON `piinton`.`id`=`kv_msi_interested_on`
JOIN `tbl_primary_info` as `piclient` ON `piclient`.`id`=`kv_msi_profilefkid`
WHERE `kv_msi_status` = 'sentinterested'
AND `kv_msi_onresstatus` = 'accepted'
AND `kv_msi_rmstatus` = 'mms'
GROUP BY `kv_msi_profilefkid`, `kv_msi_interested_on`
ORDER BY `kv_msi_created_date` DESC
ERROR - 2022-06-28 13:46:58 --> Query error: Expression #12 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'kammavaari_marriage.r.height' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `p`.`first_name`, `p`.`last_name`, `p`.`gender`, `p`.`id`, `p`.`status`, DATE_FORMAT(FROM_DAYS(DATEDIFF(now(), p.dob)), '%Y')+0 as cur_age, `p`.`living_in`, `p`.`profile_id`, `p`.`date`, `p`.`month`, `p`.`year`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `r`.`time_of_birth`, `r`.`place_of_birth`, `r`.`gothram`, `r`.`star`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `e`.`country`, `pa`.`fathers_father_district`, `pa`.`mothers_father_district`, `pa`.`father_mobile`, `pa`.`mother_mobile`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `payment_status`, `elite`, `profileowner`, `ms_usertype`, `pr`.`property_value`, `pr`.`property_type`, `pr`.`property_Desc`
FROM `tbl_primary_info` as `p`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `tbl_parents_info` as `pa` ON `p`.`id`=`pa`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`MS_id`
LEFT JOIN `ms_profilesetting` as `mprosetting` ON `p`.`id`=`mprosetting`.`MS_id`
LEFT JOIN `ms_property_info` as `pr` ON `p`.`id`=`pr`.`ms_id`
WHERE `p`.`gender` = 'female'
AND `r`.`height_cm` >= '152'
AND `r`.`height_cm` <= '183'
AND (YEAR(CURDATE()) - CAST(p.year AS UNSIGNED)) >= '18'
AND (YEAR(CURDATE()) - CAST(p.year AS UNSIGNED)) <= '27'
AND `r`.`marital_status` IN('never_married')
AND `r`.`religion` IN('Hindu')
AND `r`.`mother_tounge` IN('Telugu')
AND `r`.`caste` IN('Kamma')
AND `e`.`country` IN('USA')
AND `p`.`status` IN('1')
AND `u`.`ismain` = 1 AND `u`.`isactive` = 1
AND `mprosetting`.`profileowner` >0
AND `mprosetting`.`ms_usertype` != 'elite'
AND `mprosetting`.`ms_usertype` IN('regular', 'confidential', 'superconfidential', 'elite')
AND `p`.`status` = 1
GROUP BY `p`.`id`
ORDER BY `p`.`registered_on` DESC
ERROR - 2022-06-28 13:47:58 --> Query error: Expression #12 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'kammavaari_marriage.r.height' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `p`.`first_name`, `p`.`last_name`, `p`.`gender`, `p`.`id`, `p`.`status`, DATE_FORMAT(FROM_DAYS(DATEDIFF(now(), p.dob)), '%Y')+0 as cur_age, `p`.`living_in`, `p`.`profile_id`, `p`.`date`, `p`.`month`, `p`.`year`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `r`.`time_of_birth`, `r`.`place_of_birth`, `r`.`gothram`, `r`.`star`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `e`.`country`, `pa`.`fathers_father_district`, `pa`.`mothers_father_district`, `pa`.`father_mobile`, `pa`.`mother_mobile`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `payment_status`, `elite`, `profileowner`, `ms_usertype`, `pr`.`property_value`, `pr`.`property_type`, `pr`.`property_Desc`
FROM `tbl_primary_info` as `p`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `tbl_parents_info` as `pa` ON `p`.`id`=`pa`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`MS_id`
LEFT JOIN `ms_profilesetting` as `mprosetting` ON `p`.`id`=`mprosetting`.`MS_id`
LEFT JOIN `ms_property_info` as `pr` ON `p`.`id`=`pr`.`ms_id`
WHERE `p`.`gender` = 'female'
AND `r`.`height_cm` >= '152'
AND `r`.`height_cm` <= '183'
AND (YEAR(CURDATE()) - CAST(p.year AS UNSIGNED)) >= '18'
AND (YEAR(CURDATE()) - CAST(p.year AS UNSIGNED)) <= '27'
AND `r`.`marital_status` IN('never_married')
AND `r`.`religion` IN('Hindu')
AND `r`.`mother_tounge` IN('Telugu')
AND `r`.`caste` IN('Kamma')
AND `e`.`country` IN('USA')
AND `p`.`status` IN('1')
AND `u`.`ismain` = 1 AND `u`.`isactive` = 1
AND `mprosetting`.`profileowner` >0
AND `mprosetting`.`ms_usertype` != 'elite'
AND `mprosetting`.`ms_usertype` IN('regular', 'confidential', 'superconfidential', 'elite')
AND `p`.`status` = 1
GROUP BY `p`.`id`
ORDER BY `p`.`registered_on` DESC
ERROR - 2022-06-28 13:48:05 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:48:33 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:48:45 --> Query error: Expression #1 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'kammavaari_marriage.kv_mysideinterests.kv_msi_client_rmid' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `kv_msi_client_rmid`, `kv_msi_interested_rmid`, `kv_msi_profilefkid`, `kv_msi_interested_on`, `kv_msi_rmstatus`, `kv_msi_id`, `kv_msi_modified_date`, `sd`.`username`, `sd`.`phone_no`, `sd`.`id` as "staffid", `piinton`.`first_name` as "intonclientfname", `piinton`.`last_name` as "intonclientlname", `piclient`.`first_name` as "clientfname", `piclient`.`last_name` as "clientlname", `kv_msi_created_date`, `piclient`.`profile_id` as "clientprofileid", `piinton`.`profile_id` as "intonclientprofileid"
FROM `kv_mysideinterests`
JOIN `tbl_admin_data` as `sd` ON `sd`.`id`=`kv_msi_interested_rmid`
JOIN `tbl_primary_info` as `piinton` ON `piinton`.`id`=`kv_msi_interested_on`
JOIN `tbl_primary_info` as `piclient` ON `piclient`.`id`=`kv_msi_profilefkid`
WHERE `kv_msi_status` = 'sentinterested'
AND `kv_msi_onresstatus` = 'accepted'
AND `kv_msi_rmstatus` = 'mms'
GROUP BY `kv_msi_profilefkid`, `kv_msi_interested_on`
ORDER BY `kv_msi_created_date` DESC
ERROR - 2022-06-28 13:48:47 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:49:09 --> Query error: Expression #12 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'kammavaari_marriage.r.height' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `p`.`first_name`, `p`.`last_name`, `p`.`gender`, `p`.`id`, `p`.`status`, DATE_FORMAT(FROM_DAYS(DATEDIFF(now(), p.dob)), '%Y')+0 as cur_age, `p`.`living_in`, `p`.`profile_id`, `p`.`date`, `p`.`month`, `p`.`year`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `r`.`time_of_birth`, `r`.`place_of_birth`, `r`.`gothram`, `r`.`star`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `e`.`country`, `pa`.`fathers_father_district`, `pa`.`mothers_father_district`, `pa`.`father_mobile`, `pa`.`mother_mobile`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `payment_status`, `elite`, `profileowner`, `ms_usertype`, `pr`.`property_value`, `pr`.`property_type`, `pr`.`property_Desc`
FROM `tbl_primary_info` as `p`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `tbl_parents_info` as `pa` ON `p`.`id`=`pa`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`MS_id`
LEFT JOIN `ms_profilesetting` as `mprosetting` ON `p`.`id`=`mprosetting`.`MS_id`
LEFT JOIN `ms_property_info` as `pr` ON `p`.`id`=`pr`.`ms_id`
WHERE `p`.`last_name` LIKE '%yerra%' ESCAPE '!'
AND `u`.`ismain` = 1 AND `u`.`isactive` = 1
AND `mprosetting`.`profileowner` >0
AND `mprosetting`.`ms_usertype` != 'elite'
AND `mprosetting`.`ms_usertype` IN('regular', 'confidential', 'superconfidential', 'elite', 'superelite')
AND `p`.`status` = 1
GROUP BY `p`.`id`
ORDER BY `p`.`registered_on` DESC
ERROR - 2022-06-28 13:49:10 --> Query error: Expression #7 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'kammavaari_marriage.u.photoname' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `p`.`first_name`, `p`.`last_name`, `p`.`gender`, `p`.`profile_id`, `p`.`id`, `p`.`status`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`
FROM `tbl_primary_info` as `p`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`MS_id`
WHERE `p`.`id` = '4905'
AND `u`.`ismain` = 1 AND `u`.`isactive` = 1
GROUP BY `u`.`MS_id`
ERROR - 2022-06-28 13:49:23 --> Query error: Expression #12 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'kammavaari_marriage.r.height' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `p`.`first_name`, `p`.`last_name`, `p`.`gender`, `p`.`id`, `p`.`status`, DATE_FORMAT(FROM_DAYS(DATEDIFF(now(), p.dob)), '%Y')+0 as cur_age, `p`.`living_in`, `p`.`profile_id`, `p`.`date`, `p`.`month`, `p`.`year`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `r`.`time_of_birth`, `r`.`place_of_birth`, `r`.`gothram`, `r`.`star`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `e`.`country`, `pa`.`fathers_father_district`, `pa`.`mothers_father_district`, `pa`.`father_mobile`, `pa`.`mother_mobile`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `payment_status`, `elite`, `profileowner`, `ms_usertype`, `pr`.`property_value`, `pr`.`property_type`, `pr`.`property_Desc`
FROM `tbl_primary_info` as `p`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `tbl_parents_info` as `pa` ON `p`.`id`=`pa`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`MS_id`
LEFT JOIN `ms_profilesetting` as `mprosetting` ON `p`.`id`=`mprosetting`.`MS_id`
LEFT JOIN `ms_property_info` as `pr` ON `p`.`id`=`pr`.`ms_id`
WHERE `p`.`gender` = 'male'
AND `r`.`height_cm` >= '167'
AND `r`.`height_cm` <= '183'
AND (YEAR(CURDATE()) - CAST(p.year AS UNSIGNED)) >= '33'
AND (YEAR(CURDATE()) - CAST(p.year AS UNSIGNED)) <= '37'
AND `r`.`marital_status` IN('never_married')
AND `r`.`religion` IN('Hindu')
AND `r`.`mother_tounge` IN('Telugu')
AND `r`.`caste` IN('Kamma')
AND `e`.`heighst_education` IN('Bachelors in Degree', 'Bachelors in Engineering', 'Doctorate/phd', 'Masters in Degree', 'Masters in Engineering')
AND `e`.`country` IN('India')
AND CAST(pr.property_value AS DECIMAL(8, 2)) >= '4'
AND CAST(pr.property_value AS DECIMAL(8, 2)) <= '5'
AND `p`.`status` IN('1')
AND `u`.`ismain` = 1 AND `u`.`isactive` = 1
AND `mprosetting`.`profileowner` >0
AND `mprosetting`.`ms_usertype` != 'elite'
AND `mprosetting`.`ms_usertype` IN('regular', 'confidential', 'superconfidential')
AND `p`.`status` = 1
GROUP BY `p`.`id`
ORDER BY `p`.`registered_on` DESC
ERROR - 2022-06-28 13:49:33 --> Query error: Expression #7 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'kammavaari_marriage.u.photoname' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `p`.`first_name`, `p`.`last_name`, `p`.`gender`, `p`.`profile_id`, `p`.`id`, `p`.`status`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`
FROM `tbl_primary_info` as `p`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`MS_id`
WHERE `p`.`id` IN('4905')
AND `u`.`ismain` = 1 AND `u`.`isactive` = 1
GROUP BY `u`.`MS_id`
ERROR - 2022-06-28 13:49:39 --> Query error: Expression #7 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'kammavaari_marriage.u.photoname' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `p`.`first_name`, `p`.`last_name`, `p`.`gender`, `p`.`profile_id`, `p`.`id`, `p`.`status`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`
FROM `tbl_primary_info` as `p`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`MS_id`
WHERE `p`.`id` IN('4905')
AND `u`.`ismain` = 1 AND `u`.`isactive` = 1
GROUP BY `u`.`MS_id`
ERROR - 2022-06-28 13:49:41 --> Query error: Expression #12 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'kammavaari_marriage.r.height' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `p`.`first_name`, `p`.`last_name`, `p`.`gender`, `p`.`id`, `p`.`status`, DATE_FORMAT(FROM_DAYS(DATEDIFF(now(), p.dob)), '%Y')+0 as cur_age, `p`.`living_in`, `p`.`profile_id`, `p`.`date`, `p`.`month`, `p`.`year`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `r`.`time_of_birth`, `r`.`place_of_birth`, `r`.`gothram`, `r`.`star`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `e`.`country`, `pa`.`fathers_father_district`, `pa`.`mothers_father_district`, `pa`.`father_mobile`, `pa`.`mother_mobile`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `payment_status`, `elite`, `profileowner`, `ms_usertype`, `pr`.`property_value`, `pr`.`property_type`, `pr`.`property_Desc`
FROM `tbl_primary_info` as `p`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `tbl_parents_info` as `pa` ON `p`.`id`=`pa`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`MS_id`
LEFT JOIN `ms_profilesetting` as `mprosetting` ON `p`.`id`=`mprosetting`.`MS_id`
LEFT JOIN `ms_property_info` as `pr` ON `p`.`id`=`pr`.`ms_id`
WHERE `p`.`gender` = 'male'
AND `r`.`height_cm` >= '167'
AND `r`.`height_cm` <= '183'
AND (YEAR(CURDATE()) - CAST(p.year AS UNSIGNED)) >= '33'
AND (YEAR(CURDATE()) - CAST(p.year AS UNSIGNED)) <= '37'
AND `r`.`marital_status` IN('never_married')
AND `r`.`religion` IN('Hindu')
AND `r`.`mother_tounge` IN('Telugu')
AND `r`.`caste` IN('Kamma')
AND `e`.`heighst_education` IN('Bachelors in Degree', 'Bachelors in Engineering', 'Doctorate/phd', 'Masters in Degree', 'Masters in Engineering')
AND `e`.`country` IN('India')
AND CAST(pr.property_value AS DECIMAL(8, 2)) >= '4'
AND CAST(pr.property_value AS DECIMAL(8, 2)) <= '5'
AND `p`.`status` IN('1')
AND `u`.`ismain` = 1 AND `u`.`isactive` = 1
AND `mprosetting`.`profileowner` >0
AND `mprosetting`.`ms_usertype` != 'elite'
AND `mprosetting`.`ms_usertype` IN('regular', 'confidential', 'superconfidential')
AND `p`.`status` = 1
GROUP BY `p`.`id`
ORDER BY `p`.`registered_on` DESC
ERROR - 2022-06-28 13:50:09 --> Query error: In aggregated query without GROUP BY, expression #2 of SELECT list contains nonaggregated column 'kammavaari_marriage.tbl_profilebattery.photo'; this is incompatible with sql_mode=only_full_group_by - Invalid query: select SUM(IFNULL(`basicdetails`, 0) + IFNULL(`religion`, 0) + IFNULL(`edu_prof`, 0) + IFNULL(`parents`, 0) + IFNULL(`Siblings`, 0) + IFNULL(`photo`, 0)) as total,photo,basicdetails,religion,edu_prof,parents,Siblings from tbl_profilebattery where user_id='2491'
ERROR - 2022-06-28 13:50:11 --> Query error: Expression #1 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'kammavaari_marriage.v.kv_msi_id' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `v`.*, `p`.`gender`, `p`.`id`, `p`.`status`, `p`.`age`, `p`.`living_in`, `p`.`profile_id`, `p`.`first_name`, `last_name`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`
FROM `kv_mysideinterests` as `v`
LEFT JOIN `tbl_primary_info` as `p` ON `p`.`id`=`v`.`kv_msi_interested_on`
LEFT JOIN `tbl_religion_info` as `r` ON `v`.`kv_msi_interested_on`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `v`.`kv_msi_interested_on`=`e`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`MS_id`
INNER JOIN `ms_profilesetting` as `s` ON `p`.`id`=`s`.`ms_id`
WHERE `p`.`status` = 1
AND `v`.`kv_msi_profilefkid` = '3417'
AND `u`.`ismain` = 1
AND `kv_msi_onresstatus` = 'oneside_accepted'
GROUP BY `v`.`kv_msi_interested_on`
ORDER BY `v`.`kv_msi_created_date` DESC
ERROR - 2022-06-28 13:53:51 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:54:22 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:54:29 --> Query error: Expression #1 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'kammavaari_marriage.kv_mysideinterests.kv_msi_id' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT *
FROM `kv_mysideinterests`
JOIN `tbl_admin_data` as `sd` ON `sd`.`id`=`kv_msi_client_rmid`
WHERE (`kv_msi_rmstatus` not in("mms","closeticket","cancel","settled") OR `kv_msi_rmstatus` IS NULL) AND (`kv_msi_client_rmid` = "3" OR `kv_msi_interested_rmid` = "3")
AND `kv_msi_status` = 'sentinterested'
AND `kv_msi_onresstatus` = 'accepted'
GROUP BY `kv_msi_profilefkid`, `kv_msi_interested_on`
ERROR - 2022-06-28 13:54:49 --> Query error: Expression #12 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'kammavaari_marriage.r.height' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `p`.`first_name`, `p`.`last_name`, `p`.`gender`, `p`.`id`, `p`.`status`, DATE_FORMAT(FROM_DAYS(DATEDIFF(now(), p.dob)), '%Y')+0 as cur_age, `p`.`living_in`, `p`.`profile_id`, `p`.`date`, `p`.`month`, `p`.`year`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `r`.`time_of_birth`, `r`.`place_of_birth`, `r`.`gothram`, `r`.`star`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `e`.`country`, `pa`.`fathers_father_district`, `pa`.`mothers_father_district`, `pa`.`father_mobile`, `pa`.`mother_mobile`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `payment_status`, `elite`, `profileowner`, `ms_usertype`, `pr`.`property_value`, `pr`.`property_type`, `pr`.`property_Desc`
FROM `tbl_primary_info` as `p`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `tbl_parents_info` as `pa` ON `p`.`id`=`pa`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`MS_id`
LEFT JOIN `ms_profilesetting` as `mprosetting` ON `p`.`id`=`mprosetting`.`MS_id`
LEFT JOIN `ms_property_info` as `pr` ON `p`.`id`=`pr`.`ms_id`
WHERE `p`.`profile_id` LIKE '%KV964784%' ESCAPE '!'
AND `u`.`ismain` = 1 AND `u`.`isactive` = 1
AND `mprosetting`.`profileowner` >0
AND `mprosetting`.`ms_usertype` != 'elite'
AND `mprosetting`.`ms_usertype` IN('regular', 'confidential', 'superconfidential', 'elite')
AND `p`.`status` = 1
GROUP BY `p`.`id`
ORDER BY `p`.`registered_on` DESC
ERROR - 2022-06-28 13:54:51 --> To Id is not available for User - 401
ERROR - 2022-06-28 13:54:51 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:54:55 --> Query error: Expression #12 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'kammavaari_marriage.r.height' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `p`.`first_name`, `p`.`last_name`, `p`.`gender`, `p`.`id`, `p`.`status`, DATE_FORMAT(FROM_DAYS(DATEDIFF(now(), p.dob)), '%Y')+0 as cur_age, `p`.`living_in`, `p`.`profile_id`, `p`.`date`, `p`.`month`, `p`.`year`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `r`.`time_of_birth`, `r`.`place_of_birth`, `r`.`gothram`, `r`.`star`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `e`.`country`, `pa`.`fathers_father_district`, `pa`.`mothers_father_district`, `pa`.`father_mobile`, `pa`.`mother_mobile`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `payment_status`, `elite`, `profileowner`, `ms_usertype`, `pr`.`property_value`, `pr`.`property_type`, `pr`.`property_Desc`
FROM `tbl_primary_info` as `p`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `tbl_parents_info` as `pa` ON `p`.`id`=`pa`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`MS_id`
LEFT JOIN `ms_profilesetting` as `mprosetting` ON `p`.`id`=`mprosetting`.`MS_id`
LEFT JOIN `ms_property_info` as `pr` ON `p`.`id`=`pr`.`ms_id`
WHERE `p`.`profile_id` LIKE '%KV964784%' ESCAPE '!'
AND `u`.`ismain` = 1 AND `u`.`isactive` = 1
AND `mprosetting`.`profileowner` >0
AND `mprosetting`.`ms_usertype` != 'elite'
AND `mprosetting`.`ms_usertype` IN('regular', 'confidential', 'superconfidential', 'elite')
AND `p`.`status` = 1
GROUP BY `p`.`id`
ORDER BY `p`.`registered_on` DESC
ERROR - 2022-06-28 13:54:57 --> Query error: Expression #7 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'kammavaari_marriage.u.photoname' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `p`.`first_name`, `p`.`last_name`, `p`.`gender`, `p`.`profile_id`, `p`.`id`, `p`.`status`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`
FROM `tbl_primary_info` as `p`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`MS_id`
WHERE `p`.`id` IN('4905')
AND `u`.`ismain` = 1 AND `u`.`isactive` = 1
GROUP BY `u`.`MS_id`
ERROR - 2022-06-28 13:55:01 --> Query error: Expression #7 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'kammavaari_marriage.u.photoname' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `p`.`first_name`, `p`.`last_name`, `p`.`gender`, `p`.`profile_id`, `p`.`id`, `p`.`status`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`
FROM `tbl_primary_info` as `p`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`MS_id`
WHERE `p`.`id` IN('4905')
AND `u`.`ismain` = 1 AND `u`.`isactive` = 1
GROUP BY `u`.`MS_id`
ERROR - 2022-06-28 13:55:16 --> Query error: Expression #7 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'kammavaari_marriage.u.photoname' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `p`.`first_name`, `p`.`last_name`, `p`.`gender`, `p`.`profile_id`, `p`.`id`, `p`.`status`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`
FROM `tbl_primary_info` as `p`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`MS_id`
WHERE `p`.`id` IN('4905')
AND `u`.`ismain` = 1 AND `u`.`isactive` = 1
GROUP BY `u`.`MS_id`
ERROR - 2022-06-28 13:55:17 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:55:33 --> Query error: Expression #7 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'kammavaari_marriage.u.photoname' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `p`.`first_name`, `p`.`last_name`, `p`.`gender`, `p`.`profile_id`, `p`.`id`, `p`.`status`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`
FROM `tbl_primary_info` as `p`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`MS_id`
WHERE `p`.`id` IN('4905')
AND `u`.`ismain` = 1 AND `u`.`isactive` = 1
GROUP BY `u`.`MS_id`
ERROR - 2022-06-28 13:56:07 --> Query error: Expression #7 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'kammavaari_marriage.u.photoname' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `p`.`first_name`, `p`.`last_name`, `p`.`gender`, `p`.`profile_id`, `p`.`id`, `p`.`status`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`
FROM `tbl_primary_info` as `p`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`MS_id`
WHERE `p`.`id` IN('4905')
AND `u`.`ismain` = 1 AND `u`.`isactive` = 1
GROUP BY `u`.`MS_id`
ERROR - 2022-06-28 13:57:19 --> Query error: Expression #12 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'kammavaari_marriage.r.height' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `p`.`first_name`, `p`.`last_name`, `p`.`gender`, `p`.`id`, `p`.`status`, DATE_FORMAT(FROM_DAYS(DATEDIFF(now(), p.dob)), '%Y')+0 as cur_age, `p`.`living_in`, `p`.`profile_id`, `p`.`date`, `p`.`month`, `p`.`year`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `r`.`time_of_birth`, `r`.`place_of_birth`, `r`.`gothram`, `r`.`star`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `e`.`country`, `pa`.`fathers_father_district`, `pa`.`mothers_father_district`, `pa`.`father_mobile`, `pa`.`mother_mobile`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `payment_status`, `elite`, `profileowner`, `ms_usertype`, `pr`.`property_value`, `pr`.`property_type`, `pr`.`property_Desc`
FROM `tbl_primary_info` as `p`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `tbl_parents_info` as `pa` ON `p`.`id`=`pa`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`MS_id`
LEFT JOIN `ms_profilesetting` as `mprosetting` ON `p`.`id`=`mprosetting`.`MS_id`
LEFT JOIN `ms_property_info` as `pr` ON `p`.`id`=`pr`.`ms_id`
WHERE `p`.`profile_id` LIKE '%924065%' ESCAPE '!'
AND `u`.`ismain` = 1 AND `u`.`isactive` = 1
AND `mprosetting`.`profileowner` >0
AND `mprosetting`.`ms_usertype` != 'elite'
AND `mprosetting`.`ms_usertype` IN('regular', 'confidential', 'superconfidential')
AND `p`.`status` = 1
GROUP BY `p`.`id`
ORDER BY `p`.`registered_on` DESC
ERROR - 2022-06-28 13:57:24 --> Query error: Expression #1 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'kammavaari_marriage.kv_mysideinterests.kv_msi_client_rmid' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `kv_msi_client_rmid`, `kv_msi_interested_rmid`, `kv_msi_profilefkid`, `kv_msi_interested_on`, `kv_msi_rmstatus`, `kv_msi_id`, `kv_msi_modified_date`, `sd`.`username`, `sd`.`phone_no`, `sd`.`id` as "staffid", `piinton`.`first_name` as "intonclientfname", `piinton`.`last_name` as "intonclientlname", `piclient`.`first_name` as "clientfname", `piclient`.`last_name` as "clientlname", `kv_msi_created_date`, `piclient`.`profile_id` as "clientprofileid", `piinton`.`profile_id` as "intonclientprofileid"
FROM `kv_mysideinterests`
JOIN `tbl_admin_data` as `sd` ON `sd`.`id`=`kv_msi_interested_rmid`
JOIN `tbl_primary_info` as `piinton` ON `piinton`.`id`=`kv_msi_interested_on`
JOIN `tbl_primary_info` as `piclient` ON `piclient`.`id`=`kv_msi_profilefkid`
WHERE `kv_msi_status` = 'sentinterested'
AND `kv_msi_onresstatus` = 'accepted'
AND `kv_msi_rmstatus` = 'mms'
GROUP BY `kv_msi_profilefkid`, `kv_msi_interested_on`
ORDER BY `kv_msi_created_date` DESC
ERROR - 2022-06-28 13:57:27 --> Query error: Expression #1 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'kammavaari_marriage.kv_mysideinterests.kv_msi_id' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT *
FROM `kv_mysideinterests`
JOIN `tbl_admin_data` as `sd` ON `sd`.`id`=`kv_msi_client_rmid`
WHERE (`kv_msi_rmstatus` not in("mms","closeticket","cancel","settled") OR `kv_msi_rmstatus` IS NULL) AND (`kv_msi_client_rmid` = "20" OR `kv_msi_interested_rmid` = "20")
AND `kv_msi_status` = 'sentinterested'
AND `kv_msi_onresstatus` = 'accepted'
GROUP BY `kv_msi_profilefkid`, `kv_msi_interested_on`
ERROR - 2022-06-28 13:57:27 --> Query error: Expression #7 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'kammavaari_marriage.u.photoname' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `p`.`first_name`, `p`.`last_name`, `p`.`gender`, `p`.`profile_id`, `p`.`id`, `p`.`status`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`
FROM `tbl_primary_info` as `p`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`MS_id`
WHERE `p`.`id` IN('4905')
AND `u`.`ismain` = 1 AND `u`.`isactive` = 1
GROUP BY `u`.`MS_id`
ERROR - 2022-06-28 13:57:31 --> 404 Page Not Found: /index
ERROR - 2022-06-28 13:57:35 --> Query error: Expression #7 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'kammavaari_marriage.u.photoname' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `p`.`first_name`, `p`.`last_name`, `p`.`gender`, `p`.`profile_id`, `p`.`id`, `p`.`status`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`
FROM `tbl_primary_info` as `p`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`MS_id`
WHERE `p`.`id` IN('4905')
AND `u`.`ismain` = 1 AND `u`.`isactive` = 1
GROUP BY `u`.`MS_id`
ERROR - 2022-06-28 13:57:40 --> Query error: Expression #30 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'kammavaari_marriage.r.caste' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `p`.*, `r`.`caste`, `r`.`height`, `r`.`star`, `r`.`time_of_birth`, `r`.`raasi`, `prp`.`property_value`, `e`.`occupation`, `e`.`education_degree`, `e`.`visatype`, `e`.`city`, `e`.`country`, `e`.`annual_income`, `pfs`.`payment_status`, `pfs`.`profilesetting_id` as `pfs_id`, `pfs`.`last_call_updated`, `adm`.`username` as `profile_owner`
FROM `tbl_primary_info` as `p`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `ms_property_info` as `prp` ON `p`.`id`=`prp`.`ms_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `ms_profilesetting` as `pfs` ON `p`.`id`=`pfs`.`ms_id`
LEFT JOIN `tbl_admin_data` as `adm` ON `pfs`.`profileowner`=`adm`.`id`
WHERE `p`.`status` = '1'
AND `adm`.`id` = '20'
GROUP BY `p`.`id`
ERROR - 2022-06-28 13:58:00 --> Query error: Expression #12 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'kammavaari_marriage.r.height' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `p`.`first_name`, `p`.`last_name`, `p`.`gender`, `p`.`id`, `p`.`status`, DATE_FORMAT(FROM_DAYS(DATEDIFF(now(), p.dob)), '%Y')+0 as cur_age, `p`.`living_in`, `p`.`profile_id`, `p`.`date`, `p`.`month`, `p`.`year`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `r`.`time_of_birth`, `r`.`place_of_birth`, `r`.`gothram`, `r`.`star`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `e`.`country`, `pa`.`fathers_father_district`, `pa`.`mothers_father_district`, `pa`.`father_mobile`, `pa`.`mother_mobile`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `payment_status`, `elite`, `profileowner`, `ms_usertype`, `pr`.`property_value`, `pr`.`property_type`, `pr`.`property_Desc`
FROM `tbl_primary_info` as `p`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `tbl_parents_info` as `pa` ON `p`.`id`=`pa`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`MS_id`
LEFT JOIN `ms_profilesetting` as `mprosetting` ON `p`.`id`=`mprosetting`.`MS_id`
LEFT JOIN `ms_property_info` as `pr` ON `p`.`id`=`pr`.`ms_id`
WHERE `p`.`last_name` LIKE '%medarametla%' ESCAPE '!'
AND `u`.`ismain` = 1 AND `u`.`isactive` = 1
AND `mprosetting`.`profileowner` >0
AND `mprosetting`.`ms_usertype` != 'elite'
AND `mprosetting`.`ms_usertype` IN('regular', 'confidential', 'superconfidential')
AND `p`.`status` = 1
GROUP BY `p`.`id`
ORDER BY `p`.`registered_on` DESC
ERROR - 2022-06-28 13:58:01 --> Query error: Expression #7 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'kammavaari_marriage.r.height' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `p`.`gender`, `p`.`id`, `p`.`status`, `p`.`age`, `p`.`living_in`, `p`.`profile_id`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`
FROM `tbl_primary_info` as `p`
INNER JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`MS_id`
INNER JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
INNER JOIN `ms_profilesetting` as `s` ON `p`.`id`=`s`.`ms_id`
WHERE `p`.`gender` = 'female'
AND `r`.`religion` = 'Hindu'
AND `r`.`mother_tounge` = 'Telugu'
AND `p`.`status` = 1
AND `s`.`elite` = 'no'
AND `s`.`ms_usertype` = 'regular'
AND `u`.`ismain` = 1
AND `u`.`photoname` != ''
AND `u`.`applicationphotopath` != ''
GROUP BY `u`.`MS_id`
ORDER BY `registered_on` DESC
 LIMIT 8
ERROR - 2022-06-28 13:58:03 --> Query error: Expression #12 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'kammavaari_marriage.r.height' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `p`.`first_name`, `p`.`last_name`, `p`.`gender`, `p`.`id`, `p`.`status`, DATE_FORMAT(FROM_DAYS(DATEDIFF(now(), p.dob)), '%Y')+0 as cur_age, `p`.`living_in`, `p`.`profile_id`, `p`.`date`, `p`.`month`, `p`.`year`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `r`.`time_of_birth`, `r`.`place_of_birth`, `r`.`gothram`, `r`.`star`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `e`.`country`, `pa`.`fathers_father_district`, `pa`.`mothers_father_district`, `pa`.`father_mobile`, `pa`.`mother_mobile`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `payment_status`, `elite`, `profileowner`, `ms_usertype`, `pr`.`property_value`, `pr`.`property_type`, `pr`.`property_Desc`
FROM `tbl_primary_info` as `p`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `tbl_parents_info` as `pa` ON `p`.`id`=`pa`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`MS_id`
LEFT JOIN `ms_profilesetting` as `mprosetting` ON `p`.`id`=`mprosetting`.`MS_id`
LEFT JOIN `ms_property_info` as `pr` ON `p`.`id`=`pr`.`ms_id`
WHERE `p`.`profile_id` LIKE '%924065%' ESCAPE '!'
AND `u`.`ismain` = 1 AND `u`.`isactive` = 1
AND `mprosetting`.`profileowner` >0
AND `mprosetting`.`ms_usertype` != 'elite'
AND `mprosetting`.`ms_usertype` IN('regular', 'confidential', 'superconfidential')
AND `p`.`status` = 1
GROUP BY `p`.`id`
ORDER BY `p`.`registered_on` DESC
ERROR - 2022-06-28 13:58:13 --> Query error: Expression #7 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'kammavaari_marriage.r.height' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `p`.`gender`, `p`.`id`, `p`.`status`, `p`.`age`, `p`.`living_in`, `p`.`profile_id`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`
FROM `tbl_primary_info` as `p`
INNER JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`MS_id`
INNER JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
INNER JOIN `ms_profilesetting` as `s` ON `p`.`id`=`s`.`ms_id`
WHERE `p`.`gender` = 'male'
AND `r`.`religion` = 'Hindu'
AND `r`.`mother_tounge` = 'Telugu'
AND `p`.`status` = 1
AND `s`.`elite` = 'no'
AND `s`.`ms_usertype` = 'regular'
AND `u`.`ismain` = 1
AND `u`.`photoname` != ''
AND `u`.`applicationphotopath` != ''
GROUP BY `u`.`MS_id`
ORDER BY `registered_on` DESC
 LIMIT 8
ERROR - 2022-06-28 14:00:04 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:00:04 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:01:37 --> Query error: Expression #12 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'kammavaari_marriage.r.height' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `p`.`first_name`, `p`.`last_name`, `p`.`gender`, `p`.`id`, `p`.`status`, DATE_FORMAT(FROM_DAYS(DATEDIFF(now(), p.dob)), '%Y')+0 as cur_age, `p`.`living_in`, `p`.`profile_id`, `p`.`date`, `p`.`month`, `p`.`year`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `r`.`time_of_birth`, `r`.`place_of_birth`, `r`.`gothram`, `r`.`star`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `e`.`country`, `pa`.`fathers_father_district`, `pa`.`mothers_father_district`, `pa`.`father_mobile`, `pa`.`mother_mobile`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `payment_status`, `elite`, `profileowner`, `ms_usertype`, `pr`.`property_value`, `pr`.`property_type`, `pr`.`property_Desc`
FROM `tbl_primary_info` as `p`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `tbl_parents_info` as `pa` ON `p`.`id`=`pa`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`MS_id`
LEFT JOIN `ms_profilesetting` as `mprosetting` ON `p`.`id`=`mprosetting`.`MS_id`
LEFT JOIN `ms_property_info` as `pr` ON `p`.`id`=`pr`.`ms_id`
WHERE `p`.`gender` = 'female'
AND `r`.`height_cm` >= '152'
AND `r`.`height_cm` <= '183'
AND (YEAR(CURDATE()) - CAST(p.year AS UNSIGNED)) >= '18'
AND (YEAR(CURDATE()) - CAST(p.year AS UNSIGNED)) <= '27'
AND `r`.`marital_status` IN('never_married')
AND `r`.`religion` IN('Hindu')
AND `r`.`mother_tounge` IN('Telugu')
AND `r`.`caste` IN('Kamma')
AND `e`.`country` IN('USA')
AND `p`.`status` IN('1')
AND `u`.`ismain` = 1 AND `u`.`isactive` = 1
AND `mprosetting`.`profileowner` >0
AND `mprosetting`.`ms_usertype` != 'elite'
AND `mprosetting`.`ms_usertype` IN('regular', 'confidential', 'superconfidential', 'elite')
AND `p`.`status` = 1
GROUP BY `p`.`id`
ORDER BY `p`.`registered_on` DESC
ERROR - 2022-06-28 14:02:06 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:02:11 --> Query error: Expression #7 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'kammavaari_marriage.r.height' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `p`.`gender`, `p`.`id`, `p`.`status`, `p`.`age`, `p`.`living_in`, `p`.`profile_id`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`
FROM `tbl_primary_info` as `p`
INNER JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`MS_id`
INNER JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
INNER JOIN `ms_profilesetting` as `s` ON `p`.`id`=`s`.`ms_id`
WHERE `p`.`gender` = 'male'
AND `r`.`religion` = 'Hindu'
AND `r`.`mother_tounge` = 'Telugu'
AND `p`.`status` = 1
AND `s`.`elite` = 'no'
AND `s`.`ms_usertype` = 'regular'
AND `u`.`ismain` = 1
AND `u`.`photoname` != ''
AND `u`.`applicationphotopath` != ''
GROUP BY `u`.`MS_id`
ORDER BY `registered_on` DESC
 LIMIT 8
ERROR - 2022-06-28 14:02:13 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:02:26 --> To Id is not available for User - 401
ERROR - 2022-06-28 14:02:28 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:02:33 --> To Id is not available for User - 401
ERROR - 2022-06-28 14:02:34 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:02:45 --> Query error: Expression #12 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'kammavaari_marriage.r.height' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `p`.`first_name`, `p`.`last_name`, `p`.`gender`, `p`.`id`, `p`.`status`, DATE_FORMAT(FROM_DAYS(DATEDIFF(now(), p.dob)), '%Y')+0 as cur_age, `p`.`living_in`, `p`.`profile_id`, `p`.`date`, `p`.`month`, `p`.`year`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `r`.`time_of_birth`, `r`.`place_of_birth`, `r`.`gothram`, `r`.`star`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `e`.`country`, `pa`.`fathers_father_district`, `pa`.`mothers_father_district`, `pa`.`father_mobile`, `pa`.`mother_mobile`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `payment_status`, `elite`, `profileowner`, `ms_usertype`, `pr`.`property_value`, `pr`.`property_type`, `pr`.`property_Desc`
FROM `tbl_primary_info` as `p`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `tbl_parents_info` as `pa` ON `p`.`id`=`pa`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`MS_id`
LEFT JOIN `ms_profilesetting` as `mprosetting` ON `p`.`id`=`mprosetting`.`MS_id`
LEFT JOIN `ms_property_info` as `pr` ON `p`.`id`=`pr`.`ms_id`
WHERE `p`.`gender` = 'female'
AND `r`.`height_cm` >= '152'
AND `r`.`height_cm` <= '183'
AND (YEAR(CURDATE()) - CAST(p.year AS UNSIGNED)) >= '28'
AND (YEAR(CURDATE()) - CAST(p.year AS UNSIGNED)) <= '31'
AND `r`.`marital_status` IN('never_married')
AND `r`.`religion` IN('Hindu')
AND `r`.`mother_tounge` IN('Telugu')
AND `r`.`caste` IN('Kamma')
AND `e`.`country` IN('USA')
AND `p`.`status` IN('1')
AND `u`.`ismain` = 1 AND `u`.`isactive` = 1
AND `mprosetting`.`profileowner` >0
AND `mprosetting`.`ms_usertype` != 'elite'
AND `mprosetting`.`ms_usertype` IN('regular', 'confidential', 'superconfidential', 'elite')
AND `p`.`status` = 1
GROUP BY `p`.`id`
ORDER BY `p`.`registered_on` DESC
ERROR - 2022-06-28 14:03:03 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:03:07 --> Query error: Expression #7 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'kammavaari_marriage.r.height' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `p`.`gender`, `p`.`id`, `p`.`status`, `p`.`age`, `p`.`living_in`, `p`.`profile_id`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`
FROM `tbl_primary_info` as `p`
INNER JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`MS_id`
INNER JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
INNER JOIN `ms_profilesetting` as `s` ON `p`.`id`=`s`.`ms_id`
WHERE `p`.`gender` = 'male'
AND `r`.`religion` = 'Hindu'
AND `r`.`mother_tounge` = 'Telugu'
AND `p`.`status` = 1
AND `s`.`elite` = 'no'
AND `s`.`ms_usertype` = 'regular'
AND `u`.`ismain` = 1
AND `u`.`photoname` != ''
AND `u`.`applicationphotopath` != ''
GROUP BY `u`.`MS_id`
ORDER BY `registered_on` DESC
 LIMIT 8
ERROR - 2022-06-28 14:03:11 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:03:14 --> Query error: Expression #7 of SELECT list is not in GROUP BY clause and contains nonaggregated column 'kammavaari_marriage.r.height' which is not functionally dependent on columns in GROUP BY clause; this is incompatible with sql_mode=only_full_group_by - Invalid query: SELECT `p`.`gender`, `p`.`id`, `p`.`status`, `p`.`age`, `p`.`living_in`, `p`.`profile_id`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`
FROM `tbl_primary_info` as `p`
INNER JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`MS_id`
INNER JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
INNER JOIN `ms_profilesetting` as `s` ON `p`.`id`=`s`.`ms_id`
WHERE `p`.`gender` = 'female'
AND `r`.`religion` = 'Hindu'
AND `r`.`mother_tounge` = 'Telugu'
AND `p`.`status` = 1
AND `s`.`elite` = 'no'
AND `s`.`ms_usertype` = 'regular'
AND `u`.`ismain` = 1
AND `u`.`photoname` != ''
AND `u`.`applicationphotopath` != ''
GROUP BY `u`.`MS_id`
ORDER BY `registered_on` DESC
 LIMIT 8
ERROR - 2022-06-28 14:03:40 --> To Id is not available for User - 401
ERROR - 2022-06-28 14:03:41 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:03:55 --> Query error: In aggregated query without GROUP BY, expression #2 of SELECT list contains nonaggregated column 'kammavaari_marriage.tbl_profilebattery.photo'; this is incompatible with sql_mode=only_full_group_by - Invalid query: select SUM(IFNULL(`basicdetails`, 0) + IFNULL(`religion`, 0) + IFNULL(`edu_prof`, 0) + IFNULL(`parents`, 0) + IFNULL(`Siblings`, 0) + IFNULL(`photo`, 0)) as total,photo,basicdetails,religion,edu_prof,parents,Siblings from tbl_profilebattery where user_id='4843'
ERROR - 2022-06-28 14:04:03 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:04:03 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:04:05 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:04:15 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:04:25 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:04:26 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:04:26 --> Query error: In aggregated query without GROUP BY, expression #2 of SELECT list contains nonaggregated column 'kammavaari_marriage.tbl_profilebattery.photo'; this is incompatible with sql_mode=only_full_group_by - Invalid query: select SUM(IFNULL(`basicdetails`, 0) + IFNULL(`religion`, 0) + IFNULL(`edu_prof`, 0) + IFNULL(`parents`, 0) + IFNULL(`Siblings`, 0) + IFNULL(`photo`, 0)) as total,photo,basicdetails,religion,edu_prof,parents,Siblings from tbl_profilebattery where user_id='4843'
ERROR - 2022-06-28 14:04:42 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:05:00 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:05:30 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:05:48 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:06:19 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:07:28 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:10:16 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:10:56 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:10:58 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:11:20 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:11:49 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:11:56 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:12:54 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:12:59 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:13:07 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:13:09 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:14:04 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:14:28 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:14:29 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:14:29 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:15:18 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:15:24 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:15:35 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:15:55 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:15:56 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:15:58 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:16:05 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:16:39 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:16:54 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:17:32 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:17:47 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:18:56 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:19:32 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:19:39 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:19:51 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT `p`.*, `r`.`caste`, `r`.`height`, `r`.`star`, `r`.`time_of_birth`, `r`.`raasi`, `prp`.`property_value`, `e`.`occupation`, `e`.`education_degree`, `e`.`visatype`, `e`.`city`, `e`.`country`, `e`.`annual_income`, `pfs`.`payment_status`, `pfs`.`profilesetting_id` as `pfs_id`, `pfs`.`last_call_updated`, `adm`.`username` as `profile_owner`
FROM `tbl_primary_info` as `p`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `ms_property_info` as `prp` ON `p`.`id`=`prp`.`ms_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `ms_profilesetting` as `pfs` ON `p`.`id`=`pfs`.`ms_id`
LEFT JOIN `tbl_admin_data` as `adm` ON `pfs`.`profileowner`=`adm`.`id`
WHERE `p`.`gender` = 'male'
AND `r`.`caste` = `Array`
GROUP BY `p`.`id`
ERROR - 2022-06-28 14:20:03 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:20:08 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:20:22 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:20:30 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:20:35 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:21:14 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:22:07 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:27:19 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:32:48 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:33:15 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:34:10 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:34:37 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:35:32 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:39:47 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:40:00 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:40:11 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:40:33 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:42:16 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:44:21 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:45:24 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:47:34 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:48:00 --> To Id is not available for User - 401
ERROR - 2022-06-28 14:48:05 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:48:37 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:49:10 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:49:17 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:49:20 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:49:26 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:49:39 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:49:45 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:50:06 --> 404 Page Not Found: ../modules/dashboard/controllers/Dashboard/images
ERROR - 2022-06-28 14:50:11 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:50:11 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:50:15 --> Query error: Unknown column 'KV932033' in 'where clause' - Invalid query: SELECT *
FROM `ms_profilesetting`
WHERE `ms_id` in(KV932033)
GROUP BY `profileowner`
ERROR - 2022-06-28 14:50:23 --> Query error: Unknown column 'KV912232' in 'where clause' - Invalid query: SELECT *
FROM `ms_profilesetting`
WHERE `ms_id` in(KV912232)
GROUP BY `profileowner`
ERROR - 2022-06-28 14:50:48 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:50:51 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:51:05 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:51:30 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:51:55 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:52:26 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:52:40 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:52:45 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:53:05 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:53:16 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:53:20 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:53:24 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:53:39 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:53:40 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:54:08 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:54:08 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:54:13 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:54:17 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:54:39 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:55:30 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:56:23 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:56:29 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:56:31 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:57:04 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:58:56 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:59:07 --> 404 Page Not Found: /index
ERROR - 2022-06-28 14:59:17 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:01:47 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:02:43 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:03:17 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:03:26 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:04:46 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:05:47 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:06:24 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:07:27 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:07:39 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:08:36 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:09:02 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:10:02 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:10:14 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:10:50 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:10:52 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:10:53 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:10:55 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:11:00 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:11:03 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:11:07 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:11:20 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:11:26 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:11:28 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:11:39 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:11:50 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:12:01 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:12:02 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:12:44 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:12:47 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:13:09 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:14:10 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:14:20 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:14:44 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:15:41 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:15:52 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:16:36 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:16:38 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:16:39 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:16:53 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:17:08 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:17:23 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:17:53 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:17:54 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:18:04 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:18:06 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:18:16 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:18:47 --> To Id is not available for User - 4347
ERROR - 2022-06-28 15:18:48 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:19:20 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:19:46 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:19:47 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:20:02 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:21:21 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:21:22 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:21:29 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:22:05 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:22:12 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:22:20 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:22:52 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:25:01 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:25:57 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:26:52 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:26:59 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:27:15 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:27:36 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:27:39 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:27:54 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:29:25 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:30:07 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:30:48 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:30:53 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:31:27 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:31:34 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-06-28 15:31:44 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:31:51 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:31:53 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:32:09 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:32:13 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:32:19 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:32:21 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:32:23 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:32:31 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:32:39 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:32:39 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:32:40 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:33:02 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:33:14 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:33:18 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:33:32 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:33:41 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:33:59 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:34:02 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:34:03 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:34:04 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:34:08 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:34:13 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:34:17 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:34:35 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:34:46 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:34:51 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:34:55 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:34:55 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:34:57 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:35:01 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:35:01 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:35:03 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:35:12 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:35:24 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:35:36 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:35:46 --> To Id is not available for User - 4631
ERROR - 2022-06-28 15:35:48 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:35:58 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:36:04 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:36:06 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:36:09 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:36:21 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:36:36 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:37:29 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:37:50 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:38:17 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:38:51 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:39:00 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:39:26 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:39:32 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:39:40 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:40:31 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:43:53 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-06-28 15:47:13 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:47:15 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:47:17 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:47:25 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-06-28 15:47:55 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:48:59 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:49:19 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:49:49 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:49:56 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:49:56 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:50:09 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:50:16 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:50:18 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:50:53 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:51:38 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:51:59 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:52:32 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:52:33 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:52:34 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:53:17 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:53:36 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:54:31 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:54:35 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:55:07 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:55:13 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:55:58 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-06-28 15:56:17 --> 404 Page Not Found: /index
ERROR - 2022-06-28 15:56:29 --> 404 Page Not Found: /index
ERROR - 2022-06-28 16:00:16 --> 404 Page Not Found: /index
ERROR - 2022-06-28 16:00:30 --> 404 Page Not Found: /index
ERROR - 2022-06-28 16:00:36 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-06-28 16:02:28 --> 404 Page Not Found: /index
ERROR - 2022-06-28 16:03:15 --> 404 Page Not Found: /index
ERROR - 2022-06-28 16:03:33 --> 404 Page Not Found: /index
ERROR - 2022-06-28 16:04:05 --> 404 Page Not Found: /index
ERROR - 2022-06-28 16:04:09 --> 404 Page Not Found: /index
ERROR - 2022-06-28 16:04:42 --> 404 Page Not Found: /index
ERROR - 2022-06-28 16:08:20 --> 404 Page Not Found: /index
ERROR - 2022-06-28 16:08:59 --> 404 Page Not Found: /index
ERROR - 2022-06-28 16:09:13 --> 404 Page Not Found: /index
ERROR - 2022-06-28 16:09:20 --> 404 Page Not Found: /index
ERROR - 2022-06-28 16:09:54 --> 404 Page Not Found: /index
ERROR - 2022-06-28 16:09:55 --> 404 Page Not Found: /index
ERROR - 2022-06-28 16:10:20 --> 404 Page Not Found: /index
ERROR - 2022-06-28 16:10:48 --> 404 Page Not Found: /index
ERROR - 2022-06-28 16:11:02 --> 404 Page Not Found: /index
ERROR - 2022-06-28 16:11:10 --> 404 Page Not Found: /index
ERROR - 2022-06-28 16:11:28 --> 404 Page Not Found: /index
ERROR - 2022-06-28 16:12:53 --> 404 Page Not Found: /index
ERROR - 2022-06-28 16:13:23 --> 404 Page Not Found: /index
ERROR - 2022-06-28 16:13:49 --> 404 Page Not Found: /index
ERROR - 2022-06-28 16:15:16 --> 404 Page Not Found: /index
ERROR - 2022-06-28 16:16:51 --> 404 Page Not Found: /index
ERROR - 2022-06-28 16:18:21 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-06-28 16:18:59 --> 404 Page Not Found: /index
ERROR - 2022-06-28 16:19:11 --> 404 Page Not Found: /index
ERROR - 2022-06-28 16:19:20 --> 404 Page Not Found: /index
ERROR - 2022-06-28 16:19:50 --> 404 Page Not Found: /index
ERROR - 2022-06-28 16:20:06 --> 404 Page Not Found: /index
ERROR - 2022-06-28 16:20:50 --> 404 Page Not Found: /index
ERROR - 2022-06-28 16:21:06 --> 404 Page Not Found: /index
ERROR - 2022-06-28 16:21:14 --> 404 Page Not Found: /index
ERROR - 2022-06-28 16:21:24 --> 404 Page Not Found: /index
ERROR - 2022-06-28 16:21:28 --> 404 Page Not Found: /index
ERROR - 2022-06-28 16:21:35 --> 404 Page Not Found: /index
ERROR - 2022-06-28 16:21:35 --> 404 Page Not Found: /index
ERROR - 2022-06-28 16:21:40 --> 404 Page Not Found: /index
ERROR - 2022-06-28 16:22:28 --> 404 Page Not Found: /index
ERROR - 2022-06-28 16:23:07 --> 404 Page Not Found: /index
ERROR - 2022-06-28 16:24:57 --> 404 Page Not Found: /index
ERROR - 2022-06-28 16:25:18 --> 404 Page Not Found: /index
ERROR - 2022-06-28 16:25:21 --> 404 Page Not Found: /index
ERROR - 2022-06-28 16:25:34 --> 404 Page Not Found: /index
ERROR - 2022-06-28 16:25:35 --> 404 Page Not Found: /index
ERROR - 2022-06-28 16:25:54 --> 404 Page Not Found: /index
ERROR - 2022-06-28 16:27:12 --> 404 Page Not Found: /index
ERROR - 2022-06-28 16:27:25 --> 404 Page Not Found: /index
ERROR - 2022-06-28 16:27:39 --> 404 Page Not Found: /index
ERROR - 2022-06-28 16:27:56 --> 404 Page Not Found: /index
ERROR - 2022-06-28 16:28:06 --> 404 Page Not Found: /index
ERROR - 2022-06-28 16:29:31 --> 404 Page Not Found: /index
ERROR - 2022-06-28 16:30:15 --> 404 Page Not Found: /index
ERROR - 2022-06-28 16:32:22 --> 404 Page Not Found: /index
ERROR - 2022-06-28 16:33:11 --> 404 Page Not Found: /index
ERROR - 2022-06-28 16:34:07 --> 404 Page Not Found: /index
ERROR - 2022-06-28 16:34:57 --> 404 Page Not Found: /index
ERROR - 2022-06-28 16:35:57 --> 404 Page Not Found: /index
ERROR - 2022-06-28 16:36:32 --> 404 Page Not Found: /index
ERROR - 2022-06-28 16:37:00 --> 404 Page Not Found: /index
ERROR - 2022-06-28 16:37:59 --> 404 Page Not Found: /index
ERROR - 2022-06-28 16:39:34 --> 404 Page Not Found: /index
ERROR - 2022-06-28 16:39:47 --> 404 Page Not Found: /index
ERROR - 2022-06-28 16:42:37 --> 404 Page Not Found: /index
ERROR - 2022-06-28 16:43:59 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-06-28 16:44:08 --> Severity: error --> Exception: Invalid address:  (to):  /home/kammavaari/public_html/application/third_party/phpmailer/src/PHPMailer.php 1092
ERROR - 2022-06-28 16:44:27 --> 404 Page Not Found: /index
ERROR - 2022-06-28 16:44:48 --> 404 Page Not Found: /index
ERROR - 2022-06-28 16:45:22 --> 404 Page Not Found: /index
ERROR - 2022-06-28 16:46:52 --> 404 Page Not Found: /index
ERROR - 2022-06-28 16:46:57 --> 404 Page Not Found: /index
ERROR - 2022-06-28 16:47:24 --> 404 Page Not Found: /index
ERROR - 2022-06-28 16:47:41 --> 404 Page Not Found: /index
ERROR - 2022-06-28 16:48:01 --> 404 Page Not Found: /index
ERROR - 2022-06-28 16:50:04 --> 404 Page Not Found: /index
ERROR - 2022-06-28 16:50:04 --> 404 Page Not Found: /index
ERROR - 2022-06-28 16:50:10 --> 404 Page Not Found: /index
ERROR - 2022-06-28 16:52:34 --> 404 Page Not Found: /index
ERROR - 2022-06-28 16:52:45 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-06-28 16:52:46 --> 404 Page Not Found: /index
ERROR - 2022-06-28 16:52:54 --> 404 Page Not Found: /index
ERROR - 2022-06-28 16:53:00 --> 404 Page Not Found: /index
ERROR - 2022-06-28 16:53:10 --> 404 Page Not Found: /index
ERROR - 2022-06-28 16:53:20 --> 404 Page Not Found: /index
ERROR - 2022-06-28 16:54:41 --> 404 Page Not Found: /index
ERROR - 2022-06-28 16:54:45 --> 404 Page Not Found: /index
ERROR - 2022-06-28 16:55:14 --> 404 Page Not Found: /index
ERROR - 2022-06-28 17:01:33 --> 404 Page Not Found: /index
ERROR - 2022-06-28 17:01:56 --> 404 Page Not Found: /index
ERROR - 2022-06-28 17:02:07 --> 404 Page Not Found: /index
ERROR - 2022-06-28 17:03:54 --> 404 Page Not Found: /index
ERROR - 2022-06-28 17:06:35 --> 404 Page Not Found: /index
ERROR - 2022-06-28 17:06:39 --> 404 Page Not Found: /index
ERROR - 2022-06-28 17:07:35 --> 404 Page Not Found: /index
ERROR - 2022-06-28 17:07:42 --> 404 Page Not Found: /index
ERROR - 2022-06-28 17:08:01 --> 404 Page Not Found: /index
ERROR - 2022-06-28 17:09:52 --> 404 Page Not Found: /index
ERROR - 2022-06-28 17:10:32 --> 404 Page Not Found: /index
ERROR - 2022-06-28 17:13:50 --> 404 Page Not Found: /index
ERROR - 2022-06-28 17:13:52 --> 404 Page Not Found: /index
ERROR - 2022-06-28 17:14:02 --> 404 Page Not Found: /index
ERROR - 2022-06-28 17:14:32 --> 404 Page Not Found: /index
ERROR - 2022-06-28 17:16:01 --> 404 Page Not Found: /index
ERROR - 2022-06-28 17:16:14 --> 404 Page Not Found: /index
ERROR - 2022-06-28 17:16:50 --> To Id is not available for User - �
ERROR - 2022-06-28 17:17:24 --> 404 Page Not Found: /index
ERROR - 2022-06-28 17:18:47 --> 404 Page Not Found: /index
ERROR - 2022-06-28 17:19:02 --> 404 Page Not Found: /index
ERROR - 2022-06-28 17:20:20 --> 404 Page Not Found: /index
ERROR - 2022-06-28 17:21:02 --> 404 Page Not Found: /index
ERROR - 2022-06-28 17:21:19 --> 404 Page Not Found: /index
ERROR - 2022-06-28 17:21:20 --> 404 Page Not Found: /index
ERROR - 2022-06-28 17:21:27 --> 404 Page Not Found: /index
ERROR - 2022-06-28 17:21:36 --> 404 Page Not Found: /index
ERROR - 2022-06-28 17:21:56 --> 404 Page Not Found: /index
ERROR - 2022-06-28 17:22:07 --> 404 Page Not Found: /index
ERROR - 2022-06-28 17:22:12 --> 404 Page Not Found: /index
ERROR - 2022-06-28 17:22:25 --> 404 Page Not Found: /index
ERROR - 2022-06-28 17:22:27 --> 404 Page Not Found: /index
ERROR - 2022-06-28 17:22:40 --> 404 Page Not Found: /index
ERROR - 2022-06-28 17:23:06 --> 404 Page Not Found: /index
ERROR - 2022-06-28 17:23:13 --> 404 Page Not Found: /index
ERROR - 2022-06-28 17:23:24 --> 404 Page Not Found: /index
ERROR - 2022-06-28 17:24:59 --> 404 Page Not Found: /index
ERROR - 2022-06-28 17:25:46 --> 404 Page Not Found: /index
ERROR - 2022-06-28 17:26:31 --> 404 Page Not Found: /index
ERROR - 2022-06-28 17:27:57 --> 404 Page Not Found: /index
ERROR - 2022-06-28 17:31:14 --> 404 Page Not Found: /index
ERROR - 2022-06-28 17:32:09 --> 404 Page Not Found: /index
ERROR - 2022-06-28 17:32:45 --> 404 Page Not Found: /index
ERROR - 2022-06-28 17:34:46 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-06-28 17:34:54 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-06-28 17:35:01 --> 404 Page Not Found: ../modules/admin/controllers/Admin/null
ERROR - 2022-06-28 17:35:37 --> 404 Page Not Found: /index
ERROR - 2022-06-28 17:35:48 --> 404 Page Not Found: /index
ERROR - 2022-06-28 17:37:23 --> 404 Page Not Found: /index
ERROR - 2022-06-28 17:37:30 --> 404 Page Not Found: /index
ERROR - 2022-06-28 17:38:42 --> 404 Page Not Found: /index
ERROR - 2022-06-28 17:39:17 --> 404 Page Not Found: /index
ERROR - 2022-06-28 17:39:24 --> 404 Page Not Found: /index
ERROR - 2022-06-28 17:40:49 --> 404 Page Not Found: /index
ERROR - 2022-06-28 17:42:28 --> 404 Page Not Found: ../modules/admin/controllers/Admin/Updatepayment
ERROR - 2022-06-28 17:42:43 --> 404 Page Not Found: /index
ERROR - 2022-06-28 17:42:52 --> 404 Page Not Found: /index
ERROR - 2022-06-28 17:43:49 --> 404 Page Not Found: /index
ERROR - 2022-06-28 17:43:51 --> 404 Page Not Found: /index
ERROR - 2022-06-28 17:44:31 --> 404 Page Not Found: /index
ERROR - 2022-06-28 17:47:40 --> 404 Page Not Found: /index
ERROR - 2022-06-28 17:50:08 --> 404 Page Not Found: /index
ERROR - 2022-06-28 17:50:27 --> 404 Page Not Found: /index
ERROR - 2022-06-28 17:50:35 --> 404 Page Not Found: /index
ERROR - 2022-06-28 17:50:48 --> 404 Page Not Found: /index
ERROR - 2022-06-28 17:51:16 --> To Id is not available for User - 4737
ERROR - 2022-06-28 17:51:19 --> 404 Page Not Found: /index
ERROR - 2022-06-28 17:51:31 --> 404 Page Not Found: /index
ERROR - 2022-06-28 17:52:01 --> 404 Page Not Found: /index
ERROR - 2022-06-28 17:52:25 --> To Id is not available for User - 4737
ERROR - 2022-06-28 17:52:27 --> 404 Page Not Found: /index
ERROR - 2022-06-28 17:52:34 --> 404 Page Not Found: /index
ERROR - 2022-06-28 17:53:10 --> 404 Page Not Found: /index
ERROR - 2022-06-28 17:53:40 --> 404 Page Not Found: /index
ERROR - 2022-06-28 17:56:46 --> 404 Page Not Found: /index
ERROR - 2022-06-28 17:57:14 --> 404 Page Not Found: /index
ERROR - 2022-06-28 17:57:16 --> 404 Page Not Found: /index
ERROR - 2022-06-28 17:57:18 --> 404 Page Not Found: /index
ERROR - 2022-06-28 17:57:18 --> 404 Page Not Found: /index
ERROR - 2022-06-28 17:57:19 --> 404 Page Not Found: /index
ERROR - 2022-06-28 17:58:13 --> 404 Page Not Found: /index
ERROR - 2022-06-28 17:58:31 --> 404 Page Not Found: /index
ERROR - 2022-06-28 17:58:49 --> 404 Page Not Found: /index
ERROR - 2022-06-28 17:59:15 --> 404 Page Not Found: /index
ERROR - 2022-06-28 17:59:27 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:00:53 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:01:31 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:01:55 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:02:05 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:02:26 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:03:43 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:06:02 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:06:05 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:06:10 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:07:13 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:08:42 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:08:58 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:08:58 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:09:24 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:09:47 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:09:56 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:09:56 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:10:58 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:11:01 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:11:22 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:11:47 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:11:53 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:12:14 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:12:19 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:12:27 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:12:27 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:13:10 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:13:39 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:13:56 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:15:22 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:15:32 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:15:52 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:16:08 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:16:12 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:17:05 --> 404 Page Not Found: ../modules/dashboard/controllers/Dashboard/images
ERROR - 2022-06-28 18:18:10 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:19:15 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:19:40 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:21:07 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:22:31 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:23:18 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:23:23 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:23:32 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:23:38 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:23:41 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:23:43 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:24:00 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:25:05 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:26:14 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:26:39 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:28:19 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:29:09 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:29:27 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:29:39 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:29:57 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:30:09 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:30:16 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:30:32 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:30:44 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:30:53 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:31:07 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:31:28 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:31:45 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:31:54 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:31:57 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:32:24 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:32:28 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:32:34 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:33:04 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:33:09 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:34:26 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:34:42 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:35:02 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:35:27 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:36:17 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:36:43 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:36:47 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:37:20 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:37:28 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:37:46 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:37:48 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:38:26 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:38:33 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:38:34 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:38:51 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:39:06 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:39:16 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:39:28 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:44:52 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:45:04 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:47:39 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:48:49 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:49:00 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:56:07 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:58:54 --> 404 Page Not Found: /index
ERROR - 2022-06-28 18:59:02 --> 404 Page Not Found: /index
ERROR - 2022-06-28 19:01:33 --> 404 Page Not Found: /index
ERROR - 2022-06-28 19:05:20 --> To Id is not available for User - 1278
ERROR - 2022-06-28 19:05:21 --> 404 Page Not Found: /index
ERROR - 2022-06-28 19:06:06 --> 404 Page Not Found: /index
ERROR - 2022-06-28 19:06:06 --> 404 Page Not Found: /index
ERROR - 2022-06-28 19:08:25 --> 404 Page Not Found: /index
ERROR - 2022-06-28 19:08:25 --> 404 Page Not Found: /index
ERROR - 2022-06-28 19:08:59 --> 404 Page Not Found: /index
ERROR - 2022-06-28 19:09:00 --> 404 Page Not Found: /index
ERROR - 2022-06-28 19:09:09 --> 404 Page Not Found: /index
ERROR - 2022-06-28 19:09:11 --> 404 Page Not Found: /index
ERROR - 2022-06-28 19:10:20 --> 404 Page Not Found: /index
ERROR - 2022-06-28 19:11:18 --> 404 Page Not Found: /index
ERROR - 2022-06-28 19:11:38 --> 404 Page Not Found: /index
ERROR - 2022-06-28 19:13:41 --> 404 Page Not Found: /index
ERROR - 2022-06-28 19:14:38 --> 404 Page Not Found: /index
ERROR - 2022-06-28 19:14:47 --> 404 Page Not Found: /index
ERROR - 2022-06-28 19:14:52 --> 404 Page Not Found: /index
ERROR - 2022-06-28 19:15:34 --> 404 Page Not Found: /index
ERROR - 2022-06-28 19:16:12 --> 404 Page Not Found: /index
ERROR - 2022-06-28 19:16:12 --> 404 Page Not Found: /index
ERROR - 2022-06-28 19:16:13 --> 404 Page Not Found: /index
ERROR - 2022-06-28 19:16:13 --> 404 Page Not Found: /index
ERROR - 2022-06-28 19:16:14 --> 404 Page Not Found: /index
ERROR - 2022-06-28 19:16:14 --> 404 Page Not Found: /index
ERROR - 2022-06-28 19:16:14 --> 404 Page Not Found: /index
ERROR - 2022-06-28 19:16:14 --> 404 Page Not Found: /index
ERROR - 2022-06-28 19:16:28 --> 404 Page Not Found: /index
ERROR - 2022-06-28 19:19:55 --> 404 Page Not Found: /index
ERROR - 2022-06-28 19:22:37 --> 404 Page Not Found: /index
ERROR - 2022-06-28 19:23:56 --> 404 Page Not Found: /index
ERROR - 2022-06-28 19:24:11 --> 404 Page Not Found: /index
ERROR - 2022-06-28 19:24:13 --> 404 Page Not Found: /index
ERROR - 2022-06-28 19:24:45 --> 404 Page Not Found: /index
ERROR - 2022-06-28 19:26:25 --> 404 Page Not Found: /index
ERROR - 2022-06-28 19:27:35 --> 404 Page Not Found: /index
ERROR - 2022-06-28 19:27:46 --> 404 Page Not Found: /index
ERROR - 2022-06-28 19:27:53 --> 404 Page Not Found: /index
ERROR - 2022-06-28 19:28:47 --> 404 Page Not Found: /index
ERROR - 2022-06-28 19:29:48 --> 404 Page Not Found: /index
ERROR - 2022-06-28 19:30:47 --> 404 Page Not Found: /index
ERROR - 2022-06-28 19:31:15 --> 404 Page Not Found: /index
ERROR - 2022-06-28 19:31:42 --> 404 Page Not Found: /index
ERROR - 2022-06-28 19:35:15 --> 404 Page Not Found: /index
ERROR - 2022-06-28 19:38:56 --> 404 Page Not Found: /index
ERROR - 2022-06-28 19:40:10 --> 404 Page Not Found: /index
ERROR - 2022-06-28 19:40:50 --> 404 Page Not Found: /index
ERROR - 2022-06-28 19:41:00 --> 404 Page Not Found: /index
ERROR - 2022-06-28 19:41:22 --> 404 Page Not Found: /index
ERROR - 2022-06-28 19:45:45 --> To Id is not available for User - 401
ERROR - 2022-06-28 19:45:46 --> 404 Page Not Found: /index
ERROR - 2022-06-28 19:46:23 --> 404 Page Not Found: /index
ERROR - 2022-06-28 19:46:43 --> 404 Page Not Found: /index
ERROR - 2022-06-28 19:46:43 --> 404 Page Not Found: /index
ERROR - 2022-06-28 19:46:51 --> 404 Page Not Found: /index
ERROR - 2022-06-28 19:47:06 --> 404 Page Not Found: /index
ERROR - 2022-06-28 19:47:32 --> 404 Page Not Found: /index
ERROR - 2022-06-28 19:50:01 --> 404 Page Not Found: /index
ERROR - 2022-06-28 19:50:22 --> 404 Page Not Found: /index
ERROR - 2022-06-28 19:50:31 --> 404 Page Not Found: /index
ERROR - 2022-06-28 19:51:41 --> 404 Page Not Found: /index
ERROR - 2022-06-28 19:53:36 --> 404 Page Not Found: /index
ERROR - 2022-06-28 19:53:43 --> 404 Page Not Found: /index
ERROR - 2022-06-28 19:53:46 --> 404 Page Not Found: /index
ERROR - 2022-06-28 19:54:09 --> 404 Page Not Found: /index
ERROR - 2022-06-28 19:54:50 --> 404 Page Not Found: /index
ERROR - 2022-06-28 19:54:51 --> 404 Page Not Found: /index
ERROR - 2022-06-28 19:54:52 --> 404 Page Not Found: /index
ERROR - 2022-06-28 19:56:47 --> 404 Page Not Found: /index
ERROR - 2022-06-28 19:56:52 --> 404 Page Not Found: /index
ERROR - 2022-06-28 19:56:55 --> 404 Page Not Found: /index
ERROR - 2022-06-28 20:01:41 --> 404 Page Not Found: /index
ERROR - 2022-06-28 20:01:56 --> 404 Page Not Found: /index
ERROR - 2022-06-28 20:02:11 --> 404 Page Not Found: /index
ERROR - 2022-06-28 20:02:25 --> 404 Page Not Found: /index
ERROR - 2022-06-28 20:02:32 --> 404 Page Not Found: /index
ERROR - 2022-06-28 20:02:38 --> 404 Page Not Found: /index
ERROR - 2022-06-28 20:03:25 --> 404 Page Not Found: /index
ERROR - 2022-06-28 20:04:16 --> 404 Page Not Found: /index
ERROR - 2022-06-28 20:04:50 --> 404 Page Not Found: /index
ERROR - 2022-06-28 20:05:18 --> 404 Page Not Found: /index
ERROR - 2022-06-28 20:05:34 --> 404 Page Not Found: /index
ERROR - 2022-06-28 20:05:49 --> 404 Page Not Found: /index
ERROR - 2022-06-28 20:05:56 --> 404 Page Not Found: /index
ERROR - 2022-06-28 20:06:17 --> 404 Page Not Found: /index
ERROR - 2022-06-28 20:06:26 --> 404 Page Not Found: /index
ERROR - 2022-06-28 20:06:39 --> 404 Page Not Found: /index
ERROR - 2022-06-28 20:06:40 --> 404 Page Not Found: /index
ERROR - 2022-06-28 20:07:26 --> 404 Page Not Found: /index
ERROR - 2022-06-28 20:07:39 --> 404 Page Not Found: /index
ERROR - 2022-06-28 20:08:18 --> 404 Page Not Found: /index
ERROR - 2022-06-28 20:08:19 --> 404 Page Not Found: /index
ERROR - 2022-06-28 20:08:59 --> 404 Page Not Found: /index
ERROR - 2022-06-28 20:09:34 --> 404 Page Not Found: /index
ERROR - 2022-06-28 20:12:22 --> 404 Page Not Found: /index
ERROR - 2022-06-28 20:12:58 --> 404 Page Not Found: /index
ERROR - 2022-06-28 20:16:34 --> 404 Page Not Found: /index
ERROR - 2022-06-28 20:20:40 --> 404 Page Not Found: /index
ERROR - 2022-06-28 20:23:31 --> 404 Page Not Found: /index
ERROR - 2022-06-28 20:24:12 --> 404 Page Not Found: /index
ERROR - 2022-06-28 20:24:53 --> 404 Page Not Found: /index
ERROR - 2022-06-28 20:26:00 --> 404 Page Not Found: /index
ERROR - 2022-06-28 20:26:17 --> 404 Page Not Found: /index
ERROR - 2022-06-28 20:27:27 --> 404 Page Not Found: /index
ERROR - 2022-06-28 20:27:45 --> 404 Page Not Found: /index
ERROR - 2022-06-28 20:28:02 --> 404 Page Not Found: /index
ERROR - 2022-06-28 20:28:18 --> 404 Page Not Found: /index
ERROR - 2022-06-28 20:29:00 --> 404 Page Not Found: /index
ERROR - 2022-06-28 20:29:03 --> 404 Page Not Found: /index
ERROR - 2022-06-28 20:29:16 --> 404 Page Not Found: /index
ERROR - 2022-06-28 20:29:36 --> 404 Page Not Found: /index
ERROR - 2022-06-28 20:29:40 --> 404 Page Not Found: /index
ERROR - 2022-06-28 20:34:15 --> 404 Page Not Found: /index
ERROR - 2022-06-28 20:37:04 --> 404 Page Not Found: /index
ERROR - 2022-06-28 20:38:28 --> 404 Page Not Found: /index
ERROR - 2022-06-28 20:39:19 --> 404 Page Not Found: /index
ERROR - 2022-06-28 20:40:20 --> 404 Page Not Found: /index
ERROR - 2022-06-28 20:40:52 --> 404 Page Not Found: /index
ERROR - 2022-06-28 20:42:07 --> 404 Page Not Found: /index
ERROR - 2022-06-28 20:42:18 --> 404 Page Not Found: /index
ERROR - 2022-06-28 20:47:36 --> 404 Page Not Found: /index
ERROR - 2022-06-28 20:50:32 --> 404 Page Not Found: /index
ERROR - 2022-06-28 20:51:15 --> 404 Page Not Found: /index
ERROR - 2022-06-28 20:51:15 --> 404 Page Not Found: /index
ERROR - 2022-06-28 20:51:16 --> 404 Page Not Found: /index
ERROR - 2022-06-28 20:51:16 --> 404 Page Not Found: /index
ERROR - 2022-06-28 20:51:16 --> 404 Page Not Found: /index
ERROR - 2022-06-28 20:51:16 --> 404 Page Not Found: /index
ERROR - 2022-06-28 20:51:16 --> 404 Page Not Found: /index
ERROR - 2022-06-28 20:51:17 --> 404 Page Not Found: /index
ERROR - 2022-06-28 20:51:17 --> 404 Page Not Found: /index
ERROR - 2022-06-28 20:51:17 --> 404 Page Not Found: /index
ERROR - 2022-06-28 20:51:17 --> 404 Page Not Found: /index
ERROR - 2022-06-28 20:51:18 --> 404 Page Not Found: /index
ERROR - 2022-06-28 20:51:18 --> 404 Page Not Found: /index
ERROR - 2022-06-28 20:51:18 --> 404 Page Not Found: /index
ERROR - 2022-06-28 20:51:18 --> 404 Page Not Found: /index
ERROR - 2022-06-28 20:51:18 --> 404 Page Not Found: /index
ERROR - 2022-06-28 20:51:19 --> 404 Page Not Found: /index
ERROR - 2022-06-28 20:51:19 --> 404 Page Not Found: /index
ERROR - 2022-06-28 20:51:33 --> 404 Page Not Found: /index
ERROR - 2022-06-28 20:52:21 --> 404 Page Not Found: /index
ERROR - 2022-06-28 20:54:06 --> 404 Page Not Found: /index
ERROR - 2022-06-28 20:54:07 --> 404 Page Not Found: /index
ERROR - 2022-06-28 20:54:51 --> 404 Page Not Found: /index
ERROR - 2022-06-28 20:57:55 --> 404 Page Not Found: /index
ERROR - 2022-06-28 20:57:59 --> 404 Page Not Found: /index
ERROR - 2022-06-28 20:58:02 --> 404 Page Not Found: /index
ERROR - 2022-06-28 20:58:39 --> 404 Page Not Found: /index
ERROR - 2022-06-28 20:59:05 --> 404 Page Not Found: /index
ERROR - 2022-06-28 20:59:18 --> 404 Page Not Found: /index
ERROR - 2022-06-28 20:59:20 --> 404 Page Not Found: /index
ERROR - 2022-06-28 20:59:41 --> 404 Page Not Found: /index
ERROR - 2022-06-28 21:00:23 --> 404 Page Not Found: /index
ERROR - 2022-06-28 21:00:57 --> 404 Page Not Found: /index
ERROR - 2022-06-28 21:02:01 --> 404 Page Not Found: /index
ERROR - 2022-06-28 21:02:05 --> 404 Page Not Found: /index
ERROR - 2022-06-28 21:02:53 --> 404 Page Not Found: /index
ERROR - 2022-06-28 21:03:10 --> 404 Page Not Found: /index
ERROR - 2022-06-28 21:04:05 --> 404 Page Not Found: /index
ERROR - 2022-06-28 21:04:50 --> 404 Page Not Found: /index
ERROR - 2022-06-28 21:04:58 --> 404 Page Not Found: /index
ERROR - 2022-06-28 21:05:55 --> 404 Page Not Found: /index
ERROR - 2022-06-28 21:06:26 --> 404 Page Not Found: /index
ERROR - 2022-06-28 21:07:06 --> 404 Page Not Found: /index
ERROR - 2022-06-28 21:07:22 --> 404 Page Not Found: /index
ERROR - 2022-06-28 21:07:43 --> 404 Page Not Found: /index
ERROR - 2022-06-28 21:07:56 --> 404 Page Not Found: /index
ERROR - 2022-06-28 21:08:33 --> 404 Page Not Found: /index
ERROR - 2022-06-28 21:10:06 --> 404 Page Not Found: /index
ERROR - 2022-06-28 21:10:33 --> 404 Page Not Found: /index
ERROR - 2022-06-28 21:10:50 --> 404 Page Not Found: /index
ERROR - 2022-06-28 21:10:54 --> 404 Page Not Found: /index
ERROR - 2022-06-28 21:11:11 --> 404 Page Not Found: /index
ERROR - 2022-06-28 21:11:22 --> 404 Page Not Found: /index
ERROR - 2022-06-28 21:11:48 --> 404 Page Not Found: /index
ERROR - 2022-06-28 21:11:59 --> 404 Page Not Found: /index
ERROR - 2022-06-28 21:12:01 --> 404 Page Not Found: /index
ERROR - 2022-06-28 21:12:22 --> 404 Page Not Found: /index
ERROR - 2022-06-28 21:12:41 --> 404 Page Not Found: /index
ERROR - 2022-06-28 21:12:53 --> 404 Page Not Found: /index
ERROR - 2022-06-28 21:13:46 --> 404 Page Not Found: /index
ERROR - 2022-06-28 21:13:48 --> 404 Page Not Found: /index
ERROR - 2022-06-28 21:14:20 --> 404 Page Not Found: /index
ERROR - 2022-06-28 21:14:45 --> 404 Page Not Found: /index
ERROR - 2022-06-28 21:15:09 --> 404 Page Not Found: /index
ERROR - 2022-06-28 21:15:30 --> 404 Page Not Found: /index
ERROR - 2022-06-28 21:15:43 --> 404 Page Not Found: /index
ERROR - 2022-06-28 21:15:50 --> 404 Page Not Found: /index
ERROR - 2022-06-28 21:18:02 --> 404 Page Not Found: /index
ERROR - 2022-06-28 21:18:37 --> 404 Page Not Found: /index
ERROR - 2022-06-28 21:19:48 --> 404 Page Not Found: /index
ERROR - 2022-06-28 21:20:45 --> 404 Page Not Found: /index
ERROR - 2022-06-28 21:22:18 --> 404 Page Not Found: /index
ERROR - 2022-06-28 21:22:32 --> 404 Page Not Found: /index
ERROR - 2022-06-28 21:24:18 --> 404 Page Not Found: /index
ERROR - 2022-06-28 21:24:49 --> 404 Page Not Found: /index
ERROR - 2022-06-28 21:26:20 --> 404 Page Not Found: /index
ERROR - 2022-06-28 21:30:30 --> 404 Page Not Found: /index
ERROR - 2022-06-28 21:32:37 --> 404 Page Not Found: /index
ERROR - 2022-06-28 21:34:01 --> 404 Page Not Found: /index
ERROR - 2022-06-28 21:34:09 --> 404 Page Not Found: /index
ERROR - 2022-06-28 21:35:23 --> 404 Page Not Found: /index
ERROR - 2022-06-28 21:40:33 --> 404 Page Not Found: /index
ERROR - 2022-06-28 21:40:48 --> 404 Page Not Found: /index
ERROR - 2022-06-28 21:41:25 --> 404 Page Not Found: /index
ERROR - 2022-06-28 21:43:40 --> 404 Page Not Found: /index
ERROR - 2022-06-28 21:43:40 --> 404 Page Not Found: /index
ERROR - 2022-06-28 21:43:50 --> 404 Page Not Found: /index
ERROR - 2022-06-28 21:43:51 --> 404 Page Not Found: /index
ERROR - 2022-06-28 21:44:04 --> 404 Page Not Found: /index
ERROR - 2022-06-28 21:44:44 --> 404 Page Not Found: /index
ERROR - 2022-06-28 21:44:57 --> 404 Page Not Found: /index
ERROR - 2022-06-28 21:45:24 --> To Id is not available for User - 401
ERROR - 2022-06-28 21:45:25 --> 404 Page Not Found: /index
ERROR - 2022-06-28 21:45:30 --> 404 Page Not Found: /index
ERROR - 2022-06-28 21:45:31 --> 404 Page Not Found: /index
ERROR - 2022-06-28 21:45:34 --> 404 Page Not Found: /index
ERROR - 2022-06-28 21:45:44 --> 404 Page Not Found: /index
ERROR - 2022-06-28 21:45:51 --> 404 Page Not Found: /index
ERROR - 2022-06-28 21:46:48 --> 404 Page Not Found: /index
ERROR - 2022-06-28 21:47:25 --> 404 Page Not Found: /index
ERROR - 2022-06-28 21:47:42 --> 404 Page Not Found: /index
ERROR - 2022-06-28 21:47:58 --> 404 Page Not Found: /index
ERROR - 2022-06-28 21:49:46 --> 404 Page Not Found: /index
ERROR - 2022-06-28 21:55:12 --> 404 Page Not Found: /index
ERROR - 2022-06-28 21:56:53 --> 404 Page Not Found: /index
ERROR - 2022-06-28 22:07:57 --> 404 Page Not Found: /index
ERROR - 2022-06-28 22:09:04 --> 404 Page Not Found: /index
ERROR - 2022-06-28 22:10:13 --> 404 Page Not Found: /index
ERROR - 2022-06-28 22:11:49 --> 404 Page Not Found: /index
ERROR - 2022-06-28 22:12:08 --> 404 Page Not Found: /index
ERROR - 2022-06-28 22:16:50 --> 404 Page Not Found: /index
ERROR - 2022-06-28 22:16:54 --> 404 Page Not Found: /index
ERROR - 2022-06-28 22:18:59 --> 404 Page Not Found: /index
ERROR - 2022-06-28 22:19:00 --> 404 Page Not Found: /index
ERROR - 2022-06-28 22:25:17 --> 404 Page Not Found: /index
ERROR - 2022-06-28 22:28:44 --> 404 Page Not Found: /index
ERROR - 2022-06-28 22:33:27 --> 404 Page Not Found: /index
ERROR - 2022-06-28 22:33:33 --> 404 Page Not Found: /index
ERROR - 2022-06-28 22:33:48 --> 404 Page Not Found: /index
ERROR - 2022-06-28 22:34:20 --> 404 Page Not Found: /index
ERROR - 2022-06-28 22:46:22 --> 404 Page Not Found: /index
ERROR - 2022-06-28 22:47:28 --> 404 Page Not Found: /index
ERROR - 2022-06-28 22:48:22 --> 404 Page Not Found: /index
ERROR - 2022-06-28 22:52:28 --> 404 Page Not Found: /index
ERROR - 2022-06-28 22:52:28 --> 404 Page Not Found: /index
ERROR - 2022-06-28 22:52:29 --> 404 Page Not Found: /index
ERROR - 2022-06-28 22:52:29 --> 404 Page Not Found: /index
ERROR - 2022-06-28 23:02:36 --> 404 Page Not Found: /index
ERROR - 2022-06-28 23:12:17 --> 404 Page Not Found: /index
ERROR - 2022-06-28 23:15:31 --> 404 Page Not Found: /index
ERROR - 2022-06-28 23:29:22 --> 404 Page Not Found: /index
ERROR - 2022-06-28 23:32:22 --> 404 Page Not Found: /index
ERROR - 2022-06-28 23:33:01 --> 404 Page Not Found: /index
ERROR - 2022-06-28 23:35:21 --> 404 Page Not Found: /index
ERROR - 2022-06-28 23:37:26 --> 404 Page Not Found: /index
ERROR - 2022-06-28 23:41:48 --> 404 Page Not Found: /index
ERROR - 2022-06-28 23:41:56 --> 404 Page Not Found: /index
ERROR - 2022-06-28 23:42:01 --> 404 Page Not Found: /index
ERROR - 2022-06-28 23:42:05 --> 404 Page Not Found: /index
ERROR - 2022-06-28 23:42:17 --> 404 Page Not Found: /index
ERROR - 2022-06-28 23:42:32 --> 404 Page Not Found: /index
ERROR - 2022-06-28 23:42:53 --> 404 Page Not Found: /index
ERROR - 2022-06-28 23:45:29 --> 404 Page Not Found: /index
ERROR - 2022-06-28 23:50:44 --> 404 Page Not Found: /index
ERROR - 2022-06-28 23:54:18 --> 404 Page Not Found: /index
