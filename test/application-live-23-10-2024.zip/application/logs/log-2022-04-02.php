<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2022-04-02 00:00:32 --> 404 Page Not Found: /index
ERROR - 2022-04-02 00:01:52 --> 404 Page Not Found: /index
ERROR - 2022-04-02 00:20:23 --> 404 Page Not Found: /index
ERROR - 2022-04-02 00:47:04 --> 404 Page Not Found: /index
ERROR - 2022-04-02 00:48:58 --> 404 Page Not Found: /index
ERROR - 2022-04-02 00:51:10 --> 404 Page Not Found: /index
ERROR - 2022-04-02 01:05:46 --> 404 Page Not Found: /index
ERROR - 2022-04-02 01:06:14 --> 404 Page Not Found: /index
ERROR - 2022-04-02 01:15:26 --> 404 Page Not Found: /index
ERROR - 2022-04-02 02:07:10 --> 404 Page Not Found: /index
ERROR - 2022-04-02 02:07:29 --> 404 Page Not Found: /index
ERROR - 2022-04-02 02:07:29 --> 404 Page Not Found: /index
ERROR - 2022-04-02 02:07:29 --> 404 Page Not Found: /index
ERROR - 2022-04-02 02:07:29 --> 404 Page Not Found: /index
ERROR - 2022-04-02 02:07:29 --> 404 Page Not Found: /index
ERROR - 2022-04-02 02:07:29 --> 404 Page Not Found: /index
ERROR - 2022-04-02 02:07:32 --> 404 Page Not Found: /index
ERROR - 2022-04-02 02:11:22 --> 404 Page Not Found: /index
ERROR - 2022-04-02 02:18:06 --> 404 Page Not Found: /index
ERROR - 2022-04-02 02:28:28 --> 404 Page Not Found: /index
ERROR - 2022-04-02 02:28:29 --> 404 Page Not Found: /index
ERROR - 2022-04-02 02:28:30 --> 404 Page Not Found: /index
ERROR - 2022-04-02 02:28:36 --> 404 Page Not Found: /index
ERROR - 2022-04-02 02:28:42 --> 404 Page Not Found: /index
ERROR - 2022-04-02 02:28:43 --> 404 Page Not Found: /index
ERROR - 2022-04-02 02:28:44 --> 404 Page Not Found: /index
ERROR - 2022-04-02 02:28:45 --> 404 Page Not Found: /index
ERROR - 2022-04-02 02:28:45 --> 404 Page Not Found: /index
ERROR - 2022-04-02 02:28:46 --> 404 Page Not Found: /index
ERROR - 2022-04-02 02:28:47 --> 404 Page Not Found: /index
ERROR - 2022-04-02 02:28:53 --> 404 Page Not Found: /index
ERROR - 2022-04-02 02:28:53 --> 404 Page Not Found: /index
ERROR - 2022-04-02 02:28:54 --> 404 Page Not Found: /index
ERROR - 2022-04-02 02:28:55 --> 404 Page Not Found: /index
ERROR - 2022-04-02 02:29:01 --> 404 Page Not Found: /index
ERROR - 2022-04-02 02:29:07 --> 404 Page Not Found: /index
ERROR - 2022-04-02 02:29:08 --> 404 Page Not Found: /index
ERROR - 2022-04-02 02:29:09 --> 404 Page Not Found: /index
ERROR - 2022-04-02 02:29:10 --> 404 Page Not Found: /index
ERROR - 2022-04-02 03:09:05 --> 404 Page Not Found: /index
ERROR - 2022-04-02 03:09:19 --> 404 Page Not Found: /index
ERROR - 2022-04-02 03:23:49 --> 404 Page Not Found: ../modules/admin/controllers/Admin_ap/eliteprofiles
ERROR - 2022-04-02 03:43:09 --> 404 Page Not Found: /index
ERROR - 2022-04-02 03:52:31 --> 404 Page Not Found: /index
ERROR - 2022-04-02 03:55:04 --> 404 Page Not Found: /index
ERROR - 2022-04-02 03:58:19 --> 404 Page Not Found: /index
ERROR - 2022-04-02 04:02:51 --> 404 Page Not Found: /index
ERROR - 2022-04-02 04:03:07 --> 404 Page Not Found: /index
ERROR - 2022-04-02 04:06:09 --> Severity: error --> Exception: Invalid address:  (to):  /home4/cowcdrmy/public_html/application/third_party/phpmailer/src/PHPMailer.php 1092
ERROR - 2022-04-02 04:07:32 --> 404 Page Not Found: /index
ERROR - 2022-04-02 04:07:42 --> Severity: error --> Exception: Invalid address:  (to):  /home4/cowcdrmy/public_html/application/third_party/phpmailer/src/PHPMailer.php 1092
ERROR - 2022-04-02 04:09:40 --> 404 Page Not Found: /index
ERROR - 2022-04-02 04:09:46 --> 404 Page Not Found: /index
ERROR - 2022-04-02 04:18:28 --> 404 Page Not Found: /index
ERROR - 2022-04-02 04:28:23 --> 404 Page Not Found: /index
ERROR - 2022-04-02 04:36:52 --> 404 Page Not Found: /index
ERROR - 2022-04-02 04:37:03 --> 404 Page Not Found: /index
ERROR - 2022-04-02 04:37:04 --> 404 Page Not Found: /index
ERROR - 2022-04-02 04:37:06 --> 404 Page Not Found: /index
ERROR - 2022-04-02 04:37:21 --> 404 Page Not Found: /index
ERROR - 2022-04-02 04:37:38 --> 404 Page Not Found: /index
ERROR - 2022-04-02 04:38:23 --> 404 Page Not Found: /index
ERROR - 2022-04-02 04:38:44 --> 404 Page Not Found: /index
ERROR - 2022-04-02 04:38:49 --> 404 Page Not Found: /index
ERROR - 2022-04-02 04:39:51 --> 404 Page Not Found: /index
ERROR - 2022-04-02 04:40:06 --> 404 Page Not Found: /index
ERROR - 2022-04-02 04:40:24 --> 404 Page Not Found: /index
ERROR - 2022-04-02 04:40:43 --> 404 Page Not Found: /index
ERROR - 2022-04-02 04:41:31 --> 404 Page Not Found: /index
ERROR - 2022-04-02 04:41:43 --> 404 Page Not Found: /index
ERROR - 2022-04-02 04:53:57 --> 404 Page Not Found: /index
ERROR - 2022-04-02 04:56:32 --> 404 Page Not Found: /index
ERROR - 2022-04-02 04:57:29 --> 404 Page Not Found: /index
ERROR - 2022-04-02 04:58:59 --> 404 Page Not Found: /index
ERROR - 2022-04-02 04:59:26 --> 404 Page Not Found: /index
ERROR - 2022-04-02 05:01:36 --> 404 Page Not Found: /index
ERROR - 2022-04-02 05:07:06 --> 404 Page Not Found: /index
ERROR - 2022-04-02 05:07:23 --> 404 Page Not Found: /index
ERROR - 2022-04-02 05:07:49 --> 404 Page Not Found: /index
ERROR - 2022-04-02 05:11:44 --> 404 Page Not Found: /index
ERROR - 2022-04-02 05:12:05 --> 404 Page Not Found: /index
ERROR - 2022-04-02 05:12:43 --> 404 Page Not Found: /index
ERROR - 2022-04-02 05:12:46 --> 404 Page Not Found: /index
ERROR - 2022-04-02 05:13:36 --> 404 Page Not Found: /index
ERROR - 2022-04-02 05:13:36 --> 404 Page Not Found: /index
ERROR - 2022-04-02 05:13:36 --> 404 Page Not Found: /index
ERROR - 2022-04-02 05:13:37 --> 404 Page Not Found: /index
ERROR - 2022-04-02 05:13:37 --> 404 Page Not Found: /index
ERROR - 2022-04-02 05:13:38 --> 404 Page Not Found: /index
ERROR - 2022-04-02 05:13:38 --> 404 Page Not Found: /index
ERROR - 2022-04-02 05:13:38 --> 404 Page Not Found: /index
ERROR - 2022-04-02 05:13:39 --> 404 Page Not Found: /index
ERROR - 2022-04-02 05:13:39 --> 404 Page Not Found: /index
ERROR - 2022-04-02 05:15:43 --> 404 Page Not Found: /index
ERROR - 2022-04-02 05:17:48 --> 404 Page Not Found: /index
ERROR - 2022-04-02 05:20:11 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-04-02 05:20:11')
ERROR - 2022-04-02 05:20:45 --> 404 Page Not Found: /index
ERROR - 2022-04-02 05:20:58 --> 404 Page Not Found: /index
ERROR - 2022-04-02 05:20:59 --> 404 Page Not Found: /index
ERROR - 2022-04-02 05:31:17 --> 404 Page Not Found: /index
ERROR - 2022-04-02 05:33:25 --> 404 Page Not Found: /index
ERROR - 2022-04-02 05:35:18 --> 404 Page Not Found: /index
ERROR - 2022-04-02 05:36:01 --> 404 Page Not Found: /index
ERROR - 2022-04-02 05:36:01 --> 404 Page Not Found: /index
ERROR - 2022-04-02 05:36:01 --> 404 Page Not Found: /index
ERROR - 2022-04-02 05:39:15 --> 404 Page Not Found: /index
ERROR - 2022-04-02 05:39:15 --> 404 Page Not Found: /index
ERROR - 2022-04-02 05:39:23 --> 404 Page Not Found: /index
ERROR - 2022-04-02 05:39:23 --> 404 Page Not Found: /index
ERROR - 2022-04-02 05:39:23 --> 404 Page Not Found: /index
ERROR - 2022-04-02 05:39:23 --> 404 Page Not Found: /index
ERROR - 2022-04-02 05:39:24 --> 404 Page Not Found: /index
ERROR - 2022-04-02 05:39:24 --> 404 Page Not Found: /index
ERROR - 2022-04-02 05:39:24 --> 404 Page Not Found: /index
ERROR - 2022-04-02 05:40:57 --> 404 Page Not Found: /index
ERROR - 2022-04-02 05:41:40 --> 404 Page Not Found: /index
ERROR - 2022-04-02 05:48:52 --> 404 Page Not Found: /index
ERROR - 2022-04-02 05:49:29 --> 404 Page Not Found: /index
ERROR - 2022-04-02 05:51:25 --> 404 Page Not Found: /index
ERROR - 2022-04-02 05:51:44 --> 404 Page Not Found: /index
ERROR - 2022-04-02 05:52:27 --> 404 Page Not Found: /index
ERROR - 2022-04-02 05:57:33 --> 404 Page Not Found: /index
ERROR - 2022-04-02 05:58:59 --> 404 Page Not Found: /index
ERROR - 2022-04-02 06:11:30 --> 404 Page Not Found: /index
ERROR - 2022-04-02 06:17:45 --> 404 Page Not Found: /index
ERROR - 2022-04-02 06:21:34 --> 404 Page Not Found: /index
ERROR - 2022-04-02 06:24:46 --> 404 Page Not Found: /index
ERROR - 2022-04-02 06:24:51 --> 404 Page Not Found: /index
ERROR - 2022-04-02 06:25:19 --> 404 Page Not Found: /index
ERROR - 2022-04-02 06:31:42 --> 404 Page Not Found: /index
ERROR - 2022-04-02 06:42:57 --> Query error: Unknown column 'Array' in 'where clause' - Invalid query: SELECT `p`.*, `r`.`caste`, `r`.`height`, `r`.`star`, `r`.`time_of_birth`, `r`.`raasi`, `prp`.`property_value`, `e`.`occupation`, `e`.`education_degree`, `e`.`visatype`, `e`.`city`, `e`.`country`, `e`.`annual_income`, `pfs`.`payment_status`, `pfs`.`profilesetting_id` as `pfs_id`, `pfs`.`last_call_updated`, `adm`.`username` as `profile_owner`
FROM `tbl_primary_info` as `p`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `ms_property_info` as `prp` ON `p`.`id`=`prp`.`ms_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `ms_profilesetting` as `pfs` ON `p`.`id`=`pfs`.`ms_id`
LEFT JOIN `tbl_admin_data` as `adm` ON `pfs`.`profileowner`=`adm`.`id`
WHERE `p`.`gender` = 'female'
AND `p`.`status` = '1'
AND `r`.`caste` = `Array`
AND `adm`.`id` = '3'
GROUP BY `p`.`id`
ERROR - 2022-04-02 06:44:15 --> 404 Page Not Found: /index
ERROR - 2022-04-02 06:51:54 --> 404 Page Not Found: /index
ERROR - 2022-04-02 06:56:59 --> 404 Page Not Found: /index
ERROR - 2022-04-02 06:58:56 --> 404 Page Not Found: /index
ERROR - 2022-04-02 07:06:22 --> 404 Page Not Found: /index
ERROR - 2022-04-02 07:09:06 --> 404 Page Not Found: /index
ERROR - 2022-04-02 07:14:20 --> 404 Page Not Found: /index
ERROR - 2022-04-02 07:28:54 --> 404 Page Not Found: /index
ERROR - 2022-04-02 07:29:10 --> 404 Page Not Found: /index
ERROR - 2022-04-02 07:29:10 --> 404 Page Not Found: /index
ERROR - 2022-04-02 07:29:11 --> 404 Page Not Found: /index
ERROR - 2022-04-02 07:29:11 --> 404 Page Not Found: /index
ERROR - 2022-04-02 07:29:11 --> 404 Page Not Found: /index
ERROR - 2022-04-02 07:29:12 --> 404 Page Not Found: /index
ERROR - 2022-04-02 07:29:12 --> 404 Page Not Found: /index
ERROR - 2022-04-02 07:29:13 --> 404 Page Not Found: /index
ERROR - 2022-04-02 07:29:13 --> 404 Page Not Found: /index
ERROR - 2022-04-02 07:29:14 --> 404 Page Not Found: /index
ERROR - 2022-04-02 07:29:21 --> 404 Page Not Found: /index
ERROR - 2022-04-02 07:29:50 --> 404 Page Not Found: /index
ERROR - 2022-04-02 07:29:52 --> 404 Page Not Found: /index
ERROR - 2022-04-02 07:29:53 --> 404 Page Not Found: /index
ERROR - 2022-04-02 07:30:01 --> 404 Page Not Found: /index
ERROR - 2022-04-02 07:30:29 --> 404 Page Not Found: /index
ERROR - 2022-04-02 07:32:09 --> 404 Page Not Found: /index
ERROR - 2022-04-02 07:32:17 --> 404 Page Not Found: /index
ERROR - 2022-04-02 07:32:51 --> 404 Page Not Found: /index
ERROR - 2022-04-02 07:35:26 --> 404 Page Not Found: /index
ERROR - 2022-04-02 07:38:21 --> 404 Page Not Found: /index
ERROR - 2022-04-02 07:49:19 --> 404 Page Not Found: /index
ERROR - 2022-04-02 07:49:33 --> 404 Page Not Found: /index
ERROR - 2022-04-02 07:49:37 --> 404 Page Not Found: /index
ERROR - 2022-04-02 07:49:55 --> 404 Page Not Found: /index
ERROR - 2022-04-02 07:50:26 --> 404 Page Not Found: /index
ERROR - 2022-04-02 07:55:15 --> 404 Page Not Found: /index
ERROR - 2022-04-02 08:02:35 --> 404 Page Not Found: /index
ERROR - 2022-04-02 08:06:20 --> 404 Page Not Found: /index
ERROR - 2022-04-02 08:06:34 --> 404 Page Not Found: /index
ERROR - 2022-04-02 08:06:38 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-04-02 08:06:38')
ERROR - 2022-04-02 08:06:46 --> 404 Page Not Found: /index
ERROR - 2022-04-02 08:09:49 --> 404 Page Not Found: /index
ERROR - 2022-04-02 08:11:54 --> 404 Page Not Found: /index
ERROR - 2022-04-02 08:20:37 --> 404 Page Not Found: /index
ERROR - 2022-04-02 08:37:20 --> 404 Page Not Found: /index
ERROR - 2022-04-02 08:39:38 --> 404 Page Not Found: /index
ERROR - 2022-04-02 08:39:49 --> 404 Page Not Found: /index
ERROR - 2022-04-02 08:39:55 --> 404 Page Not Found: /index
ERROR - 2022-04-02 08:40:21 --> 404 Page Not Found: /index
ERROR - 2022-04-02 08:42:06 --> 404 Page Not Found: /index
ERROR - 2022-04-02 08:44:22 --> 404 Page Not Found: /index
ERROR - 2022-04-02 08:46:10 --> 404 Page Not Found: /index
ERROR - 2022-04-02 08:48:51 --> 404 Page Not Found: /index
ERROR - 2022-04-02 08:50:58 --> 404 Page Not Found: /index
ERROR - 2022-04-02 08:54:04 --> 404 Page Not Found: /index
ERROR - 2022-04-02 08:54:05 --> 404 Page Not Found: /index
ERROR - 2022-04-02 08:54:05 --> 404 Page Not Found: /index
ERROR - 2022-04-02 08:54:06 --> 404 Page Not Found: /index
ERROR - 2022-04-02 08:54:06 --> 404 Page Not Found: /index
ERROR - 2022-04-02 08:54:06 --> 404 Page Not Found: /index
ERROR - 2022-04-02 08:54:07 --> 404 Page Not Found: /index
ERROR - 2022-04-02 08:54:07 --> 404 Page Not Found: /index
ERROR - 2022-04-02 08:54:07 --> 404 Page Not Found: /index
ERROR - 2022-04-02 08:54:08 --> 404 Page Not Found: /index
ERROR - 2022-04-02 09:03:55 --> 404 Page Not Found: /index
ERROR - 2022-04-02 09:07:39 --> 404 Page Not Found: /index
ERROR - 2022-04-02 09:07:51 --> 404 Page Not Found: /index
ERROR - 2022-04-02 09:09:45 --> 404 Page Not Found: /index
ERROR - 2022-04-02 09:10:38 --> 404 Page Not Found: /index
ERROR - 2022-04-02 09:13:41 --> 404 Page Not Found: /index
ERROR - 2022-04-02 09:19:32 --> 404 Page Not Found: /index
ERROR - 2022-04-02 09:21:25 --> 404 Page Not Found: /index
ERROR - 2022-04-02 09:22:51 --> 404 Page Not Found: /index
ERROR - 2022-04-02 09:23:46 --> 404 Page Not Found: /index
ERROR - 2022-04-02 09:24:37 --> 404 Page Not Found: /index
ERROR - 2022-04-02 09:28:08 --> 404 Page Not Found: /index
ERROR - 2022-04-02 09:28:28 --> 404 Page Not Found: /index
ERROR - 2022-04-02 09:31:03 --> 404 Page Not Found: /index
ERROR - 2022-04-02 09:32:17 --> 404 Page Not Found: /index
ERROR - 2022-04-02 09:36:48 --> 404 Page Not Found: /index
ERROR - 2022-04-02 09:37:24 --> 404 Page Not Found: /index
ERROR - 2022-04-02 09:38:47 --> 404 Page Not Found: /index
ERROR - 2022-04-02 09:38:52 --> 404 Page Not Found: /index
ERROR - 2022-04-02 09:41:13 --> 404 Page Not Found: /index
ERROR - 2022-04-02 09:45:00 --> 404 Page Not Found: /index
ERROR - 2022-04-02 09:45:30 --> 404 Page Not Found: /index
ERROR - 2022-04-02 09:49:58 --> 404 Page Not Found: /index
ERROR - 2022-04-02 09:50:22 --> 404 Page Not Found: /index
ERROR - 2022-04-02 09:51:11 --> 404 Page Not Found: /index
ERROR - 2022-04-02 09:51:32 --> 404 Page Not Found: /index
ERROR - 2022-04-02 09:51:49 --> 404 Page Not Found: /index
ERROR - 2022-04-02 09:52:07 --> 404 Page Not Found: /index
ERROR - 2022-04-02 09:52:07 --> 404 Page Not Found: /index
ERROR - 2022-04-02 09:52:07 --> 404 Page Not Found: /index
ERROR - 2022-04-02 09:53:14 --> 404 Page Not Found: /index
ERROR - 2022-04-02 09:53:46 --> 404 Page Not Found: /index
ERROR - 2022-04-02 09:53:46 --> 404 Page Not Found: /index
ERROR - 2022-04-02 09:56:39 --> 404 Page Not Found: /index
ERROR - 2022-04-02 09:57:52 --> 404 Page Not Found: /index
ERROR - 2022-04-02 10:01:37 --> 404 Page Not Found: /index
ERROR - 2022-04-02 10:05:14 --> 404 Page Not Found: /index
ERROR - 2022-04-02 10:09:02 --> 404 Page Not Found: /index
ERROR - 2022-04-02 10:10:56 --> 404 Page Not Found: /index
ERROR - 2022-04-02 10:14:36 --> 404 Page Not Found: /index
ERROR - 2022-04-02 10:15:41 --> 404 Page Not Found: /index
ERROR - 2022-04-02 10:16:14 --> 404 Page Not Found: /index
ERROR - 2022-04-02 10:16:27 --> 404 Page Not Found: /index
ERROR - 2022-04-02 10:20:29 --> 404 Page Not Found: /index
ERROR - 2022-04-02 10:20:30 --> 404 Page Not Found: /index
ERROR - 2022-04-02 10:21:42 --> 404 Page Not Found: /index
ERROR - 2022-04-02 10:22:39 --> 404 Page Not Found: /index
ERROR - 2022-04-02 10:28:51 --> 404 Page Not Found: /index
ERROR - 2022-04-02 10:33:45 --> 404 Page Not Found: /index
ERROR - 2022-04-02 10:38:29 --> 404 Page Not Found: /index
ERROR - 2022-04-02 10:38:57 --> 404 Page Not Found: /index
ERROR - 2022-04-02 10:43:51 --> To Id is not available for User - 3740
ERROR - 2022-04-02 10:43:52 --> 404 Page Not Found: /index
ERROR - 2022-04-02 10:43:55 --> 404 Page Not Found: /index
ERROR - 2022-04-02 10:43:57 --> 404 Page Not Found: /index
ERROR - 2022-04-02 10:46:35 --> 404 Page Not Found: /index
ERROR - 2022-04-02 10:48:08 --> 404 Page Not Found: /index
ERROR - 2022-04-02 10:51:03 --> To Id is not available for User - 3740
ERROR - 2022-04-02 10:51:04 --> 404 Page Not Found: /index
ERROR - 2022-04-02 10:59:38 --> 404 Page Not Found: /index
ERROR - 2022-04-02 11:00:28 --> 404 Page Not Found: /index
ERROR - 2022-04-02 11:09:34 --> 404 Page Not Found: /index
ERROR - 2022-04-02 11:10:21 --> 404 Page Not Found: /index
ERROR - 2022-04-02 11:11:06 --> 404 Page Not Found: /index
ERROR - 2022-04-02 11:13:54 --> 404 Page Not Found: /index
ERROR - 2022-04-02 11:20:45 --> 404 Page Not Found: /index
ERROR - 2022-04-02 11:20:59 --> 404 Page Not Found: /index
ERROR - 2022-04-02 11:24:57 --> 404 Page Not Found: /index
ERROR - 2022-04-02 11:25:21 --> 404 Page Not Found: /index
ERROR - 2022-04-02 11:27:58 --> 404 Page Not Found: /index
ERROR - 2022-04-02 11:28:45 --> 404 Page Not Found: /index
ERROR - 2022-04-02 11:30:01 --> 404 Page Not Found: /index
ERROR - 2022-04-02 11:34:21 --> 404 Page Not Found: /index
ERROR - 2022-04-02 11:38:10 --> 404 Page Not Found: /index
ERROR - 2022-04-02 11:41:36 --> 404 Page Not Found: /index
ERROR - 2022-04-02 11:42:51 --> To Id is not available for User - 3740
ERROR - 2022-04-02 11:42:51 --> 404 Page Not Found: /index
ERROR - 2022-04-02 11:47:31 --> 404 Page Not Found: /index
ERROR - 2022-04-02 11:49:30 --> 404 Page Not Found: /index
ERROR - 2022-04-02 11:49:42 --> 404 Page Not Found: /index
ERROR - 2022-04-02 11:53:40 --> 404 Page Not Found: /index
ERROR - 2022-04-02 11:55:19 --> 404 Page Not Found: /index
ERROR - 2022-04-02 11:56:01 --> 404 Page Not Found: /index
ERROR - 2022-04-02 11:59:36 --> 404 Page Not Found: /index
ERROR - 2022-04-02 12:00:26 --> 404 Page Not Found: /index
ERROR - 2022-04-02 12:00:53 --> 404 Page Not Found: /index
ERROR - 2022-04-02 12:00:58 --> 404 Page Not Found: /index
ERROR - 2022-04-02 12:01:13 --> To Id is not available for User - 3459
ERROR - 2022-04-02 12:01:14 --> 404 Page Not Found: /index
ERROR - 2022-04-02 12:02:37 --> 404 Page Not Found: /index
ERROR - 2022-04-02 12:03:14 --> 404 Page Not Found: /index
ERROR - 2022-04-02 12:04:08 --> 404 Page Not Found: /index
ERROR - 2022-04-02 12:05:28 --> 404 Page Not Found: /index
ERROR - 2022-04-02 12:05:36 --> 404 Page Not Found: /index
ERROR - 2022-04-02 12:07:35 --> 404 Page Not Found: /index
ERROR - 2022-04-02 12:07:36 --> 404 Page Not Found: /index
ERROR - 2022-04-02 12:08:05 --> 404 Page Not Found: /index
ERROR - 2022-04-02 12:08:31 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-04-02 12:08:31')
ERROR - 2022-04-02 12:11:46 --> 404 Page Not Found: /index
ERROR - 2022-04-02 12:13:51 --> 404 Page Not Found: /index
ERROR - 2022-04-02 12:14:04 --> 404 Page Not Found: /index
ERROR - 2022-04-02 12:15:36 --> 404 Page Not Found: /index
ERROR - 2022-04-02 12:15:43 --> 404 Page Not Found: /index
ERROR - 2022-04-02 12:16:18 --> 404 Page Not Found: /index
ERROR - 2022-04-02 12:16:42 --> 404 Page Not Found: /index
ERROR - 2022-04-02 12:17:52 --> 404 Page Not Found: /index
ERROR - 2022-04-02 12:18:05 --> 404 Page Not Found: /index
ERROR - 2022-04-02 12:19:05 --> 404 Page Not Found: /index
ERROR - 2022-04-02 12:19:13 --> 404 Page Not Found: /index
ERROR - 2022-04-02 12:19:13 --> 404 Page Not Found: /index
ERROR - 2022-04-02 12:20:26 --> 404 Page Not Found: /index
ERROR - 2022-04-02 12:20:53 --> 404 Page Not Found: /index
ERROR - 2022-04-02 12:22:35 --> 404 Page Not Found: /index
ERROR - 2022-04-02 12:23:02 --> 404 Page Not Found: /index
ERROR - 2022-04-02 12:23:03 --> 404 Page Not Found: /index
ERROR - 2022-04-02 12:31:50 --> 404 Page Not Found: /index
ERROR - 2022-04-02 12:34:56 --> 404 Page Not Found: /index
ERROR - 2022-04-02 12:35:53 --> 404 Page Not Found: /index
ERROR - 2022-04-02 12:36:19 --> 404 Page Not Found: /index
ERROR - 2022-04-02 12:36:34 --> 404 Page Not Found: /index
ERROR - 2022-04-02 12:36:39 --> 404 Page Not Found: /index
ERROR - 2022-04-02 12:40:49 --> 404 Page Not Found: /index
ERROR - 2022-04-02 12:43:02 --> 404 Page Not Found: /index
ERROR - 2022-04-02 12:45:47 --> 404 Page Not Found: /index
ERROR - 2022-04-02 12:47:08 --> 404 Page Not Found: /index
ERROR - 2022-04-02 12:50:09 --> 404 Page Not Found: /index
ERROR - 2022-04-02 12:56:51 --> 404 Page Not Found: /index
ERROR - 2022-04-02 12:58:37 --> 404 Page Not Found: /index
ERROR - 2022-04-02 12:58:51 --> 404 Page Not Found: /index
ERROR - 2022-04-02 12:59:31 --> 404 Page Not Found: /index
ERROR - 2022-04-02 13:00:03 --> 404 Page Not Found: /index
ERROR - 2022-04-02 13:00:14 --> 404 Page Not Found: /index
ERROR - 2022-04-02 13:00:31 --> 404 Page Not Found: /index
ERROR - 2022-04-02 13:00:40 --> 404 Page Not Found: /index
ERROR - 2022-04-02 13:01:54 --> 404 Page Not Found: /index
ERROR - 2022-04-02 13:01:56 --> 404 Page Not Found: /index
ERROR - 2022-04-02 13:02:01 --> 404 Page Not Found: /index
ERROR - 2022-04-02 13:03:22 --> 404 Page Not Found: /index
ERROR - 2022-04-02 13:04:29 --> Query error: Table 'cowcdrmy_kammamarriage.ms_shortlist_viewedd_ignored' doesn't exist - Invalid query: SELECT `v`.*, `p`.`gender`, `p`.`id`, `p`.`status`, `p`.`age`, `p`.`living_in`, `p`.`profile_id`, `p`.`first_name`, `last_name`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `s`.*
FROM `kv_profileview` as `v`
LEFT JOIN `tbl_primary_info` as `p` ON `v`.`kv_profileview_on` = `p`.`id`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`ms_id`
INNER JOIN `ms_profilesetting` as `s` ON `p`.`id`=`s`.`ms_id`
WHERE `s`.`elite` = 'no'
AND `p`.`status` = 1
AND `v`.`kv_userfkid` = '217'
AND `u`.`ismain` = 1
AND  `p`.`id` not in(select kv_msi_interested_on from kv_mysideinterests where kv_msi_profilefkid="217")
AND  p.id not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid = "217" AND `shortlist_status` = 1)
AND  `p`.`id` not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid="217"AND ignore_status=1)
ORDER BY `v`.`kv_profileview_created_date` DESC
 LIMIT 10
ERROR - 2022-04-02 13:04:40 --> Severity: error --> Exception: Call to a member function result_array() on null /home4/cowcdrmy/public_html/application/modules/dashboard/models/My_account_model.php 911
ERROR - 2022-04-02 13:06:10 --> 404 Page Not Found: /index
ERROR - 2022-04-02 13:06:11 --> 404 Page Not Found: /index
ERROR - 2022-04-02 13:07:46 --> 404 Page Not Found: /index
ERROR - 2022-04-02 13:14:08 --> 404 Page Not Found: /index
ERROR - 2022-04-02 13:15:11 --> 404 Page Not Found: /index
ERROR - 2022-04-02 13:16:29 --> 404 Page Not Found: /index
ERROR - 2022-04-02 13:20:01 --> 404 Page Not Found: /index
ERROR - 2022-04-02 13:31:01 --> 404 Page Not Found: /index
ERROR - 2022-04-02 13:31:34 --> 404 Page Not Found: /index
ERROR - 2022-04-02 13:31:55 --> 404 Page Not Found: /index
ERROR - 2022-04-02 13:32:21 --> 404 Page Not Found: /index
ERROR - 2022-04-02 13:32:51 --> 404 Page Not Found: /index
ERROR - 2022-04-02 13:32:56 --> 404 Page Not Found: /index
ERROR - 2022-04-02 13:33:30 --> 404 Page Not Found: /index
ERROR - 2022-04-02 13:36:39 --> 404 Page Not Found: /index
ERROR - 2022-04-02 13:39:14 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '<script>alert("xssvuln")</script> AND <script>alert("xssvuln") < `/script>`
AND ' at line 8 - Invalid query: SELECT `p`.`gender`, `p`.`id`, `p`.`status`, `p`.`age`, `p`.`living_in`, `p`.`profile_id`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`
FROM `tbl_primary_info` as `p`
INNER JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`MS_id`
INNER JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
INNER JOIN `ms_profilesetting` as `s` ON `p`.`id`=`s`.`ms_id`
WHERE `p`.`gender` = '<script>alert(\"xssvuln\")</script>'
AND `p`.`age` BETWEEN <script>alert("xssvuln")</script> AND <script>alert("xssvuln") < `/script>`
AND `r`.`religion` = '<script>alert(\"xssvuln\")</script>'
AND `r`.`mother_tounge` = '<script>alert(\"xssvuln\")</script>'
AND `p`.`status` = 1
AND `s`.`elite` = 'no'
AND `s`.`ms_usertype` = 'regular'
AND `u`.`ismain` = 1
AND `u`.`photoname` != ''
AND `u`.`applicationphotopath` != ''
GROUP BY `u`.`MS_id`
ORDER BY `registered_on` DESC
 LIMIT 8
ERROR - 2022-04-02 13:40:34 --> 404 Page Not Found: /index
ERROR - 2022-04-02 13:41:11 --> 404 Page Not Found: /index
ERROR - 2022-04-02 13:42:32 --> 404 Page Not Found: /index
ERROR - 2022-04-02 13:42:54 --> 404 Page Not Found: /index
ERROR - 2022-04-02 13:47:47 --> 404 Page Not Found: /index
ERROR - 2022-04-02 13:48:01 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-04-02 13:48:01')
ERROR - 2022-04-02 13:48:16 --> 404 Page Not Found: /index
ERROR - 2022-04-02 13:50:22 --> 404 Page Not Found: /index
ERROR - 2022-04-02 13:51:47 --> Severity: error --> Exception: Call to undefined method My_account_model::from() /home4/cowcdrmy/public_html/application/modules/dashboard/models/My_account_model.php 849
ERROR - 2022-04-02 13:53:57 --> 404 Page Not Found: /index
ERROR - 2022-04-02 13:57:39 --> 404 Page Not Found: /index
ERROR - 2022-04-02 14:02:52 --> 404 Page Not Found: /index
ERROR - 2022-04-02 14:03:47 --> 404 Page Not Found: /index
ERROR - 2022-04-02 14:05:55 --> 404 Page Not Found: /index
ERROR - 2022-04-02 14:13:02 --> 404 Page Not Found: /index
ERROR - 2022-04-02 14:14:47 --> 404 Page Not Found: /index
ERROR - 2022-04-02 14:24:10 --> 404 Page Not Found: /index
ERROR - 2022-04-02 14:26:04 --> 404 Page Not Found: /index
ERROR - 2022-04-02 14:32:30 --> 404 Page Not Found: /index
ERROR - 2022-04-02 14:35:01 --> 404 Page Not Found: /index
ERROR - 2022-04-02 14:36:08 --> 404 Page Not Found: /index
ERROR - 2022-04-02 14:36:12 --> 404 Page Not Found: /index
ERROR - 2022-04-02 14:44:23 --> 404 Page Not Found: /index
ERROR - 2022-04-02 14:46:35 --> 404 Page Not Found: /index
ERROR - 2022-04-02 14:46:41 --> 404 Page Not Found: /index
ERROR - 2022-04-02 14:47:40 --> 404 Page Not Found: /index
ERROR - 2022-04-02 14:48:07 --> 404 Page Not Found: /index
ERROR - 2022-04-02 14:49:06 --> 404 Page Not Found: /index
ERROR - 2022-04-02 14:52:46 --> 404 Page Not Found: /index
ERROR - 2022-04-02 14:55:00 --> 404 Page Not Found: /index
ERROR - 2022-04-02 15:02:47 --> 404 Page Not Found: /index
ERROR - 2022-04-02 15:08:22 --> 404 Page Not Found: /index
ERROR - 2022-04-02 15:09:00 --> 404 Page Not Found: /index
ERROR - 2022-04-02 15:09:15 --> 404 Page Not Found: /index
ERROR - 2022-04-02 15:10:02 --> 404 Page Not Found: /index
ERROR - 2022-04-02 15:10:49 --> 404 Page Not Found: /index
ERROR - 2022-04-02 15:10:57 --> 404 Page Not Found: /index
ERROR - 2022-04-02 15:10:59 --> 404 Page Not Found: /index
ERROR - 2022-04-02 15:11:04 --> 404 Page Not Found: /index
ERROR - 2022-04-02 15:11:07 --> 404 Page Not Found: /index
ERROR - 2022-04-02 15:20:46 --> 404 Page Not Found: /index
ERROR - 2022-04-02 15:23:36 --> 404 Page Not Found: /index
ERROR - 2022-04-02 15:35:15 --> 404 Page Not Found: /index
ERROR - 2022-04-02 15:36:04 --> 404 Page Not Found: /index
ERROR - 2022-04-02 15:36:45 --> 404 Page Not Found: /index
ERROR - 2022-04-02 15:36:48 --> 404 Page Not Found: /index
ERROR - 2022-04-02 15:40:47 --> 404 Page Not Found: /index
ERROR - 2022-04-02 15:45:00 --> 404 Page Not Found: /index
ERROR - 2022-04-02 15:46:48 --> 404 Page Not Found: /index
ERROR - 2022-04-02 15:47:55 --> 404 Page Not Found: /index
ERROR - 2022-04-02 15:50:27 --> Severity: error --> Exception: Call to undefined method My_account_model::from() /home4/cowcdrmy/public_html/application/modules/dashboard/models/My_account_model.php 849
ERROR - 2022-04-02 15:50:41 --> 404 Page Not Found: /index
ERROR - 2022-04-02 15:54:29 --> 404 Page Not Found: /index
ERROR - 2022-04-02 15:56:46 --> 404 Page Not Found: /index
ERROR - 2022-04-02 15:58:42 --> 404 Page Not Found: /index
ERROR - 2022-04-02 15:59:53 --> 404 Page Not Found: /index
ERROR - 2022-04-02 16:01:04 --> 404 Page Not Found: /index
ERROR - 2022-04-02 16:06:17 --> 404 Page Not Found: /index
ERROR - 2022-04-02 16:07:21 --> 404 Page Not Found: /index
ERROR - 2022-04-02 16:14:09 --> 404 Page Not Found: /index
ERROR - 2022-04-02 16:14:12 --> 404 Page Not Found: /index
ERROR - 2022-04-02 16:15:49 --> 404 Page Not Found: /index
ERROR - 2022-04-02 16:16:01 --> 404 Page Not Found: /index
ERROR - 2022-04-02 16:16:05 --> 404 Page Not Found: /index
ERROR - 2022-04-02 16:16:48 --> 404 Page Not Found: /index
ERROR - 2022-04-02 16:17:10 --> 404 Page Not Found: /index
ERROR - 2022-04-02 16:17:28 --> 404 Page Not Found: /index
ERROR - 2022-04-02 16:18:58 --> 404 Page Not Found: /index
ERROR - 2022-04-02 16:20:44 --> 404 Page Not Found: /index
ERROR - 2022-04-02 16:23:01 --> 404 Page Not Found: /index
ERROR - 2022-04-02 16:34:37 --> 404 Page Not Found: /index
ERROR - 2022-04-02 16:37:33 --> 404 Page Not Found: /index
ERROR - 2022-04-02 16:37:43 --> 404 Page Not Found: /index
ERROR - 2022-04-02 16:37:50 --> 404 Page Not Found: /index
ERROR - 2022-04-02 16:38:04 --> 404 Page Not Found: /index
ERROR - 2022-04-02 16:39:52 --> 404 Page Not Found: /index
ERROR - 2022-04-02 16:42:07 --> 404 Page Not Found: /index
ERROR - 2022-04-02 16:44:35 --> 404 Page Not Found: /index
ERROR - 2022-04-02 16:49:56 --> 404 Page Not Found: /index
ERROR - 2022-04-02 16:51:11 --> 404 Page Not Found: /index
ERROR - 2022-04-02 16:58:49 --> 404 Page Not Found: /index
ERROR - 2022-04-02 17:00:41 --> 404 Page Not Found: /index
ERROR - 2022-04-02 17:03:31 --> To Id is not available for User - 3740
ERROR - 2022-04-02 17:03:31 --> 404 Page Not Found: /index
ERROR - 2022-04-02 17:04:04 --> 404 Page Not Found: /index
ERROR - 2022-04-02 17:06:30 --> 404 Page Not Found: /index
ERROR - 2022-04-02 17:09:18 --> 404 Page Not Found: /index
ERROR - 2022-04-02 17:09:39 --> 404 Page Not Found: /index
ERROR - 2022-04-02 17:13:45 --> 404 Page Not Found: /index
ERROR - 2022-04-02 17:19:49 --> 404 Page Not Found: /index
ERROR - 2022-04-02 17:21:11 --> 404 Page Not Found: /index
ERROR - 2022-04-02 17:21:17 --> 404 Page Not Found: /index
ERROR - 2022-04-02 17:22:13 --> 404 Page Not Found: /index
ERROR - 2022-04-02 17:27:25 --> 404 Page Not Found: /index
ERROR - 2022-04-02 17:27:46 --> 404 Page Not Found: /index
ERROR - 2022-04-02 17:29:42 --> 404 Page Not Found: /index
ERROR - 2022-04-02 17:29:43 --> 404 Page Not Found: /index
ERROR - 2022-04-02 17:32:12 --> 404 Page Not Found: /index
ERROR - 2022-04-02 17:32:34 --> 404 Page Not Found: /index
ERROR - 2022-04-02 17:32:45 --> 404 Page Not Found: /index
ERROR - 2022-04-02 17:36:12 --> 404 Page Not Found: /index
ERROR - 2022-04-02 17:38:50 --> 404 Page Not Found: /index
ERROR - 2022-04-02 17:40:42 --> 404 Page Not Found: /index
ERROR - 2022-04-02 17:51:17 --> 404 Page Not Found: /index
ERROR - 2022-04-02 17:55:39 --> 404 Page Not Found: /index
ERROR - 2022-04-02 17:56:26 --> 404 Page Not Found: /index
ERROR - 2022-04-02 17:57:29 --> 404 Page Not Found: /index
ERROR - 2022-04-02 17:58:51 --> 404 Page Not Found: /index
ERROR - 2022-04-02 17:58:51 --> 404 Page Not Found: /index
ERROR - 2022-04-02 17:58:51 --> 404 Page Not Found: /index
ERROR - 2022-04-02 18:00:17 --> 404 Page Not Found: /index
ERROR - 2022-04-02 18:01:19 --> 404 Page Not Found: /index
ERROR - 2022-04-02 18:01:27 --> 404 Page Not Found: /index
ERROR - 2022-04-02 18:01:30 --> 404 Page Not Found: /index
ERROR - 2022-04-02 18:01:30 --> 404 Page Not Found: /index
ERROR - 2022-04-02 18:01:30 --> 404 Page Not Found: /index
ERROR - 2022-04-02 18:01:50 --> 404 Page Not Found: /index
ERROR - 2022-04-02 18:02:59 --> 404 Page Not Found: /index
ERROR - 2022-04-02 18:04:34 --> 404 Page Not Found: /index
ERROR - 2022-04-02 18:08:05 --> 404 Page Not Found: /index
ERROR - 2022-04-02 18:08:39 --> 404 Page Not Found: /index
ERROR - 2022-04-02 18:09:11 --> 404 Page Not Found: /index
ERROR - 2022-04-02 18:14:27 --> 404 Page Not Found: /index
ERROR - 2022-04-02 18:15:15 --> 404 Page Not Found: /index
ERROR - 2022-04-02 18:18:15 --> 404 Page Not Found: /index
ERROR - 2022-04-02 18:19:06 --> 404 Page Not Found: /index
ERROR - 2022-04-02 18:19:51 --> 404 Page Not Found: /index
ERROR - 2022-04-02 18:20:00 --> 404 Page Not Found: /index
ERROR - 2022-04-02 18:21:26 --> 404 Page Not Found: /index
ERROR - 2022-04-02 18:21:47 --> 404 Page Not Found: /index
ERROR - 2022-04-02 18:24:17 --> 404 Page Not Found: /index
ERROR - 2022-04-02 18:24:19 --> 404 Page Not Found: /index
ERROR - 2022-04-02 18:26:31 --> 404 Page Not Found: /index
ERROR - 2022-04-02 18:31:23 --> 404 Page Not Found: /index
ERROR - 2022-04-02 18:31:31 --> 404 Page Not Found: /index
ERROR - 2022-04-02 18:32:02 --> 404 Page Not Found: /index
ERROR - 2022-04-02 18:33:31 --> 404 Page Not Found: /index
ERROR - 2022-04-02 18:33:35 --> 404 Page Not Found: /index
ERROR - 2022-04-02 18:33:52 --> 404 Page Not Found: /index
ERROR - 2022-04-02 18:35:21 --> 404 Page Not Found: /index
ERROR - 2022-04-02 18:35:29 --> 404 Page Not Found: /index
ERROR - 2022-04-02 18:35:30 --> 404 Page Not Found: /index
ERROR - 2022-04-02 18:42:49 --> 404 Page Not Found: /index
ERROR - 2022-04-02 18:50:35 --> 404 Page Not Found: /index
ERROR - 2022-04-02 18:50:51 --> 404 Page Not Found: /index
ERROR - 2022-04-02 18:55:11 --> 404 Page Not Found: /index
ERROR - 2022-04-02 18:59:39 --> 404 Page Not Found: /index
ERROR - 2022-04-02 19:05:40 --> 404 Page Not Found: /index
ERROR - 2022-04-02 19:06:01 --> 404 Page Not Found: /index
ERROR - 2022-04-02 19:08:07 --> Query error: Column 'from_msid' cannot be null - Invalid query: INSERT INTO `MS_shortlist_viewedd_ignored` (`from_msid`, `to_msid`, `viewed_status`, `viewed_date`) VALUES (NULL, NULL, 1, '2022-04-02 19:08:07')
ERROR - 2022-04-02 19:10:04 --> 404 Page Not Found: /index
ERROR - 2022-04-02 19:12:40 --> 404 Page Not Found: /index
ERROR - 2022-04-02 19:13:04 --> 404 Page Not Found: /index
ERROR - 2022-04-02 19:15:04 --> 404 Page Not Found: /index
ERROR - 2022-04-02 19:16:59 --> 404 Page Not Found: /index
ERROR - 2022-04-02 19:17:44 --> 404 Page Not Found: /index
ERROR - 2022-04-02 19:23:52 --> 404 Page Not Found: /index
ERROR - 2022-04-02 19:26:34 --> 404 Page Not Found: /index
ERROR - 2022-04-02 19:28:37 --> 404 Page Not Found: /index
ERROR - 2022-04-02 19:30:24 --> 404 Page Not Found: /index
ERROR - 2022-04-02 19:31:32 --> 404 Page Not Found: /index
ERROR - 2022-04-02 19:31:54 --> 404 Page Not Found: /index
ERROR - 2022-04-02 19:43:43 --> 404 Page Not Found: /index
ERROR - 2022-04-02 19:44:19 --> 404 Page Not Found: /index
ERROR - 2022-04-02 19:45:09 --> 404 Page Not Found: /index
ERROR - 2022-04-02 19:48:12 --> 404 Page Not Found: /index
ERROR - 2022-04-02 19:51:47 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: select SUM(IFNULL(`basicdetails`, 0) + IFNULL(`religion`, 0) + IFNULL(`edu_prof`, 0) + IFNULL(`parents`, 0) + IFNULL(`Siblings`, 0) + IFNULL(`photo`, 0)) as total,photo,basicdetails,religion,edu_prof,parents,Siblings from tbl_profilebattery where user_id=
ERROR - 2022-04-02 19:51:48 --> 404 Page Not Found: /index
ERROR - 2022-04-02 19:51:49 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: select SUM(IFNULL(`basicdetails`, 0) + IFNULL(`religion`, 0) + IFNULL(`edu_prof`, 0) + IFNULL(`parents`, 0) + IFNULL(`Siblings`, 0) + IFNULL(`photo`, 0)) as total,photo,basicdetails,religion,edu_prof,parents,Siblings from tbl_profilebattery where user_id=
ERROR - 2022-04-02 19:51:51 --> Query error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near '' at line 1 - Invalid query: select SUM(IFNULL(`basicdetails`, 0) + IFNULL(`religion`, 0) + IFNULL(`edu_prof`, 0) + IFNULL(`parents`, 0) + IFNULL(`Siblings`, 0) + IFNULL(`photo`, 0)) as total,photo,basicdetails,religion,edu_prof,parents,Siblings from tbl_profilebattery where user_id=
ERROR - 2022-04-02 19:56:59 --> 404 Page Not Found: /index
ERROR - 2022-04-02 20:04:34 --> 404 Page Not Found: /index
ERROR - 2022-04-02 20:06:01 --> 404 Page Not Found: /index
ERROR - 2022-04-02 20:11:56 --> 404 Page Not Found: /index
ERROR - 2022-04-02 20:14:30 --> 404 Page Not Found: /index
ERROR - 2022-04-02 20:19:05 --> 404 Page Not Found: /index
ERROR - 2022-04-02 20:19:05 --> 404 Page Not Found: /index
ERROR - 2022-04-02 20:19:05 --> 404 Page Not Found: /index
ERROR - 2022-04-02 20:19:06 --> 404 Page Not Found: /index
ERROR - 2022-04-02 20:22:12 --> 404 Page Not Found: /index
ERROR - 2022-04-02 20:24:07 --> 404 Page Not Found: /index
ERROR - 2022-04-02 20:28:43 --> Query error: Table 'cowcdrmy_kammamarriage.ms_shortlist_viewedd_ignored' doesn't exist - Invalid query: SELECT `v`.*, `p`.`gender`, `p`.`id`, `p`.`status`, `p`.`age`, `p`.`living_in`, `p`.`profile_id`, `p`.`first_name`, `last_name`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `s`.*
FROM `kv_profileview` as `v`
LEFT JOIN `tbl_primary_info` as `p` ON `v`.`kv_profileview_on` = `p`.`id`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`ms_id`
INNER JOIN `ms_profilesetting` as `s` ON `p`.`id`=`s`.`ms_id`
WHERE `s`.`elite` = 'no'
AND `p`.`status` = 1
AND `v`.`kv_userfkid` = '3581'
AND `u`.`ismain` = 1
AND  `p`.`id` not in(select kv_msi_interested_on from kv_mysideinterests where kv_msi_profilefkid="3581")
AND  p.id not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid = "3581" AND `shortlist_status` = 1)
AND  `p`.`id` not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid="3581"AND ignore_status=1)
ORDER BY `v`.`kv_profileview_created_date` DESC
 LIMIT 10
ERROR - 2022-04-02 20:28:56 --> Severity: error --> Exception: Call to a member function result_array() on null /home4/cowcdrmy/public_html/application/modules/dashboard/models/My_account_model.php 911
ERROR - 2022-04-02 20:28:58 --> Query error: Table 'cowcdrmy_kammamarriage.ms_shortlist_viewedd_ignored' doesn't exist - Invalid query: SELECT `v`.*, `p`.`gender`, `p`.`id`, `p`.`status`, `p`.`age`, `p`.`living_in`, `p`.`profile_id`, `p`.`first_name`, `last_name`, `r`.`height`, `r`.`marital_status`, `r`.`religion`, `r`.`mother_tounge`, `r`.`user_id`, `r`.`caste`, `e`.`user_id`, `e`.`heighst_education`, `e`.`annual_income`, `e`.`occupation`, `e`.`about_me`, `u`.`photoname`, `u`.`MS_id`, `u`.`ismain`, `u`.`isactive`, `u`.`applicationphotopath`, `s`.*
FROM `kv_profileview` as `v`
LEFT JOIN `tbl_primary_info` as `p` ON `v`.`kv_profileview_on` = `p`.`id`
LEFT JOIN `tbl_religion_info` as `r` ON `p`.`id`=`r`.`user_id`
LEFT JOIN `tbl_professional_info` as `e` ON `p`.`id`=`e`.`user_id`
LEFT JOIN `MS_photos` as `u` ON `p`.`id`=`u`.`ms_id`
INNER JOIN `ms_profilesetting` as `s` ON `p`.`id`=`s`.`ms_id`
WHERE `s`.`elite` = 'no'
AND `p`.`status` = 1
AND `v`.`kv_userfkid` = '3581'
AND `u`.`ismain` = 1
AND  `p`.`id` not in(select kv_msi_interested_on from kv_mysideinterests where kv_msi_profilefkid="3581")
AND  p.id not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid = "3581" AND `shortlist_status` = 1)
AND  `p`.`id` not in(select to_msid from ms_shortlist_viewedd_ignored where from_msid="3581"AND ignore_status=1)
ORDER BY `v`.`kv_profileview_created_date` DESC
 LIMIT 10
ERROR - 2022-04-02 20:29:00 --> Severity: error --> Exception: Call to a member function result_array() on null /home4/cowcdrmy/public_html/application/modules/dashboard/models/My_account_model.php 911
ERROR - 2022-04-02 20:29:40 --> 404 Page Not Found: /index
ERROR - 2022-04-02 20:34:14 --> 404 Page Not Found: /index
ERROR - 2022-04-02 20:35:35 --> 404 Page Not Found: /index
ERROR - 2022-04-02 20:36:30 --> 404 Page Not Found: /index
ERROR - 2022-04-02 20:36:32 --> 404 Page Not Found: /index
ERROR - 2022-04-02 20:37:46 --> 404 Page Not Found: /index
ERROR - 2022-04-02 20:37:50 --> 404 Page Not Found: /index
ERROR - 2022-04-02 20:40:42 --> 404 Page Not Found: /index
ERROR - 2022-04-02 20:41:45 --> 404 Page Not Found: /index
ERROR - 2022-04-02 20:42:56 --> 404 Page Not Found: /index
ERROR - 2022-04-02 20:46:12 --> 404 Page Not Found: /index
ERROR - 2022-04-02 20:46:35 --> 404 Page Not Found: /index
ERROR - 2022-04-02 20:48:26 --> 404 Page Not Found: /index
ERROR - 2022-04-02 20:51:18 --> 404 Page Not Found: /index
ERROR - 2022-04-02 20:52:03 --> 404 Page Not Found: /index
ERROR - 2022-04-02 20:52:19 --> 404 Page Not Found: /index
ERROR - 2022-04-02 20:52:48 --> To Id is not available for User - 4389
ERROR - 2022-04-02 20:52:54 --> 404 Page Not Found: /index
ERROR - 2022-04-02 20:54:34 --> 404 Page Not Found: /index
ERROR - 2022-04-02 20:56:41 --> 404 Page Not Found: /index
ERROR - 2022-04-02 21:01:17 --> 404 Page Not Found: /index
ERROR - 2022-04-02 21:03:37 --> 404 Page Not Found: /index
ERROR - 2022-04-02 21:04:03 --> 404 Page Not Found: /index
ERROR - 2022-04-02 21:08:34 --> 404 Page Not Found: /index
ERROR - 2022-04-02 21:10:56 --> 404 Page Not Found: /index
ERROR - 2022-04-02 21:11:27 --> To Id is not available for User - �
ERROR - 2022-04-02 21:11:30 --> 404 Page Not Found: /index
ERROR - 2022-04-02 21:11:30 --> 404 Page Not Found: /index
ERROR - 2022-04-02 21:12:09 --> 404 Page Not Found: /index
ERROR - 2022-04-02 21:12:17 --> 404 Page Not Found: /index
ERROR - 2022-04-02 21:12:45 --> 404 Page Not Found: /index
ERROR - 2022-04-02 21:12:45 --> 404 Page Not Found: /index
ERROR - 2022-04-02 21:12:49 --> 404 Page Not Found: /index
ERROR - 2022-04-02 21:13:13 --> 404 Page Not Found: /index
ERROR - 2022-04-02 21:13:20 --> 404 Page Not Found: /index
ERROR - 2022-04-02 21:17:50 --> 404 Page Not Found: /index
ERROR - 2022-04-02 21:23:55 --> 404 Page Not Found: /index
ERROR - 2022-04-02 21:25:08 --> 404 Page Not Found: /index
ERROR - 2022-04-02 21:25:45 --> 404 Page Not Found: /index
ERROR - 2022-04-02 21:32:13 --> 404 Page Not Found: /index
ERROR - 2022-04-02 21:32:25 --> 404 Page Not Found: /index
ERROR - 2022-04-02 21:34:11 --> 404 Page Not Found: /index
ERROR - 2022-04-02 21:34:48 --> 404 Page Not Found: /index
ERROR - 2022-04-02 21:36:17 --> 404 Page Not Found: /index
ERROR - 2022-04-02 21:37:37 --> 404 Page Not Found: /index
ERROR - 2022-04-02 21:39:16 --> 404 Page Not Found: /index
ERROR - 2022-04-02 21:40:55 --> 404 Page Not Found: /index
ERROR - 2022-04-02 21:41:45 --> 404 Page Not Found: /index
ERROR - 2022-04-02 21:41:50 --> 404 Page Not Found: /index
ERROR - 2022-04-02 21:41:50 --> 404 Page Not Found: /index
ERROR - 2022-04-02 21:42:52 --> Query error: Column 'phone' cannot be null - Invalid query: INSERT INTO `tbl_contactus` (`name`, `email`, `phone`, `message`, `contacted_date_time`) VALUES ('Rufus Grustas', 'JinnyGrobmyer37627@gmail.com', NULL, 'Submit your site to over 1000 directories all with one click here> https://bit.ly/submit-your-site-here', '2022-04-02 21:42:52')
ERROR - 2022-04-02 21:43:03 --> 404 Page Not Found: /index
ERROR - 2022-04-02 21:43:03 --> 404 Page Not Found: /index
ERROR - 2022-04-02 21:43:07 --> 404 Page Not Found: /index
ERROR - 2022-04-02 21:43:28 --> 404 Page Not Found: /index
ERROR - 2022-04-02 21:44:01 --> 404 Page Not Found: /index
ERROR - 2022-04-02 21:48:54 --> 404 Page Not Found: /index
ERROR - 2022-04-02 21:51:01 --> 404 Page Not Found: /index
ERROR - 2022-04-02 21:52:30 --> 404 Page Not Found: /index
ERROR - 2022-04-02 21:54:34 --> 404 Page Not Found: /index
ERROR - 2022-04-02 21:55:12 --> 404 Page Not Found: /index
ERROR - 2022-04-02 21:58:47 --> 404 Page Not Found: /index
ERROR - 2022-04-02 22:03:25 --> 404 Page Not Found: /index
ERROR - 2022-04-02 22:03:50 --> 404 Page Not Found: /index
ERROR - 2022-04-02 22:04:08 --> 404 Page Not Found: /index
ERROR - 2022-04-02 22:04:11 --> 404 Page Not Found: /index
ERROR - 2022-04-02 22:05:01 --> 404 Page Not Found: /index
ERROR - 2022-04-02 22:06:21 --> 404 Page Not Found: /index
ERROR - 2022-04-02 22:16:39 --> 404 Page Not Found: /index
ERROR - 2022-04-02 22:23:21 --> 404 Page Not Found: /index
ERROR - 2022-04-02 22:24:33 --> 404 Page Not Found: /index
ERROR - 2022-04-02 22:26:18 --> 404 Page Not Found: /index
ERROR - 2022-04-02 22:28:25 --> 404 Page Not Found: /index
ERROR - 2022-04-02 22:28:55 --> 404 Page Not Found: /index
ERROR - 2022-04-02 22:30:10 --> 404 Page Not Found: /index
ERROR - 2022-04-02 22:30:21 --> 404 Page Not Found: /index
ERROR - 2022-04-02 22:30:51 --> 404 Page Not Found: /index
ERROR - 2022-04-02 22:31:42 --> 404 Page Not Found: /index
ERROR - 2022-04-02 22:42:50 --> 404 Page Not Found: /index
ERROR - 2022-04-02 22:46:11 --> 404 Page Not Found: /index
ERROR - 2022-04-02 22:46:19 --> 404 Page Not Found: /index
ERROR - 2022-04-02 22:48:06 --> 404 Page Not Found: /index
ERROR - 2022-04-02 22:48:13 --> 404 Page Not Found: /index
ERROR - 2022-04-02 22:51:04 --> 404 Page Not Found: /index
ERROR - 2022-04-02 22:51:16 --> 404 Page Not Found: /index
ERROR - 2022-04-02 22:54:49 --> 404 Page Not Found: /index
ERROR - 2022-04-02 22:57:56 --> 404 Page Not Found: /index
ERROR - 2022-04-02 23:00:19 --> 404 Page Not Found: /index
ERROR - 2022-04-02 23:00:19 --> 404 Page Not Found: /index
ERROR - 2022-04-02 23:00:19 --> 404 Page Not Found: /index
ERROR - 2022-04-02 23:08:06 --> 404 Page Not Found: /index
ERROR - 2022-04-02 23:09:55 --> 404 Page Not Found: /index
ERROR - 2022-04-02 23:10:40 --> 404 Page Not Found: /index
ERROR - 2022-04-02 23:14:07 --> 404 Page Not Found: /index
ERROR - 2022-04-02 23:14:44 --> 404 Page Not Found: /index
ERROR - 2022-04-02 23:15:18 --> 404 Page Not Found: /index
ERROR - 2022-04-02 23:19:49 --> 404 Page Not Found: /index
ERROR - 2022-04-02 23:20:57 --> 404 Page Not Found: /index
ERROR - 2022-04-02 23:22:32 --> 404 Page Not Found: /index
ERROR - 2022-04-02 23:27:30 --> 404 Page Not Found: /index
ERROR - 2022-04-02 23:27:57 --> 404 Page Not Found: /index
ERROR - 2022-04-02 23:34:04 --> To Id is not available for User - 2373
ERROR - 2022-04-02 23:34:04 --> 404 Page Not Found: /index
ERROR - 2022-04-02 23:34:05 --> 404 Page Not Found: /index
ERROR - 2022-04-02 23:46:17 --> To Id is not available for User - 2373
ERROR - 2022-04-02 23:46:17 --> 404 Page Not Found: /index
ERROR - 2022-04-02 23:46:38 --> 404 Page Not Found: /index
ERROR - 2022-04-02 23:49:28 --> 404 Page Not Found: /index
