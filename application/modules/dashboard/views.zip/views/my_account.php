<!-- Main Content Start Here -->
		<div class="main_content">
			<div class="container">
				<div class="row m-0">
					<div class="tab-nav col-md-12">
						<ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
							<li class="nav-item" role="presentation"> <a class="nav-link active" id="pills-home-tab" data-toggle="pill" href="#pills-home" role="tab" aria-controls="pills-home" aria-selected="true">My Profile</a> </li>
							<li class="nav-item" role="presentation"> <a class="nav-link" id="pills-profile-tab" data-toggle="pill" href="#pills-profile" role="tab" aria-controls="pills-profile" aria-selected="false">Manage Photos</a> </li>
							<?php if($primary_info["ms_usertype"]=='regular') { ?>
							<li class="nav-item" role="presentation"> <a class="nav-link" id="pills-contact-tab" data-toggle="pill" href="#pills-contact" role="tab" aria-controls="pills-contact" aria-selected="false">Upgrade Membership</a> </li>
							<?php } ?><!--	<li class="nav-item" role="presentation"> <a class="nav-link" id="pills-profile-setting-tab" data-toggle="pill" href="#pills-profile-setting" role="tab" aria-controls="pills-profile-setting" aria-selected="false">Profile Settings</a> </li>
						-->	<li class="nav-item" role="presentation"> <a class="nav-link" id="pills-payment-tab" data-toggle="pill" href="#pills-payment" role="tab" aria-controls="pills-payment" aria-selected="false">Payment Statistics</a> </li>
						</ul>
					</div>
					<div class="col-md-12 p-0">
						<div class="row mx-n2">
							<div class="col-md-8 px-2 tab-content" id="pills-tabContent">
								<div class="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab">
									<div class="dashboard_main_content">
										<div class="profileHolder">
											<div class="row pt-3 pb-4 col-md-12">
											
												<div class="profile_img col-md-3"> 
												<?php if(isset($profile_pic[0]) && $profile_pic[0]['applicationphotopath']!="" && $profile_pic[0]['ismain']==1 && $profile_pic[0]['isactive']) { ?>
													<img  class="profileImg"  src="<?php echo $profile_pic[0]['applicationphotopath']; ?>" alt="<?php echo $primary_info["last_name"];?>"> 
												 <?php } else{ ?>
													<img  class="profileImg"  src="<?php echo site_url();?>images/noimage.jpg" alt="<?php echo $primary_info["last_name"];?>"> 
												 <?php } ?>
												 </div>
												<div class="my_profile_main col-md-9">
													<p><?php echo $primary_info["first_name"]." ".$primary_info["last_name"]; ?> | <?php echo $primary_info["profile_id"]; ?> </p> <span class="profile_info">
															<p class="mt-2"><?php echo $primary_info["currentAge"]; ?> Age, <?php echo $religion_details["height"]; ?>'' inches Height</p>
															<p><?php echo $religion_details["caste"]; ?>,<?php echo $religion_details["religion"]; ?><br /></p>
															<p><?php  if(!empty($profile_info["heighst_education"])){echo $profile_info["heighst_education"];}else{echo 'NA';} ?></p>
															<p><?php echo $profile_info["city"].", ".$profile_info["state"];?></p>
													</span> 	<!--<a class="horoscope mr-4">Generate Horoscope</a> <a class="horoscope mr-4">Upload Horoscope <input accept="image/png, image/jpeg,image/jpg,image/gif" class="inputupload_file" id="horoscopeId" type="file" /></a> -->
													</div>
											</div>
											<hr/>
											<div class="pt-4">
												<div class="col-md-12">
													<p class="profile_heading pb-4">Basic Information <!--<span class="edit_link" data-toggle="modal" data-target="#exampleModal">Edit</span> --></p>
													<div class="row pb-3">
														<p class="col-md-4 attribute_name">About My Self</p>
														<p class="col-md-8 attribute_value"><?php if($primary_info["city"]=='') { echo "N/A"; } else { ?>Hi there! I am from <?php echo $profile_info["city"]."(".$profile_info["country"].")";?>.<?php if(isset($profile_info["heighst_education"])) { echo "I have studied ".$profile_info["heighst_education"]; } } ?>.</p>
													</div>
													<div class="row pb-3">
														<p class="col-md-4 attribute_name">Name:</p>
														<p class="col-md-8 attribute_value"><?php if($primary_info["first_name"]=='') { echo "N/A"; } else { echo $primary_info["first_name"]; } ?></p>
													</div>
													<div class="row pb-3">
														<p class="col-md-4 attribute_name">Marital Status:</p>
														<p class="col-md-8 attribute_value"><?php if($profile_info["marital_status"]=='') { echo "N/A"; } else { echo $profile_info["marital_status"]; } ?></p>
													</div>
													<div class="row pb-3">
														<p class="col-md-4 attribute_name">Height:</p>
														<p class="col-md-8 attribute_value"><?php if($religion_details["height"]=='') { echo "N/A"; } else { echo $religion_details["height"]."'' inches"; } ?></p>
													</div>
													<div class="row pb-3">
														<p class="col-md-4 attribute_name">Caste:</p>
														<p class="col-md-8 attribute_value"><?php if($religion_details["caste"]=='') { echo "N/A"; } else { echo $religion_details["caste"]; } ?></p>
													</div>
													<div class="row pb-3">
														<p class="col-md-4 attribute_name">Religion:</p>
														<p class="col-md-8 attribute_value"><?php if($religion_details["religion"]=='') { echo "N/A"; } else { echo $religion_details["religion"]; } ?></p>
													</div>
													<div class="row pb-3">
														<p class="col-md-4 attribute_name">Mother tongue:</p>
														<p class="col-md-8 attribute_value"><?php if($profile_info["mother_tounge"]=='') { echo "N/A"; } else { echo $profile_info["mother_tounge"]; } ?></p>
													</div>
													<div class="row pb-3">
														<p class="col-md-4 attribute_name">Age:</p>
														<p class="col-md-8 attribute_value"><?php if($profile_info["dob"]=='') { echo "N/A"; } else { echo  $profile_info["dob"]."(".$primary_info["currentAge"].")"; } ?></p>
													</div>
													<div class="row pb-3">
														<p class="col-md-4 attribute_name">Time Of Birth:</p>
														<p class="col-md-8 attribute_value"><?php if($profile_info["time_of_birth"]=='') { echo "N/A"; } else { echo $profile_info["time_of_birth"]; } ?></p>
													</div>
													<div class="row pb-3">
														<p class="col-md-4 attribute_name">Place Of Birth:</p>
														<p class="col-md-8 attribute_value"><?php if($profile_info["place_of_birth"]=='') { echo "N/A"; } else { echo $profile_info["place_of_birth"]; } ?></p>
													</div>
													<div class="row pb-3">
														<p class="col-md-4 attribute_name">Star:</p>
														<p class="col-md-8 attribute_value"><?php if($profile_info["star"]=='') { echo "N/A"; } else { echo $profile_info["star"]; } ?></p>
													</div>
													<div class="row pb-3">
														<p class="col-md-4 attribute_name">Padam:</p>
														<p class="col-md-8 attribute_value"><?php if($profile_info["padam"]=='') { echo "N/A"; } else { echo $profile_info["padam"]; } ?></p>
													</div>
													<div class="row pb-3">
														<p class="col-md-4 attribute_name">Raasi:</p>
														<p class="col-md-8 attribute_value"><?php if($profile_info["raasi"]=='') { echo "N/A"; } else { echo $profile_info["raasi"]; } ?></p>
													</div>
													<div class="row pb-3">
														<p class="col-md-4 attribute_name">Gothram:</p>
														<p class="col-md-8 attribute_value"><?php if($profile_info["gothram"]=='') { echo "N/A"; } else { echo $profile_info["gothram"]; } ?></p>
													</div>
												<!--	<div class="row pb-3">
														<p class="col-md-4 attribute_name">Lagnam:</p>
														<p class="col-md-8 attribute_value edit_link" data-toggle="modal" data-target="#exampleModal1">Add</p>
													</div>  
													<div class="row pb-3">
														<p class="col-md-4 attribute_name">Complexion:</p>
														<p class="col-md-8 attribute_value edit_link" data-toggle="modal" data-target="#exampleModal1">Add</p>
													</div>  -->
													<hr /> </div>
												<div class="col-md-12 pt-4">
													<p class="profile_heading pb-4">My Profession <!--<span class="edit_link" data-toggle="modal" data-target="#exampleModal">Edit</span>--></p>
													<div class="row pb-3">
														<p class="col-md-4 attribute_name">Profession:</p>
														<p class="col-md-8 attribute_value"><?php if($profile_info["occupation"]=='') { echo "N/A"; } else { echo $profile_info["occupation"]; } ?></p>
													</div>
													<div class="row pb-3">
														<p class="col-md-4 attribute_name">Income:</p>
														<p class="col-md-8 attribute_value"><?php if($profile_info["annual_income"]=='') { echo "N/A"; } else { echo "Rs -".$profile_info["annual_income"]; } ?></p>
													</div>
													<div class="row pb-3">
														<p class="col-md-4 attribute_name">Company Name:</p>
														<p class="col-md-8 attribute_value edit_link"><?php if($profile_info["company_name"]=='') { echo "N/A"; } else { echo $profile_info["company_name"]; } ?></p>
													</div>
													<div class="row pb-3">
														<p class="col-md-4 attribute_name">Professional Details:</p>
														<p class="col-md-8 attribute_value"><?php if($profile_info["about_profession"]=='') { echo "N/A"; } else { echo $profile_info["about_profession"]; } ?></p>
													</div>
													<hr /> </div>
												<div class="col-md-12 pt-4">
													<p class="profile_heading pb-4">My Education <!--<span class="edit_link" data-toggle="modal" data-target="#exampleModal">Edit</span> --></p>
													<div class="row pb-3">
														<p class="col-md-4 attribute_name">Education:</p>
														<p class="col-md-8 attribute_value"><?php if($profile_info["heighst_education"]=='') { echo "N/A"; } else { echo $profile_info["heighst_education"]; } ?></p>
														<p class="col-md-4 attribute_name">Specialization</p>
														<p class="col-md-8 attribute_value"><?php if($profile_info["specialization"]=='') { echo ""; } else { echo $profile_info["specialization"]; } ?></p>
													
													</div>
													<hr /> </div>
												<div class="col-md-12 pt-4">
													<p class="profile_heading pb-4">My Location <!--<span class="edit_link" data-toggle="modal" data-target="#exampleModal">Edit</span>--></p>
													<div class="row pb-3">
														<p class="col-md-4 attribute_name">Country Living:</p>
														<p class="col-md-8 attribute_value"><?php if($profile_info["living_in"]=='') { echo "N/A"; } else { echo $profile_info["living_in"]; } ?></p>
													</div>
													<div class="row pb-3">
														<p class="col-md-4 attribute_name">State Living:</p>
														<p class="col-md-8 attribute_value"><?php if($profile_info["state"]=='') { echo "N/A"; } else { echo $profile_info["state"]; } ?></p>
													</div>
													<div class="row pb-3">
														<p class="col-md-4 attribute_name">District Living:</p>
														<p class="col-md-8 attribute_value"><?php if($profile_info["distrct"]=='') { echo "N/A"; } else { echo $profile_info["district"]; } ?></p>
													</div>
													<div class="row pb-3">
														<p class="col-md-4 attribute_name">City Living:</p>
														<p class="col-md-8 attribute_value"><?php if($profile_info["city"]=='') { echo "N/A"; } else { echo $profile_info["city"]; } ?></p>
													</div>
													<hr /> </div>
												<div class="col-md-12 pt-4">
													<p class="profile_heading pb-4">My Contact Info <!--<span class="edit_link" data-toggle="modal" data-target="#exampleModal">Edit</span>--></p>
													<div class="row pb-3">
														<p class="col-md-4 attribute_name">Contact:</p>
														<p class="col-md-8 attribute_value">+91 - <?php if($profile_info["mobile"]=='') { echo "N/A"; } else { echo $profile_info["mobile"]; } ?></p>
													</div>
													<div class="row pb-3">
														<p class="col-md-4 attribute_name">Email:</p>
														<p class="col-md-8 attribute_value"><?php if($profile_info["email"]=='') { echo "N/A"; } else { echo $profile_info["email"]; } ?></p>
													</div>
													<div class="row pb-3">
														<p class="col-md-4 attribute_name">Address:</p>
														<p class="col-md-8 attribute_value"><?php if($profile_info["city"]=='') { echo "N/A"; } else { echo $profile_info["city"]; } ?></p>
													</div>
													<hr/> </div>
												<div class="col-md-12 pt-4">
													<p class="profile_heading pb-4">Family Details <!--<span class="edit_link" data-toggle="modal" data-target="#exampleModal">Edit</span>--></p>
													<div class="row pb-3">
														<p class="col-md-4 attribute_name">Father Name:</p>
														<p class="col-md-8 attribute_value edit_link"><?php if($profile_info["father_name"]=='') { echo "N/A"; } else { echo ucwords($profile_info["father_name"]); } ?></p>
													</div>
													<div class="row pb-3">
														<p class="col-md-4 attribute_name">Father Contact Details:</p>
														<p class="col-md-8 attribute_value"><?php if($profile_info["father_mobile"]=='') { echo "N/A"; } else { echo $profile_info["father_mobile"]; } ?></p>
													</div>
													<div class="row pb-3">
														<p class="col-md-4 attribute_name">Father Email:</p>
														<p class="col-md-8 attribute_value"><?php if($profile_info["father_email"]=='') { echo "N/A"; } else { echo $profile_info["father_email"]; } ?></p>
													</div>
													<div class="row pb-3">
														<p class="col-md-4 attribute_name">Father Education:</p>
														<p class="col-md-8 attribute_value"><?php if($profile_info["father_education"]=='') { echo "N/A"; } else { echo $profile_info["father_education"]; } ?></p>
													</div>
													<div class="row pb-3">
														<p class="col-md-4 attribute_name">Father Profession:</p>
														<p class="col-md-8 attribute_value"><?php if($profile_info["father_profession"]=='') { echo "N/A"; } else { echo $profile_info["father_profession"]; } ?></p>
													</div>
												<!--	<div class="row pb-3">
														<p class="col-md-4 attribute_name">Father Designation:</p>
														<p class="col-md-8 attribute_value"><?php if($profile_info["father_mobile"]=='') { echo "N/A"; } else { echo $profile_info["father_mobile"]; } ?></p>
													</div>
													<div class="row pb-3">
														<p class="col-md-4 attribute_name">Father Company Name:</p>
														<p class="col-md-8 attribute_value">N/A</p>
													</div>   -->
													<div class="row pb-3">
														<p class="col-md-4 attribute_name">Father's Father Name:</p>
														<p class="col-md-8 attribute_value"><?php if($profile_info["fathers_father_name"]=='') { echo "N/A"; } else { echo $profile_info["fathers_father_name"]; } ?></p>
													</div>
												<!--	<div class="row pb-3">
														<p class="col-md-4 attribute_name">Father Job Location:</p>
														<p class="col-md-8 attribute_value"><?php if($profile_info["father_mobile"]=='') { echo "N/A"; } else { echo $profile_info["father_mobile"]; } ?></p>
													</div>   -->
													<div class="row pb-3">
														<p class="col-md-4 attribute_name">Father's Father State:</p>
														<p class="col-md-8 attribute_value"><?php if($profile_info["fathers_father_state"]=='') { echo "N/A"; } else { echo $profile_info["fathers_father_state"]; } ?></p>
													</div>
													<div class="row pb-3">
														<p class="col-md-4 attribute_name">Father's Father District:</p>
														<p class="col-md-8 attribute_value"><?php if($profile_info["fathers_father_district"]=='') { echo "N/A"; } else { echo $profile_info["fathers_father_district"]; } ?></p>
													</div>
													<div class="row pb-3">
														<p class="col-md-4 attribute_name">Father's Father Native Place:</p>
														<p class="col-md-8 attribute_value"><?php if($profile_info["fathers_father_native_place"]=='') { echo "N/A"; } else { echo $profile_info["fathers_father_native_place"]; } ?></p>
													</div>
													<div class="row pb-3">
														<p class="col-md-4 attribute_name">Mother's Name:</p>
														<p class="col-md-8 attribute_value edit_link"><?php if($profile_info["mother_name"]=='') { echo "N/A"; } else { echo $profile_info["mother_name"]; } ?></p>
													</div>
													<div class="row pb-3">
														<p class="col-md-4 attribute_name">Mother's Contact Details:</p>
														<p class="col-md-8 attribute_value"><?php if($profile_info["mother_mobile"]=='') { echo "N/A"; } else { echo $profile_info["mother_mobile"]; } ?></p>
													</div>
													<div class="row pb-3">
														<p class="col-md-4 attribute_name">Mother's Email:</p>
														<p class="col-md-8 attribute_value"><?php if($profile_info["mother_email"]=='') { echo "N/A"; } else { echo $profile_info["mother_email"]; } ?></p>
													</div>
													<div class="row pb-3">
														<p class="col-md-4 attribute_name">Mother's Education:</p>
														<p class="col-md-8 attribute_value"><?php if($profile_info["mother_education"]=='') { echo "N/A"; } else { echo $profile_info["mother_education"]; } ?></p>
													</div>
													<div class="row pb-3">
														<p class="col-md-4 attribute_name">Mother's Profession:</p>
														<p class="col-md-8 attribute_value"><?php if($profile_info["mother_profession"]=='') { echo "N/A"; } else { echo $profile_info["mother_profession"]; } ?></p>
													</div>
												<!--	<div class="row pb-3">
														<p class="col-md-4 attribute_name">Mother's Designation:</p>
														<p class="col-md-8 attribute_value"><?php if($profile_info["father_mobile"]=='') { echo "N/A"; } else { echo $profile_info["father_mobile"]; } ?></p>
													</div>
													<div class="row pb-3">
														<p class="col-md-4 attribute_name">Mother's Company Name:</p>
														<p class="col-md-8 attribute_value"><?php if($profile_info["father_mobile"]=='') { echo "N/A"; } else { echo $profile_info["father_mobile"]; } ?></p>
													</div>
													<div class="row pb-3">
														<p class="col-md-4 attribute_name">Mother's Job Location:</p>
														<p class="col-md-8 attribute_value"><?php if($profile_info["father_mobile"]=='') { echo "N/A"; } else { echo $profile_info["father_mobile"]; } ?></p>
													</div>  -->
													<div class="row pb-3">
														<p class="col-md-4 attribute_name">Mother's Father Name:</p>
														<p class="col-md-8 attribute_value"><?php if($profile_info["mothers_father_name"]=='') { echo "N/A"; } else { echo $profile_info["mothers_father_name"]; } ?></p>
													</div>
													<div class="row pb-3">
														<p class="col-md-4 attribute_name">Mother's Father Surname:</p>
														<p class="col-md-8 attribute_value"><?php if($profile_info["mothers_father_surname"]=='') { echo "N/A"; } else { echo $profile_info["mothers_father_surname"]; } ?></p>
													</div>
													<div class="row pb-3">
														<p class="col-md-4 attribute_name">Mother's Father State:</p>
														<p class="col-md-8 attribute_value"><?php if($profile_info["mothers_father_state"]=='') { echo "N/A"; } else { echo $profile_info["mothers_father_state"]; } ?></p>
													</div>
													<div class="row pb-3">
														<p class="col-md-4 attribute_name">Mother's Father District:</p>
														<p class="col-md-8 attribute_value"><?php if($profile_info["mothers_father_district"]=='') { echo "N/A"; } else { echo $profile_info["mothers_father_district"]; } ?></p>
													</div>
													<div class="row pb-3">
														<p class="col-md-4 attribute_name">Mother's Father Native:</p>
														<p class="col-md-8 attribute_value"><?php if($profile_info["mothers_father_native_place"]=='') { echo "N/A"; } else { echo $profile_info["mothers_father_native_place"]; } ?></p>
													</div>
													<div class="row pb-3">
														<p class="col-md-4 attribute_name">No of Brothers:</p>
														<p class="col-md-8 attribute_value edit_link"><?php if($profile_info["no_of_brothers"]=='') { echo "N/A"; } else { echo $profile_info["no_of_brothers"]; } ?></p>
													</div>
													<div class="row pb-3">
														<p class="col-md-4 attribute_name">No of Sisters:</p>
														<p class="col-md-8 attribute_value"><?php if($profile_info["no_of_sisters"]=='') { echo "N/A"; } else { echo $profile_info["no_of_sisters"]; } ?></p>
													</div>
													<hr /> </div>
												<div class="col-md-12 pt-4">
												<!--	<p class="profile_heading pb-4">Property Details<span class="edit_link">Edit</span></p> -->
													<div class="row pb-3">
														<p class="col-md-4 attribute_name">Property Type:</p>
														<p class="col-md-8 attribute_value"><?php if($profile_info["Property_type"]=='') { echo "N/A"; } else { echo $profile_info["Property_type"]; } ?></p>
													</div>
													<div class="row pb-3">
														<p class="col-md-4 attribute_name">Property Value:</p>
														<p class="col-md-8 attribute_value">
														<?php if($profile_info["property_value"]=='') { 
															echo "N/A"; 
															} else {
																echo $profile_info['property_value']." <span> Cr</span>" ;
																	}
															 ?></p>
													</div>
													<div class="row pb-3">
														<p class="col-md-4 attribute_name">Property Details:</p>
													<p class="col-md-8 attribute_value edit_link"><?php if($profile_info["Property_desc"]=='') { echo "N/A"; } else { echo $profile_info["Property_desc"]; } ?></p>
													</div>
													<hr /> </div>
												<div class="col-md-12 pt-4">
													<p class="profile_heading pb-4">Partner Preferences<!--<span class="edit_link">Edit</span>--></p>
													<div class="row pb-3">
														<p class="col-md-4 attribute_name">Age Gap:</p>
														<p class="col-md-8 attribute_value"><?php if($preference_details["p_age_from"]=='') { echo "N/A"; } else { echo $preference_details["p_age_from"]." to "; } ?>  <?php if($preference_details["p_age_to"]=='') { echo "N/A"; } else { echo $preference_details["p_age_to"]." Years"; } ?></p>
													</div>
													<div class="row pb-3">
														<p class="col-md-4 attribute_name">Height:</p>
														<p class="col-md-8 attribute_value"><?php if($preference_details["p_height_from"]=='') { echo "N/A"; } else { echo $preference_details["p_height_from"].'" Inches to '	; } ?>  <?php if($preference_details["p_height_to"]=='') { echo "N/A"; } else { echo $preference_details["p_height_to"].'" Inches'; } ?></p>
													</div>
													<div class="row pb-3">
														<p class="col-md-4 attribute_name">Marital Status:</p>
														<p class="col-md-8 attribute_value"><?php if($preference_details["p_marital_status"]=='') { echo "N/A"; } else { echo $preference_details["p_marital_status"]; } ?></p>
													</div>
											<!--		<div class="row pb-3">
														<p class="col-md-4 attribute_name">Open to second marriage:</p>
														<p class="col-md-8 attribute_value edit_link">Add</p>
													</div>  -->
													<hr /> </div>
												<div class="col-md-12 pt-4">
													<p class="profile_heading pb-4">Religion Preferences<!--<span class="edit_link">Edit</span>--></p>
													<div class="row pb-3">
														<p class="col-md-4 attribute_name">Mother Tongue:</p>
														<p class="col-md-8 attribute_value"><?php if($preference_details["p_mother_tongue"]=='') { echo "N/A"; } else { echo $preference_details["p_mother_tongue"]; } ?></p>
													</div>
													<div class="row pb-3">
														<p class="col-md-4 attribute_name">Religion:</p>
														<p class="col-md-8 attribute_value"><?php if($profile_info["religion"]=='') { echo "N/A"; } else { echo $profile_info["religion"]; } ?></p>
													</div> 
													<div class="row pb-3">
														<p class="col-md-4 attribute_name">Caste:</p>
														<p class="col-md-8 attribute_value"><?php if($preference_details["caste"]=='') { echo "N/A"; } else { echo $preference_details["caste"]; } ?></p>
													</div>
													<div class="row pb-3">
														<p class="col-md-4 attribute_name">Star:</p>
														<p class="col-md-8 attribute_value edit_link"><?php if($preference_details["p_star"]=='') { echo "N/A"; } else { echo $preference_details["p_star"]; } ?></p>
													</div>
												 
													<hr /> </div>
												<div class="col-md-12 pt-4">
													<p class="profile_heading pb-4">Partner Education &amp; Career <!--<span class="edit_link">Edit</span>--></p>
													<div class="row pb-3">
														<p class="col-md-4 attribute_name">Education Category:</p>
														<p class="col-md-8 attribute_value"><?php if($preference_details["p_education"]=='') { echo "N/A"; } else { echo $preference_details["p_education"]; } ?></p>
													</div>
													<div class="row pb-3">
														<p class="col-md-4 attribute_name">Employee In Group:</p>
														<p class="col-md-8 attribute_value"><?php if($preference_details["employee_in"]=='') { echo "N/A"; } else { echo $preference_details["employee_in"]; } ?></p>
													</div>
													<div class="row pb-3">
														<p class="col-md-4 attribute_name">Profession Group:</p>
														<p class="col-md-8 attribute_value"><?php if($preference_details["p_profession"]=='') { echo "N/A"; } else { echo $preference_details["p_profession"]; } ?></p>
													</div>
													<div class="row pb-3">
														<p class="col-md-4 attribute_name">Preferred Country:</p>
														<p class="col-md-8 attribute_value edit_link"><?php if($preference_details["p_country"]=='') { echo "N/A"; } else { echo $preference_details["p_country"]; } ?></p>
													</div>
													<div class="row pb-3">
														<p class="col-md-4 attribute_name">Preferred City:</p>
														<p class="col-md-8 attribute_value edit_link"><?php if($preference_details["p_city"]=='') { echo "N/A"; } else { echo $preference_details["p_city"]; } ?></p>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
								<!-- Tab 2 Manage Photos Start Here -->
								<div class="tab-pane fade" id="pills-profile" role="tabpanel" aria-labelledby="pills-profile-tab">
									<div class="search_section manage_photos">
										<h2 class="text-center pb-2">Manage Photos</h2>
										<div class="text-center">
										<form method="post" action="<?php echo site_url();?>register/upload/<?php echo $this->uri->segment(3);?>" enctype="multipart/form-data">
                        <div class="col-md-12">
                           <input type="file" class="form-control upload-input" id="images" name="images[]" onchange="preview_images();" multiple/>
                        </div>
                        <div class="col-md-12 ptb-20 ht-140" style="padding:10px;" id="image_preview"></div>
                         <input type="submit" class="btn btn-teal min-140 gradient_bg mt-4 mb-2" name='submit_image' value="Upload Images"/>
                       </form>
										</div>
									</div>
								</div>
								<!-- Tab 2 Manage Photos Ends Here -->
								<!-- Tab 3 Upgrade Membership Start Here -->
								<div class="tab-pane fade" id="pills-contact" role="tabpanel" aria-labelledby="pills-contact-tab">
									<div class="search_section">
										<div class="modal-body row">
											<div class="col-md-6 services_card upgrade_membership">
												<div class="row">
													<div class="services_card_top">
														<h2>Diamond Membership</h2> </div>
													<div class="services_card_content pb-3 pl-3 pr-3">
														<p>₹4,999 <span>/ 60 Days</span></p>
														<ul>
															<li>Express interest & View Upto 30 contacts</li>
															<li>Client Should Contact Relation Ship Manager </li>
															<li>Call Support For Any Clarifications</li>
															<li>60 days of validity</li>
														</ul>
														<button class="btn btn-teal min-140 gradient_bg" type="submit">Contact: +91-9177036777</button>
													</div>
												</div>
											</div>
											<div class="col-md-6 services_card upgrade_membership">
												<div class="row">
													<div class="services_card_top">
														<h2>Premium Service</h2> </div>
													<div class="services_card_content pb-3 pl-3 pr-3">
														<p>₹9,999 <span>/ 120 Days</span></p>
														<ul>
															<li>Assisted by separate RM</li>
															<li>Express interest & View Upto 45 contacts</li>
															<li>Call Support For Any Clarifications</li>								
															<li>Feed Back Will Be Updated For With In 10 Days</li>
														</ul>
														<button class="btn gradient_bg btn-teal min-140" type="submit">Contact: +91-9177036777</button>
													</div>
												</div>
											</div>
											<div class="col-md-6 services_card upgrade_membership">
												<div class="row">
													<div class="services_card_top">
														<h2>VIP & FAST TRACK</</h2> </div>
													<div class="services_card_content pb-3 pl-3 pr-3">
														<p>₹19,999 <span>/ 240 Days</span></p>
														<ul>
															<li>Express interest & View Upto 60 contacts</li>
															<li>Our Senior General Manager Will Take Responsibility In Dealing With Both Sides </li>
															<li>Call Support For Any Clarifications</li>
															<li>Feedback Will Be Updated With In Week</li>
															<li>240 days of validity</li>
														</ul>
														<button class="btn gradient_bg btn-teal min-140" type="submit">Contact: +91-9177036777</button>
													</div>
												</div>
											</div>
											<div class="col-md-6 services_card upgrade_membership">
												<div class="row">
													<div class="services_card_top">
														<h2>ELITE Membership</h2> </div>
													<div class="services_card_content pb-3 pl-3 pr-3">
														<p>₹49,999 <span>/ 1 Year</span></p>
														<ul>
															<li>Express interest & View Upto "90 contacts"</li>
															<li>Our Senior General Manager Will Take Responsibility In Dealing With Both Sides </li>
															<li>Call Support For Any Clarifications</li>
															<li>No Registration Required</li>
															<li>Feedback Will Be Updated Twice a Week</li>
														</ul>
														<button class="btn gradient_bg btn-teal min-140" type="submit">Contact: +91-9177036777</button>
													</div>
												</div>
											</div>
										</div>
									</div>
								</div>
								<!-- Tab 3 Upgrade Membership Ends Here -->
								<!-- Tab 3 Upgrade Membership Start Here -->
								<!-- Tab 4 Profile Setting Start Here -->
							<!--	<div class="tab-pane fade" id="pills-profile-setting" role="tabpanel" aria-labelledby="pills-profile-setting-tab">
									<div class="search_section pt-3">
										<div class="tab-nav col-md-12">
											<ul class="nav nav-pills mb-3" id="pills-tab" role="tablist">
												<li class="nav-item" role="presentation"> <a class="nav-link active" id="pills-edit-password" data-toggle="pill" href="#pills-password" role="tab" aria-controls="pills-password" aria-selected="true">Edit Password</a> </li>
												<li class="nav-item" role="presentation"> <a class="nav-link" id="pills-primary-contact" data-toggle="pill" href="#pills-primary" role="tab" aria-controls="pills-primary" aria-selected="false">Edit Primary Contact</a> </li>
												<li class="nav-item" role="presentation"> <a class="nav-link" id="pills-delete-profile" data-toggle="pill" href="#pills-delete" role="tab" aria-controls="pills-delete" aria-selected="false">Delete Profile</a> </li>
											</ul>
										</div>
										<div class="tab-content" id="pills-tabContent1">
											<div class="tab-pane fade show active" id="pills-password" role="tabpanel" aria-labelledby="pills-password-tab">
												<form class="col-md-10 edit_password_content pb-3 pt-2">
													<div class="row mb-3">
														<div class="col-md-6">
															<label class="col-md-12 text-right" for="">Mobile Number:</label>
														</div>
														<div class="col-md-6">
															<input class="form_control" name="mobile" placeholder=<?php if($profile_info["mobile"]!=''){ echo $profile_info["mobile"]; } else { echo "Enter Your Mobile Number"; } ?> type="number" readonly />
														</div>
													</div>
													<div class="row mb-3">
														<div class="col-md-6">
															<label class="col-md-12 text-right" for="">Enter New Password:</label>
														</div>
														<div class="col-md-6">
															<input class="form_control" min="6" minlength="6" name="new_password" placeholder="Enter new password" type="password" /> <span class="input-group-addon"><i class="fa fa-eye-slash" aria-hidden="true"></i></span> </div>
													</div>
													<div class="row">
														<div class="col-md-6">
															<label class="col-md-12 text-right" for="">Re enter New Password:</label>
														</div>
														<div class="col-md-6">
															<input class="form_control" min="6" minlength="6" name="confirm_password" placeholder="Re Enter password" type="password" /> <span class="input-group-addon"><i class="fa fa-eye-slash" aria-hidden="true"></i></span> </div>
													</div>
													<button class="btn btn-black m-2 btn-grad-orange edit_submit" id="password_update" type="submit">Update</button>
												</form>
											</div>
											<div class="tab-pane fade" id="pills-primary" role="tabpanel" aria-labelledby="pills-primary-tab">
												<div class="row pt-3 pb-3">
													<div class=" col-sm-12 col-xs-12 col-md-6 col-lg-6 col-xl-6 text-center">
														<div class="contactEditSection">
															<p class="px-3 pb-3" offset="0"> To Edit your primary EmailId, please enter your new email id and click <strong>"Send OTP"</strong> and verify your Email address .</p>
															<form class="text-center pt-2 text-left ka-editForm">
																<div>
																	<input class="form_control" placeholder="Enter new email address" type="email"> </div>
																<button class="btn btn-black m-2 btn-grad-orange edit_submit" type="submit">Submit</button>
															</form>
														</div>
													</div>
													<div class="col-sm-12 col-xs-12 col-md-6 col-lg-6 col-xl-6 text-center">
														<div class="contactEditSection">
															<p class="px-3 pb-3"> To Edit your primary mobile no, please enter your new mobile no and click <strong>"Send OTP"</strong> and verify your Mobile Number.</p>
															<div class="row pt-2">
																<select class="form_control col-4" style="border-radius: 6px 0 0 6px !important;">
																	<option value="1"> India(91) </option>
																	<option value="2"> USA(001) </option>
																	<option value="3"> UK(0044) </option>
																	<option value="4"> Canada(001) </option>
																	<option value="5"> Australia(0061) </option>
																	<option value="6"> Singapore(0065) </option>
																	<option value="7"> Saudi Arabia(0966) </option>
																	<option value="8"> South Africa(0027) </option>
																	<option value="9"> Kuwait(965) </option>
																	<option value="10"> Pakistan(92) </option>
																	<option value="11"> Afghanistan(93) </option>
																	<option value="12"> Albania(355) </option>
																	<option value="13"> Algeria(213) </option>
																	<option value="17"> Anguiila(126) </option>
																	<option value="18"> Antarctica(672) </option>
																	<option value="21"> Armenia(374) </option>
																	<option value="22"> Aruba(297) </option>
																	<option value="23"> Austria(43) </option>
																	<option value="24"> Azerbaijan(994) </option>
																	<option value="26"> Bahrain(973) </option>
																	<option value="27"> Bangladesh(880) </option>
																	<option value="30"> Belgium(32) </option>
																	<option value="37"> Botswana(267) </option>
																	<option value="39"> Brazil(55) </option>
																	<option value="40"> British Indian Ocean Territory(0) </option>
																	<option value="42"> Brunei(673) </option>
																	<option value="53"> China(86) </option>
																	<option value="58"> Congo(0) </option>
																	<option value="64"> Czech Republic(420) </option>
																	<option value="65"> Denmark(45) </option>
																	<option value="71"> Egypt(20) </option>
																	<option value="74"> Eritrea(291) </option>
																	<option value="76"> Ethiopia(251) </option>
																	<option value="80"> Finland(358) </option>
																	<option value="81"> France(33) </option>
																	<option value="88"> Germany(0049) </option>
																	<option value="89"> Ghana(233) </option>
																	<option value="93"> Grenada(147) </option>
																	<option value="103"> Hong Kong(852) </option>
																	<option value="104"> Hungary(36) </option>
																	<option value="105"> Iceland(354) </option>
																	<option value="106"> Indonesia(62) </option>
																	<option value="108"> Iraq(964) </option>
																	<option value="109"> Ireland(353) </option>
																	<option value="110"> Israel(972) </option>
																	<option value="111"> Italy(39) </option>
																	<option value="112"> Ivory Coast(225) </option>
																	<option value="113"> Jamaica(187) </option>
																	<option value="114"> Japan(81) </option>
																	<option value="115"> Jordan(962) </option>
																	<option value="116"> Kazakstan(7) </option>
																	<option value="117"> Kenya(254) </option>
																	<option value="119"> South Korea(82) </option>
																	<option value="120"> North Korea(0) </option>
																	<option value="124"> Lebanon(961) </option>
																	<option value="126"> Liberia(231) </option>
																	<option value="130"> Luxembourg(352) </option>
																	<option value="135"> Malaysia(60) </option>
																	<option value="136"> Maldives(960) </option>
																	<option value="137"> Mali(223) </option>
																	<option value="140"> Martinique(0) </option>
																	<option value="142"> Mauritius(230) </option>
																	<option value="144"> Mexico(52) </option>
																	<option value="155"> Nepal(977) </option>
																	<option value="156"> Netherlands(31) </option>
																	<option value="159"> New Zealand(64) </option>
																	<option value="162"> Nigeria(234) </option>
																	<option value="166"> Norway(47) </option>
																	<option value="167"> Oman(968) </option>
																	<option value="173"> Philippines(63) </option>
																	<option value="174"> Poland(48) </option>
																	<option value="176"> Puerto Rico(1) </option>
																	<option value="177"> Qatar(974) </option>
																	<option value="180"> Russia(7) </option>
																	<option value="189"> Senegal(221) </option>
																	<option value="195"> Spain(34) </option>
																	<option value="199"> Sudan(249) </option>
																	<option value="202"> Swaziland(268) </option>
																	<option value="203"> Sweden(46) </option>
																	<option value="204"> Switzerland (0041) </option>
																	<option value="206"> Taiwan(886) </option>
																	<option value="208"> Tanzania(255) </option>
																	<option value="209"> Thailand(66) </option>
																	<option value="215"> Turkey(90) </option>
																	<option value="219"> Uganda(256) </option>
																	<option value="220"> Ukraine(0) </option>
																	<option value="221"> United Arab Emirates(971) </option>
																	<option value="227"> Vietnam(84) </option>
																	<option value="234"> Zambia(260) </option>
																	<option value="237"> Not Given(00) </option>
																	<option value="238"> Other(00) </option>
																	<option value="239"> Srilanka(94) </option>
																	<option value="240"> West Indies(264) </option>
																	<option value="241"> Europe(0028) </option>
																	<option value="243"> WEST AFRICA(221) </option>
																	<option value="246"> Cambodia(855) </option>
																	<option value="247"> Seychelles(248) </option>
																</select>
																<input class="form_control col-8" placeholder="Enter mobile number" type="number" style="border-radius:0 6px 6px 0 !important;"> </div>
															<button class="btn btn-black m-2 btn-grad-orange edit_submit" type="submit">Submit</button>
														</div>
													</div>
												</div>
											</div>
											<div class="tab-pane fade" id="pills-delete" role="tabpanel" aria-labelledby="pills-delete-tab">
												<div class="col-md-12 pt-1 pb-3 edit_password_content">
													<textarea class="form_control text_control col-md-12 p-2" name="message" cols="10" rows="10" placeholder="Please enter you reason"></textarea>
													<button class="btn btn-black m-2 btn-grad-orange edit_submit" type="submit">Submit</button>
												</div>
											</div>
										</div>
									</div>
								</div>
								--><!-- Tab 5  Payment Statitics Start Here -->
								<div class="tab-pane fade" id="pills-payment" role="tabpanel" aria-labelledby="pills-payment-tab">
									<div class="search_section col-md-12 pt-3 pb-2">
										<h2 class="mb-4">Payment Statistics</h2>
										<div class="row pb-3">
											<p class="col-md-4 attribute_name">Membership Type:</p>
											<p class="col-md-8 attribute_value"><?php echo ucfirst($primary_info["ms_usertype"]); ?></p> <!--<a class="payment_upgrade btn btn-teal btn_gradiant" data-toggle="modal" data-target="#exampleModal">Upgrade Membership</a> --></div>
										<div class="row pb-3">
											<p class="col-md-4 attribute_name">Profile Created Date:</p>
											<p class="col-md-8 attribute_value"><?php echo date("d-M-Y", strtotime($payment_statistics["registered_on"])); ?></p>
										</div>
										<div class="row pb-3">
											<p class="col-md-4 attribute_name">Number of Login Counts:</p>
											<p class="col-md-8 attribute_value"><?php echo $payment_statistics["login_count"]; ?></p>
										</div>
										<div class="row pb-3">
											<p class="col-md-4 attribute_name">Last Login Date:</p>
											<p class="col-md-8 attribute_value"><?php echo date("d-M-Y H:i:s", strtotime($payment_statistics["login_date_time"])); ?></p>
										</div>
										<div class="row pb-3">
											<p class="col-md-4 attribute_name">Expiry Date:</p>
											<p class="col-md-8 attribute_value"><?php if($payment_details[0]["expiry_date"]){ echo date("d-M-Y", strtotime($payment_details[0]["expiry_date"]));} ?></p>
										</div>
										<div class="row pb-3">
											<p class="col-md-4 attribute_name">Express Interest Limit:</p>
											<p class="col-md-8 attribute_value">75</p>
										</div>
										<div class="row pb-3">
											<p class="col-md-4 attribute_name">Remaining Express Interest Limit:</p>
											<p class="col-md-8 attribute_value"><?php echo 75-count($payment_statistics["intrest"]); ?></p>
										</div>
										<div class="row pb-3">
											<p class="col-md-4 attribute_name">Payment Date:</p>
											<p class="col-md-8 attribute_value"><?php if($payment_statistics["paid_date"]!=''){ echo date("d-M-Y", strtotime($payment_statistics["paid_date"])); }else{echo "Not Paid";}?></p>
										</div>
									</div>
								</div>
								<!-- Tab 5 Payment Statitics Start Here -->
							</div>
							<div class="col-md-4 px-2">
								<div class="search_section">
									<div class="text-center">
										<p>Why are you waiting, Start searching
											<br> your life partner</p> <a class="btn btn-teal btn_gradiant" href="<?php echo site_url();?>/dashboard/search_partner" tabindex="0">Search Now</a> </div>
								</div>
							  <?php $this->load->view('viewed-profile',$data);?>	</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	<!-- Main Content Ends Here -->
		<!-- Edit Popup Start Here -->
	<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
		<div class="modal-dialog popup_main">
			<div class="modal-content popup_main_in">
				<div class="modal-header popup_header">
					<h2 class="modal-title" id="exampleModalLabel">Basic Information</h2>
					<button type="button" class="close close_btn" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
				</div>
				<div class="modal-body row">
					<div class="col-md-12 pt-1 pb-3 edit_password_content">
						<p class="pb-3 text-center">Enter the details to be added / modified, which will be reviewed and updated shortly.</p>
						<textarea class="form_control text_control col-md-12 p-2" name="message" cols="10" rows="10" placeholder="Please enter the text here"></textarea>
						<button class="btn btn-black m-2 btn-grad-orange edit_submit" type="submit">Submit</button>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- Edit Popup Ends Here -->
	<!-- Edit Popup One Start Here -->
	<div class="modal fade" id="exampleModal1" tabindex="-1" aria-labelledby="exampleModalLabel1" aria-hidden="true">
		<div class="modal-dialog popup_main">
			<div class="modal-content popup_main_in">
				<button type="button" class="close close_btn close_btn1 text-right" data-dismiss="modal" aria-label="Close"> <span aria-hidden="true">&times;</span> </button>
				<div class="modal-body row">
					<div class="col-md-12 pt-1 pb-3 edit_password_content">
						<form class="row row-10">
							<div class="col-12">
								<div class="row row-10">
									<div class="col flex-1 form-group">
										<label class="form-label">Country</label>
										<select class="form-control grey-bg selectpicker" title="Select" data-live-search="true">
											<option>India</option>
											<option>USA</option>
											<option>UK</option>
										</select>
									</div>
									<div class="col flex-1 form-group">
										<label class="form-label">State</label>
										<select class="form-control grey-bg selectpicker" title="Select" data-live-search="true">
											<option>Telangana</option>
											<option>Andra Pradesh</option>
											<option>Tamilnadu</option>
										</select>
									</div>
									<div class="col flex-1 form-group">
										<label class="form-label">City</label>
										<select class="form-control grey-bg selectpicker" title="Select" data-live-search="true">
											<option>Hyderabad</option>
											<option>Amaravathi</option>
											<option>Tirvendram</option>
										</select>
									</div>
								</div>
								<div class="row row-10">
									<div class="col flex-1 form-group">
										<label class="form-label">Country</label>
										<select class="form-control grey-bg selectpicker" title="Select" data-live-search="true">
											<option>India</option>
											<option>USA</option>
											<option>UK</option>
										</select>
									</div>
									<div class="col flex-1 form-group">
										<label class="form-label">State</label>
										<select class="form-control grey-bg selectpicker" title="Select" data-live-search="true">
											<option>Telangana</option>
											<option>Andra Pradesh</option>
											<option>Tamilnadu</option>
										</select>
									</div>
									<div class="col flex-1 form-group">
										<label class="form-label">City</label>
										<select class="form-control grey-bg selectpicker" title="Select" data-live-search="true">
											<option>Hyderabad</option>
											<option>Amaravathi</option>
											<option>Tirvendram</option>
										</select>
									</div>
								</div>
							</div>
						</form>
						<button class="btn btn-black m-2 btn-grad-orange edit_submit" type="submit">Submit</button>
					</div>
				</div>
			</div>
		</div>
	</div>
	<!-- Edit Popup One Ends Here -->
	
	 <script>
         function preview_images() 
         {
          var total_file=document.getElementById("images").files.length;
          for(var i=0;i<total_file;i++)
          {
           $('#image_preview').append("<div class='col-md-1'><img class='img-responsive ht-140 mb-20' src='"+URL.createObjectURL(event.target.files[i])+"'></div>");
          }
         }
      </script>
      <script>
         $('#add_more').click(function() {
              "use strict";
              $(this).before($("<div/>", {
                id: 'filediv'
              }).fadeIn('slow').append(
                $("<input/>", {
                  name: 'file[]',
                  type: 'file',
                  id: 'file',
                  multiple: 'multiple',
                  accept: 'image/*'
                })
              ));
            });
         
            $('#upload').click(function(e) {
              "use strict";
              e.preventDefault();
         
              if (window.filesToUpload.length === 0 || typeof window.filesToUpload === "undefined") {
                alert("No files are selected.");
                return false;
              }
         
            });
         
            deletePreview = function (ele, i) {
              "use strict";
              try {
                $(ele).parent().remove();
                window.filesToUpload.splice(i, 1);
              } catch (e) {
                console.log(e.message);
              }
            }
         
            $("#file").on('change', function() {
              "use strict";
         
              // create an empty array for the files to reside.
              window.filesToUpload = [];
         
              if (this.files.length >= 1) {
                $("[id^=previewImg]").remove();
                $.each(this.files, function(i, img) {
                  var reader = new FileReader(),
                    newElement = $("<div id='previewImg" + i + "' class='previewBox'><img /></div>"),
                    deleteBtn = $("<span class='delete' onClick='deletePreview(this, " + i + ")'>X</span>").prependTo(newElement),
                    preview = newElement.find("img");
         
                  reader.onloadend = function() {
                    preview.attr("src", reader.result);
                    preview.attr("alt", img.name);
                  };
         
                  try {
                    window.filesToUpload.push(document.getElementById("file").files[i]);
                  } catch (e) {
                    console.log(e.message);
                  }
         
                  if (img) {
                    reader.readAsDataURL(img);
                  } else {
                    preview.src = "";
                  }
         
                  newElement.appendTo("#filediv");
                });
              }
            });
         
      </script>
      <script>
         $(document).ready(function(){
         
         $("input").focusout(function(){
         
         var nameC = $(this).attr("data-Nclass");
         
         if($(this).val().length > 0)
          $(nameC).addClass("stayPlaceInput");
         else
          $(nameC).removeClass("stayPlaceInput");
         });
         
         });
      </script>