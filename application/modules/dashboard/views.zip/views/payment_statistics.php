<div class="main-dashboard container-fluid">
  <div class="">
   
    <div class="col-md-6 col-xs-12 search-result">

   <?Php print_r($payment_details); ?>
   
  </div>
 
</div>

</div>
	
